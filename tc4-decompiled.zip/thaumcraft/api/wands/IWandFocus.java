/*    */ package thaumcraft.api.wands;public interface IWandFocus { int getFocusColor();
/*    */   IIcon getFocusDepthLayerIcon();
/*    */   IIcon getOrnament();
/*    */   WandFocusAnimation getAnimation();
/*    */   AspectList getVisCost();
/*    */   boolean isVisCostPerTick();
/*    */   ItemStack onFocusRightClick(ItemStack paramItemStack, World paramWorld, EntityPlayer paramEntityPlayer, MovingObjectPosition paramMovingObjectPosition);
/*    */   void onUsingFocusTick(ItemStack paramItemStack, EntityPlayer paramEntityPlayer, int paramInt);
/*    */   void onPlayerStoppedUsingFocus(ItemStack paramItemStack, World paramWorld, EntityPlayer paramEntityPlayer, int paramInt);
/*    */   String getSortingHelper(ItemStack paramItemStack);
/*    */   boolean onFocusBlockStartBreak(ItemStack paramItemStack, int paramInt1, int paramInt2, int paramInt3, EntityPlayer paramEntityPlayer);
/*    */   boolean acceptsEnchant(int paramInt);
/*    */   
/* 14 */   public enum WandFocusAnimation { WAVE, CHARGE; }
/*    */    }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\wands\IWandFocus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */