/*     */ package thaumcraft.api.wands;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.EnumRarity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ 
/*     */ public class ItemFocusBasic
/*     */   extends Item {
/*     */   public IIcon icon;
/*     */   
/*     */   public ItemFocusBasic() {
/*  29 */     this.maxStackSize = 1;
/*  30 */     this.canRepair = false;
/*  31 */     setMaxDamage(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIconFromDamage(int par1) {
/*  39 */     return this.icon;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDamageable() {
/*  44 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer player, List<String> list, boolean par4) {
/*  49 */     AspectList al = getVisCost(stack);
/*  50 */     if (al != null && al.size() > 0) {
/*  51 */       list.add(StatCollector.translateToLocal(isVisCostPerTick(stack) ? "item.Focus.cost2" : "item.Focus.cost1"));
/*  52 */       for (Aspect aspect : al.getAspectsSorted()) {
/*  53 */         DecimalFormat myFormatter = new DecimalFormat("#####.##");
/*  54 */         String amount = myFormatter.format((al.getAmount(aspect) / 100.0F));
/*  55 */         list.add(" §" + aspect.getChatcolor() + aspect.getName() + "§r x " + amount);
/*     */       } 
/*     */     } 
/*  58 */     addFocusInformation(stack, player, list, par4);
/*     */   }
/*     */   
/*     */   public void addFocusInformation(ItemStack focusstack, EntityPlayer player, List<String> list, boolean par4) {
/*  62 */     LinkedHashMap<Short, Integer> map = new LinkedHashMap<Short, Integer>();
/*  63 */     for (short id : getAppliedUpgrades(focusstack)) {
/*  64 */       if (id >= 0) {
/*  65 */         int amt = 1;
/*  66 */         if (map.containsKey(Short.valueOf(id))) {
/*  67 */           amt = ((Integer)map.get(Short.valueOf(id))).intValue() + 1;
/*     */         }
/*  69 */         map.put(Short.valueOf(id), Integer.valueOf(amt));
/*     */       } 
/*     */     } 
/*  72 */     for (Short id : map.keySet()) {
/*  73 */       list.add(EnumChatFormatting.DARK_PURPLE + FocusUpgradeType.types[id.shortValue()].getLocalizedName() + ((((Integer)map.get(id)).intValue() > 1) ? (" " + StatCollector.translateToLocal("enchantment.level." + map.get(id))) : ""));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVisCostPerTick(ItemStack focusstack) {
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumRarity getRarity(ItemStack focusstack) {
/*  88 */     return EnumRarity.rare;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFocusColor(ItemStack focusstack) {
/*  95 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIcon getOrnament(ItemStack focusstack) {
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIcon getFocusDepthLayerIcon(ItemStack focusstack) {
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   public enum WandFocusAnimation {
/* 116 */     WAVE, CHARGE;
/*     */   }
/*     */   
/*     */   public WandFocusAnimation getAnimation(ItemStack focusstack) {
/* 120 */     return WandFocusAnimation.WAVE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSortingHelper(ItemStack focusstack) {
/* 127 */     String out = "";
/* 128 */     for (short id : getAppliedUpgrades(focusstack)) {
/* 129 */       out = out + id;
/*     */     }
/* 131 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AspectList getVisCost(ItemStack focusstack) {
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getActivationCooldown(ItemStack focusstack) {
/* 146 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxAreaSize(ItemStack focusstack) {
/* 153 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FocusUpgradeType[] getPossibleUpgradesByRank(ItemStack focusstack, int rank) {
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short[] getAppliedUpgrades(ItemStack focusstack) {
/* 167 */     short[] l = { -1, -1, -1, -1, -1 };
/* 168 */     NBTTagList nbttaglist = getFocusUpgradeTagList(focusstack);
/* 169 */     if (nbttaglist == null)
/*     */     {
/* 171 */       return l;
/*     */     }
/*     */ 
/*     */     
/* 175 */     for (int j = 0; j < nbttaglist.tagCount(); j++) {
/*     */       
/* 177 */       if (j >= 5)
/* 178 */         break;  l[j] = nbttaglist.getCompoundTagAt(j).getShort("id");
/*     */     } 
/*     */     
/* 181 */     return l;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean applyUpgrade(ItemStack focusstack, FocusUpgradeType type, int rank) {
/* 186 */     short[] upgrades = getAppliedUpgrades(focusstack);
/* 187 */     if (upgrades[rank - 1] != -1 || rank < 1 || rank > 5) {
/* 188 */       return false;
/*     */     }
/* 190 */     upgrades[rank - 1] = type.id;
/* 191 */     setFocusUpgradeTagList(focusstack, upgrades);
/* 192 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canApplyUpgrade(ItemStack focusstack, EntityPlayer player, FocusUpgradeType type, int rank) {
/* 201 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUpgradedWith(ItemStack focusstack, FocusUpgradeType focusUpgradetype) {
/* 208 */     return (getUpgradeLevel(focusstack, focusUpgradetype) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUpgradeLevel(ItemStack focusstack, FocusUpgradeType focusUpgradetype) {
/* 215 */     short[] list = getAppliedUpgrades(focusstack);
/* 216 */     int level = 0;
/* 217 */     for (short id : list) {
/* 218 */       if (id == focusUpgradetype.id)
/*     */       {
/* 220 */         level++;
/*     */       }
/*     */     } 
/* 223 */     return level;
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack onFocusRightClick(ItemStack wandstack, World world, EntityPlayer player, MovingObjectPosition movingobjectposition) {
/* 228 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUsingFocusTick(ItemStack wandstack, EntityPlayer player, int count) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void onPlayerStoppedUsingFocus(ItemStack wandstack, World world, EntityPlayer player, int count) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onFocusBlockStartBreak(ItemStack wandstack, int x, int y, int z, EntityPlayer player) {
/* 242 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NBTTagList getFocusUpgradeTagList(ItemStack focusstack) {
/* 250 */     return (focusstack.stackTagCompound == null) ? null : focusstack.stackTagCompound.getTagList("upgrade", 10);
/*     */   }
/*     */   
/*     */   private void setFocusUpgradeTagList(ItemStack focusstack, short[] upgrades) {
/* 254 */     if (!focusstack.hasTagCompound())
/* 255 */       focusstack.setTagCompound(new NBTTagCompound()); 
/* 256 */     NBTTagCompound nbttagcompound = focusstack.getTagCompound();
/* 257 */     NBTTagList tlist = new NBTTagList();
/* 258 */     nbttagcompound.setTag("upgrade", (NBTBase)tlist);
/* 259 */     for (short id : upgrades) {
/* 260 */       NBTTagCompound f = new NBTTagCompound();
/* 261 */       f.setShort("id", id);
/* 262 */       tlist.appendTag((NBTBase)f);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate(ItemStack stack, World world, Entity entity, int p_77663_4_, boolean p_77663_5_) {
/* 268 */     if (stack.stackTagCompound != null && stack.stackTagCompound.hasKey("ench")) {
/* 269 */       stack.stackTagCompound.removeTag("ench");
/*     */     }
/* 271 */     super.onUpdate(stack, world, entity, p_77663_4_, p_77663_5_);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\wands\ItemFocusBasic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */