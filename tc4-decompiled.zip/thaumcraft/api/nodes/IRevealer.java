package thaumcraft.api.nodes;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;

public interface IRevealer {
  boolean showNodes(ItemStack paramItemStack, EntityLivingBase paramEntityLivingBase);
}


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\nodes\IRevealer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */