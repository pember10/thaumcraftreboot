package thaumcraft.api.nodes;

import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.aspects.IAspectContainer;

public interface INode extends IAspectContainer {
  String getId();
  
  AspectList getAspectsBase();
  
  NodeType getNodeType();
  
  void setNodeType(NodeType paramNodeType);
  
  void setNodeModifier(NodeModifier paramNodeModifier);
  
  NodeModifier getNodeModifier();
  
  int getNodeVisBase(Aspect paramAspect);
  
  void setNodeVisBase(Aspect paramAspect, short paramShort);
}


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\nodes\INode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */