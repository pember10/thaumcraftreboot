/*     */ package thaumcraft.api.visnet;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import thaumcraft.api.TileThaumcraft;
/*     */ import thaumcraft.api.WorldCoordinates;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TileVisNode
/*     */   extends TileThaumcraft
/*     */ {
/*  20 */   WeakReference<TileVisNode> parent = null;
/*  21 */   ArrayList<WeakReference<TileVisNode>> children = new ArrayList<WeakReference<TileVisNode>>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WorldCoordinates getLocation() {
/*  27 */     return new WorldCoordinates((TileEntity)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getRange();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isSource();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int consumeVis(Aspect aspect, int vis) {
/*  47 */     if (VisNetHandler.isNodeValid(getParent())) {
/*  48 */       int out = ((TileVisNode)getParent().get()).consumeVis(aspect, vis);
/*  49 */       if (out > 0) {
/*  50 */         triggerConsumeEffect(aspect);
/*     */       }
/*  52 */       return out;
/*     */     } 
/*  54 */     return 0;
/*     */   }
/*     */   
/*     */   public void removeThisNode() {
/*  58 */     for (WeakReference<TileVisNode> n : getChildren()) {
/*  59 */       if (n != null && n.get() != null) {
/*  60 */         ((TileVisNode)n.get()).removeThisNode();
/*     */       }
/*     */     } 
/*     */     
/*  64 */     this.children = new ArrayList<WeakReference<TileVisNode>>();
/*  65 */     if (VisNetHandler.isNodeValid(getParent())) {
/*  66 */       ((TileVisNode)getParent().get()).nodeRefresh = true;
/*     */     }
/*  68 */     setParent((WeakReference<TileVisNode>)null);
/*  69 */     parentChanged();
/*     */     
/*  71 */     if (isSource()) {
/*  72 */       HashMap<WorldCoordinates, WeakReference<TileVisNode>> sourcelist = VisNetHandler.sources.get(Integer.valueOf(this.worldObj.provider.dimensionId));
/*  73 */       if (sourcelist == null) {
/*  74 */         sourcelist = new HashMap<WorldCoordinates, WeakReference<TileVisNode>>();
/*     */       }
/*  76 */       sourcelist.remove(getLocation());
/*  77 */       VisNetHandler.sources.put(Integer.valueOf(this.worldObj.provider.dimensionId), sourcelist);
/*     */     } 
/*     */     
/*  80 */     this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invalidate() {
/*  87 */     removeThisNode();
/*  88 */     super.invalidate();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void triggerConsumeEffect(Aspect aspect) {}
/*     */ 
/*     */   
/*     */   public WeakReference<TileVisNode> getParent() {
/*  97 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WeakReference<TileVisNode> getRootSource() {
/* 104 */     return VisNetHandler.isNodeValid(getParent()) ? ((TileVisNode)getParent().get()).getRootSource() : (isSource() ? new WeakReference<TileVisNode>(this) : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(WeakReference<TileVisNode> parent) {
/* 113 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<WeakReference<TileVisNode>> getChildren() {
/* 120 */     return this.children;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canUpdate() {
/* 125 */     return true;
/*     */   }
/*     */   
/* 128 */   protected int nodeCounter = 0;
/*     */   
/*     */   private boolean nodeRegged = false;
/*     */   
/*     */   public boolean nodeRefresh = false;
/*     */   
/*     */   public void updateEntity() {
/* 135 */     if (!this.worldObj.isRemote && (this.nodeCounter++ % 40 == 0 || this.nodeRefresh)) {
/*     */       
/* 137 */       if (!this.nodeRefresh && this.children.size() > 0) {
/* 138 */         for (WeakReference<TileVisNode> n : this.children) {
/* 139 */           if (n == null || n.get() == null || !VisNetHandler.canNodeBeSeen(this, n.get())) {
/* 140 */             this.nodeRefresh = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 147 */       if (this.nodeRefresh) {
/* 148 */         for (WeakReference<TileVisNode> n : this.children) {
/* 149 */           if (n.get() != null) {
/* 150 */             ((TileVisNode)n.get()).nodeRefresh = true;
/*     */           }
/*     */         } 
/* 153 */         this.children.clear();
/* 154 */         this.parent = null;
/*     */       } 
/*     */ 
/*     */       
/* 158 */       if (isSource() && !this.nodeRegged) {
/* 159 */         VisNetHandler.addSource(getWorldObj(), this);
/* 160 */         this.nodeRegged = true;
/*     */       }
/* 162 */       else if (!isSource() && !VisNetHandler.isNodeValid(getParent())) {
/* 163 */         setParent(VisNetHandler.addNode(getWorldObj(), this));
/* 164 */         this.nodeRefresh = true;
/*     */       } 
/*     */       
/* 167 */       if (this.nodeRefresh) {
/* 168 */         this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/* 169 */         parentChanged();
/*     */       } 
/* 171 */       this.nodeRefresh = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parentChanged() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getAttunement() {
/* 184 */     return -1;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\visnet\TileVisNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */