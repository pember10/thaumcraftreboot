package thaumcraft.api.aspects;

import net.minecraftforge.common.util.ForgeDirection;

public interface IEssentiaTransport {
  boolean isConnectable(ForgeDirection paramForgeDirection);
  
  boolean canInputFrom(ForgeDirection paramForgeDirection);
  
  boolean canOutputTo(ForgeDirection paramForgeDirection);
  
  void setSuction(Aspect paramAspect, int paramInt);
  
  Aspect getSuctionType(ForgeDirection paramForgeDirection);
  
  int getSuctionAmount(ForgeDirection paramForgeDirection);
  
  int takeEssentia(Aspect paramAspect, int paramInt, ForgeDirection paramForgeDirection);
  
  int addEssentia(Aspect paramAspect, int paramInt, ForgeDirection paramForgeDirection);
  
  Aspect getEssentiaType(ForgeDirection paramForgeDirection);
  
  int getEssentiaAmount(ForgeDirection paramForgeDirection);
  
  int getMinimumSuction();
  
  boolean renderExtendedTube();
}


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\aspects\IEssentiaTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */