/*    */ package thaumcraft.api;
/*    */ 
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.network.NetworkManager;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TileThaumcraft
/*    */   extends TileEntity
/*    */ {
/*    */   public void readFromNBT(NBTTagCompound nbttagcompound) {
/* 25 */     super.readFromNBT(nbttagcompound);
/* 26 */     readCustomNBT(nbttagcompound);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void readCustomNBT(NBTTagCompound nbttagcompound) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeToNBT(NBTTagCompound nbttagcompound) {
/* 37 */     super.writeToNBT(nbttagcompound);
/* 38 */     writeCustomNBT(nbttagcompound);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeCustomNBT(NBTTagCompound nbttagcompound) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public Packet getDescriptionPacket() {
/* 49 */     NBTTagCompound nbttagcompound = new NBTTagCompound();
/* 50 */     writeCustomNBT(nbttagcompound);
/* 51 */     return (Packet)new S35PacketUpdateTileEntity(this.xCoord, this.yCoord, this.zCoord, -999, nbttagcompound);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt) {
/* 56 */     super.onDataPacket(net, pkt);
/* 57 */     readCustomNBT(pkt.func_148857_g());
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\TileThaumcraft.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */