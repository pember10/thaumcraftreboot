package thaumcraft.api;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public interface IWarpingGear {
  int getWarp(ItemStack paramItemStack, EntityPlayer paramEntityPlayer);
}


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\IWarpingGear.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */