/*    */ package thaumcraft.api.research;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResearchCategoryList
/*    */ {
/*    */   public int minDisplayColumn;
/*    */   public int minDisplayRow;
/*    */   public int maxDisplayColumn;
/*    */   public int maxDisplayRow;
/*    */   public ResourceLocation icon;
/*    */   public ResourceLocation background;
/*    */   public Map<String, ResearchItem> research;
/*    */   
/*    */   public ResearchCategoryList(ResourceLocation icon, ResourceLocation background) {
/* 32 */     this.research = new HashMap<String, ResearchItem>();
/*    */     this.icon = icon;
/*    */     this.background = background;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\research\ResearchCategoryList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */