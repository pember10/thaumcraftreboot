package thaumcraft.api.crafting;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import thaumcraft.api.aspects.AspectList;

public interface IArcaneRecipe {
  boolean matches(IInventory paramIInventory, World paramWorld, EntityPlayer paramEntityPlayer);
  
  ItemStack getCraftingResult(IInventory paramIInventory);
  
  int getRecipeSize();
  
  ItemStack getRecipeOutput();
  
  AspectList getAspects();
  
  AspectList getAspects(IInventory paramIInventory);
  
  String getResearch();
}


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\crafting\IArcaneRecipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */