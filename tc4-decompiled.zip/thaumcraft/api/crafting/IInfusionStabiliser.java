package thaumcraft.api.crafting;

import net.minecraft.world.World;

public interface IInfusionStabiliser {
  boolean canStabaliseInfusion(World paramWorld, int paramInt1, int paramInt2, int paramInt3);
}


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\crafting\IInfusionStabiliser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */