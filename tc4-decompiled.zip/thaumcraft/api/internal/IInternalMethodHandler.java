package thaumcraft.api.internal;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;

public interface IInternalMethodHandler {
  void generateVisEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
  
  boolean isResearchComplete(String paramString1, String paramString2);
  
  ItemStack getStackInRowAndColumn(Object paramObject, int paramInt1, int paramInt2);
  
  AspectList getObjectAspects(ItemStack paramItemStack);
  
  AspectList getBonusObjectTags(ItemStack paramItemStack, AspectList paramAspectList);
  
  AspectList generateTags(Item paramItem, int paramInt);
  
  boolean consumeVisFromWand(ItemStack paramItemStack, EntityPlayer paramEntityPlayer, AspectList paramAspectList, boolean paramBoolean1, boolean paramBoolean2);
  
  boolean consumeVisFromWandCrafting(ItemStack paramItemStack, EntityPlayer paramEntityPlayer, AspectList paramAspectList, boolean paramBoolean);
  
  boolean consumeVisFromInventory(EntityPlayer paramEntityPlayer, AspectList paramAspectList);
  
  void addWarpToPlayer(EntityPlayer paramEntityPlayer, int paramInt, boolean paramBoolean);
  
  void addStickyWarpToPlayer(EntityPlayer paramEntityPlayer, int paramInt);
  
  boolean hasDiscoveredAspect(String paramString, Aspect paramAspect);
  
  AspectList getDiscoveredAspects(String paramString);
}


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\api\internal\IInternalMethodHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */