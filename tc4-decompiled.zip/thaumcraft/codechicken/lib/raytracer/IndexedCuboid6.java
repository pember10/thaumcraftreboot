/*    */ package thaumcraft.codechicken.lib.raytracer;
/*    */ 
/*    */ import thaumcraft.codechicken.lib.vec.Cuboid6;
/*    */ 
/*    */ public class IndexedCuboid6
/*    */   extends Cuboid6
/*    */ {
/*    */   public Object data;
/*    */   
/*    */   public IndexedCuboid6(Object data, Cuboid6 cuboid) {
/* 11 */     super(cuboid);
/* 12 */     this.data = data;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\codechicken\lib\raytracer\IndexedCuboid6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */