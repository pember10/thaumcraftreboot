/*    */ package thaumcraft.codechicken.lib.raytracer;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.MovingObjectPosition;
/*    */ import net.minecraft.util.Vec3;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtendedMOP
/*    */   extends MovingObjectPosition
/*    */   implements Comparable<ExtendedMOP>
/*    */ {
/*    */   public Object data;
/*    */   public double dist;
/*    */   
/*    */   public ExtendedMOP(Entity entity, Object data) {
/* 17 */     super(entity);
/* 18 */     setData(data);
/*    */   }
/*    */ 
/*    */   
/*    */   public ExtendedMOP(int x, int y, int z, int side, Vec3 hit, Object data) {
/* 23 */     super(x, y, z, side, hit);
/* 24 */     setData(data);
/*    */   }
/*    */ 
/*    */   
/*    */   public ExtendedMOP(MovingObjectPosition mop, Object data, double dist) {
/* 29 */     super(0, 0, 0, 0, mop.hitVec);
/* 30 */     this.typeOfHit = mop.typeOfHit;
/* 31 */     this.blockX = mop.blockX;
/* 32 */     this.blockY = mop.blockY;
/* 33 */     this.blockZ = mop.blockZ;
/* 34 */     this.sideHit = mop.sideHit;
/* 35 */     this.subHit = mop.subHit;
/* 36 */     setData(data);
/* 37 */     this.dist = dist;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setData(Object data) {
/* 42 */     if (data instanceof Integer)
/* 43 */       this.subHit = ((Integer)data).intValue(); 
/* 44 */     this.data = data;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> T getData(MovingObjectPosition mop) {
/* 50 */     if (mop instanceof ExtendedMOP) {
/* 51 */       return (T)((ExtendedMOP)mop).data;
/*    */     }
/* 53 */     return (T)Integer.valueOf(mop.subHit);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int compareTo(ExtendedMOP o) {
/* 59 */     return (this.dist == o.dist) ? 0 : ((this.dist < o.dist) ? -1 : 1);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\codechicken\lib\raytracer\ExtendedMOP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */