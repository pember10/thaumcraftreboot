/*    */ package thaumcraft.codechicken.lib.render.uv;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.MathContext;
/*    */ import java.math.RoundingMode;
/*    */ import thaumcraft.codechicken.lib.vec.ITransformation;
/*    */ 
/*    */ public class UVScale extends UVTransformation {
/*    */   double su;
/*    */   
/*    */   public UVScale(double scaleu, double scalev) {
/* 12 */     this.su = scaleu;
/* 13 */     this.sv = scalev;
/*    */   }
/*    */   double sv;
/*    */   public UVScale(double d) {
/* 17 */     this(d, d);
/*    */   }
/*    */ 
/*    */   
/*    */   public void apply(UV uv) {
/* 22 */     uv.u *= this.su;
/* 23 */     uv.v *= this.sv;
/*    */   }
/*    */ 
/*    */   
/*    */   public UVTransformation inverse() {
/* 28 */     return new UVScale(1.0D / this.su, 1.0D / this.sv);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 33 */     MathContext cont = new MathContext(4, RoundingMode.HALF_UP);
/* 34 */     return "UVScale(" + new BigDecimal(this.su, cont) + ", " + new BigDecimal(this.sv, cont) + ")";
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\codechicken\lib\rende\\uv\UVScale.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */