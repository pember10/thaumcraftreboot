/*    */ package thaumcraft.codechicken.lib.vec;
/*    */ 
/*    */ public class AxisCycle
/*    */ {
/*  5 */   public static Transformation[] cycles = new Transformation[] { new RedundantTransformation(), new VariableTransformation(new Matrix4(0.0D, 0.0D, 1.0D, 0.0D, 1.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D))
/*    */       {
/*    */         public void apply(Vector3 vec)
/*    */         {
/*  9 */           double d0 = vec.x, d1 = vec.y, d2 = vec.z;
/* 10 */           vec.x = d2; vec.y = d0; vec.z = d1;
/*    */         } public Transformation inverse() {
/* 12 */           return AxisCycle.cycles[2];
/*    */         }
/*    */       }, new VariableTransformation(new Matrix4(0.0D, 1.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 1.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D)) {
/*    */         public void apply(Vector3 vec) {
/* 16 */           double d0 = vec.x, d1 = vec.y, d2 = vec.z;
/* 17 */           vec.x = d1; vec.y = d2; vec.z = d0;
/*    */         } public Transformation inverse() {
/* 19 */           return AxisCycle.cycles[1];
/*    */         }
/*    */       } };
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\codechicken\lib\vec\AxisCycle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */