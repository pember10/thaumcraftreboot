/*    */ package thaumcraft.client.lib;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import thaumcraft.api.aspects.Aspect;
/*    */ import thaumcraft.common.config.Config;
/*    */ 
/*    */ public class PlayerNotifications {
/*    */   public static class Notification { public String text;
/*    */     public ResourceLocation image;
/*    */     
/*    */     public Notification(String text, ResourceLocation image, long expire, long created, int color) {
/* 13 */       this.text = text;
/* 14 */       this.image = image;
/* 15 */       this.expire = expire;
/* 16 */       this.created = created;
/* 17 */       this.color = color;
/*    */     }
/*    */     public long expire; public long created; public int color; }
/*    */   
/*    */   public static class AspectNotification { public Aspect aspect;
/*    */     public float startX;
/*    */     public float startY;
/*    */     public long expire;
/*    */     public long created;
/*    */     
/*    */     public AspectNotification(Aspect aspect, float startX, float startY, long created, long expire) {
/* 28 */       this.aspect = aspect;
/* 29 */       this.startX = startX;
/* 30 */       this.startY = startY;
/* 31 */       this.expire = expire;
/* 32 */       this.created = created;
/*    */     } }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public static ArrayList<Notification> notificationList = new ArrayList<Notification>();
/* 42 */   public static ArrayList<AspectNotification> aspectList = new ArrayList<AspectNotification>();
/*    */   
/*    */   public static void addNotification(String text) {
/* 45 */     addNotification(text, null, 16777215);
/*    */   }
/*    */   
/*    */   public static void addAspectNotification(Aspect aspect) {
/* 49 */     long time = System.nanoTime() / 1000000L + (Minecraft.getMinecraft()).theWorld.rand.nextInt(1000);
/* 50 */     float x = 0.4F + (Minecraft.getMinecraft()).theWorld.rand.nextFloat() * 0.2F;
/* 51 */     float y = 0.4F + (Minecraft.getMinecraft()).theWorld.rand.nextFloat() * 0.2F;
/* 52 */     aspectList.add(new AspectNotification(aspect, x, y, time, time + 1500L));
/*    */   }
/*    */ 
/*    */   
/*    */   public static void addNotification(String text, Aspect aspect) {
/* 57 */     addNotification(text, aspect.getImage(), aspect.getColor());
/*    */   }
/*    */   
/*    */   public static void addNotification(String text, ResourceLocation image) {
/* 61 */     addNotification(text, image, 16777215);
/*    */   }
/*    */   
/*    */   public static void addNotification(String text, ResourceLocation image, int color) {
/* 65 */     long time = System.nanoTime() / 1000000L;
/* 66 */     long timeBonus = (notificationList.size() == 0) ? (Config.notificationDelay / 2) : 0L;
/* 67 */     notificationList.add(new Notification(text, image, time + Config.notificationDelay + timeBonus, time + (Config.notificationDelay / 4), color));
/*    */   }
/*    */   
/*    */   public static ArrayList<Notification> getListAndUpdate(long time) {
/* 71 */     ArrayList<Notification> temp = new ArrayList<Notification>();
/* 72 */     boolean first = true;
/* 73 */     for (Notification li : notificationList) {
/* 74 */       if (li.expire >= time)
/* 75 */         if (!first) {
/* 76 */           temp.add(new Notification(li.text, li.image, time + Config.notificationDelay, li.created, li.color));
/*    */         } else {
/* 78 */           temp.add(li);
/*    */         }  
/* 80 */       first = false;
/*    */     } 
/* 82 */     notificationList = temp;
/* 83 */     return temp;
/*    */   }
/*    */   
/*    */   public static ArrayList<AspectNotification> getAspectListAndUpdate(long time) {
/* 87 */     ArrayList<AspectNotification> temp = new ArrayList<AspectNotification>();
/* 88 */     for (AspectNotification li : aspectList) {
/* 89 */       if (li.expire >= time) {
/* 90 */         temp.add(li);
/*    */       }
/*    */     } 
/* 93 */     aspectList = temp;
/* 94 */     return temp;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\lib\PlayerNotifications.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */