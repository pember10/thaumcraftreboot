/*     */ package thaumcraft.client.lib;
/*     */ 
/*     */ import com.google.common.collect.Maps;
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent;
/*     */ import cpw.mods.fml.common.registry.GameData;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.awt.Color;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.entity.RenderItem;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.client.shader.ShaderGroup;
/*     */ import net.minecraft.client.util.JsonException;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.input.Mouse;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.wands.ItemFocusBasic;
/*     */ import thaumcraft.client.fx.ParticleEngine;
/*     */ import thaumcraft.client.gui.GuiResearchPopup;
/*     */ import thaumcraft.client.gui.GuiResearchRecipe;
/*     */ import thaumcraft.client.gui.MappingThread;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.blocks.ItemJarFilled;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.items.wands.ItemWandCasting;
/*     */ import thaumcraft.common.items.wands.WandManager;
/*     */ import thaumcraft.common.items.wands.foci.ItemFocusTrade;
/*     */ import thaumcraft.common.lib.crafting.ThaumcraftCraftingManager;
/*     */ import thaumcraft.common.lib.events.EssentiaHandler;
/*     */ import thaumcraft.common.lib.research.ScanManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientTickEventsFML
/*     */ {
/*  68 */   public static GuiResearchPopup researchPopup = null;
/*  69 */   public int tickCount = 0;
/*     */   int prevWorld;
/*     */   boolean checkedDate = false;
/*  72 */   final ResourceLocation HUD = new ResourceLocation("thaumcraft", "textures/gui/hud.png");
/*  73 */   RenderItem ri = new RenderItem();
/*  74 */   DecimalFormat myFormatter = new DecimalFormat("#######.##");
/*  75 */   DecimalFormat myFormatter2 = new DecimalFormat("#######.#");
/*  76 */   HashMap<Integer, AspectList> oldvals = new HashMap<Integer, AspectList>();
/*  77 */   long nextsync = 0L;
/*     */   boolean startThread = false;
/*  79 */   public static int warpVignette = 0; private static final int SHADER_DESAT = 0; private static final int SHADER_BLUR = 1;
/*     */   private static final int SHADER_HUNGER = 2;
/*     */   private static final int SHADER_SUNSCORNED = 3;
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent
/*     */   public void playerTick(TickEvent.PlayerTickEvent event) {
/*  86 */     if (event.side == Side.SERVER)
/*  87 */       return;  if (event.phase == TickEvent.Phase.START) {
/*     */       
/*  89 */       if (!this.startThread && GuiResearchRecipe.cache.size() <= 0) {
/*  90 */         Map<String, Integer> idMappings = Maps.newHashMap();
/*  91 */         GameData.getBlockRegistry().serializeInto(idMappings);
/*  92 */         GameData.getItemRegistry().serializeInto(idMappings);
/*  93 */         Thread t = new Thread((Runnable)new MappingThread(idMappings));
/*  94 */         t.start();
/*  95 */         this.startThread = true;
/*     */       } 
/*     */       
/*  98 */       Minecraft mc = Minecraft.getMinecraft();
/*  99 */       if (event.player.getItemInUse() != null && event.player.getItemInUse().getItem() instanceof ItemWandCasting)
/*     */       {
/* 101 */         event.player.setItemInUse(event.player.inventory.getCurrentItem(), event.player.getItemInUseCount());
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 106 */         if (event.player.getEntityId() == mc.thePlayer.getEntityId()) {
/*     */           
/* 108 */           checkShaders(event, mc);
/*     */           
/* 110 */           if (warpVignette > 0) {
/* 111 */             warpVignette--;
/* 112 */             RenderEventHandler.targetBrightness = 0.0F;
/*     */           } else {
/* 114 */             RenderEventHandler.targetBrightness = 1.0F;
/*     */           } 
/*     */           
/* 117 */           if (RenderEventHandler.fogFiddled) {
/* 118 */             if (RenderEventHandler.fogDuration < 100) {
/* 119 */               RenderEventHandler.fogTarget = 0.1F * RenderEventHandler.fogDuration / 100.0F;
/* 120 */             } else if (RenderEventHandler.fogTarget < 0.1F) {
/* 121 */               RenderEventHandler.fogTarget += 0.001F;
/*     */             } 
/* 123 */             RenderEventHandler.fogDuration--;
/* 124 */             if (RenderEventHandler.fogDuration < 0) RenderEventHandler.fogFiddled = false; 
/*     */           } 
/*     */         } 
/* 127 */       } catch (Exception e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   ResourceLocation[] shader_resources = new ResourceLocation[] { new ResourceLocation("shaders/post/desaturatetc.json"), new ResourceLocation("shaders/post/blurtc.json"), new ResourceLocation("shaders/post/hunger.json"), new ResourceLocation("shaders/post/sunscorned.json") };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkShaders(TickEvent.PlayerTickEvent event, Minecraft mc) {
/* 143 */     if (event.player.isPotionActive(Config.potionDeathGazeID)) {
/* 144 */       warpVignette = 10;
/* 145 */       if (!RenderEventHandler.shaderGroups.containsKey(Integer.valueOf(0))) {
/*     */         try {
/* 147 */           setShader(new ShaderGroup(mc.getTextureManager(), mc.getResourceManager(), mc.getFramebuffer(), this.shader_resources[0]), 0);
/*     */         }
/* 149 */         catch (JsonException e) {}
/*     */       
/*     */       }
/*     */     }
/* 153 */     else if (RenderEventHandler.shaderGroups.containsKey(Integer.valueOf(0))) {
/* 154 */       deactivateShader(0);
/*     */     } 
/*     */ 
/*     */     
/* 158 */     if (event.player.isPotionActive(Config.potionBlurredID)) {
/* 159 */       if (!RenderEventHandler.shaderGroups.containsKey(Integer.valueOf(1))) {
/*     */         try {
/* 161 */           setShader(new ShaderGroup(mc.getTextureManager(), mc.getResourceManager(), mc.getFramebuffer(), this.shader_resources[1]), 1);
/*     */         }
/* 163 */         catch (JsonException e) {}
/*     */       
/*     */       }
/*     */     }
/* 167 */     else if (RenderEventHandler.shaderGroups.containsKey(Integer.valueOf(1))) {
/* 168 */       deactivateShader(1);
/*     */     } 
/*     */ 
/*     */     
/* 172 */     if (event.player.isPotionActive(Config.potionUnHungerID)) {
/* 173 */       if (!RenderEventHandler.shaderGroups.containsKey(Integer.valueOf(2))) {
/*     */         try {
/* 175 */           setShader(new ShaderGroup(mc.getTextureManager(), mc.getResourceManager(), mc.getFramebuffer(), this.shader_resources[2]), 2);
/*     */         }
/* 177 */         catch (JsonException e) {}
/*     */       
/*     */       }
/*     */     }
/* 181 */     else if (RenderEventHandler.shaderGroups.containsKey(Integer.valueOf(2))) {
/* 182 */       deactivateShader(2);
/*     */     } 
/*     */ 
/*     */     
/* 186 */     if (event.player.isPotionActive(Config.potionSunScornedID)) {
/* 187 */       if (!RenderEventHandler.shaderGroups.containsKey(Integer.valueOf(3))) {
/*     */         try {
/* 189 */           setShader(new ShaderGroup(mc.getTextureManager(), mc.getResourceManager(), mc.getFramebuffer(), this.shader_resources[3]), 3);
/*     */         }
/* 191 */         catch (JsonException e) {}
/*     */       
/*     */       }
/*     */     }
/* 195 */     else if (RenderEventHandler.shaderGroups.containsKey(Integer.valueOf(3))) {
/* 196 */       deactivateShader(3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void setShader(ShaderGroup target, int shaderId) {
/* 202 */     if (OpenGlHelper.shadersSupported) {
/*     */       
/* 204 */       Minecraft mc = Minecraft.getMinecraft();
/* 205 */       if (RenderEventHandler.shaderGroups.containsKey(Integer.valueOf(shaderId))) {
/*     */         
/* 207 */         ((ShaderGroup)RenderEventHandler.shaderGroups.get(Integer.valueOf(shaderId))).deleteShaderGroup();
/* 208 */         RenderEventHandler.shaderGroups.remove(Integer.valueOf(shaderId));
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 213 */         if (target == null) {
/* 214 */           deactivateShader(shaderId);
/*     */         } else {
/* 216 */           RenderEventHandler.resetShaders = true;
/* 217 */           RenderEventHandler.shaderGroups.put(Integer.valueOf(shaderId), target);
/*     */         }
/*     */       
/* 220 */       } catch (Exception ioexception) {
/*     */         
/* 222 */         RenderEventHandler.shaderGroups.remove(Integer.valueOf(shaderId));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void deactivateShader(int shaderId) {
/* 229 */     if (RenderEventHandler.shaderGroups.containsKey(Integer.valueOf(shaderId)))
/*     */     {
/* 231 */       ((ShaderGroup)RenderEventHandler.shaderGroups.get(Integer.valueOf(shaderId))).deleteShaderGroup();
/*     */     }
/*     */     
/* 234 */     RenderEventHandler.shaderGroups.remove(Integer.valueOf(shaderId));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent
/*     */   public void clientWorldTick(TickEvent.ClientTickEvent event) {
/* 242 */     if (event.side == Side.SERVER)
/* 243 */       return;  Minecraft mc = FMLClientHandler.instance().getClient();
/* 244 */     WorldClient worldClient = mc.theWorld;
/* 245 */     if (event.phase == TickEvent.Phase.START) {
/*     */       
/* 247 */       this.tickCount++;
/* 248 */       for (String fxk : (String[])EssentiaHandler.sourceFX.keySet().toArray((Object[])new String[0])) {
/* 249 */         EssentiaHandler.EssentiaSourceFX fx = (EssentiaHandler.EssentiaSourceFX)EssentiaHandler.sourceFX.get(fxk);
/* 250 */         if (fx.ticks <= 0) {
/* 251 */           EssentiaHandler.sourceFX.remove(fxk);
/* 252 */         } else if (worldClient != null) {
/* 253 */           int mod = 0;
/* 254 */           TileEntity tile = worldClient.getTileEntity(fx.start.posX, fx.start.posY, fx.start.posZ);
/* 255 */           if (tile != null && tile instanceof thaumcraft.common.tiles.TileInfusionMatrix) mod = -1;
/*     */           
/* 257 */           if (fx.ticks > 5) {
/* 258 */             Thaumcraft.proxy.essentiaTrailFx((World)worldClient, fx.end.posX, fx.end.posY, fx.end.posZ, fx.start.posX, fx.start.posY + mod, fx.start.posZ, this.tickCount, fx.color, 1.0F);
/*     */           }
/*     */           else {
/*     */             
/* 262 */             float scale = (fx.ticks * fx.ticks) / 25.0F;
/* 263 */             Thaumcraft.proxy.essentiaTrailFx((World)worldClient, fx.end.posX, fx.end.posY, fx.end.posZ, fx.start.posX, fx.start.posY + mod, fx.start.posZ, this.tickCount - 5 - fx.ticks, fx.color, scale);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 268 */           fx.ticks--;
/* 269 */           EssentiaHandler.sourceFX.put(fxk, fx);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 275 */     else if (mc.theWorld != null && !this.checkedDate) {
/* 276 */       this.checkedDate = true;
/* 277 */       Calendar calendar = mc.theWorld.getCurrentDate();
/* 278 */       if (calendar.get(2) + 1 == 10 && calendar.get(5) == 31) {
/* 279 */         Thaumcraft.isHalloween = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent
/*     */   public void renderTick(TickEvent.RenderTickEvent event) {
/*     */     // Byte code:
/*     */     //   0: invokestatic instance : ()Lcpw/mods/fml/client/FMLClientHandler;
/*     */     //   3: invokevirtual getClient : ()Lnet/minecraft/client/Minecraft;
/*     */     //   6: astore_2
/*     */     //   7: aload_2
/*     */     //   8: getfield theWorld : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   11: astore_3
/*     */     //   12: aload_1
/*     */     //   13: getfield phase : Lcpw/mods/fml/common/gameevent/TickEvent$Phase;
/*     */     //   16: getstatic cpw/mods/fml/common/gameevent/TickEvent$Phase.START : Lcpw/mods/fml/common/gameevent/TickEvent$Phase;
/*     */     //   19: if_acmpne -> 25
/*     */     //   22: goto -> 392
/*     */     //   25: invokestatic getMinecraft : ()Lnet/minecraft/client/Minecraft;
/*     */     //   28: getfield renderViewEntity : Lnet/minecraft/entity/EntityLivingBase;
/*     */     //   31: instanceof net/minecraft/entity/player/EntityPlayer
/*     */     //   34: ifeq -> 392
/*     */     //   37: invokestatic getMinecraft : ()Lnet/minecraft/client/Minecraft;
/*     */     //   40: getfield renderViewEntity : Lnet/minecraft/entity/EntityLivingBase;
/*     */     //   43: checkcast net/minecraft/entity/player/EntityPlayer
/*     */     //   46: astore #4
/*     */     //   48: invokestatic currentTimeMillis : ()J
/*     */     //   51: lstore #5
/*     */     //   53: getstatic thaumcraft/client/lib/ClientTickEventsFML.researchPopup : Lthaumcraft/client/gui/GuiResearchPopup;
/*     */     //   56: ifnonnull -> 70
/*     */     //   59: new thaumcraft/client/gui/GuiResearchPopup
/*     */     //   62: dup
/*     */     //   63: aload_2
/*     */     //   64: invokespecial <init> : (Lnet/minecraft/client/Minecraft;)V
/*     */     //   67: putstatic thaumcraft/client/lib/ClientTickEventsFML.researchPopup : Lthaumcraft/client/gui/GuiResearchPopup;
/*     */     //   70: getstatic thaumcraft/client/lib/ClientTickEventsFML.researchPopup : Lthaumcraft/client/gui/GuiResearchPopup;
/*     */     //   73: invokevirtual updateResearchWindow : ()V
/*     */     //   76: aload_2
/*     */     //   77: getfield currentScreen : Lnet/minecraft/client/gui/GuiScreen;
/*     */     //   80: astore #7
/*     */     //   82: aload #7
/*     */     //   84: instanceof net/minecraft/client/gui/inventory/GuiContainer
/*     */     //   87: ifeq -> 137
/*     */     //   90: aload #7
/*     */     //   92: pop
/*     */     //   93: invokestatic isShiftKeyDown : ()Z
/*     */     //   96: ifeq -> 105
/*     */     //   99: getstatic thaumcraft/common/config/Config.showTags : Z
/*     */     //   102: ifeq -> 120
/*     */     //   105: aload #7
/*     */     //   107: pop
/*     */     //   108: invokestatic isShiftKeyDown : ()Z
/*     */     //   111: ifne -> 137
/*     */     //   114: getstatic thaumcraft/common/config/Config.showTags : Z
/*     */     //   117: ifeq -> 137
/*     */     //   120: invokestatic isGrabbed : ()Z
/*     */     //   123: ifne -> 137
/*     */     //   126: aload_0
/*     */     //   127: aload #7
/*     */     //   129: checkcast net/minecraft/client/gui/inventory/GuiContainer
/*     */     //   132: aload #4
/*     */     //   134: invokevirtual renderAspectsInGui : (Lnet/minecraft/client/gui/inventory/GuiContainer;Lnet/minecraft/entity/player/EntityPlayer;)V
/*     */     //   137: aload #4
/*     */     //   139: ifnull -> 392
/*     */     //   142: aload_2
/*     */     //   143: getfield inGameHasFocus : Z
/*     */     //   146: ifeq -> 392
/*     */     //   149: aload_2
/*     */     //   150: pop
/*     */     //   151: invokestatic isGuiEnabled : ()Z
/*     */     //   154: ifeq -> 392
/*     */     //   157: aload #4
/*     */     //   159: getfield inventory : Lnet/minecraft/entity/player/InventoryPlayer;
/*     */     //   162: iconst_2
/*     */     //   163: invokevirtual armorItemInSlot : (I)Lnet/minecraft/item/ItemStack;
/*     */     //   166: ifnull -> 208
/*     */     //   169: aload #4
/*     */     //   171: getfield inventory : Lnet/minecraft/entity/player/InventoryPlayer;
/*     */     //   174: iconst_2
/*     */     //   175: invokevirtual armorItemInSlot : (I)Lnet/minecraft/item/ItemStack;
/*     */     //   178: invokevirtual getItem : ()Lnet/minecraft/item/Item;
/*     */     //   181: getstatic thaumcraft/common/config/ConfigItems.itemHoverHarness : Lnet/minecraft/item/Item;
/*     */     //   184: if_acmpne -> 208
/*     */     //   187: aload_0
/*     */     //   188: aload_1
/*     */     //   189: getfield renderTickTime : F
/*     */     //   192: aload #4
/*     */     //   194: lload #5
/*     */     //   196: aload #4
/*     */     //   198: getfield inventory : Lnet/minecraft/entity/player/InventoryPlayer;
/*     */     //   201: iconst_2
/*     */     //   202: invokevirtual armorItemInSlot : (I)Lnet/minecraft/item/ItemStack;
/*     */     //   205: invokevirtual renderHoverHUD : (FLnet/minecraft/entity/player/EntityPlayer;JLnet/minecraft/item/ItemStack;)V
/*     */     //   208: aload #4
/*     */     //   210: getfield capabilities : Lnet/minecraft/entity/player/PlayerCapabilities;
/*     */     //   213: getfield isCreativeMode : Z
/*     */     //   216: ifne -> 306
/*     */     //   219: getstatic thaumcraft/common/Thaumcraft.instance : Lthaumcraft/common/Thaumcraft;
/*     */     //   222: getfield runicEventHandler : Lthaumcraft/common/lib/events/EventHandlerRunic;
/*     */     //   225: getfield runicCharge : Ljava/util/HashMap;
/*     */     //   228: aload #4
/*     */     //   230: invokevirtual getEntityId : ()I
/*     */     //   233: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   236: invokevirtual containsKey : (Ljava/lang/Object;)Z
/*     */     //   239: ifeq -> 306
/*     */     //   242: getstatic thaumcraft/common/Thaumcraft.instance : Lthaumcraft/common/Thaumcraft;
/*     */     //   245: getfield runicEventHandler : Lthaumcraft/common/lib/events/EventHandlerRunic;
/*     */     //   248: getfield runicCharge : Ljava/util/HashMap;
/*     */     //   251: aload #4
/*     */     //   253: invokevirtual getEntityId : ()I
/*     */     //   256: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   259: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   262: checkcast java/lang/Integer
/*     */     //   265: invokevirtual intValue : ()I
/*     */     //   268: ifle -> 306
/*     */     //   271: getstatic thaumcraft/common/Thaumcraft.instance : Lthaumcraft/common/Thaumcraft;
/*     */     //   274: getfield runicEventHandler : Lthaumcraft/common/lib/events/EventHandlerRunic;
/*     */     //   277: getfield runicInfo : Ljava/util/HashMap;
/*     */     //   280: aload #4
/*     */     //   282: invokevirtual getEntityId : ()I
/*     */     //   285: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   288: invokevirtual containsKey : (Ljava/lang/Object;)Z
/*     */     //   291: ifeq -> 306
/*     */     //   294: aload_0
/*     */     //   295: aload_1
/*     */     //   296: getfield renderTickTime : F
/*     */     //   299: aload #4
/*     */     //   301: lload #5
/*     */     //   303: invokevirtual renderRunicArmorBar : (FLnet/minecraft/entity/player/EntityPlayer;J)V
/*     */     //   306: aload #4
/*     */     //   308: getfield inventory : Lnet/minecraft/entity/player/InventoryPlayer;
/*     */     //   311: invokevirtual getCurrentItem : ()Lnet/minecraft/item/ItemStack;
/*     */     //   314: ifnull -> 392
/*     */     //   317: aload #4
/*     */     //   319: getfield inventory : Lnet/minecraft/entity/player/InventoryPlayer;
/*     */     //   322: invokevirtual getCurrentItem : ()Lnet/minecraft/item/ItemStack;
/*     */     //   325: invokevirtual getItem : ()Lnet/minecraft/item/Item;
/*     */     //   328: instanceof thaumcraft/common/items/wands/ItemWandCasting
/*     */     //   331: ifeq -> 360
/*     */     //   334: aload_0
/*     */     //   335: aload_1
/*     */     //   336: getfield renderTickTime : F
/*     */     //   339: invokestatic valueOf : (F)Ljava/lang/Float;
/*     */     //   342: aload #4
/*     */     //   344: lload #5
/*     */     //   346: aload #4
/*     */     //   348: getfield inventory : Lnet/minecraft/entity/player/InventoryPlayer;
/*     */     //   351: invokevirtual getCurrentItem : ()Lnet/minecraft/item/ItemStack;
/*     */     //   354: invokespecial renderCastingWandHud : (Ljava/lang/Float;Lnet/minecraft/entity/player/EntityPlayer;JLnet/minecraft/item/ItemStack;)V
/*     */     //   357: goto -> 392
/*     */     //   360: aload #4
/*     */     //   362: getfield inventory : Lnet/minecraft/entity/player/InventoryPlayer;
/*     */     //   365: invokevirtual getCurrentItem : ()Lnet/minecraft/item/ItemStack;
/*     */     //   368: invokevirtual getItem : ()Lnet/minecraft/item/Item;
/*     */     //   371: instanceof thaumcraft/common/items/relics/ItemSanityChecker
/*     */     //   374: ifeq -> 392
/*     */     //   377: aload_0
/*     */     //   378: aload_1
/*     */     //   379: getfield renderTickTime : F
/*     */     //   382: invokestatic valueOf : (F)Ljava/lang/Float;
/*     */     //   385: aload #4
/*     */     //   387: lload #5
/*     */     //   389: invokespecial renderSanityHud : (Ljava/lang/Float;Lnet/minecraft/entity/player/EntityPlayer;J)V
/*     */     //   392: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #290	-> 0
/*     */     //   #291	-> 7
/*     */     //   #292	-> 12
/*     */     //   #295	-> 25
/*     */     //   #296	-> 37
/*     */     //   #297	-> 48
/*     */     //   #298	-> 53
/*     */     //   #299	-> 70
/*     */     //   #300	-> 76
/*     */     //   #302	-> 82
/*     */     //   #305	-> 126
/*     */     //   #308	-> 137
/*     */     //   #309	-> 157
/*     */     //   #311	-> 187
/*     */     //   #314	-> 208
/*     */     //   #318	-> 294
/*     */     //   #321	-> 306
/*     */     //   #322	-> 317
/*     */     //   #323	-> 334
/*     */     //   #325	-> 360
/*     */     //   #326	-> 377
/*     */     //   #332	-> 392
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   48	344	4	player	Lnet/minecraft/entity/player/EntityPlayer;
/*     */     //   53	339	5	time	J
/*     */     //   82	310	7	gui	Lnet/minecraft/client/gui/GuiScreen;
/*     */     //   0	393	0	this	Lthaumcraft/client/lib/ClientTickEventsFML;
/*     */     //   0	393	1	event	Lcpw/mods/fml/common/gameevent/TickEvent$RenderTickEvent;
/*     */     //   7	386	2	mc	Lnet/minecraft/client/Minecraft;
/*     */     //   12	381	3	world	Lnet/minecraft/world/World;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private void renderSanityHud(Float partialTicks, EntityPlayer player, long time) {
/* 339 */     Minecraft mc = Minecraft.getMinecraft();
/*     */     
/* 341 */     GL11.glPushMatrix();
/*     */     
/* 343 */     ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft(), mc.displayWidth, mc.displayHeight);
/* 344 */     GL11.glClear(256);
/* 345 */     GL11.glMatrixMode(5889);
/* 346 */     GL11.glLoadIdentity();
/* 347 */     GL11.glOrtho(0.0D, sr.getScaledWidth_double(), sr.getScaledHeight_double(), 0.0D, 1000.0D, 3000.0D);
/* 348 */     GL11.glMatrixMode(5888);
/* 349 */     GL11.glLoadIdentity();
/* 350 */     int k = sr.getScaledWidth();
/* 351 */     int l = sr.getScaledHeight();
/*     */     
/* 353 */     GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/* 354 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/* 356 */     GL11.glEnable(3042);
/* 357 */     GL11.glBlendFunc(770, 771);
/*     */     
/* 359 */     mc.renderEngine.bindTexture(this.HUD);
/*     */     
/* 361 */     GL11.glPushMatrix();
/* 362 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 363 */     UtilsFX.drawTexturedQuad(1, 1, 152, 0, 20, 76, -90.0D);
/* 364 */     GL11.glPopMatrix();
/*     */     
/* 366 */     float tw = Thaumcraft.proxy.getPlayerKnowledge().getWarpTotal(player.getCommandSenderName());
/* 367 */     int p = Thaumcraft.proxy.getPlayerKnowledge().getWarpPerm(player.getCommandSenderName());
/* 368 */     int s = Thaumcraft.proxy.getPlayerKnowledge().getWarpSticky(player.getCommandSenderName());
/* 369 */     int t = Thaumcraft.proxy.getPlayerKnowledge().getWarpTemp(player.getCommandSenderName());
/* 370 */     float mod = 1.0F;
/* 371 */     if (tw > 100.0F) {
/* 372 */       mod = 100.0F / tw;
/* 373 */       tw = 100.0F;
/*     */     } 
/* 375 */     int gap = (int)((100.0F - tw) / 100.0F * 48.0F);
/* 376 */     int wt = (int)(t / 100.0F * 48.0F * mod);
/* 377 */     int ws = (int)(s / 100.0F * 48.0F * mod);
/*     */     
/* 379 */     if (t > 0) {
/* 380 */       GL11.glPushMatrix();
/* 381 */       GL11.glColor4f(1.0F, 0.5F, 1.0F, 1.0F);
/* 382 */       UtilsFX.drawTexturedQuad(7, 21 + gap, 200, gap, 8, wt + gap, -90.0D);
/* 383 */       GL11.glPopMatrix();
/*     */     } 
/* 385 */     if (s > 0) {
/* 386 */       GL11.glPushMatrix();
/* 387 */       GL11.glColor4f(0.75F, 0.0F, 0.75F, 1.0F);
/* 388 */       UtilsFX.drawTexturedQuad(7, 21 + wt + gap, 200, wt + gap, 8, wt + ws + gap, -90.0D);
/* 389 */       GL11.glPopMatrix();
/*     */     } 
/* 391 */     if (p > 0) {
/* 392 */       GL11.glPushMatrix();
/* 393 */       GL11.glColor4f(0.5F, 0.0F, 0.5F, 1.0F);
/* 394 */       UtilsFX.drawTexturedQuad(7, 21 + wt + ws + gap, 200, wt + ws + gap, 8, 48, -90.0D);
/* 395 */       GL11.glPopMatrix();
/*     */     } 
/* 397 */     GL11.glPushMatrix();
/* 398 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 399 */     UtilsFX.drawTexturedQuad(1, 1, 176, 0, 20, 76, -90.0D);
/* 400 */     GL11.glPopMatrix();
/* 401 */     if (tw >= 100.0F) {
/* 402 */       GL11.glPushMatrix();
/* 403 */       UtilsFX.drawTexturedQuad(1, 1, 216, 0, 20, 16, -90.0D);
/* 404 */       GL11.glPopMatrix();
/*     */     } 
/* 406 */     GL11.glDisable(3042);
/*     */     
/* 408 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private void renderCastingWandHud(Float partialTicks, EntityPlayer player, long time, ItemStack wandstack) {
/* 418 */     Minecraft mc = Minecraft.getMinecraft();
/* 419 */     ItemWandCasting wand = (ItemWandCasting)wandstack.getItem();
/*     */     
/* 421 */     if (this.oldvals.get(Integer.valueOf(player.inventory.currentItem)) == null) {
/* 422 */       this.oldvals.put(Integer.valueOf(player.inventory.currentItem), wand.getAllVis(wandstack));
/*     */     }
/* 424 */     else if (this.nextsync <= time) {
/* 425 */       this.oldvals.put(Integer.valueOf(player.inventory.currentItem), wand.getAllVis(wandstack));
/* 426 */       this.nextsync = time + 1000L;
/*     */     } 
/*     */     
/* 429 */     GL11.glPushMatrix();
/*     */     
/* 431 */     ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft(), mc.displayWidth, mc.displayHeight);
/* 432 */     GL11.glClear(256);
/* 433 */     GL11.glMatrixMode(5889);
/* 434 */     GL11.glLoadIdentity();
/* 435 */     GL11.glOrtho(0.0D, sr.getScaledWidth_double(), sr.getScaledHeight_double(), 0.0D, 1000.0D, 3000.0D);
/* 436 */     GL11.glMatrixMode(5888);
/* 437 */     GL11.glLoadIdentity();
/* 438 */     int k = sr.getScaledWidth();
/* 439 */     int l = sr.getScaledHeight();
/*     */     
/* 441 */     int dailLocation = Config.dialBottom ? (l - 32) : 0;
/*     */     
/* 443 */     GL11.glTranslatef(0.0F, dailLocation, -2000.0F);
/* 444 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/* 446 */     GL11.glEnable(3042);
/* 447 */     GL11.glBlendFunc(770, 771);
/*     */     
/* 449 */     mc.renderEngine.bindTexture(this.HUD);
/*     */     
/* 451 */     GL11.glPushMatrix();
/* 452 */     GL11.glScaled(0.5D, 0.5D, 0.5D);
/* 453 */     UtilsFX.drawTexturedQuad(0, 0, 0, 0, 64, 64, -90.0D);
/* 454 */     GL11.glPopMatrix();
/*     */     
/* 456 */     GL11.glTranslatef(16.0F, 16.0F, 0.0F);
/*     */     
/* 458 */     int max = wand.getMaxVis(wandstack);
/* 459 */     ItemFocusBasic focus = wand.getFocus(wandstack);
/* 460 */     ItemStack focusStack = wand.getFocusItem(wandstack);
/* 461 */     int count = 0;
/*     */     
/* 463 */     AspectList aspects = wand.getAllVis(wandstack);
/* 464 */     for (Aspect aspect : aspects.getAspects()) {
/* 465 */       int amt = aspects.getAmount(aspect);
/* 466 */       GL11.glPushMatrix();
/* 467 */       if (!Config.dialBottom) GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F); 
/* 468 */       GL11.glRotatef((-15 + count * 24), 0.0F, 0.0F, 1.0F);
/* 469 */       GL11.glTranslatef(0.0F, -32.0F, 0.0F);
/* 470 */       GL11.glScaled(0.5D, 0.5D, 0.5D);
/*     */       
/* 472 */       int loc = (int)(30.0F * amt / max);
/*     */       
/* 474 */       GL11.glPushMatrix();
/* 475 */       Color ac = new Color(aspect.getColor());
/* 476 */       GL11.glColor4f(ac.getRed() / 255.0F, ac.getGreen() / 255.0F, ac.getBlue() / 255.0F, 0.8F);
/* 477 */       UtilsFX.drawTexturedQuad(-4, 35 - loc, 104, 0, 8, loc, -90.0D);
/* 478 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 479 */       GL11.glPopMatrix();
/*     */       
/* 481 */       GL11.glPushMatrix();
/* 482 */       UtilsFX.drawTexturedQuad(-8, -3, 72, 0, 16, 42, -90.0D);
/* 483 */       GL11.glPopMatrix();
/* 484 */       int sh = 0;
/* 485 */       if (focus != null && focus.getVisCost(focusStack).getAmount(aspect) > 0) {
/* 486 */         GL11.glPushMatrix();
/* 487 */         UtilsFX.drawTexturedQuad(-4, -8, 136, 0, 8, 8, -90.0D);
/* 488 */         sh = 8;
/* 489 */         GL11.glPopMatrix();
/*     */       } 
/*     */       
/* 492 */       if (((AspectList)this.oldvals.get(Integer.valueOf(player.inventory.currentItem))).getAmount(aspect) > amt) {
/* 493 */         GL11.glPushMatrix();
/* 494 */         UtilsFX.drawTexturedQuad(-4, -8 - sh, 128, 0, 8, 8, -90.0D);
/* 495 */         GL11.glPopMatrix();
/*     */       }
/* 497 */       else if (((AspectList)this.oldvals.get(Integer.valueOf(player.inventory.currentItem))).getAmount(aspect) < amt) {
/* 498 */         GL11.glPushMatrix();
/* 499 */         UtilsFX.drawTexturedQuad(-4, -8 - sh, 120, 0, 8, 8, -90.0D);
/* 500 */         GL11.glPopMatrix();
/*     */       } 
/*     */       
/* 503 */       if (player.isSneaking()) {
/* 504 */         GL11.glPushMatrix();
/* 505 */         GL11.glRotatef(-90.0F, 0.0F, 0.0F, 1.0F);
/* 506 */         String msg = (amt / 100) + "";
/* 507 */         mc.ingameGUI.drawString(mc.fontRenderer, msg, -32, -4, 16777215);
/* 508 */         GL11.glPopMatrix();
/*     */         
/* 510 */         if (focus != null && focus.getVisCost(focusStack).getAmount(aspect) > 0) {
/* 511 */           float mod = wand.getConsumptionModifier(wandstack, player, aspect, false);
/* 512 */           GL11.glPushMatrix();
/* 513 */           GL11.glRotatef(-90.0F, 0.0F, 0.0F, 1.0F);
/* 514 */           msg = this.myFormatter.format((focus.getVisCost(focusStack).getAmount(aspect) * mod / 100.0F));
/* 515 */           mc.ingameGUI.drawString(mc.fontRenderer, msg, 8, -4, 16777215);
/* 516 */           GL11.glPopMatrix();
/*     */         } 
/*     */         
/* 519 */         mc.renderEngine.bindTexture(this.HUD);
/*     */       } 
/*     */       
/* 522 */       GL11.glPopMatrix();
/* 523 */       count++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 528 */     if (focus != null) {
/* 529 */       ItemStack picked = null;
/* 530 */       if (focus instanceof ItemFocusTrade) {
/* 531 */         ItemFocusTrade wt = (ItemFocusTrade)focus;
/* 532 */         picked = wt.getPickedBlock(player.inventory.getCurrentItem());
/* 533 */         if (picked != null) {
/* 534 */           renderWandTradeHud(partialTicks.floatValue(), player, time, picked);
/*     */         }
/*     */       } 
/* 537 */       if (picked == null) {
/* 538 */         GL11.glPushMatrix();
/* 539 */         GL11.glTranslatef(-24.0F, -24.0F, 90.0F);
/* 540 */         GL11.glEnable(2896);
/* 541 */         this.ri.renderItemAndEffectIntoGUI(mc.fontRenderer, mc.renderEngine, wand.getFocusItem(wandstack), 16, 16);
/* 542 */         GL11.glDisable(2896);
/* 543 */         GL11.glPopMatrix();
/* 544 */         float f = WandManager.getCooldown((EntityLivingBase)player);
/* 545 */         if (f > 0.0F) {
/* 546 */           GL11.glPushMatrix();
/* 547 */           GL11.glTranslatef(0.0F, 0.0F, 150.0F);
/* 548 */           GL11.glScaled(0.5D, 0.5D, 0.5D);
/* 549 */           String secs = this.myFormatter2.format(f) + "s";
/* 550 */           int w = mc.fontRenderer.getStringWidth(secs) / 2;
/* 551 */           mc.ingameGUI.drawString(mc.fontRenderer, secs, -w, -4, 16777215);
/* 552 */           GL11.glPopMatrix();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 558 */     GL11.glDisable(3042);
/*     */     
/* 560 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void renderRunicArmorBar(float partialTicks, EntityPlayer player, long time) {
/* 569 */     Minecraft mc = Minecraft.getMinecraft();
/* 570 */     float total = ((Integer[])Thaumcraft.instance.runicEventHandler.runicInfo.get(Integer.valueOf(player.getEntityId())))[0].intValue();
/* 571 */     float current = ((Integer)Thaumcraft.instance.runicEventHandler.runicCharge.get(Integer.valueOf(player.getEntityId()))).intValue();
/*     */     
/* 573 */     GL11.glPushMatrix();
/*     */     
/* 575 */     ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft(), mc.displayWidth, mc.displayHeight);
/* 576 */     GL11.glClear(256);
/* 577 */     GL11.glMatrixMode(5889);
/* 578 */     GL11.glLoadIdentity();
/* 579 */     GL11.glOrtho(0.0D, sr.getScaledWidth_double(), sr.getScaledHeight_double(), 0.0D, 1000.0D, 3000.0D);
/* 580 */     GL11.glMatrixMode(5888);
/* 581 */     GL11.glLoadIdentity();
/* 582 */     GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/*     */     
/* 584 */     GL11.glDisable(2929);
/* 585 */     GL11.glDepthMask(false);
/* 586 */     GL11.glEnable(3042);
/* 587 */     GL11.glBlendFunc(770, 771);
/* 588 */     GL11.glDisable(3008);
/*     */     
/* 590 */     int k = sr.getScaledWidth();
/* 591 */     int l = sr.getScaledHeight();
/*     */     
/* 593 */     GL11.glTranslatef((k / 2 - 91), (l - 39), 0.0F);
/*     */     
/* 595 */     mc.renderEngine.bindTexture(ParticleEngine.particleTexture);
/*     */     
/* 597 */     float fill = current / total;
/*     */     
/* 599 */     for (int a = 0; a < fill * 10.0F; a++) {
/* 600 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 601 */       UtilsFX.drawTexturedQuad(a * 8, 0, 160, 16, 9, 9, -90.0D);
/* 602 */       GL11.glPushMatrix();
/* 603 */       GL11.glScaled(0.5D, 0.5D, 0.5D);
/* 604 */       GL11.glColor4f(1.0F, 0.75F, 0.24F, MathHelper.sin(player.ticksExisted / 4.0F + a) * 0.4F + 0.6F);
/* 605 */       UtilsFX.drawTexturedQuad(a * 16, 0, a * 16, 96, 16, 16, -90.0D);
/* 606 */       GL11.glPopMatrix();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 611 */     GL11.glDepthMask(true);
/* 612 */     GL11.glEnable(2929);
/* 613 */     GL11.glEnable(3008);
/* 614 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */ 
/*     */     
/* 617 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void renderHoverHUD(float partialTicks, EntityPlayer player, long time, ItemStack armor) {
/* 624 */     Minecraft mc = Minecraft.getMinecraft();
/* 625 */     GL11.glPushMatrix();
/*     */     
/* 627 */     ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft(), mc.displayWidth, mc.displayHeight);
/* 628 */     GL11.glClear(256);
/* 629 */     GL11.glMatrixMode(5889);
/* 630 */     GL11.glLoadIdentity();
/* 631 */     GL11.glOrtho(0.0D, sr.getScaledWidth_double(), sr.getScaledHeight_double(), 0.0D, 1000.0D, 3000.0D);
/* 632 */     GL11.glMatrixMode(5888);
/* 633 */     GL11.glLoadIdentity();
/* 634 */     GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/*     */ 
/*     */     
/* 637 */     GL11.glDisable(2929);
/* 638 */     GL11.glDepthMask(false);
/* 639 */     GL11.glEnable(3042);
/* 640 */     GL11.glBlendFunc(770, 771);
/* 641 */     GL11.glDisable(3008);
/*     */     
/* 643 */     int k = sr.getScaledWidth();
/* 644 */     int l = sr.getScaledHeight();
/*     */     
/* 646 */     int fuel = 0;
/* 647 */     if (armor.hasTagCompound() && armor.stackTagCompound.hasKey("jar")) {
/* 648 */       ItemStack jar = ItemStack.loadItemStackFromNBT(armor.stackTagCompound.getCompoundTag("jar"));
/* 649 */       if (jar != null && jar.getItem() instanceof ItemJarFilled && jar.hasTagCompound()) {
/* 650 */         AspectList aspects = ((ItemJarFilled)jar.getItem()).getAspects(jar);
/* 651 */         if (aspects != null && aspects.size() > 0) {
/* 652 */           fuel = (short)aspects.getAmount(Aspect.ENERGY);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 658 */     int level = Math.round(fuel / 64.0F * 48.0F);
/*     */ 
/*     */     
/* 661 */     mc.renderEngine.bindTexture(ParticleEngine.particleTexture);
/* 662 */     GL11.glColor4f(0.0F, 1.0F, 0.75F, 1.0F);
/* 663 */     UtilsFX.drawTexturedQuad(6, l / 2 + 24 - level, 224, 48 - level, 8, level, -91.0D);
/* 664 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 665 */     UtilsFX.drawTexturedQuad(5, l / 2 - 28, 240, 0, 10, 56, -90.0D);
/*     */     
/* 667 */     if (armor.hasTagCompound() && armor.stackTagCompound.hasKey("hover") && armor.stackTagCompound.getByte("hover") == 1) {
/*     */       
/* 669 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.66F);
/* 670 */       UtilsFX.drawTexturedQuad(2, l / 2 - 43, 16 * (int)(Minecraft.getSystemTime() % 700L) / 50, 32, 16, 16, -90.0D);
/*     */       
/* 672 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */     
/*     */     try {
/* 676 */       ResourceLocation resourcelocation = mc.renderEngine.getResourceLocation(armor.getItemSpriteNumber());
/* 677 */       mc.renderEngine.bindTexture(resourcelocation);
/* 678 */       Object object = armor.getIconIndex();
/* 679 */       if (object == null)
/*     */       {
/* 681 */         object = ((TextureMap)Minecraft.getMinecraft().getTextureManager().getTexture(resourcelocation)).getAtlasSprite("missingno");
/*     */       }
/*     */       
/* 684 */       int i1 = armor.getItem().getColorFromItemStack(armor, 0);
/* 685 */       float f2 = (i1 >> 16 & 0xFF) / 255.0F;
/* 686 */       float f = (i1 >> 8 & 0xFF) / 255.0F;
/* 687 */       float f1 = (i1 & 0xFF) / 255.0F;
/*     */       
/* 689 */       GL11.glColor4f(f2, f, f1, 1.0F);
/*     */       
/* 691 */       this.ri.renderIcon(2, l / 2 - 43, (IIcon)object, 16, 16);
/* 692 */     } catch (Exception e) {}
/*     */ 
/*     */ 
/*     */     
/* 696 */     GL11.glDepthMask(true);
/* 697 */     GL11.glEnable(2929);
/* 698 */     GL11.glEnable(3008);
/* 699 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */ 
/*     */     
/* 702 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/* 706 */   ItemStack lastItem = null;
/* 707 */   int lastCount = 0;
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void renderWandTradeHud(float partialTicks, EntityPlayer player, long time, ItemStack picked) {
/* 712 */     Minecraft mc = Minecraft.getMinecraft();
/* 713 */     int amount = this.lastCount;
/* 714 */     if (player.inventory.inventoryChanged || !picked.isItemEqual(this.lastItem)) {
/* 715 */       amount = 0;
/* 716 */       for (ItemStack is : player.inventory.mainInventory) {
/* 717 */         if (is != null && is.isItemEqual(picked)) {
/* 718 */           amount += is.stackSize;
/*     */         }
/*     */       } 
/* 721 */       this.lastItem = picked;
/* 722 */       player.inventory.inventoryChanged = false;
/*     */     } 
/* 724 */     this.lastCount = amount;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 737 */     GL11.glPushMatrix();
/* 738 */     RenderHelper.enableGUIStandardItemLighting();
/* 739 */     GL11.glDisable(2896);
/* 740 */     GL11.glEnable(32826);
/* 741 */     GL11.glEnable(2903);
/* 742 */     GL11.glEnable(2896);
/*     */     try {
/* 744 */       this.ri.renderItemAndEffectIntoGUI(mc.fontRenderer, mc.renderEngine, picked, -8, -8);
/* 745 */     } catch (Exception e) {}
/* 746 */     GL11.glDisable(2896);
/*     */     
/* 748 */     GL11.glPushMatrix();
/* 749 */     String am = "" + amount;
/* 750 */     int sw = mc.fontRenderer.getStringWidth(am);
/* 751 */     GL11.glTranslatef(0.0F, -mc.fontRenderer.FONT_HEIGHT, 500.0F);
/* 752 */     GL11.glScalef(0.5F, 0.5F, 0.5F);
/* 753 */     for (int a = -1; a <= 1; ) { for (int b = -1; b <= 1; b++)
/* 754 */       { if ((a == 0 || b == 0) && (a != 0 || b != 0))
/* 755 */           mc.fontRenderer.drawString(am, a + 16 - sw, b + 24, 0);  }  a++; }
/* 756 */      mc.fontRenderer.drawString(am, 16 - sw, 24, 16777215);
/* 757 */     GL11.glPopMatrix();
/*     */     
/* 759 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderAspectsInGui(GuiContainer gui, EntityPlayer player) {
/* 764 */     Minecraft mc = FMLClientHandler.instance().getClient();
/* 765 */     ScaledResolution var13 = new ScaledResolution(Minecraft.getMinecraft(), mc.displayWidth, mc.displayHeight);
/* 766 */     int var14 = var13.getScaledWidth();
/* 767 */     int var15 = var13.getScaledHeight();
/* 768 */     int var16 = Mouse.getX() * var14 / mc.displayWidth;
/* 769 */     int var17 = var15 - Mouse.getY() * var15 / mc.displayHeight - 1;
/*     */ 
/*     */     
/* 772 */     GL11.glPushMatrix();
/*     */ 
/*     */     
/* 775 */     GL11.glPushAttrib(1048575);
/*     */ 
/*     */ 
/*     */     
/* 779 */     GL11.glDisable(2896);
/* 780 */     for (int var20 = 0; var20 < gui.inventorySlots.inventorySlots.size(); var20++) {
/*     */ 
/*     */       
/* 783 */       int xs = UtilsFX.getGuiXSize(gui);
/* 784 */       int ys = UtilsFX.getGuiYSize(gui);
/* 785 */       int shift = 0;
/* 786 */       int shift2 = 0;
/* 787 */       int shiftx = -8;
/* 788 */       int shifty = -8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 795 */       if (Thaumcraft.instance.aspectShift) {
/* 796 */         shiftx -= 8;
/* 797 */         shifty -= 8;
/*     */       } 
/* 799 */       Slot var23 = gui.inventorySlots.inventorySlots.get(var20);
/* 800 */       int guiLeft = shift + (gui.width - xs - shift2) / 2;
/* 801 */       int guiTop = (gui.height - ys) / 2;
/* 802 */       if (isMouseOverSlot(var23, var16, var17, guiLeft, guiTop))
/*     */       {
/* 804 */         if (var23.getStack() != null) {
/*     */           
/* 806 */           int h = ScanManager.generateItemHash(var23.getStack().getItem(), var23.getStack().getItemDamage());
/*     */           
/* 808 */           List<String> list = (List<String>)Thaumcraft.proxy.getScannedObjects().get(player.getCommandSenderName());
/* 809 */           if (list != null && (list.contains("@" + h) || list.contains("#" + h))) {
/*     */             
/* 811 */             AspectList tags = ThaumcraftCraftingManager.getObjectTags(var23.getStack());
/* 812 */             tags = ThaumcraftCraftingManager.getBonusTags(var23.getStack(), tags);
/*     */             
/* 814 */             if (tags != null) {
/*     */               
/* 816 */               int x = var16 + 17;
/* 817 */               int y = var17 + 7 - 33;
/* 818 */               GL11.glDisable(2929);
/*     */               
/* 820 */               int index = 0;
/* 821 */               if (tags.size() > 0)
/* 822 */                 for (Aspect tag : tags.getAspectsSortedAmount()) {
/* 823 */                   if (tag != null) {
/* 824 */                     x = var16 + 17 + index * 18;
/* 825 */                     y = var17 + 7 - 33;
/*     */                     
/* 827 */                     UtilsFX.bindTexture("textures/aspects/_back.png");
/* 828 */                     GL11.glPushMatrix();
/* 829 */                     GL11.glEnable(3042);
/* 830 */                     GL11.glBlendFunc(770, 771);
/* 831 */                     GL11.glTranslated((x + shiftx - 2), (y + shifty - 2), 0.0D);
/* 832 */                     GL11.glScaled(1.25D, 1.25D, 0.0D);
/* 833 */                     UtilsFX.drawTexturedQuadFull(0, 0, UtilsFX.getGuiZLevel((Gui)gui));
/* 834 */                     GL11.glDisable(3042);
/* 835 */                     GL11.glPopMatrix();
/*     */                     
/* 837 */                     if (Thaumcraft.proxy.playerKnowledge.hasDiscoveredAspect(player.getCommandSenderName(), tag)) {
/* 838 */                       UtilsFX.drawTag(x + shiftx, y + shifty, tag, tags.getAmount(tag), 0, UtilsFX.getGuiZLevel((Gui)gui));
/*     */                     } else {
/* 840 */                       UtilsFX.bindTexture("textures/aspects/_unknown.png");
/* 841 */                       GL11.glPushMatrix();
/* 842 */                       GL11.glEnable(3042);
/* 843 */                       GL11.glBlendFunc(770, 771);
/* 844 */                       GL11.glTranslated((x + shiftx), (y + shifty), 0.0D);
/* 845 */                       UtilsFX.drawTexturedQuadFull(0, 0, UtilsFX.getGuiZLevel((Gui)gui));
/* 846 */                       GL11.glDisable(3042);
/* 847 */                       GL11.glPopMatrix();
/*     */                     } 
/*     */                     
/* 850 */                     index++;
/*     */                   } 
/* 852 */                 }   GL11.glEnable(2929);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 859 */     GL11.glPopAttrib();
/*     */     
/* 861 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMouseOverSlot(Slot par1Slot, int par2, int par3, int par4, int par5) {
/* 869 */     int var4 = par4;
/* 870 */     int var5 = par5;
/* 871 */     par2 -= var4;
/* 872 */     par3 -= var5;
/* 873 */     return (par2 >= par1Slot.xDisplayPosition - 1 && par2 < par1Slot.xDisplayPosition + 16 + 1 && par3 >= par1Slot.yDisplayPosition - 1 && par3 < par1Slot.yDisplayPosition + 16 + 1);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\lib\ClientTickEventsFML.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */