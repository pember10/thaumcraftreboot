/*    */ package thaumcraft.client.fx.particles;
/*    */ 
/*    */ public class FXGeneric extends EntityFX {
/*    */   boolean loop;
/*    */   int delay;
/*    */   int startParticle;
/*    */   int numParticles;
/*    */   int particleInc;
/*    */   
/*    */   public void setLoop(boolean loop) {
/*    */     this.loop = loop;
/*    */   }
/*    */   
/* 14 */   public FXGeneric(World world, double x, double y, double z, double xx, double yy, double zz) { super(world, x, y, z, xx, yy, zz);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 26 */     this.loop = false;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 36 */     this.delay = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     this.startParticle = 0;
/* 45 */     this.numParticles = 1;
/* 46 */     this.particleInc = 1; setSize(0.1F, 0.1F); this.noClip = false; this.prevPosX = this.posX; this.prevPosY = this.posY; this.prevPosZ = this.posZ; this.motionX = xx;
/*    */     this.motionY = yy;
/*    */     this.motionZ = zz;
/* 49 */     this.noClip = true; } public void setParticles(int startParticle, int numParticles, int particleInc) { this.startParticle = startParticle;
/* 50 */     this.numParticles = numParticles;
/* 51 */     this.particleInc = particleInc;
/* 52 */     setParticleTextureIndex(startParticle); } public void setScale(float scale) { this.particleScale = scale; } public void setMaxAge(int max, int delay) {
/*    */     this.particleMaxAge = max;
/*    */     this.particleMaxAge += delay;
/*    */     this.delay = delay;
/*    */   }
/*    */   public void onUpdate() {
/* 58 */     super.onUpdate();
/*    */     
/* 60 */     if (this.loop) {
/* 61 */       setParticleTextureIndex(this.startParticle + this.particleAge / this.particleInc % this.numParticles);
/*    */     } else {
/* 63 */       float fs = this.particleAge / this.particleMaxAge;
/* 64 */       setParticleTextureIndex((int)(this.startParticle + Math.min(this.numParticles * fs, (this.numParticles - 1))));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) {
/* 71 */     if (this.particleAge < this.delay)
/* 72 */       return;  float t = this.particleAlpha;
/* 73 */     if (this.particleAge <= 1 || this.particleAge >= this.particleMaxAge - 1) this.particleAlpha = t / 2.0F; 
/* 74 */     super.renderParticle(tessellator, f, f1, f2, f3, f4, f5);
/* 75 */     this.particleAlpha = t;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXGeneric.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */