/*     */ package thaumcraft.client.fx.particles;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.client.renderers.tile.TileNodeRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FXBurst
/*     */   extends EntityFX
/*     */ {
/*     */   public FXBurst(World world, double d, double d1, double d2, float f) {
/*  18 */     super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
/*     */     
/*  20 */     this.particleRed = 1.0F;
/*  21 */     this.particleGreen = 1.0F;
/*  22 */     this.particleBlue = 1.0F;
/*  23 */     this.particleGravity = 0.0F;
/*  24 */     this.motionX = this.motionY = this.motionZ = 0.0D;
/*  25 */     this.particleScale *= f;
/*  26 */     this.particleMaxAge = 31;
/*  27 */     this.noClip = false;
/*  28 */     setSize(0.01F, 0.01F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) {
/*  36 */     tessellator.draw();
/*  37 */     GL11.glPushMatrix();
/*     */ 
/*     */     
/*  40 */     GL11.glDepthMask(false);
/*  41 */     GL11.glEnable(3042);
/*  42 */     GL11.glBlendFunc(770, 1);
/*     */     
/*  44 */     UtilsFX.bindTexture(TileNodeRenderer.nodetex);
/*     */     
/*  46 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.75F);
/*     */     
/*  48 */     float var8 = (this.particleAge % 32) / 32.0F;
/*  49 */     float var9 = var8 + 0.03125F;
/*  50 */     float var10 = 0.96875F;
/*  51 */     float var11 = 1.0F;
/*  52 */     float var12 = this.particleScale;
/*     */     
/*  54 */     float var13 = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/*  55 */     float var14 = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/*  56 */     float var15 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/*  57 */     float var16 = 1.0F;
/*     */     
/*  59 */     tessellator.startDrawingQuads();
/*  60 */     tessellator.setBrightness(240);
/*     */     
/*  62 */     tessellator.setColorRGBA_F(this.particleRed * var16, this.particleGreen * var16, this.particleBlue * var16, 1.0F);
/*  63 */     tessellator.addVertexWithUV((var13 - f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 - f3 * var12 - f5 * var12), var9, var11);
/*  64 */     tessellator.addVertexWithUV((var13 - f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 - f3 * var12 + f5 * var12), var9, var10);
/*  65 */     tessellator.addVertexWithUV((var13 + f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 + f3 * var12 + f5 * var12), var8, var10);
/*  66 */     tessellator.addVertexWithUV((var13 + f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 + f3 * var12 - f5 * var12), var8, var11);
/*     */     
/*  68 */     tessellator.draw();
/*     */     
/*  70 */     GL11.glDisable(3042);
/*  71 */     GL11.glDepthMask(true);
/*     */     
/*  73 */     GL11.glPopMatrix();
/*  74 */     (Minecraft.getMinecraft()).renderEngine.bindTexture(UtilsFX.getParticleTexture());
/*  75 */     tessellator.startDrawingQuads();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  82 */     this.prevPosX = this.posX;
/*  83 */     this.prevPosY = this.posY;
/*  84 */     this.prevPosZ = this.posZ;
/*     */     
/*  86 */     if (this.particleAge++ >= this.particleMaxAge)
/*     */     {
/*  88 */       setDead();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGravity(float value) {
/* 101 */     this.particleGravity = value;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXBurst.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */