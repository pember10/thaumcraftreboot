/*    */ package thaumcraft.client.fx.particles;
/*    */ 
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.world.World;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FXSlimyBubble
/*    */   extends EntityFX
/*    */ {
/*    */   int particle;
/*    */   
/*    */   public FXSlimyBubble(World world, double d, double d1, double d2, float f) {
/* 17 */     super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 30 */     this.particle = 144; this.particleRed = 1.0F; this.particleGreen = 1.0F; this.particleBlue = 1.0F;
/*    */     this.particleGravity = 0.0F;
/*    */     this.motionX = this.motionY = this.motionZ = 0.0D;
/*    */     this.particleScale = f;
/*    */     this.particleMaxAge = 15 + world.rand.nextInt(5);
/*    */     this.noClip = false;
/* 36 */     setSize(0.01F, 0.01F); } public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) { GL11.glColor4f(1.0F, 1.0F, 1.0F, this.particleAlpha);
/*    */     
/* 38 */     float var8 = (this.particle % 16) / 16.0F;
/* 39 */     float var9 = var8 + 0.0625F;
/* 40 */     float var10 = (this.particle / 16) / 16.0F;
/* 41 */     float var11 = var10 + 0.0625F;
/* 42 */     float var12 = this.particleScale;
/* 43 */     float var13 = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/* 44 */     float var14 = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/* 45 */     float var15 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/*    */     
/* 47 */     tessellator.setBrightness(getBrightnessForRender(f));
/*    */     
/* 49 */     tessellator.setColorRGBA_F(this.particleRed, this.particleGreen, this.particleBlue, this.particleAlpha);
/* 50 */     tessellator.addVertexWithUV((var13 - f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 - f3 * var12 - f5 * var12), var9, var11);
/*    */ 
/*    */ 
/*    */     
/* 54 */     tessellator.addVertexWithUV((var13 - f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 - f3 * var12 + f5 * var12), var9, var10);
/*    */ 
/*    */ 
/*    */     
/* 58 */     tessellator.addVertexWithUV((var13 + f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 + f3 * var12 + f5 * var12), var8, var10);
/*    */ 
/*    */ 
/*    */     
/* 62 */     tessellator.addVertexWithUV((var13 + f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 + f3 * var12 - f5 * var12), var8, var11); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFXLayer() {
/* 71 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 77 */     this.prevPosX = this.posX;
/* 78 */     this.prevPosY = this.posY;
/* 79 */     this.prevPosZ = this.posZ;
/*    */     
/* 81 */     if (this.particleAge++ >= this.particleMaxAge) {
/* 82 */       setDead();
/*    */     }
/* 84 */     if (this.particleAge - 1 < 6) {
/* 85 */       this.particle = 144 + this.particleAge / 2;
/* 86 */       if (this.particleAge == 5) {
/* 87 */         this.posY += 0.1D;
/*    */       }
/*    */     }
/* 90 */     else if (this.particleAge < this.particleMaxAge - 4) {
/* 91 */       this.motionY += 0.005D;
/* 92 */       this.particle = 147 + this.particleAge % 4 / 2;
/*    */     } else {
/* 94 */       this.motionY /= 2.0D;
/* 95 */       this.particle = 150 - (this.particleMaxAge - this.particleAge) / 2;
/*    */     } 
/*    */     
/* 98 */     this.posY += this.motionY;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXSlimyBubble.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */