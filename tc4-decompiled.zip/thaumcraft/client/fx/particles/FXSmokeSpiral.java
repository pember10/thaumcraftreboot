/*     */ package thaumcraft.client.fx.particles;
/*     */ 
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class FXSmokeSpiral
/*     */   extends EntityFX
/*     */ {
/*  12 */   private float radius = 1.0F;
/*  13 */   private int start = 0;
/*  14 */   private int miny = 0;
/*     */ 
/*     */   
/*     */   public FXSmokeSpiral(World world, double d, double d1, double d2, float radius, int start, int miny) {
/*  18 */     super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
/*     */     
/*  20 */     this.particleGravity = -0.01F;
/*  21 */     this.motionX = this.motionY = this.motionZ = 0.0D;
/*  22 */     this.particleScale *= 1.0F;
/*  23 */     this.particleMaxAge = 20 + world.rand.nextInt(10);
/*  24 */     this.noClip = false;
/*  25 */     setSize(0.01F, 0.01F);
/*  26 */     this.prevPosX = this.posX;
/*  27 */     this.prevPosY = this.posY;
/*  28 */     this.prevPosZ = this.posZ;
/*  29 */     this.radius = radius;
/*  30 */     this.start = start;
/*  31 */     this.miny = miny;
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) {
/*  36 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.66F * this.particleAlpha);
/*     */     
/*  38 */     int particle = (int)(1.0F + this.particleAge / this.particleMaxAge * 4.0F);
/*     */     
/*  40 */     float r1 = this.start + 720.0F * (this.particleAge + f) / this.particleMaxAge;
/*  41 */     float r2 = 90.0F - 180.0F * (this.particleAge + f) / this.particleMaxAge;
/*     */     
/*  43 */     float mX = -MathHelper.sin(r1 / 180.0F * 3.1415927F) * MathHelper.cos(r2 / 180.0F * 3.1415927F);
/*     */     
/*  45 */     float mZ = MathHelper.cos(r1 / 180.0F * 3.1415927F) * MathHelper.cos(r2 / 180.0F * 3.1415927F);
/*     */     
/*  47 */     float mY = -MathHelper.sin(r2 / 180.0F * 3.1415927F);
/*  48 */     mX *= this.radius;
/*  49 */     mY *= this.radius;
/*  50 */     mZ *= this.radius;
/*     */     
/*  52 */     float var8 = (particle % 16) / 16.0F;
/*  53 */     float var9 = var8 + 0.0624375F;
/*  54 */     float var10 = (particle / 16) / 16.0F;
/*  55 */     float var11 = var10 + 0.0624375F;
/*  56 */     float var12 = 0.15F * this.particleScale;
/*  57 */     float var13 = (float)(this.posX + mX - interpPosX);
/*  58 */     float var14 = (float)(Math.max(this.posY + mY, (this.miny + 0.1F)) - interpPosY);
/*  59 */     float var15 = (float)(this.posZ + mZ - interpPosZ);
/*  60 */     float var16 = 1.0F;
/*     */     
/*  62 */     tessellator.setBrightness(getBrightnessForRender(f));
/*  63 */     tessellator.setColorRGBA_F(this.particleRed * var16, this.particleGreen * var16, this.particleBlue * var16, 0.66F * this.particleAlpha);
/*     */     
/*  65 */     tessellator.addVertexWithUV((var13 - f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 - f3 * var12 - f5 * var12), var9, var11);
/*     */ 
/*     */ 
/*     */     
/*  69 */     tessellator.addVertexWithUV((var13 - f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 - f3 * var12 + f5 * var12), var9, var10);
/*     */ 
/*     */ 
/*     */     
/*  73 */     tessellator.addVertexWithUV((var13 + f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 + f3 * var12 + f5 * var12), var8, var10);
/*     */ 
/*     */ 
/*     */     
/*  77 */     tessellator.addVertexWithUV((var13 + f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 + f3 * var12 - f5 * var12), var8, var11);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFXLayer() {
/*  86 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  91 */     setAlphaF((this.particleMaxAge - this.particleAge) / this.particleMaxAge);
/*  92 */     if (this.particleAge++ >= this.particleMaxAge)
/*     */     {
/*  94 */       setDead();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean pushOutOfBlocks(double par1, double par3, double par5) {
/* 100 */     int var7 = MathHelper.floor_double(par1);
/* 101 */     int var8 = MathHelper.floor_double(par3);
/* 102 */     int var9 = MathHelper.floor_double(par5);
/* 103 */     double var10 = par1 - var7;
/* 104 */     double var12 = par3 - var8;
/* 105 */     double var14 = par5 - var9;
/*     */     
/* 107 */     if (!this.worldObj.isAirBlock(var7, var8, var9)) {
/* 108 */       boolean var16 = !this.worldObj.isBlockNormalCubeDefault(var7 - 1, var8, var9, true);
/*     */       
/* 110 */       boolean var17 = !this.worldObj.isBlockNormalCubeDefault(var7 + 1, var8, var9, true);
/*     */       
/* 112 */       boolean var18 = !this.worldObj.isBlockNormalCubeDefault(var7, var8 - 1, var9, true);
/*     */       
/* 114 */       boolean var19 = !this.worldObj.isBlockNormalCubeDefault(var7, var8 + 1, var9, true);
/*     */       
/* 116 */       boolean var20 = !this.worldObj.isBlockNormalCubeDefault(var7, var8, var9 - 1, true);
/*     */       
/* 118 */       boolean var21 = !this.worldObj.isBlockNormalCubeDefault(var7, var8, var9 + 1, true);
/*     */       
/* 120 */       byte var22 = -1;
/* 121 */       double var23 = 9999.0D;
/*     */       
/* 123 */       if (var16 && var10 < var23) {
/* 124 */         var23 = var10;
/* 125 */         var22 = 0;
/*     */       } 
/*     */       
/* 128 */       if (var17 && 1.0D - var10 < var23) {
/* 129 */         var23 = 1.0D - var10;
/* 130 */         var22 = 1;
/*     */       } 
/*     */       
/* 133 */       if (var18 && var12 < var23) {
/* 134 */         var23 = var12;
/* 135 */         var22 = 2;
/*     */       } 
/*     */       
/* 138 */       if (var19 && 1.0D - var12 < var23) {
/* 139 */         var23 = 1.0D - var12;
/* 140 */         var22 = 3;
/*     */       } 
/*     */       
/* 143 */       if (var20 && var14 < var23) {
/* 144 */         var23 = var14;
/* 145 */         var22 = 4;
/*     */       } 
/*     */       
/* 148 */       if (var21 && 1.0D - var14 < var23) {
/* 149 */         var23 = 1.0D - var14;
/* 150 */         var22 = 5;
/*     */       } 
/*     */       
/* 153 */       float var25 = this.rand.nextFloat() * 0.05F + 0.025F;
/* 154 */       float var26 = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F;
/*     */       
/* 156 */       if (var22 == 0) {
/* 157 */         this.motionX = -var25;
/* 158 */         this.motionY = this.motionZ = var26;
/*     */       } 
/*     */       
/* 161 */       if (var22 == 1) {
/* 162 */         this.motionX = var25;
/* 163 */         this.motionY = this.motionZ = var26;
/*     */       } 
/*     */       
/* 166 */       if (var22 == 2) {
/* 167 */         this.motionY = -var25;
/* 168 */         this.motionX = this.motionZ = var26;
/*     */       } 
/*     */       
/* 171 */       if (var22 == 3) {
/* 172 */         this.motionY = var25;
/* 173 */         this.motionX = this.motionZ = var26;
/*     */       } 
/*     */       
/* 176 */       if (var22 == 4) {
/* 177 */         this.motionZ = -var25;
/* 178 */         this.motionY = this.motionX = var26;
/*     */       } 
/*     */       
/* 181 */       if (var22 == 5) {
/* 182 */         this.motionZ = var25;
/* 183 */         this.motionY = this.motionX = var26;
/*     */       } 
/*     */       
/* 186 */       return true;
/*     */     } 
/* 188 */     return false;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXSmokeSpiral.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */