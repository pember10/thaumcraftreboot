/*     */ package thaumcraft.client.fx.particles;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FXBubble
/*     */   extends EntityFX
/*     */ {
/*  16 */   public int particle = 16;
/*     */   public double bubblespeed;
/*     */   
/*     */   public FXBubble(World par1World, double par2, double par4, double par6, double par8, double par10, double par12, int age) {
/*  20 */     super(par1World, par2, par4, par6, par8, par10, par12);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     this.bubblespeed = 0.002D; this.particleRed = 1.0F; this.particleGreen = 0.0F; this.particleBlue = 0.5F; setSize(0.02F, 0.02F); this.noClip = true; this.particleScale *= this.rand.nextFloat() * 0.3F + 0.2F; this.motionX = par8 * 0.20000000298023224D + ((float)(Math.random() * 2.0D - 1.0D) * 0.02F); this.motionY = par10 * 0.20000000298023224D + ((float)Math.random() * 0.02F); this.motionZ = par12 * 0.20000000298023224D + ((float)(Math.random() * 2.0D - 1.0D) * 0.02F); this.particleMaxAge = (int)((age + 2) + 8.0D / (Math.random() * 0.8D + 0.2D)); EntityLivingBase renderentity = (FMLClientHandler.instance().getClient()).renderViewEntity; int visibleDistance = 50; if (!(FMLClientHandler.instance().getClient()).gameSettings.fancyGraphics)
/*     */       visibleDistance = 25;  if (renderentity.getDistance(this.posX, this.posY, this.posZ) > visibleDistance)
/*     */       this.particleMaxAge = 0;  this.prevPosX = this.posX; this.prevPosY = this.posY; this.prevPosZ = this.posZ;
/*     */   } public void setFroth() { this.particleScale *= 0.75F; this.particleMaxAge = 4 + this.rand.nextInt(3);
/*     */     this.bubblespeed = -0.001D;
/*     */     this.motionX /= 5.0D;
/*     */     this.motionY /= 10.0D;
/*  67 */     this.motionZ /= 5.0D; } public void onUpdate() { this.prevPosX = this.posX;
/*  68 */     this.prevPosY = this.posY;
/*  69 */     this.prevPosZ = this.posZ;
/*  70 */     this.motionY += this.bubblespeed;
/*  71 */     if (this.bubblespeed > 0.0D) {
/*  72 */       this.motionX += ((this.worldObj.rand.nextFloat() - this.worldObj.rand.nextFloat()) * 0.01F);
/*  73 */       this.motionZ += ((this.worldObj.rand.nextFloat() - this.worldObj.rand.nextFloat()) * 0.01F);
/*     */     } 
/*     */     
/*  76 */     this.posX += this.motionX;
/*  77 */     this.posY += this.motionY;
/*  78 */     this.posZ += this.motionZ;
/*     */     
/*  80 */     this.motionX *= 0.8500000238418579D;
/*  81 */     this.motionY *= 0.8500000238418579D;
/*  82 */     this.motionZ *= 0.8500000238418579D;
/*     */     
/*  84 */     if (this.particleMaxAge-- <= 0) {
/*     */       
/*  86 */       setDead();
/*     */     
/*     */     }
/*  89 */     else if (this.particleMaxAge <= 2) {
/*  90 */       this.particle++;
/*     */     }  }
/*     */   public void setFroth2() { this.particleScale *= 0.75F; this.particleMaxAge = 12 + this.rand.nextInt(12); this.bubblespeed = -0.005D;
/*     */     this.motionX /= 5.0D;
/*     */     this.motionY /= 10.0D;
/*  95 */     this.motionZ /= 5.0D; } public void setRGB(float r, float g, float b) { this.particleRed = r;
/*  96 */     this.particleGreen = g;
/*  97 */     this.particleBlue = b; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) {
/* 103 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, this.particleAlpha);
/*     */     
/* 105 */     float var8 = (this.particle % 16) / 16.0F;
/* 106 */     float var9 = var8 + 0.0624375F;
/* 107 */     float var10 = (this.particle / 16) / 16.0F;
/* 108 */     float var11 = var10 + 0.0624375F;
/* 109 */     float var12 = 0.1F * this.particleScale;
/* 110 */     float var13 = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/* 111 */     float var14 = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/* 112 */     float var15 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/* 113 */     float var16 = 1.0F;
/*     */     
/* 115 */     tessellator.setBrightness(240);
/*     */     
/* 117 */     tessellator.setColorRGBA_F(this.particleRed * var16, this.particleGreen * var16, this.particleBlue * var16, this.particleAlpha);
/* 118 */     tessellator.addVertexWithUV((var13 - f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 - f3 * var12 - f5 * var12), var9, var11);
/* 119 */     tessellator.addVertexWithUV((var13 - f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 - f3 * var12 + f5 * var12), var9, var10);
/* 120 */     tessellator.addVertexWithUV((var13 + f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 + f3 * var12 + f5 * var12), var8, var10);
/* 121 */     tessellator.addVertexWithUV((var13 + f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 + f3 * var12 - f5 * var12), var8, var11);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXBubble.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */