/*    */ package thaumcraft.client.fx.particles;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class FXBreaking
/*    */   extends EntityFX
/*    */ {
/*    */   public void setParticleMaxAge(int particleMaxAge) {
/* 17 */     this.particleMaxAge = particleMaxAge;
/*    */   }
/*    */ 
/*    */   
/*    */   public FXBreaking(World par1World, double par2, double par4, double par6, Item par8Item) {
/* 22 */     super(par1World, par2, par4, par6, 0.0D, 0.0D, 0.0D);
/* 23 */     setParticleIcon(par8Item.getIconFromDamage(0));
/* 24 */     this.particleRed = this.particleGreen = this.particleBlue = 1.0F;
/* 25 */     this.particleGravity = Blocks.snow_layer.blockParticleGravity;
/* 26 */     this.particleScale /= 2.0F;
/*    */   }
/*    */ 
/*    */   
/*    */   public FXBreaking(World par1World, double par2, double par4, double par6, double par8, double par10, double par12, Item par14Item) {
/* 31 */     this(par1World, par2, par4, par6, par14Item);
/* 32 */     this.motionX *= 0.10000000149011612D;
/* 33 */     this.motionY *= 0.10000000149011612D;
/* 34 */     this.motionZ *= 0.10000000149011612D;
/* 35 */     this.motionX += par8;
/* 36 */     this.motionY += par10;
/* 37 */     this.motionZ += par12;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getFXLayer() {
/* 42 */     return 2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderParticle(Tessellator par1Tessellator, float par2, float par3, float par4, float par5, float par6, float par7) {
/* 49 */     float f6 = (this.particleTextureIndexX + this.particleTextureJitterX / 4.0F) / 16.0F;
/* 50 */     float f7 = f6 + 0.015609375F;
/* 51 */     float f8 = (this.particleTextureIndexY + this.particleTextureJitterY / 4.0F) / 16.0F;
/* 52 */     float f9 = f8 + 0.015609375F;
/* 53 */     float f10 = 0.1F * this.particleScale;
/* 54 */     float fade = 1.0F - this.particleAge / this.particleMaxAge;
/* 55 */     f10 *= fade;
/* 56 */     if (this.particleIcon != null) {
/*    */       
/* 58 */       f6 = this.particleIcon.getInterpolatedU((this.particleTextureJitterX / 4.0F * 16.0F));
/* 59 */       f7 = this.particleIcon.getInterpolatedU(((this.particleTextureJitterX + 1.0F) / 4.0F * 16.0F));
/* 60 */       f8 = this.particleIcon.getInterpolatedV((this.particleTextureJitterY / 4.0F * 16.0F));
/* 61 */       f9 = this.particleIcon.getInterpolatedV(((this.particleTextureJitterY + 1.0F) / 4.0F * 16.0F));
/*    */     } 
/*    */     
/* 64 */     float f11 = (float)(this.prevPosX + (this.posX - this.prevPosX) * par2 - interpPosX);
/* 65 */     float f12 = (float)(this.prevPosY + (this.posY - this.prevPosY) * par2 - interpPosY);
/* 66 */     float f13 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * par2 - interpPosZ);
/* 67 */     float f14 = 1.0F;
/*    */     
/* 69 */     par1Tessellator.setColorRGBA_F(f14 * this.particleRed, f14 * this.particleGreen, f14 * this.particleBlue, this.particleAlpha * fade);
/* 70 */     par1Tessellator.addVertexWithUV((f11 - par3 * f10 - par6 * f10), (f12 - par4 * f10), (f13 - par5 * f10 - par7 * f10), f6, f9);
/* 71 */     par1Tessellator.addVertexWithUV((f11 - par3 * f10 + par6 * f10), (f12 + par4 * f10), (f13 - par5 * f10 + par7 * f10), f6, f8);
/* 72 */     par1Tessellator.addVertexWithUV((f11 + par3 * f10 + par6 * f10), (f12 + par4 * f10), (f13 + par5 * f10 + par7 * f10), f7, f8);
/* 73 */     par1Tessellator.addVertexWithUV((f11 + par3 * f10 - par6 * f10), (f12 - par4 * f10), (f13 + par5 * f10 - par7 * f10), f7, f9);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXBreaking.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */