/*     */ package thaumcraft.client.fx.particles;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockLiquid;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.crash.CrashReport;
/*     */ import net.minecraft.crash.CrashReportCategory;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.ReportedException;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class FXDrop
/*     */   extends EntityFX
/*     */ {
/*     */   int bobTimer;
/*     */   
/*     */   public FXDrop(World par1World, double par2, double par4, double par6, float r, float g, float b) {
/*  32 */     super(par1World, par2, par4, par6, 0.0D, 0.0D, 0.0D);
/*  33 */     this.motionX = this.motionY = this.motionZ = 0.0D;
/*     */     
/*  35 */     this.particleRed = r;
/*  36 */     this.particleGreen = g;
/*  37 */     this.particleBlue = b;
/*     */     
/*  39 */     setParticleTextureIndex(113);
/*     */     
/*  41 */     this.particleGravity = 0.06F;
/*  42 */     this.bobTimer = 40;
/*  43 */     this.particleMaxAge = (int)(64.0D / (Math.random() * 0.8D + 0.2D));
/*  44 */     this.motionX = this.motionY = this.motionZ = 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBrightnessForRender(float par1) {
/*  50 */     return 257;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getBrightness(float par1) {
/*  59 */     return 1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  68 */     this.prevPosX = this.posX;
/*  69 */     this.prevPosY = this.posY;
/*  70 */     this.prevPosZ = this.posZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     this.motionY -= this.particleGravity;
/*     */     
/*  80 */     if (this.bobTimer-- > 0) {
/*     */       
/*  82 */       this.motionX *= 0.02D;
/*  83 */       this.motionY *= 0.02D;
/*  84 */       this.motionZ *= 0.02D;
/*  85 */       setParticleTextureIndex(113);
/*     */     }
/*     */     else {
/*     */       
/*  89 */       setParticleTextureIndex(112);
/*     */     } 
/*     */     
/*  92 */     moveEntity(this.motionX, this.motionY, this.motionZ);
/*     */     
/*  94 */     this.motionX *= 0.9800000190734863D;
/*  95 */     this.motionY *= 0.9800000190734863D;
/*  96 */     this.motionZ *= 0.9800000190734863D;
/*     */     
/*  98 */     if (this.particleMaxAge-- <= 0)
/*     */     {
/* 100 */       setDead();
/*     */     }
/*     */     
/* 103 */     if (this.onGround) {
/*     */ 
/*     */       
/* 106 */       setParticleTextureIndex(114);
/*     */       
/* 108 */       this.motionX *= 0.699999988079071D;
/* 109 */       this.motionZ *= 0.699999988079071D;
/*     */     } 
/*     */     
/* 112 */     Material material = this.worldObj.getBlock(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)).getMaterial();
/*     */     
/* 114 */     if (material != Material.glass && (material.isLiquid() || material.isSolid())) {
/*     */       
/* 116 */       double d0 = ((MathHelper.floor_double(this.posY) + 1) - BlockLiquid.getLiquidHeightPercent(this.worldObj.getBlockMetadata(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ))));
/*     */       
/* 118 */       if (this.posY < d0)
/*     */       {
/* 120 */         setDead();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void moveEntity(double par1, double par3, double par5) {
/* 128 */     int x = MathHelper.floor_double(this.posX);
/* 129 */     int y = MathHelper.floor_double(this.posY);
/* 130 */     int z = MathHelper.floor_double(this.posZ);
/*     */     
/* 132 */     if (this.noClip || this.worldObj.getBlock(x, y, z) == ConfigBlocks.blockJar) {
/*     */       
/* 134 */       this.boundingBox.offset(par1, par3, par5);
/* 135 */       this.posX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0D;
/* 136 */       this.posY = this.boundingBox.minY + this.yOffset - this.ySize;
/* 137 */       this.posZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0D;
/*     */       
/* 139 */       x = MathHelper.floor_double(this.posX);
/* 140 */       y = MathHelper.floor_double(this.posY);
/* 141 */       y = MathHelper.floor_double(this.posY);
/*     */       
/* 143 */       if (this.worldObj.getBlock(x, y + 1, z) == ConfigBlocks.blockJar) {
/* 144 */         this.posX = this.prevPosX;
/* 145 */         this.posY = this.prevPosY;
/* 146 */         this.posZ = this.prevPosZ;
/* 147 */         this.motionY = 0.0D;
/* 148 */         this.onGround = true;
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 154 */       this.worldObj.theProfiler.startSection("move");
/* 155 */       this.ySize *= 0.4F;
/* 156 */       double d3 = this.posX;
/* 157 */       double d4 = this.posY;
/* 158 */       double d5 = this.posZ;
/*     */       
/* 160 */       if (this.isInWeb) {
/*     */         
/* 162 */         this.isInWeb = false;
/* 163 */         par1 *= 0.25D;
/* 164 */         par3 *= 0.05000000074505806D;
/* 165 */         par5 *= 0.25D;
/* 166 */         this.motionX = 0.0D;
/* 167 */         this.motionY = 0.0D;
/* 168 */         this.motionZ = 0.0D;
/*     */       } 
/*     */       
/* 171 */       double d6 = par1;
/* 172 */       double d7 = par3;
/* 173 */       double d8 = par5;
/* 174 */       AxisAlignedBB axisalignedbb = this.boundingBox.copy();
/* 175 */       boolean flag = (this.onGround && isSneaking());
/*     */       
/* 177 */       if (flag) {
/*     */         double d9;
/*     */ 
/*     */         
/* 181 */         for (d9 = 0.05D; par1 != 0.0D && this.worldObj.getCollidingBoundingBoxes((Entity)this, this.boundingBox.getOffsetBoundingBox(par1, -1.0D, 0.0D)).isEmpty(); d6 = par1) {
/*     */           
/* 183 */           if (par1 < d9 && par1 >= -d9) {
/*     */             
/* 185 */             par1 = 0.0D;
/*     */           }
/* 187 */           else if (par1 > 0.0D) {
/*     */             
/* 189 */             par1 -= d9;
/*     */           }
/*     */           else {
/*     */             
/* 193 */             par1 += d9;
/*     */           } 
/*     */         } 
/*     */         
/* 197 */         for (; par5 != 0.0D && this.worldObj.getCollidingBoundingBoxes((Entity)this, this.boundingBox.getOffsetBoundingBox(0.0D, -1.0D, par5)).isEmpty(); d8 = par5) {
/*     */           
/* 199 */           if (par5 < d9 && par5 >= -d9) {
/*     */             
/* 201 */             par5 = 0.0D;
/*     */           }
/* 203 */           else if (par5 > 0.0D) {
/*     */             
/* 205 */             par5 -= d9;
/*     */           }
/*     */           else {
/*     */             
/* 209 */             par5 += d9;
/*     */           } 
/*     */         } 
/*     */         
/* 213 */         while (par1 != 0.0D && par5 != 0.0D && this.worldObj.getCollidingBoundingBoxes((Entity)this, this.boundingBox.getOffsetBoundingBox(par1, -1.0D, par5)).isEmpty()) {
/*     */           
/* 215 */           if (par1 < d9 && par1 >= -d9) {
/*     */             
/* 217 */             par1 = 0.0D;
/*     */           }
/* 219 */           else if (par1 > 0.0D) {
/*     */             
/* 221 */             par1 -= d9;
/*     */           }
/*     */           else {
/*     */             
/* 225 */             par1 += d9;
/*     */           } 
/*     */           
/* 228 */           if (par5 < d9 && par5 >= -d9) {
/*     */             
/* 230 */             par5 = 0.0D;
/*     */           }
/* 232 */           else if (par5 > 0.0D) {
/*     */             
/* 234 */             par5 -= d9;
/*     */           }
/*     */           else {
/*     */             
/* 238 */             par5 += d9;
/*     */           } 
/*     */           
/* 241 */           d6 = par1;
/* 242 */           d8 = par5;
/*     */         } 
/*     */       } 
/*     */       
/* 246 */       List<AxisAlignedBB> list = this.worldObj.getCollidingBoundingBoxes((Entity)this, this.boundingBox.addCoord(par1, par3, par5));
/*     */       
/* 248 */       for (int i = 0; i < list.size(); i++)
/*     */       {
/* 250 */         par3 = ((AxisAlignedBB)list.get(i)).calculateYOffset(this.boundingBox, par3);
/*     */       }
/*     */       
/* 253 */       this.boundingBox.offset(0.0D, par3, 0.0D);
/*     */       
/* 255 */       if (!this.field_70135_K && d7 != par3) {
/*     */         
/* 257 */         par5 = 0.0D;
/* 258 */         par3 = 0.0D;
/* 259 */         par1 = 0.0D;
/*     */       } 
/*     */       
/* 262 */       boolean flag1 = (this.onGround || (d7 != par3 && d7 < 0.0D));
/*     */       
/*     */       int j;
/* 265 */       for (j = 0; j < list.size(); j++)
/*     */       {
/* 267 */         par1 = ((AxisAlignedBB)list.get(j)).calculateXOffset(this.boundingBox, par1);
/*     */       }
/*     */       
/* 270 */       this.boundingBox.offset(par1, 0.0D, 0.0D);
/*     */       
/* 272 */       if (!this.field_70135_K && d6 != par1) {
/*     */         
/* 274 */         par5 = 0.0D;
/* 275 */         par3 = 0.0D;
/* 276 */         par1 = 0.0D;
/*     */       } 
/*     */       
/* 279 */       for (j = 0; j < list.size(); j++)
/*     */       {
/* 281 */         par5 = ((AxisAlignedBB)list.get(j)).calculateZOffset(this.boundingBox, par5);
/*     */       }
/*     */       
/* 284 */       this.boundingBox.offset(0.0D, 0.0D, par5);
/*     */       
/* 286 */       if (!this.field_70135_K && d8 != par5) {
/*     */         
/* 288 */         par5 = 0.0D;
/* 289 */         par3 = 0.0D;
/* 290 */         par1 = 0.0D;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 298 */       if (this.stepHeight > 0.0F && flag1 && (flag || this.ySize < 0.05F) && (d6 != par1 || d8 != par5)) {
/*     */         
/* 300 */         double d9 = par1;
/* 301 */         double d1 = par3;
/* 302 */         double d2 = par5;
/* 303 */         par1 = d6;
/* 304 */         par3 = this.stepHeight;
/* 305 */         par5 = d8;
/* 306 */         AxisAlignedBB axisalignedbb1 = this.boundingBox.copy();
/* 307 */         this.boundingBox.setBB(axisalignedbb);
/* 308 */         list = this.worldObj.getCollidingBoundingBoxes((Entity)this, this.boundingBox.addCoord(d6, par3, d8));
/*     */         int k;
/* 310 */         for (k = 0; k < list.size(); k++)
/*     */         {
/* 312 */           par3 = ((AxisAlignedBB)list.get(k)).calculateYOffset(this.boundingBox, par3);
/*     */         }
/*     */         
/* 315 */         this.boundingBox.offset(0.0D, par3, 0.0D);
/*     */         
/* 317 */         if (!this.field_70135_K && d7 != par3) {
/*     */           
/* 319 */           par5 = 0.0D;
/* 320 */           par3 = 0.0D;
/* 321 */           par1 = 0.0D;
/*     */         } 
/*     */         
/* 324 */         for (k = 0; k < list.size(); k++)
/*     */         {
/* 326 */           par1 = ((AxisAlignedBB)list.get(k)).calculateXOffset(this.boundingBox, par1);
/*     */         }
/*     */         
/* 329 */         this.boundingBox.offset(par1, 0.0D, 0.0D);
/*     */         
/* 331 */         if (!this.field_70135_K && d6 != par1) {
/*     */           
/* 333 */           par5 = 0.0D;
/* 334 */           par3 = 0.0D;
/* 335 */           par1 = 0.0D;
/*     */         } 
/*     */         
/* 338 */         for (k = 0; k < list.size(); k++)
/*     */         {
/* 340 */           par5 = ((AxisAlignedBB)list.get(k)).calculateZOffset(this.boundingBox, par5);
/*     */         }
/*     */         
/* 343 */         this.boundingBox.offset(0.0D, 0.0D, par5);
/*     */         
/* 345 */         if (!this.field_70135_K && d8 != par5) {
/*     */           
/* 347 */           par5 = 0.0D;
/* 348 */           par3 = 0.0D;
/* 349 */           par1 = 0.0D;
/*     */         } 
/*     */         
/* 352 */         if (!this.field_70135_K && d7 != par3) {
/*     */           
/* 354 */           par5 = 0.0D;
/* 355 */           par3 = 0.0D;
/* 356 */           par1 = 0.0D;
/*     */         }
/*     */         else {
/*     */           
/* 360 */           par3 = -this.stepHeight;
/*     */           
/* 362 */           for (k = 0; k < list.size(); k++)
/*     */           {
/* 364 */             par3 = ((AxisAlignedBB)list.get(k)).calculateYOffset(this.boundingBox, par3);
/*     */           }
/*     */           
/* 367 */           this.boundingBox.offset(0.0D, par3, 0.0D);
/*     */         } 
/*     */         
/* 370 */         if (d9 * d9 + d2 * d2 >= par1 * par1 + par5 * par5) {
/*     */           
/* 372 */           par1 = d9;
/* 373 */           par3 = d1;
/* 374 */           par5 = d2;
/* 375 */           this.boundingBox.setBB(axisalignedbb1);
/*     */         } 
/*     */       } 
/*     */       
/* 379 */       this.worldObj.theProfiler.endSection();
/* 380 */       this.worldObj.theProfiler.startSection("rest");
/* 381 */       this.posX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0D;
/* 382 */       this.posY = this.boundingBox.minY + this.yOffset - this.ySize;
/* 383 */       this.posZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0D;
/* 384 */       this.isCollidedHorizontally = (d6 != par1 || d8 != par5);
/* 385 */       this.isCollidedVertically = (d7 != par3);
/* 386 */       this.onGround = (d7 != par3 && d7 < 0.0D);
/* 387 */       this.isCollided = (this.isCollidedHorizontally || this.isCollidedVertically);
/* 388 */       updateFallState(par3, this.onGround);
/*     */       
/* 390 */       if (d6 != par1)
/*     */       {
/* 392 */         this.motionX = 0.0D;
/*     */       }
/*     */       
/* 395 */       if (d7 != par3)
/*     */       {
/* 397 */         this.motionY = 0.0D;
/*     */       }
/*     */       
/* 400 */       if (d8 != par5)
/*     */       {
/* 402 */         this.motionZ = 0.0D;
/*     */       }
/*     */       
/* 405 */       double d12 = this.posX - d3;
/* 406 */       double d10 = this.posY - d4;
/* 407 */       double d11 = this.posZ - d5;
/*     */       
/* 409 */       if (canTriggerWalking() && !flag && this.ridingEntity == null) {
/*     */         
/* 411 */         int l = MathHelper.floor_double(this.posX);
/* 412 */         int k = MathHelper.floor_double(this.posY - 0.20000000298023224D - this.yOffset);
/* 413 */         int i1 = MathHelper.floor_double(this.posZ);
/* 414 */         Block j1 = this.worldObj.getBlock(l, k, i1);
/*     */         
/* 416 */         if (j1.isAir((IBlockAccess)this.worldObj, l, k, i1)) {
/*     */           
/* 418 */           int k1 = this.worldObj.getBlock(l, k - 1, i1).getRenderType();
/*     */           
/* 420 */           if (k1 == 11 || k1 == 32 || k1 == 21)
/*     */           {
/* 422 */             j1 = this.worldObj.getBlock(l, k - 1, i1);
/*     */           }
/*     */         } 
/*     */         
/* 426 */         if (j1 != Blocks.ladder)
/*     */         {
/* 428 */           d10 = 0.0D;
/*     */         }
/*     */         
/* 431 */         this.distanceWalkedModified = (float)(this.distanceWalkedModified + MathHelper.sqrt_double(d12 * d12 + d11 * d11) * 0.6D);
/* 432 */         this.distanceWalkedOnStepModified = (float)(this.distanceWalkedOnStepModified + MathHelper.sqrt_double(d12 * d12 + d10 * d10 + d11 * d11) * 0.6D);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 439 */         func_145775_I();
/*     */       }
/* 441 */       catch (Throwable throwable) {
/*     */         
/* 443 */         CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Checking entity tile collision");
/* 444 */         CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being checked for collision");
/* 445 */         addEntityCrashInfo(crashreportcategory);
/* 446 */         throw new ReportedException(crashreport);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 452 */       this.worldObj.theProfiler.endSection();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXDrop.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */