/*     */ package thaumcraft.client.fx.particles;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class FXBoreParticles
/*     */   extends EntityFX {
/*     */   private Block blockInstance;
/*     */   private Item itemInstance;
/*     */   private int metadata;
/*     */   private int side;
/*     */   private double targetX;
/*     */   private double targetY;
/*     */   private double targetZ;
/*     */   
/*     */   public FXBoreParticles(World par1World, double par2, double par4, double par6, double tx, double ty, double tz, Block par14Block, int par15, int par16) {
/*  29 */     super(par1World, par2, par4, par6, 0.0D, 0.0D, 0.0D);
/*  30 */     this.blockInstance = par14Block;
/*  31 */     setParticleIcon(par14Block.getIcon(par15, par16));
/*     */     
/*  33 */     this.particleGravity = par14Block.blockParticleGravity;
/*  34 */     this.particleRed = this.particleGreen = this.particleBlue = 0.6F;
/*  35 */     this.particleScale = this.rand.nextFloat() * 0.3F + 0.4F;
/*  36 */     this.side = par15;
/*     */     
/*  38 */     this.targetX = tx;
/*  39 */     this.targetY = ty;
/*  40 */     this.targetZ = tz;
/*     */     
/*  42 */     double dx = tx - this.posX;
/*  43 */     double dy = ty - this.posY;
/*  44 */     double dz = tz - this.posZ;
/*  45 */     int base = (int)(MathHelper.sqrt_double(dx * dx + dy * dy + dz * dz) * 3.0F);
/*  46 */     if (base < 1) base = 1; 
/*  47 */     this.particleMaxAge = base / 2 + this.rand.nextInt(base);
/*     */     
/*  49 */     float f3 = 0.01F;
/*  50 */     this.motionX = ((float)this.worldObj.rand.nextGaussian() * f3);
/*  51 */     this.motionY = ((float)this.worldObj.rand.nextGaussian() * f3);
/*  52 */     this.motionZ = ((float)this.worldObj.rand.nextGaussian() * f3);
/*     */ 
/*     */     
/*  55 */     this.particleGravity = 0.2F;
/*  56 */     this.noClip = false;
/*     */     
/*  58 */     EntityLivingBase renderentity = (FMLClientHandler.instance().getClient()).renderViewEntity;
/*  59 */     int visibleDistance = 64;
/*  60 */     if (!(FMLClientHandler.instance().getClient()).gameSettings.fancyGraphics) visibleDistance = 32; 
/*  61 */     if (renderentity.getDistance(this.posX, this.posY, this.posZ) > visibleDistance) this.particleMaxAge = 0;
/*     */   
/*     */   }
/*     */   
/*     */   public FXBoreParticles(World par1World, double par2, double par4, double par6, double tx, double ty, double tz, Item item, int par15, int par16) {
/*  66 */     super(par1World, par2, par4, par6, 0.0D, 0.0D, 0.0D);
/*  67 */     this.itemInstance = item;
/*  68 */     setParticleIcon(item.getIconFromDamage(par16));
/*  69 */     this.metadata = par16;
/*  70 */     this.particleGravity = Blocks.snow_layer.blockParticleGravity;
/*  71 */     this.particleRed = this.particleGreen = this.particleBlue = 0.6F;
/*  72 */     this.particleScale = this.rand.nextFloat() * 0.3F + 0.4F;
/*  73 */     this.side = par15;
/*     */     
/*  75 */     this.targetX = tx;
/*  76 */     this.targetY = ty;
/*  77 */     this.targetZ = tz;
/*     */     
/*  79 */     double dx = tx - this.posX;
/*  80 */     double dy = ty - this.posY;
/*  81 */     double dz = tz - this.posZ;
/*  82 */     int base = (int)(MathHelper.sqrt_double(dx * dx + dy * dy + dz * dz) * 3.0F);
/*  83 */     if (base < 1) base = 1; 
/*  84 */     this.particleMaxAge = base / 2 + this.rand.nextInt(base);
/*     */     
/*  86 */     float f3 = 0.01F;
/*  87 */     this.motionX = ((float)this.worldObj.rand.nextGaussian() * f3);
/*  88 */     this.motionY = ((float)this.worldObj.rand.nextGaussian() * f3);
/*  89 */     this.motionZ = ((float)this.worldObj.rand.nextGaussian() * f3);
/*     */ 
/*     */     
/*  92 */     this.particleGravity = 0.2F;
/*  93 */     this.noClip = false;
/*     */     
/*  95 */     EntityLivingBase renderentity = (FMLClientHandler.instance().getClient()).renderViewEntity;
/*  96 */     int visibleDistance = 64;
/*  97 */     if (!(FMLClientHandler.instance().getClient()).gameSettings.fancyGraphics) visibleDistance = 32; 
/*  98 */     if (renderentity.getDistance(this.posX, this.posY, this.posZ) > visibleDistance) this.particleMaxAge = 0;
/*     */   
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/* 103 */     this.prevPosX = this.posX;
/* 104 */     this.prevPosY = this.posY;
/* 105 */     this.prevPosZ = this.posZ;
/*     */ 
/*     */ 
/*     */     
/* 109 */     if (this.particleAge++ >= this.particleMaxAge || (MathHelper.floor_double(this.posX) == MathHelper.floor_double(this.targetX) && MathHelper.floor_double(this.posY) == MathHelper.floor_double(this.targetY) && MathHelper.floor_double(this.posZ) == MathHelper.floor_double(this.targetZ))) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       setDead();
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 120 */     if (!this.noClip) pushOutOfBlocks(this.posX, this.posY, this.posZ); 
/* 121 */     moveEntity(this.motionX, this.motionY, this.motionZ);
/*     */     
/* 123 */     this.motionX *= 0.985D;
/* 124 */     this.motionY *= 0.985D;
/* 125 */     this.motionZ *= 0.985D;
/*     */     
/* 127 */     double dx = this.targetX - this.posX;
/* 128 */     double dy = this.targetY - this.posY;
/* 129 */     double dz = this.targetZ - this.posZ;
/* 130 */     double d13 = 0.3D;
/* 131 */     double d11 = MathHelper.sqrt_double(dx * dx + dy * dy + dz * dz);
/*     */     
/* 133 */     if (d11 < 4.0D) {
/* 134 */       this.particleScale *= 0.9F;
/* 135 */       d13 = 0.6D;
/*     */     } 
/*     */     
/* 138 */     dx /= d11;
/* 139 */     dy /= d11;
/* 140 */     dz /= d11;
/*     */     
/* 142 */     this.motionX += dx * d13;
/* 143 */     this.motionY += dy * d13;
/* 144 */     this.motionZ += dz * d13;
/*     */     
/* 146 */     this.motionX = MathHelper.clamp_float((float)this.motionX, -0.35F, 0.35F);
/* 147 */     this.motionY = MathHelper.clamp_float((float)this.motionY, -0.35F, 0.35F);
/* 148 */     this.motionZ = MathHelper.clamp_float((float)this.motionZ, -0.35F, 0.35F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FXBoreParticles func_70596_a(int par1, int par2, int par3) {
/* 154 */     if (this.blockInstance != null && this.worldObj.getBlock(par1, par2, par3) == this.blockInstance) {
/* 155 */       if (this.blockInstance == Blocks.grass && this.side != 1)
/*     */       {
/* 157 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 163 */         int var4 = this.blockInstance.colorMultiplier((IBlockAccess)this.worldObj, par1, par2, par3);
/*     */         
/* 165 */         this.particleRed *= (var4 >> 16 & 0xFF) / 255.0F;
/* 166 */         this.particleGreen *= (var4 >> 8 & 0xFF) / 255.0F;
/* 167 */         this.particleBlue *= (var4 & 0xFF) / 255.0F;
/* 168 */       } catch (Exception e) {}
/* 169 */       return this;
/*     */     } 
/*     */     
/*     */     try {
/* 173 */       int var4 = this.itemInstance.getColorFromItemStack(new ItemStack(this.itemInstance, 1, this.metadata), 0);
/* 174 */       this.particleRed *= (var4 >> 16 & 0xFF) / 255.0F;
/* 175 */       this.particleGreen *= (var4 >> 8 & 0xFF) / 255.0F;
/* 176 */       this.particleBlue *= (var4 & 0xFF) / 255.0F;
/* 177 */     } catch (Exception e) {}
/* 178 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FXBoreParticles applyRenderColor(int par1) {
/* 187 */     if (this.blockInstance != null) {
/* 188 */       if (this.blockInstance == Blocks.grass)
/*     */       {
/* 190 */         return this;
/*     */       }
/*     */ 
/*     */       
/* 194 */       int var2 = this.blockInstance.getRenderColor(par1);
/* 195 */       this.particleRed *= (var2 >> 16 & 0xFF) / 255.0F;
/* 196 */       this.particleGreen *= (var2 >> 8 & 0xFF) / 255.0F;
/* 197 */       this.particleBlue *= (var2 & 0xFF) / 255.0F;
/* 198 */       return this;
/*     */     } 
/*     */     
/* 201 */     int var4 = this.itemInstance.getColorFromItemStack(new ItemStack(this.itemInstance, 1, this.metadata), this.metadata);
/* 202 */     this.particleRed *= (var4 >> 16 & 0xFF) / 255.0F;
/* 203 */     this.particleGreen *= (var4 >> 8 & 0xFF) / 255.0F;
/* 204 */     this.particleBlue *= (var4 & 0xFF) / 255.0F;
/* 205 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFXLayer() {
/* 211 */     return (this.blockInstance != null) ? 1 : 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderParticle(Tessellator par1Tessellator, float par2, float par3, float par4, float par5, float par6, float par7) {
/* 217 */     float f6 = (this.particleTextureIndexX + this.particleTextureJitterX / 4.0F) / 16.0F;
/* 218 */     float f7 = f6 + 0.015609375F;
/* 219 */     float f8 = (this.particleTextureIndexY + this.particleTextureJitterY / 4.0F) / 16.0F;
/* 220 */     float f9 = f8 + 0.015609375F;
/* 221 */     float f10 = 0.1F * this.particleScale;
/*     */     
/* 223 */     if (this.particleIcon != null) {
/*     */       
/* 225 */       f6 = this.particleIcon.getInterpolatedU((this.particleTextureJitterX / 4.0F * 16.0F));
/* 226 */       f7 = this.particleIcon.getInterpolatedU(((this.particleTextureJitterX + 1.0F) / 4.0F * 16.0F));
/* 227 */       f8 = this.particleIcon.getInterpolatedV((this.particleTextureJitterY / 4.0F * 16.0F));
/* 228 */       f9 = this.particleIcon.getInterpolatedV(((this.particleTextureJitterY + 1.0F) / 4.0F * 16.0F));
/*     */     } 
/*     */     
/* 231 */     float f11 = (float)(this.prevPosX + (this.posX - this.prevPosX) * par2 - interpPosX);
/* 232 */     float f12 = (float)(this.prevPosY + (this.posY - this.prevPosY) * par2 - interpPosY);
/* 233 */     float f13 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * par2 - interpPosZ);
/* 234 */     float f14 = 1.0F;
/* 235 */     par1Tessellator.setColorOpaque_F(f14 * this.particleRed, f14 * this.particleGreen, f14 * this.particleBlue);
/* 236 */     par1Tessellator.addVertexWithUV((f11 - par3 * f10 - par6 * f10), (f12 - par4 * f10), (f13 - par5 * f10 - par7 * f10), f6, f9);
/* 237 */     par1Tessellator.addVertexWithUV((f11 - par3 * f10 + par6 * f10), (f12 + par4 * f10), (f13 - par5 * f10 + par7 * f10), f6, f8);
/* 238 */     par1Tessellator.addVertexWithUV((f11 + par3 * f10 + par6 * f10), (f12 + par4 * f10), (f13 + par5 * f10 + par7 * f10), f7, f8);
/* 239 */     par1Tessellator.addVertexWithUV((f11 + par3 * f10 - par6 * f10), (f12 - par4 * f10), (f13 + par5 * f10 - par7 * f10), f7, f9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean pushOutOfBlocks(double par1, double par3, double par5) {
/* 246 */     int var7 = MathHelper.floor_double(par1);
/* 247 */     int var8 = MathHelper.floor_double(par3);
/* 248 */     int var9 = MathHelper.floor_double(par5);
/* 249 */     double var10 = par1 - var7;
/* 250 */     double var12 = par3 - var8;
/* 251 */     double var14 = par5 - var9;
/*     */     
/* 253 */     if (!this.worldObj.isAirBlock(var7, var8, var9) && !this.worldObj.isAnyLiquid(this.boundingBox)) {
/*     */       
/* 255 */       boolean var16 = !this.worldObj.isBlockNormalCubeDefault(var7 - 1, var8, var9, true);
/* 256 */       boolean var17 = !this.worldObj.isBlockNormalCubeDefault(var7 + 1, var8, var9, true);
/* 257 */       boolean var18 = !this.worldObj.isBlockNormalCubeDefault(var7, var8 - 1, var9, true);
/* 258 */       boolean var19 = !this.worldObj.isBlockNormalCubeDefault(var7, var8 + 1, var9, true);
/* 259 */       boolean var20 = !this.worldObj.isBlockNormalCubeDefault(var7, var8, var9 - 1, true);
/* 260 */       boolean var21 = !this.worldObj.isBlockNormalCubeDefault(var7, var8, var9 + 1, true);
/* 261 */       byte var22 = -1;
/* 262 */       double var23 = 9999.0D;
/*     */       
/* 264 */       if (var16 && var10 < var23) {
/*     */         
/* 266 */         var23 = var10;
/* 267 */         var22 = 0;
/*     */       } 
/*     */       
/* 270 */       if (var17 && 1.0D - var10 < var23) {
/*     */         
/* 272 */         var23 = 1.0D - var10;
/* 273 */         var22 = 1;
/*     */       } 
/*     */       
/* 276 */       if (var18 && var12 < var23) {
/*     */         
/* 278 */         var23 = var12;
/* 279 */         var22 = 2;
/*     */       } 
/*     */       
/* 282 */       if (var19 && 1.0D - var12 < var23) {
/*     */         
/* 284 */         var23 = 1.0D - var12;
/* 285 */         var22 = 3;
/*     */       } 
/*     */       
/* 288 */       if (var20 && var14 < var23) {
/*     */         
/* 290 */         var23 = var14;
/* 291 */         var22 = 4;
/*     */       } 
/*     */       
/* 294 */       if (var21 && 1.0D - var14 < var23) {
/*     */         
/* 296 */         var23 = 1.0D - var14;
/* 297 */         var22 = 5;
/*     */       } 
/*     */       
/* 300 */       float var25 = this.rand.nextFloat() * 0.05F + 0.025F;
/* 301 */       float var26 = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F;
/*     */       
/* 303 */       if (var22 == 0) {
/*     */         
/* 305 */         this.motionX = -var25;
/* 306 */         this.motionY = this.motionZ = var26;
/*     */       } 
/*     */       
/* 309 */       if (var22 == 1) {
/*     */         
/* 311 */         this.motionX = var25;
/* 312 */         this.motionY = this.motionZ = var26;
/*     */       } 
/*     */       
/* 315 */       if (var22 == 2) {
/*     */         
/* 317 */         this.motionY = -var25;
/* 318 */         this.motionX = this.motionZ = var26;
/*     */       } 
/*     */       
/* 321 */       if (var22 == 3) {
/*     */         
/* 323 */         this.motionY = var25;
/* 324 */         this.motionX = this.motionZ = var26;
/*     */       } 
/*     */       
/* 327 */       if (var22 == 4) {
/*     */         
/* 329 */         this.motionZ = -var25;
/* 330 */         this.motionY = this.motionX = var26;
/*     */       } 
/*     */       
/* 333 */       if (var22 == 5) {
/*     */         
/* 335 */         this.motionZ = var25;
/* 336 */         this.motionY = this.motionX = var26;
/*     */       } 
/*     */       
/* 339 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 343 */     return false;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXBoreParticles.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */