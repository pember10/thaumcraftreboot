/*     */ package thaumcraft.client.fx.particles;
/*     */ 
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class FXBlockRunes
/*     */   extends EntityFX {
/*     */   double ofx;
/*     */   double ofy;
/*     */   float rotation;
/*     */   int runeIndex;
/*     */   
/*     */   public FXBlockRunes(World world, double d, double d1, double d2, float f1, float f2, float f3, int m) {
/*  16 */     super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  41 */     this.ofx = 0.0D;
/*  42 */     this.ofy = 0.0D;
/*  43 */     this.rotation = 0.0F;
/*  44 */     this.runeIndex = 0; if (f1 == 0.0F)
/*     */       f1 = 1.0F;  this.rotation = (this.rand.nextInt(4) * 90); this.particleRed = f1; this.particleGreen = f2; this.particleBlue = f3; this.particleGravity = 0.0F; this.motionX = this.motionY = this.motionZ = 0.0D; this.particleMaxAge = 3 * m; this.noClip = false; setSize(0.01F, 0.01F); this.prevPosX = this.posX; this.prevPosY = this.posY; this.prevPosZ = this.posZ; this.noClip = true; this.runeIndex = (int)(Math.random() * 16.0D + 224.0D);
/*     */     this.ofx = this.rand.nextFloat() * 0.2D;
/*     */     this.ofy = -0.3D + this.rand.nextFloat() * 0.6D;
/*     */     this.particleScale = (float)(1.0D + this.rand.nextGaussian() * 0.10000000149011612D);
/*  49 */     this.particleAlpha = 0.0F; } public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) { tessellator.draw();
/*  50 */     GL11.glPushMatrix();
/*     */     
/*  52 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, this.particleAlpha / 2.0F);
/*     */     
/*  54 */     this; float var13 = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/*     */     
/*  56 */     this; float var14 = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/*     */     
/*  58 */     this; float var15 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/*     */ 
/*     */     
/*  61 */     GL11.glTranslated(var13, var14, var15);
/*  62 */     GL11.glRotatef(this.rotation, 0.0F, 1.0F, 0.0F);
/*  63 */     GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
/*  64 */     GL11.glTranslated(this.ofx, this.ofy, -0.51D);
/*     */     
/*  66 */     float var8 = (this.runeIndex % 16) / 16.0F;
/*  67 */     float var9 = var8 + 0.0624375F;
/*  68 */     float var10 = 0.375F;
/*  69 */     float var11 = var10 + 0.0624375F;
/*  70 */     float var12 = 0.3F * this.particleScale;
/*     */     
/*  72 */     float var16 = 1.0F;
/*     */     
/*  74 */     tessellator.startDrawingQuads();
/*  75 */     tessellator.setBrightness(240);
/*  76 */     tessellator.setColorRGBA_F(this.particleRed * var16, this.particleGreen * var16, this.particleBlue * var16, this.particleAlpha / 2.0F);
/*     */ 
/*     */     
/*  79 */     tessellator.addVertexWithUV(-0.5D * var12, 0.5D * var12, 0.0D, var9, var11);
/*     */     
/*  81 */     tessellator.addVertexWithUV(0.5D * var12, 0.5D * var12, 0.0D, var9, var10);
/*     */     
/*  83 */     tessellator.addVertexWithUV(0.5D * var12, -0.5D * var12, 0.0D, var8, var10);
/*     */     
/*  85 */     tessellator.addVertexWithUV(-0.5D * var12, -0.5D * var12, 0.0D, var8, var11);
/*     */     
/*  87 */     tessellator.draw();
/*     */     
/*  89 */     GL11.glPopMatrix();
/*  90 */     tessellator.startDrawingQuads(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  96 */     this.prevPosX = this.posX;
/*  97 */     this.prevPosY = this.posY;
/*  98 */     this.prevPosZ = this.posZ;
/*  99 */     float threshold = this.particleMaxAge / 5.0F;
/*     */     
/* 101 */     if (this.particleAge <= threshold) {
/* 102 */       this.particleAlpha = this.particleAge / threshold;
/*     */     } else {
/* 104 */       this.particleAlpha = (this.particleMaxAge - this.particleAge) / this.particleMaxAge;
/*     */     } 
/*     */     
/* 107 */     if (this.particleAge++ >= this.particleMaxAge) {
/* 108 */       setDead();
/*     */     }
/*     */     
/* 111 */     this.motionY -= 0.04D * this.particleGravity;
/*     */     
/* 113 */     this.posX += this.motionX;
/* 114 */     this.posY += this.motionY;
/* 115 */     this.posZ += this.motionZ;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGravity(float value) {
/* 120 */     this.particleGravity = value;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXBlockRunes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */