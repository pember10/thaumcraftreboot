/*    */ package thaumcraft.client.fx.particles;
/*    */ 
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.world.World;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FXSpark
/*    */   extends EntityFX
/*    */ {
/*    */   int particle;
/*    */   boolean flip;
/*    */   
/*    */   public FXSpark(World world, double d, double d1, double d2, float f) {
/* 17 */     super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 32 */     this.particle = 0;
/* 33 */     this.flip = false; this.particleRed = 1.0F; this.particleGreen = 1.0F; this.particleBlue = 1.0F; this.particleGravity = 0.0F; this.motionX = this.motionY = this.motionZ = 0.0D;
/*    */     this.particleScale = f;
/*    */     this.particleMaxAge = 5 + world.rand.nextInt(5);
/*    */     this.noClip = false;
/*    */     setSize(0.01F, 0.01F);
/*    */     this.particle = world.rand.nextInt(3) * 8;
/* 39 */     this.flip = world.rand.nextBoolean(); } public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) { GL11.glColor4f(1.0F, 1.0F, 1.0F, this.particleAlpha);
/* 40 */     int part = this.particle + (int)(this.particleAge / this.particleMaxAge * 7.0F);
/*    */     
/* 42 */     float var8 = (part % 8) / 8.0F;
/* 43 */     float var9 = var8 + 0.125F;
/* 44 */     float var10 = (part / 8) / 8.0F;
/* 45 */     float var11 = var10 + 0.125F;
/* 46 */     float var12 = this.particleScale;
/* 47 */     if (this.flip) {
/* 48 */       float t = var8;
/* 49 */       var8 = var9;
/* 50 */       var9 = t;
/*    */     } 
/* 52 */     float var13 = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/* 53 */     float var14 = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/* 54 */     float var15 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/*    */     
/* 56 */     tessellator.setBrightness(getBrightnessForRender(f));
/*    */     
/* 58 */     tessellator.setColorRGBA_F(this.particleRed, this.particleGreen, this.particleBlue, this.particleAlpha);
/* 59 */     tessellator.addVertexWithUV((var13 - f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 - f3 * var12 - f5 * var12), var9, var11);
/*    */ 
/*    */ 
/*    */     
/* 63 */     tessellator.addVertexWithUV((var13 - f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 - f3 * var12 + f5 * var12), var9, var10);
/*    */ 
/*    */ 
/*    */     
/* 67 */     tessellator.addVertexWithUV((var13 + f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 + f3 * var12 + f5 * var12), var8, var10);
/*    */ 
/*    */ 
/*    */     
/* 71 */     tessellator.addVertexWithUV((var13 + f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 + f3 * var12 - f5 * var12), var8, var11); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFXLayer() {
/* 80 */     return 2;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 86 */     this.prevPosX = this.posX;
/* 87 */     this.prevPosY = this.posY;
/* 88 */     this.prevPosZ = this.posZ;
/*    */     
/* 90 */     if (this.particleAge++ >= this.particleMaxAge)
/* 91 */       setDead(); 
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXSpark.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */