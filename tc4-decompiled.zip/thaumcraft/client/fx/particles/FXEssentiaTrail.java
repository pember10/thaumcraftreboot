/*     */ package thaumcraft.client.fx.particles;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class FXEssentiaTrail
/*     */   extends EntityFX
/*     */ {
/*     */   private double targetX;
/*     */   private double targetY;
/*     */   private double targetZ;
/*  19 */   private int count = 0;
/*     */   
/*     */   public int particle;
/*     */   
/*     */   public FXEssentiaTrail(World par1World, double par2, double par4, double par6, double tx, double ty, double tz, int count, int color, float scale) {
/*  24 */     super(par1World, par2, par4, par6, 0.0D, 0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     this.particle = 24;
/*     */     this.particleRed = this.particleGreen = this.particleBlue = 0.6F;
/*     */     this.particleScale = (MathHelper.sin(count / 2.0F) * 0.1F + 1.0F) * scale;
/*     */     this.count = count;
/*     */     this.targetX = tx;
/*     */     this.targetY = ty;
/*     */     this.targetZ = tz;
/*     */     double dx = tx - this.posX;
/*     */     double dy = ty - this.posY;
/*     */     double dz = tz - this.posZ;
/*     */     int base = (int)(MathHelper.sqrt_double(dx * dx + dy * dy + dz * dz) * 30.0F);
/*     */     if (base < 1)
/*     */       base = 1; 
/*     */     this.particleMaxAge = base / 2 + this.rand.nextInt(base);
/*     */     this.motionX = (MathHelper.sin(count / 4.0F) * 0.015F) + this.rand.nextGaussian() * 0.0020000000949949026D;
/*     */     this.motionY = (0.1F + MathHelper.sin(count / 3.0F) * 0.01F);
/*     */     this.motionZ = (MathHelper.sin(count / 2.0F) * 0.015F) + this.rand.nextGaussian() * 0.0020000000949949026D;
/*     */     Color c = new Color(color);
/*     */     float mr = c.getRed() / 255.0F * 0.2F;
/*     */     float mg = c.getGreen() / 255.0F * 0.2F;
/*     */     float mb = c.getBlue() / 255.0F * 0.2F;
/*     */     this.particleRed = c.getRed() / 255.0F - mr + this.rand.nextFloat() * mr;
/*     */     this.particleGreen = c.getGreen() / 255.0F - mg + this.rand.nextFloat() * mg;
/*     */     this.particleBlue = c.getBlue() / 255.0F - mb + this.rand.nextFloat() * mb;
/*     */     this.particleGravity = 0.2F;
/*     */     this.noClip = false;
/*     */     try {
/*     */       EntityLivingBase renderentity = (FMLClientHandler.instance().getClient()).renderViewEntity;
/*     */       int visibleDistance = 64;
/*     */       if (!(FMLClientHandler.instance().getClient()).gameSettings.fancyGraphics)
/*     */         visibleDistance = 32; 
/*     */       if (renderentity.getDistance(this.posX, this.posY, this.posZ) > visibleDistance)
/*     */         this.particleMaxAge = 0; 
/*     */     } catch (Exception e) {}
/*     */   }
/*     */   
/*     */   public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) {
/*     */     float t2 = 0.5625F;
/*     */     float t3 = 0.625F;
/*     */     float t4 = 0.0625F;
/*     */     float t5 = 0.125F;
/*     */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
/*     */     int part = this.particle + this.particleAge % 16;
/*     */     float s = MathHelper.sin((this.particleAge - this.count) / 5.0F) * 0.25F + 1.0F;
/*     */     float var12 = 0.1F * this.particleScale * s;
/*     */     float var13 = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/*     */     float var14 = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/*     */     float var15 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/*     */     float var16 = 1.0F;
/*     */     tessellator.setBrightness(240);
/*     */     tessellator.setColorRGBA_F(this.particleRed * var16, this.particleGreen * var16, this.particleBlue * var16, 0.5F);
/*     */     tessellator.addVertexWithUV((var13 - f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 - f3 * var12 - f5 * var12), t2, t5);
/*     */     tessellator.addVertexWithUV((var13 - f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 - f3 * var12 + f5 * var12), t3, t5);
/*     */     tessellator.addVertexWithUV((var13 + f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 + f3 * var12 + f5 * var12), t3, t4);
/*     */     tessellator.addVertexWithUV((var13 + f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 + f3 * var12 - f5 * var12), t2, t4);
/*     */   }
/*     */   
/*     */   public int getFXLayer() {
/*     */     return 1;
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*     */     this.prevPosX = this.posX;
/*     */     this.prevPosY = this.posY;
/*     */     this.prevPosZ = this.posZ;
/*     */     if (this.particleAge++ >= this.particleMaxAge) {
/*     */       setDead();
/*     */       return;
/*     */     } 
/*     */     this.motionY += 0.01D * this.particleGravity;
/*     */     if (!this.noClip)
/*     */       pushOutOfBlocks(this.posX, this.posY, this.posZ); 
/*     */     moveEntity(this.motionX, this.motionY, this.motionZ);
/*     */     this.motionX *= 0.985D;
/*     */     this.motionY *= 0.985D;
/*     */     this.motionZ *= 0.985D;
/*     */     this.motionX = MathHelper.clamp_float((float)this.motionX, -0.05F, 0.05F);
/*     */     this.motionY = MathHelper.clamp_float((float)this.motionY, -0.05F, 0.05F);
/*     */     this.motionZ = MathHelper.clamp_float((float)this.motionZ, -0.05F, 0.05F);
/*     */     double dx = this.targetX - this.posX;
/*     */     double dy = this.targetY - this.posY;
/*     */     double dz = this.targetZ - this.posZ;
/*     */     double d13 = 0.01D;
/*     */     double d11 = MathHelper.sqrt_double(dx * dx + dy * dy + dz * dz);
/*     */     if (d11 < 2.0D)
/*     */       this.particleScale *= 0.98F; 
/*     */     if (this.particleScale < 0.2F) {
/*     */       setDead();
/*     */       return;
/*     */     } 
/*     */     dx /= d11;
/*     */     dy /= d11;
/*     */     dz /= d11;
/*     */     this.motionX += dx * d13 / Math.min(1.0D, d11);
/*     */     this.motionY += dy * d13 / Math.min(1.0D, d11);
/*     */     this.motionZ += dz * d13 / Math.min(1.0D, d11);
/*     */   }
/*     */   
/*     */   public void setGravity(float value) {
/*     */     this.particleGravity = value;
/*     */   }
/*     */   
/*     */   protected boolean pushOutOfBlocks(double par1, double par3, double par5) {
/*     */     int var7 = MathHelper.floor_double(par1);
/*     */     int var8 = MathHelper.floor_double(par3);
/*     */     int var9 = MathHelper.floor_double(par5);
/*     */     double var10 = par1 - var7;
/*     */     double var12 = par3 - var8;
/*     */     double var14 = par5 - var9;
/*     */     if (!this.worldObj.isAirBlock(var7, var8, var9) && this.worldObj.isBlockNormalCubeDefault(var7, var8, var9, true) && !this.worldObj.isAnyLiquid(this.boundingBox)) {
/*     */       boolean var16 = !this.worldObj.isBlockNormalCubeDefault(var7 - 1, var8, var9, true);
/*     */       boolean var17 = !this.worldObj.isBlockNormalCubeDefault(var7 + 1, var8, var9, true);
/*     */       boolean var18 = !this.worldObj.isBlockNormalCubeDefault(var7, var8 - 1, var9, true);
/*     */       boolean var19 = !this.worldObj.isBlockNormalCubeDefault(var7, var8 + 1, var9, true);
/*     */       boolean var20 = !this.worldObj.isBlockNormalCubeDefault(var7, var8, var9 - 1, true);
/*     */       boolean var21 = !this.worldObj.isBlockNormalCubeDefault(var7, var8, var9 + 1, true);
/*     */       byte var22 = -1;
/*     */       double var23 = 9999.0D;
/*     */       if (var16 && var10 < var23) {
/*     */         var23 = var10;
/*     */         var22 = 0;
/*     */       } 
/*     */       if (var17 && 1.0D - var10 < var23) {
/*     */         var23 = 1.0D - var10;
/*     */         var22 = 1;
/*     */       } 
/*     */       if (var18 && var12 < var23) {
/*     */         var23 = var12;
/*     */         var22 = 2;
/*     */       } 
/*     */       if (var19 && 1.0D - var12 < var23) {
/*     */         var23 = 1.0D - var12;
/*     */         var22 = 3;
/*     */       } 
/*     */       if (var20 && var14 < var23) {
/*     */         var23 = var14;
/*     */         var22 = 4;
/*     */       } 
/*     */       if (var21 && 1.0D - var14 < var23) {
/*     */         var23 = 1.0D - var14;
/*     */         var22 = 5;
/*     */       } 
/*     */       float var25 = this.rand.nextFloat() * 0.05F + 0.025F;
/*     */       float var26 = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F;
/*     */       if (var22 == 0) {
/*     */         this.motionX = -var25;
/*     */         this.motionY = this.motionZ = var26;
/*     */       } 
/*     */       if (var22 == 1) {
/*     */         this.motionX = var25;
/*     */         this.motionY = this.motionZ = var26;
/*     */       } 
/*     */       if (var22 == 2) {
/*     */         this.motionY = -var25;
/*     */         this.motionX = this.motionZ = var26;
/*     */       } 
/*     */       if (var22 == 3) {
/*     */         this.motionY = var25;
/*     */         this.motionX = this.motionZ = var26;
/*     */       } 
/*     */       if (var22 == 4) {
/*     */         this.motionZ = -var25;
/*     */         this.motionY = this.motionX = var26;
/*     */       } 
/*     */       if (var22 == 5) {
/*     */         this.motionZ = var25;
/*     */         this.motionY = this.motionX = var26;
/*     */       } 
/*     */       return true;
/*     */     } 
/*     */     return false;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXEssentiaTrail.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */