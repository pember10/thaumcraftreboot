/*     */ package thaumcraft.client.fx.particles;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FXVent
/*     */   extends EntityFX
/*     */ {
/*     */   float psm;
/*     */   
/*     */   public FXVent(World par1World, double par2, double par4, double par6, double par8, double par10, double par12, int color) {
/*  22 */     super(par1World, par2, par4, par6, par8, par10, par12);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     this.psm = 1.0F; setSize(0.02F, 0.02F); this.particleScale = this.rand.nextFloat() * 0.1F + 0.05F; this.motionX = par8; this.motionY = par10; this.motionZ = par12; this.noClip = true; Color c = new Color(color); this.particleRed = c.getRed() / 255.0F; this.particleBlue = c.getBlue() / 255.0F; this.particleGreen = c.getGreen() / 255.0F; setHeading(this.motionX, this.motionY, this.motionZ, 0.125F, 5.0F); EntityLivingBase renderentity = (FMLClientHandler.instance().getClient()).renderViewEntity; int visibleDistance = 50; if (!(FMLClientHandler.instance().getClient()).gameSettings.fancyGraphics)
/*     */       visibleDistance = 25;  if (renderentity.getDistance(this.posX, this.posY, this.posZ) > visibleDistance)
/*  49 */       this.particleMaxAge = 0;  this.prevPosX = this.posX; this.prevPosY = this.posY; this.prevPosZ = this.posZ; } public void setScale(float f) { this.particleScale *= f;
/*  50 */     this.psm *= f; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeading(double par1, double par3, double par5, float par7, float par8) {
/*  55 */     float f2 = MathHelper.sqrt_double(par1 * par1 + par3 * par3 + par5 * par5);
/*  56 */     par1 /= f2;
/*  57 */     par3 /= f2;
/*  58 */     par5 /= f2;
/*  59 */     par1 += this.rand.nextGaussian() * (this.rand.nextBoolean() ? -1 : true) * 0.007499999832361937D * par8;
/*  60 */     par3 += this.rand.nextGaussian() * (this.rand.nextBoolean() ? -1 : true) * 0.007499999832361937D * par8;
/*  61 */     par5 += this.rand.nextGaussian() * (this.rand.nextBoolean() ? -1 : true) * 0.007499999832361937D * par8;
/*  62 */     par1 *= par7;
/*  63 */     par3 *= par7;
/*  64 */     par5 *= par7;
/*  65 */     this.motionX = par1;
/*  66 */     this.motionY = par3;
/*  67 */     this.motionZ = par5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  75 */     this.prevPosX = this.posX;
/*  76 */     this.prevPosY = this.posY;
/*  77 */     this.prevPosZ = this.posZ;
/*  78 */     this.particleAge++;
/*  79 */     if (this.particleScale > this.psm)
/*     */     {
/*  81 */       setDead();
/*     */     }
/*     */     
/*  84 */     this.motionY += 0.0025D;
/*  85 */     moveEntity(this.motionX, this.motionY, this.motionZ);
/*  86 */     this.motionX *= 0.8500000190734863D;
/*  87 */     this.motionY *= 0.8500000190734863D;
/*  88 */     this.motionZ *= 0.8500000190734863D;
/*  89 */     if (this.particleScale < this.psm) this.particleScale = (float)(this.particleScale * 1.15D);
/*     */     
/*  91 */     if (this.onGround) {
/*     */       
/*  93 */       this.motionX *= 0.699999988079071D;
/*  94 */       this.motionZ *= 0.699999988079071D;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setRGB(float r, float g, float b) {
/*  99 */     this.particleRed = r;
/* 100 */     this.particleGreen = g;
/* 101 */     this.particleBlue = b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) {
/* 107 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.33F);
/* 108 */     int part = (int)(1.0F + this.particleScale / this.psm * 4.0F);
/* 109 */     float var8 = (part % 16) / 16.0F;
/* 110 */     float var9 = var8 + 0.0624375F;
/* 111 */     float var10 = (part / 16) / 16.0F;
/* 112 */     float var11 = var10 + 0.0624375F;
/* 113 */     float var12 = 0.3F * this.particleScale;
/*     */     
/* 115 */     float var13 = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/* 116 */     float var14 = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/* 117 */     float var15 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/* 118 */     float var16 = 1.0F;
/*     */     
/* 120 */     tessellator.setBrightness(getBrightnessForRender(f));
/* 121 */     float alpha = this.particleAlpha * (this.psm - this.particleScale) / this.psm;
/* 122 */     tessellator.setColorRGBA_F(this.particleRed * var16, this.particleGreen * var16, this.particleBlue * var16, alpha);
/* 123 */     tessellator.addVertexWithUV((var13 - f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 - f3 * var12 - f5 * var12), var9, var11);
/* 124 */     tessellator.addVertexWithUV((var13 - f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 - f3 * var12 + f5 * var12), var9, var10);
/* 125 */     tessellator.addVertexWithUV((var13 + f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 + f3 * var12 + f5 * var12), var8, var10);
/* 126 */     tessellator.addVertexWithUV((var13 + f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 + f3 * var12 - f5 * var12), var8, var11);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFXLayer() {
/* 133 */     return 1;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\particles\FXVent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */