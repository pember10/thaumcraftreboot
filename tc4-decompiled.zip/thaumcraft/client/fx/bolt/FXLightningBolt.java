/*     */ package thaumcraft.client.fx.bolt;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import java.util.Iterator;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.fx.WRVector3;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ 
/*     */ 
/*     */ public class FXLightningBolt
/*     */   extends EntityFX
/*     */ {
/*     */   private int type;
/*     */   private float width;
/*     */   private FXLightningBoltCommon main;
/*     */   
/*     */   public FXLightningBolt(World world, WRVector3 jammervec, WRVector3 targetvec, long seed) {
/*  26 */     super(world, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     this.type = 0;
/*     */     
/* 130 */     this.width = 0.03F; this.main = new FXLightningBoltCommon(world, jammervec, targetvec, seed); setupFromMain(); } public FXLightningBolt(World world, Entity detonator, Entity target, long seed) { super(world, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D); this.type = 0; this.width = 0.03F; this.main = new FXLightningBoltCommon(world, detonator, target, seed); setupFromMain(); } public FXLightningBolt(World world, Entity detonator, Entity target, long seed, int speed) { super(world, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D); this.type = 0; this.width = 0.03F; this.main = new FXLightningBoltCommon(world, detonator, target, seed, speed); setupFromMain(); } public FXLightningBolt(World world, TileEntity detonator, Entity target, long seed) { super(world, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D); this.type = 0; this.width = 0.03F; this.main = new FXLightningBoltCommon(world, detonator, target, seed); setupFromMain(); } public FXLightningBolt(World world, double x1, double y1, double z1, double x, double y, double z, long seed, int duration, float multi) { super(world, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D); this.type = 0; this.width = 0.03F; this.main = new FXLightningBoltCommon(world, x1, y1, z1, x, y, z, seed, duration, multi); setupFromMain(); } public FXLightningBolt(World world, double x1, double y1, double z1, double x, double y, double z, long seed, int duration, float multi, int speed) { super(world, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D); this.type = 0; this.width = 0.03F; this.main = new FXLightningBoltCommon(world, x1, y1, z1, x, y, z, seed, duration, multi, speed); setupFromMain(); } public FXLightningBolt(World world, double x1, double y1, double z1, double x, double y, double z, long seed, int duration) { super(world, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D); this.type = 0; this.width = 0.03F; this.main = new FXLightningBoltCommon(world, x1, y1, z1, x, y, z, seed, duration, 1.0F); setupFromMain(); } private void setupFromMain() { this.particleAge = this.main.particleMaxAge; setPosition(this.main.start.x, this.main.start.y, this.main.start.z); setVelocity(0.0D, 0.0D, 0.0D); } public void defaultFractal() { this.main.defaultFractal(); } public FXLightningBolt(World world, TileEntity detonator, double x, double y, double z, long seed) { super(world, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D); this.type = 0; this.width = 0.03F;
/*     */     this.main = new FXLightningBoltCommon(world, detonator, x, y, z, seed);
/*     */     setupFromMain(); } public void fractal(int splits, float amount, float splitchance, float splitlength, float splitangle) {
/*     */     this.main.fractal(splits, amount, splitchance, splitlength, splitangle);
/*     */   } public void onUpdate() {
/* 135 */     this.main.onUpdate();
/* 136 */     if (this.main.particleAge >= this.main.particleMaxAge)
/* 137 */       setDead();  } public void finalizeBolt() { this.main.finalizeBolt();
/*     */     (FMLClientHandler.instance().getClient()).effectRenderer.addEffect(this); }
/*     */   public void setType(int type) { this.type = type;
/*     */     this.main.type = type; }
/*     */   private static WRVector3 getRelativeViewVector(WRVector3 pos) {
/* 142 */     EntityClientPlayerMP entityClientPlayerMP = (FMLClientHandler.instance().getClient()).thePlayer;
/* 143 */     return new WRVector3(((float)((EntityPlayer)entityClientPlayerMP).posX - pos.x), ((float)((EntityPlayer)entityClientPlayerMP).posY - pos.y), ((float)((EntityPlayer)entityClientPlayerMP).posZ - pos.z));
/*     */   } public void setMultiplier(float m) {
/*     */     this.main.multiplier = m;
/*     */   } public void setWidth(float m) {
/*     */     this.width = m;
/*     */   }
/*     */   private void renderBolt(Tessellator tessellator, float partialframe, float cosyaw, float cospitch, float sinyaw, float cossinpitch, int pass, float mainalpha) {
/* 150 */     WRVector3 playervec = new WRVector3((sinyaw * -cospitch), (-cossinpitch / cosyaw), (cosyaw * cospitch));
/* 151 */     float boltage = (this.main.particleAge >= 0) ? (this.main.particleAge / this.main.particleMaxAge) : 0.0F;
/* 152 */     if (pass == 0) {
/* 153 */       mainalpha = (1.0F - boltage) * 0.4F;
/*     */     } else {
/* 155 */       mainalpha = 1.0F - boltage * 0.5F;
/* 156 */     }  int renderlength = (int)((this.main.particleAge + partialframe + (int)(this.main.length * 3.0F)) / (int)(this.main.length * 3.0F) * this.main.numsegments0);
/* 157 */     for (Iterator<FXLightningBoltCommon.Segment> iterator = this.main.segments.iterator(); iterator.hasNext(); ) {
/*     */       
/* 159 */       FXLightningBoltCommon.Segment rendersegment = iterator.next();
/* 160 */       if (rendersegment.segmentno <= renderlength) {
/*     */         
/* 162 */         float width = this.width * (getRelativeViewVector(rendersegment.startpoint.point).length() / 5.0F + 1.0F) * (1.0F + rendersegment.light) * 0.5F;
/* 163 */         WRVector3 diff1 = WRVector3.crossProduct(playervec, rendersegment.prevdiff).scale(width / rendersegment.sinprev);
/* 164 */         WRVector3 diff2 = WRVector3.crossProduct(playervec, rendersegment.nextdiff).scale(width / rendersegment.sinnext);
/* 165 */         WRVector3 startvec = rendersegment.startpoint.point;
/* 166 */         WRVector3 endvec = rendersegment.endpoint.point;
/* 167 */         float rx1 = (float)(startvec.x - interpPosX);
/* 168 */         float ry1 = (float)(startvec.y - interpPosY);
/* 169 */         float rz1 = (float)(startvec.z - interpPosZ);
/* 170 */         float rx2 = (float)(endvec.x - interpPosX);
/* 171 */         float ry2 = (float)(endvec.y - interpPosY);
/* 172 */         float rz2 = (float)(endvec.z - interpPosZ);
/* 173 */         tessellator.setColorRGBA_F(this.particleRed, this.particleGreen, this.particleBlue, mainalpha * rendersegment.light);
/* 174 */         tessellator.addVertexWithUV((rx2 - diff2.x), (ry2 - diff2.y), (rz2 - diff2.z), 0.5D, 0.0D);
/* 175 */         tessellator.addVertexWithUV((rx1 - diff1.x), (ry1 - diff1.y), (rz1 - diff1.z), 0.5D, 0.0D);
/* 176 */         tessellator.addVertexWithUV((rx1 + diff1.x), (ry1 + diff1.y), (rz1 + diff1.z), 0.5D, 1.0D);
/* 177 */         tessellator.addVertexWithUV((rx2 + diff2.x), (ry2 + diff2.y), (rz2 + diff2.z), 0.5D, 1.0D);
/* 178 */         if (rendersegment.next == null) {
/*     */           
/* 180 */           WRVector3 roundend = rendersegment.endpoint.point.copy().add(rendersegment.diff.copy().normalize().scale(width));
/* 181 */           float rx3 = (float)(roundend.x - interpPosX);
/* 182 */           float ry3 = (float)(roundend.y - interpPosY);
/* 183 */           float rz3 = (float)(roundend.z - interpPosZ);
/* 184 */           tessellator.addVertexWithUV((rx3 - diff2.x), (ry3 - diff2.y), (rz3 - diff2.z), 0.0D, 0.0D);
/* 185 */           tessellator.addVertexWithUV((rx2 - diff2.x), (ry2 - diff2.y), (rz2 - diff2.z), 0.5D, 0.0D);
/* 186 */           tessellator.addVertexWithUV((rx2 + diff2.x), (ry2 + diff2.y), (rz2 + diff2.z), 0.5D, 1.0D);
/* 187 */           tessellator.addVertexWithUV((rx3 + diff2.x), (ry3 + diff2.y), (rz3 + diff2.z), 0.0D, 1.0D);
/*     */         } 
/* 189 */         if (rendersegment.prev == null) {
/*     */           
/* 191 */           WRVector3 roundend = rendersegment.startpoint.point.copy().sub(rendersegment.diff.copy().normalize().scale(width));
/* 192 */           float rx3 = (float)(roundend.x - interpPosX);
/* 193 */           float ry3 = (float)(roundend.y - interpPosY);
/* 194 */           float rz3 = (float)(roundend.z - interpPosZ);
/* 195 */           tessellator.addVertexWithUV((rx1 - diff1.x), (ry1 - diff1.y), (rz1 - diff1.z), 0.5D, 0.0D);
/* 196 */           tessellator.addVertexWithUV((rx3 - diff1.x), (ry3 - diff1.y), (rz3 - diff1.z), 0.0D, 0.0D);
/* 197 */           tessellator.addVertexWithUV((rx3 + diff1.x), (ry3 + diff1.y), (rz3 + diff1.z), 0.0D, 1.0D);
/* 198 */           tessellator.addVertexWithUV((rx1 + diff1.x), (ry1 + diff1.y), (rz1 + diff1.z), 0.5D, 1.0D);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderParticle(Tessellator tessellator, float partialframe, float cosyaw, float cospitch, float sinyaw, float sinsinpitch, float cossinpitch) {
/* 209 */     EntityClientPlayerMP entityClientPlayerMP = (FMLClientHandler.instance().getClient()).thePlayer;
/* 210 */     int visibleDistance = 100;
/* 211 */     if (!(FMLClientHandler.instance().getClient()).gameSettings.fancyGraphics) visibleDistance = 50; 
/* 212 */     if (entityClientPlayerMP.getDistance(this.posX, this.posY, this.posZ) > visibleDistance)
/*     */       return; 
/* 214 */     tessellator.draw();
/* 215 */     GL11.glPushMatrix();
/*     */     
/* 217 */     GL11.glDepthMask(false);
/* 218 */     GL11.glEnable(3042);
/*     */     
/* 220 */     this.particleRed = this.particleGreen = this.particleBlue = 1.0F;
/* 221 */     float ma = 1.0F;
/*     */     
/* 223 */     switch (this.type) { case 0:
/* 224 */         this.particleRed = 0.6F; this.particleGreen = 0.3F; this.particleBlue = 0.6F; GL11.glBlendFunc(770, 1); break;
/* 225 */       case 1: this.particleRed = 0.6F; this.particleGreen = 0.6F; this.particleBlue = 0.1F; GL11.glBlendFunc(770, 1); break;
/* 226 */       case 2: this.particleRed = 0.1F; this.particleGreen = 0.1F; this.particleBlue = 0.6F; GL11.glBlendFunc(770, 1); break;
/* 227 */       case 3: this.particleRed = 0.1F; this.particleGreen = 1.0F; this.particleBlue = 0.1F; GL11.glBlendFunc(770, 1); break;
/* 228 */       case 4: this.particleRed = 0.6F; this.particleGreen = 0.1F; this.particleBlue = 0.1F; GL11.glBlendFunc(770, 1); break;
/* 229 */       case 5: this.particleRed = 0.6F; this.particleGreen = 0.2F; this.particleBlue = 0.6F; GL11.glBlendFunc(770, 771); break;
/* 230 */       case 6: this.particleRed = 0.75F; this.particleGreen = 1.0F; this.particleBlue = 1.0F; ma = 0.2F; GL11.glBlendFunc(770, 771);
/*     */         break; }
/*     */     
/* 233 */     UtilsFX.bindTexture("textures/misc/p_large.png");
/* 234 */     tessellator.startDrawingQuads();
/* 235 */     tessellator.setBrightness(15728880);
/* 236 */     renderBolt(tessellator, partialframe, cosyaw, cospitch, sinyaw, cossinpitch, 0, ma);
/* 237 */     tessellator.draw();
/*     */     
/* 239 */     switch (this.type) { case 0:
/* 240 */         this.particleRed = 1.0F; this.particleGreen = 0.6F; this.particleBlue = 1.0F; break;
/* 241 */       case 1: this.particleRed = 1.0F; this.particleGreen = 1.0F; this.particleBlue = 0.1F; break;
/* 242 */       case 2: this.particleRed = 0.1F; this.particleGreen = 0.1F; this.particleBlue = 1.0F; break;
/* 243 */       case 3: this.particleRed = 0.1F; this.particleGreen = 0.6F; this.particleBlue = 0.1F; break;
/* 244 */       case 4: this.particleRed = 1.0F; this.particleGreen = 0.1F; this.particleBlue = 0.1F; break;
/* 245 */       case 5: this.particleRed = 0.0F; this.particleGreen = 0.0F; this.particleBlue = 0.0F; GL11.glBlendFunc(770, 771); break;
/* 246 */       case 6: this.particleRed = 0.75F; this.particleGreen = 1.0F; this.particleBlue = 1.0F; ma = 0.2F; GL11.glBlendFunc(770, 771);
/*     */         break; }
/*     */     
/* 249 */     UtilsFX.bindTexture("textures/misc/p_small.png");
/* 250 */     tessellator.startDrawingQuads();
/* 251 */     tessellator.setBrightness(15728880);
/* 252 */     renderBolt(tessellator, partialframe, cosyaw, cospitch, sinyaw, cossinpitch, 1, ma);
/* 253 */     tessellator.draw();
/*     */     
/* 255 */     GL11.glDisable(3042);
/* 256 */     GL11.glDepthMask(true);
/* 257 */     GL11.glPopMatrix();
/*     */     
/* 259 */     (Minecraft.getMinecraft()).renderEngine.bindTexture(UtilsFX.getParticleTexture());
/*     */     
/* 261 */     tessellator.startDrawingQuads();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderPass() {
/* 266 */     return 2;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\bolt\FXLightningBolt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */