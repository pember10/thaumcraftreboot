/*     */ package thaumcraft.client.fx.other;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ 
/*     */ public class FXBlockWard extends EntityFX {
/*     */   ForgeDirection side;
/*     */   int rotation;
/*     */   float sx;
/*     */   float sy;
/*     */   float sz;
/*     */   
/*  19 */   public FXBlockWard(World world, double d, double d1, double d2, ForgeDirection side, float f, float f1, float f2) { super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  43 */     this.rotation = 0;
/*  44 */     this.sx = 0.0F;
/*  45 */     this.sy = 0.0F;
/*  46 */     this.sz = 0.0F; this.side = side; this.particleGravity = 0.0F; this.motionX = this.motionY = this.motionZ = 0.0D; this.particleMaxAge = 12 + this.rand.nextInt(5); this.noClip = false; setSize(0.01F, 0.01F); this.prevPosX = this.posX; this.prevPosY = this.posY; this.prevPosZ = this.posZ; this.noClip = true; this.particleScale = (float)(1.4D + this.rand.nextGaussian() * 0.30000001192092896D); this.rotation = this.rand.nextInt(360); this.sx = MathHelper.clamp_float(f - 0.6F + this.rand.nextFloat() * 0.2F, -0.4F, 0.4F); this.sy = MathHelper.clamp_float(f1 - 0.6F + this.rand.nextFloat() * 0.2F, -0.4F, 0.4F); this.sz = MathHelper.clamp_float(f2 - 0.6F + this.rand.nextFloat() * 0.2F, -0.4F, 0.4F); if (side.offsetX != 0)
/*     */       this.sx = 0.0F; 
/*     */     if (side.offsetY != 0)
/*     */       this.sy = 0.0F; 
/*     */     if (side.offsetZ != 0)
/*  51 */       this.sz = 0.0F;  } public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) { tessellator.draw();
/*  52 */     GL11.glPushMatrix();
/*  53 */     float fade = (this.particleAge + f) / this.particleMaxAge;
/*  54 */     int frame = Math.min(15, (int)(15.0F * fade));
/*  55 */     UtilsFX.bindTexture("textures/models/hemis" + frame + ".png");
/*     */     
/*  57 */     GL11.glDepthMask(false);
/*  58 */     GL11.glEnable(3042);
/*  59 */     GL11.glBlendFunc(770, 1);
/*     */     
/*  61 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, this.particleAlpha / 2.0F);
/*     */     
/*  63 */     this; float var13 = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/*  64 */     this; float var14 = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/*  65 */     this; float var15 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/*     */     
/*  67 */     GL11.glTranslated((var13 + this.sx), (var14 + this.sy), (var15 + this.sz));
/*     */     
/*  69 */     GL11.glRotatef(90.0F, this.side.offsetY, -this.side.offsetX, this.side.offsetZ);
/*  70 */     GL11.glRotatef(this.rotation, 0.0F, 0.0F, 1.0F);
/*  71 */     if (this.side.offsetZ > 0) {
/*  72 */       GL11.glTranslated(0.0D, 0.0D, 0.5049999952316284D);
/*  73 */       GL11.glRotatef(180.0F, 0.0F, -1.0F, 0.0F);
/*     */     } else {
/*  75 */       GL11.glTranslated(0.0D, 0.0D, -0.5049999952316284D);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  80 */     float var12 = this.particleScale;
/*     */     
/*  82 */     float var16 = 1.0F;
/*     */     
/*  84 */     tessellator.startDrawingQuads();
/*  85 */     tessellator.setBrightness(240);
/*  86 */     tessellator.setColorRGBA_F(this.particleRed * var16, this.particleGreen * var16, this.particleBlue * var16, this.particleAlpha / 2.0F);
/*     */     
/*  88 */     tessellator.addVertexWithUV(-0.5D * var12, 0.5D * var12, 0.0D, 0.0D, 1.0D);
/*  89 */     tessellator.addVertexWithUV(0.5D * var12, 0.5D * var12, 0.0D, 1.0D, 1.0D);
/*  90 */     tessellator.addVertexWithUV(0.5D * var12, -0.5D * var12, 0.0D, 1.0D, 0.0D);
/*  91 */     tessellator.addVertexWithUV(-0.5D * var12, -0.5D * var12, 0.0D, 0.0D, 0.0D);
/*  92 */     tessellator.draw();
/*     */     
/*  94 */     GL11.glDisable(3042);
/*  95 */     GL11.glDepthMask(true);
/*     */     
/*  97 */     GL11.glPopMatrix();
/*  98 */     (Minecraft.getMinecraft()).renderEngine.bindTexture(UtilsFX.getParticleTexture());
/*  99 */     tessellator.startDrawingQuads(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 106 */     this.prevPosX = this.posX;
/* 107 */     this.prevPosY = this.posY;
/* 108 */     this.prevPosZ = this.posZ;
/* 109 */     float threshold = this.particleMaxAge / 5.0F;
/* 110 */     if (this.particleAge <= threshold) {
/* 111 */       this.particleAlpha = this.particleAge / threshold;
/*     */     } else {
/* 113 */       this.particleAlpha = (this.particleMaxAge - this.particleAge) / this.particleMaxAge;
/*     */     } 
/* 115 */     if (this.particleAge++ >= this.particleMaxAge)
/*     */     {
/* 117 */       setDead();
/*     */     }
/*     */     
/* 120 */     this.motionY -= 0.04D * this.particleGravity;
/*     */     
/* 122 */     this.posX += this.motionX;
/* 123 */     this.posY += this.motionY;
/* 124 */     this.posZ += this.motionZ;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGravity(float value) {
/* 129 */     this.particleGravity = value;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\other\FXBlockWard.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */