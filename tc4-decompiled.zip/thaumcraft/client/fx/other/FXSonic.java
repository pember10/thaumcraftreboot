/*     */ package thaumcraft.client.fx.other;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.model.AdvancedModelLoader;
/*     */ import net.minecraftforge.client.model.IModelCustom;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ 
/*     */ public class FXSonic extends EntityFX {
/*     */   Entity target;
/*     */   float yaw;
/*     */   float pitch;
/*     */   private IModelCustom model;
/*     */   
/*     */   public FXSonic(World world, double d, double d1, double d2, Entity target, int age) {
/*  22 */     super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  50 */     this.target = null;
/*  51 */     this.yaw = 0.0F;
/*  52 */     this.pitch = 0.0F; this.particleRed = 1.0F; this.particleGreen = 1.0F; this.particleBlue = 1.0F; this.particleGravity = 0.0F; this.motionX = this.motionY = this.motionZ = 0.0D; this.particleMaxAge = age + this.rand.nextInt(age / 2); this.noClip = false; setSize(0.01F, 0.01F); this.noClip = true; this.particleScale = 1.0F; this.target = target; this.yaw = target.getRotationYawHead(); this.pitch = target.rotationPitch;
/*     */     this.prevPosX = this.posX = target.posX;
/*     */     this.prevPosY = this.posY = target.posY + target.getEyeHeight();
/*  55 */     this.prevPosZ = this.posZ = target.posZ; } private static final ResourceLocation MODEL = new ResourceLocation("thaumcraft", "textures/models/hemis.obj");
/*     */   
/*     */   public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) {
/*  58 */     tessellator.draw();
/*  59 */     GL11.glPushMatrix();
/*  60 */     GL11.glDisable(2884);
/*     */     
/*  62 */     GL11.glEnable(3042);
/*  63 */     GL11.glBlendFunc(770, 1);
/*     */     
/*  65 */     if (this.model == null) {
/*  66 */       this.model = AdvancedModelLoader.loadModel(MODEL);
/*     */     }
/*     */     
/*  69 */     float fade = (this.particleAge + f) / this.particleMaxAge;
/*     */     
/*  71 */     float xx = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/*  72 */     float yy = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/*  73 */     float zz = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/*  74 */     GL11.glTranslated(xx, yy, zz);
/*  75 */     float b = 1.0F;
/*  76 */     int frame = Math.min(15, (int)(14.0F * fade) + 1);
/*  77 */     UtilsFX.bindTexture("textures/models/ripple" + frame + ".png");
/*  78 */     b = 0.5F;
/*  79 */     int i = 220;
/*  80 */     int j = i % 65536;
/*  81 */     int k = i / 65536;
/*  82 */     OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, j / 1.0F, k / 1.0F);
/*  83 */     GL11.glRotatef(-this.yaw, 0.0F, 1.0F, 0.0F);
/*  84 */     GL11.glRotatef(this.pitch, 1.0F, 0.0F, 0.0F);
/*  85 */     GL11.glTranslated(0.0D, 0.0D, (2.0F * this.target.height + this.target.width / 2.0F));
/*  86 */     GL11.glScaled(0.25D * this.target.height, 0.25D * this.target.height, (-1.0F * this.target.height));
/*  87 */     GL11.glColor4f(b, b, b, 1.0F);
/*  88 */     this.model.renderAll();
/*     */     
/*  90 */     GL11.glDisable(3042);
/*     */     
/*  92 */     GL11.glEnable(2884);
/*  93 */     GL11.glPopMatrix();
/*     */     
/*  95 */     (Minecraft.getMinecraft()).renderEngine.bindTexture(UtilsFX.getParticleTexture());
/*  96 */     tessellator.startDrawingQuads();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 102 */     this.prevPosX = this.posX;
/* 103 */     this.prevPosY = this.posY;
/* 104 */     this.prevPosZ = this.posZ;
/*     */     
/* 106 */     if (this.particleAge++ >= this.particleMaxAge) {
/* 107 */       setDead();
/*     */     }
/*     */     
/* 110 */     this.posX = this.target.posX;
/* 111 */     this.posY = this.target.posY + this.target.getEyeHeight();
/* 112 */     this.posZ = this.target.posZ;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\other\FXSonic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */