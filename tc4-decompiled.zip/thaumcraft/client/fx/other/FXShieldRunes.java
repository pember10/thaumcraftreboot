/*     */ package thaumcraft.client.fx.other;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.model.AdvancedModelLoader;
/*     */ import net.minecraftforge.client.model.IModelCustom;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ 
/*     */ public class FXShieldRunes
/*     */   extends EntityFX {
/*     */   Entity target;
/*     */   float yaw;
/*     */   float pitch;
/*     */   private IModelCustom model;
/*     */   
/*     */   public FXShieldRunes(World world, double d, double d1, double d2, Entity target, int age, float yaw, float pitch) {
/*  23 */     super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  50 */     this.target = null;
/*  51 */     this.yaw = 0.0F;
/*  52 */     this.pitch = 0.0F; this.particleRed = 1.0F; this.particleGreen = 1.0F; this.particleBlue = 1.0F; this.particleGravity = 0.0F; this.motionX = this.motionY = this.motionZ = 0.0D; this.particleMaxAge = age + this.rand.nextInt(age / 2); this.noClip = false; setSize(0.01F, 0.01F); this.noClip = true; this.particleScale = 1.0F; this.target = target; this.yaw = yaw; this.pitch = pitch;
/*     */     this.prevPosX = this.posX = target.posX;
/*     */     this.prevPosY = this.posY = (target.boundingBox.minY + target.boundingBox.maxY) / 2.0D;
/*  55 */     this.prevPosZ = this.posZ = target.posZ; } private static final ResourceLocation MODEL = new ResourceLocation("thaumcraft", "textures/models/hemis.obj");
/*     */   
/*     */   public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) {
/*  58 */     tessellator.draw();
/*  59 */     GL11.glPushMatrix();
/*  60 */     GL11.glDisable(2884);
/*     */     
/*  62 */     GL11.glEnable(3042);
/*  63 */     GL11.glBlendFunc(770, 1);
/*     */     
/*  65 */     if (this.model == null) {
/*  66 */       this.model = AdvancedModelLoader.loadModel(MODEL);
/*     */     }
/*     */     
/*  69 */     float fade = (this.particleAge + f) / this.particleMaxAge;
/*     */     
/*  71 */     float xx = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/*  72 */     float yy = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/*  73 */     float zz = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/*  74 */     GL11.glTranslated(xx, yy, zz);
/*  75 */     float b = 1.0F;
/*  76 */     int frame = Math.min(15, (int)(14.0F * fade) + 1);
/*  77 */     if (this.target instanceof net.minecraft.entity.monster.EntityMob && !(this.target instanceof thaumcraft.common.entities.monster.EntityCultist)) {
/*  78 */       UtilsFX.bindTexture("textures/models/ripple" + frame + ".png");
/*  79 */       b = 0.5F;
/*     */     } else {
/*  81 */       UtilsFX.bindTexture("textures/models/hemis" + frame + ".png");
/*     */     } 
/*  83 */     int i = 220;
/*  84 */     int j = i % 65536;
/*  85 */     int k = i / 65536;
/*  86 */     OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, j / 1.0F, k / 1.0F);
/*  87 */     GL11.glRotatef(180.0F - this.yaw, 0.0F, 1.0F, 0.0F);
/*  88 */     GL11.glRotatef(-this.pitch, 1.0F, 0.0F, 0.0F);
/*  89 */     GL11.glScaled(0.4D * this.target.height, 0.4D * this.target.height, 0.4D * this.target.height);
/*  90 */     GL11.glColor4f(b, b, b, Math.min(1.0F, (1.0F - fade) * 3.0F));
/*  91 */     this.model.renderAll();
/*     */     
/*  93 */     GL11.glDisable(3042);
/*     */     
/*  95 */     GL11.glEnable(2884);
/*  96 */     GL11.glPopMatrix();
/*     */     
/*  98 */     (Minecraft.getMinecraft()).renderEngine.bindTexture(UtilsFX.getParticleTexture());
/*  99 */     tessellator.startDrawingQuads();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 105 */     this.prevPosX = this.posX;
/* 106 */     this.prevPosY = this.posY;
/* 107 */     this.prevPosZ = this.posZ;
/*     */     
/* 109 */     if (this.particleAge++ >= this.particleMaxAge) {
/* 110 */       setDead();
/*     */     }
/*     */     
/* 113 */     this.posX = this.target.posX;
/* 114 */     this.posY = (this.target.boundingBox.minY + this.target.boundingBox.maxY) / 2.0D;
/* 115 */     this.posZ = this.target.posZ;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\other\FXShieldRunes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */