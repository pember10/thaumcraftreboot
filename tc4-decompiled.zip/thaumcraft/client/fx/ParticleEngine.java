/*     */ package thaumcraft.client.fx;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.Callable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.crash.CrashReport;
/*     */ import net.minecraft.crash.CrashReportCategory;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ReportedException;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.RenderWorldLastEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParticleEngine
/*     */ {
/*  32 */   public static ParticleEngine instance = new ParticleEngine();
/*     */   
/*  34 */   public static final ResourceLocation particleTexture = new ResourceLocation("thaumcraft", "textures/misc/particles.png");
/*     */   
/*  36 */   public static final ResourceLocation particleTexture2 = new ResourceLocation("thaumcraft", "textures/misc/particles2.png");
/*     */ 
/*     */   
/*     */   protected World worldObj;
/*     */   
/*  41 */   private HashMap<Integer, ArrayList<EntityFX>>[] particles = new HashMap[] { new HashMap<Object, Object>(), new HashMap<Object, Object>(), new HashMap<Object, Object>(), new HashMap<Object, Object>() };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private Random rand = new Random();
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent
/*     */   public void onRenderWorldLast(RenderWorldLastEvent event) {
/*  52 */     float frame = event.partialTicks;
/*  53 */     EntityClientPlayerMP entityClientPlayerMP = (Minecraft.getMinecraft()).thePlayer;
/*  54 */     TextureManager renderer = (Minecraft.getMinecraft()).renderEngine;
/*  55 */     int dim = (Minecraft.getMinecraft()).theWorld.provider.dimensionId;
/*     */     
/*  57 */     renderer.bindTexture(particleTexture);
/*     */     
/*  59 */     GL11.glPushMatrix();
/*     */     
/*  61 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  62 */     GL11.glDepthMask(false);
/*  63 */     GL11.glEnable(3042);
/*  64 */     GL11.glAlphaFunc(516, 0.003921569F);
/*  65 */     boolean rebound = false;
/*  66 */     for (int layer = 0; layer < 4; layer++) {
/*  67 */       if (this.particles[layer].containsKey(Integer.valueOf(dim))) {
/*  68 */         ArrayList<EntityFX> parts = this.particles[layer].get(Integer.valueOf(dim));
/*  69 */         if (parts.size() != 0) {
/*     */           
/*  71 */           if (!rebound && layer >= 2) {
/*  72 */             renderer.bindTexture(particleTexture2);
/*  73 */             rebound = true;
/*     */           } 
/*     */           
/*  76 */           GL11.glPushMatrix();
/*     */           
/*  78 */           switch (layer) { case 0:
/*     */             case 2:
/*  80 */               GL11.glBlendFunc(770, 1); break;
/*     */             case 1:
/*     */             case 3:
/*  83 */               GL11.glBlendFunc(770, 771);
/*     */               break; }
/*     */ 
/*     */           
/*  87 */           float f1 = ActiveRenderInfo.rotationX;
/*  88 */           float f2 = ActiveRenderInfo.rotationZ;
/*  89 */           float f3 = ActiveRenderInfo.rotationYZ;
/*  90 */           float f4 = ActiveRenderInfo.rotationXY;
/*  91 */           float f5 = ActiveRenderInfo.rotationXZ;
/*  92 */           EntityFX.interpPosX = ((Entity)entityClientPlayerMP).lastTickPosX + (((Entity)entityClientPlayerMP).posX - ((Entity)entityClientPlayerMP).lastTickPosX) * frame;
/*  93 */           EntityFX.interpPosY = ((Entity)entityClientPlayerMP).lastTickPosY + (((Entity)entityClientPlayerMP).posY - ((Entity)entityClientPlayerMP).lastTickPosY) * frame;
/*  94 */           EntityFX.interpPosZ = ((Entity)entityClientPlayerMP).lastTickPosZ + (((Entity)entityClientPlayerMP).posZ - ((Entity)entityClientPlayerMP).lastTickPosZ) * frame;
/*     */           
/*  96 */           Tessellator tessellator = Tessellator.instance;
/*  97 */           tessellator.startDrawingQuads();
/*     */           
/*  99 */           for (int j = 0; j < parts.size(); j++) {
/* 100 */             final EntityFX entityfx = parts.get(j);
/* 101 */             if (entityfx != null) {
/* 102 */               tessellator.setBrightness(entityfx.getBrightnessForRender(frame));
/*     */               
/*     */               try {
/* 105 */                 entityfx.renderParticle(tessellator, frame, f1, f5, f2, f3, f4);
/* 106 */               } catch (Throwable throwable) {
/* 107 */                 CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Rendering Particle");
/* 108 */                 CrashReportCategory crashreportcategory = crashreport.makeCategory("Particle being rendered");
/* 109 */                 crashreportcategory.addCrashSectionCallable("Particle", new Callable()
/*     */                     {
/*     */                       public String call() {
/* 112 */                         return entityfx.toString();
/*     */                       }
/*     */                     });
/* 115 */                 crashreportcategory.addCrashSectionCallable("Particle Type", new Callable()
/*     */                     {
/*     */                       public String call() {
/* 118 */                         return "ENTITY_PARTICLE_TEXTURE";
/*     */                       }
/*     */                     });
/* 121 */                 throw new ReportedException(crashreport);
/*     */               } 
/*     */             } 
/*     */           } 
/* 125 */           tessellator.draw();
/*     */           
/* 127 */           GL11.glPopMatrix();
/*     */         } 
/*     */       } 
/* 130 */     }  GL11.glDisable(3042);
/* 131 */     GL11.glDepthMask(true);
/* 132 */     GL11.glAlphaFunc(516, 0.1F);
/* 133 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   public void addEffect(World world, EntityFX fx) {
/* 137 */     if (!this.particles[fx.getFXLayer()].containsKey(Integer.valueOf(world.provider.dimensionId))) {
/* 138 */       this.particles[fx.getFXLayer()].put(Integer.valueOf(world.provider.dimensionId), new ArrayList<EntityFX>());
/*     */     }
/* 140 */     ArrayList<EntityFX> parts = this.particles[fx.getFXLayer()].get(Integer.valueOf(world.provider.dimensionId));
/* 141 */     if (parts.size() >= 2000) {
/* 142 */       parts.remove(0);
/*     */     }
/* 144 */     parts.add(fx);
/* 145 */     this.particles[fx.getFXLayer()].put(Integer.valueOf(world.provider.dimensionId), parts);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent
/*     */   public void updateParticles(TickEvent.ClientTickEvent event) {
/* 151 */     if (event.side == Side.SERVER)
/* 152 */       return;  Minecraft mc = FMLClientHandler.instance().getClient();
/* 153 */     WorldClient worldClient = mc.theWorld;
/* 154 */     if (mc.theWorld == null)
/* 155 */       return;  int dim = ((World)worldClient).provider.dimensionId;
/* 156 */     if (event.phase == TickEvent.Phase.START)
/* 157 */       for (int layer = 0; layer < 4; layer++) {
/* 158 */         if (this.particles[layer].containsKey(Integer.valueOf(dim))) {
/* 159 */           ArrayList<EntityFX> parts = this.particles[layer].get(Integer.valueOf(dim));
/*     */           
/* 161 */           for (int j = 0; j < parts.size(); j++) {
/* 162 */             final EntityFX entityfx = parts.get(j);
/*     */             
/*     */             try {
/* 165 */               if (entityfx != null) {
/* 166 */                 entityfx.onUpdate();
/*     */               }
/* 168 */             } catch (Throwable throwable) {
/* 169 */               CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Ticking Particle");
/*     */               
/* 171 */               CrashReportCategory crashreportcategory = crashreport.makeCategory("Particle being ticked");
/*     */               
/* 173 */               crashreportcategory.addCrashSectionCallable("Particle", new Callable()
/*     */                   {
/*     */                     public String call() {
/* 176 */                       return entityfx.toString();
/*     */                     }
/*     */                   });
/* 179 */               crashreportcategory.addCrashSectionCallable("Particle Type", new Callable()
/*     */                   {
/*     */                     public String call() {
/* 182 */                       return "ENTITY_PARTICLE_TEXTURE";
/*     */                     }
/*     */                   });
/* 185 */               throw new ReportedException(crashreport);
/*     */             } 
/*     */             
/* 188 */             if (entityfx == null || entityfx.isDead) {
/* 189 */               parts.remove(j--);
/* 190 */               this.particles[layer].put(Integer.valueOf(dim), parts);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\ParticleEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */