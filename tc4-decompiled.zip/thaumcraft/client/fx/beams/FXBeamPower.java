/*     */ package thaumcraft.client.fx.beams;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.fx.ParticleEngine;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FXBeamPower
/*     */   extends EntityFX
/*     */ {
/*  21 */   public int particle = 16;
/*     */   
/*  23 */   private double offset = 0.0D;
/*     */   
/*  25 */   private double tX = 0.0D;
/*  26 */   private double tY = 0.0D;
/*  27 */   private double tZ = 0.0D;
/*  28 */   private double ptX = 0.0D;
/*  29 */   private double ptY = 0.0D;
/*  30 */   private double ptZ = 0.0D;
/*     */   private float length; private float rotYaw; private float rotPitch; private float prevYaw; private float prevPitch; private Entity targetEntity; private float opacity; private float prevSize; public void updateBeam(double xx, double yy, double zz, double x, double y, double z) {
/*     */     setPosition(xx, yy, zz);
/*     */     this.tX = x;
/*     */     this.tY = y;
/*     */     this.tZ = z;
/*     */     for (; this.particleMaxAge - this.particleAge < 4; this.particleMaxAge++);
/*     */   }
/*  38 */   public FXBeamPower(World par1World, double px, double py, double pz, double tx, double ty, double tz, float red, float green, float blue, int age) { super(par1World, px, py, pz, 0.0D, 0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     this.length = 0.0F;
/* 116 */     this.rotYaw = 0.0F;
/* 117 */     this.rotPitch = 0.0F;
/* 118 */     this.prevYaw = 0.0F;
/* 119 */     this.prevPitch = 0.0F;
/* 120 */     this.targetEntity = null;
/*     */     
/* 122 */     this.opacity = 0.3F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     this.prevSize = 0.0F; this.particleRed = 0.5F; this.particleGreen = 0.5F; this.particleBlue = 0.5F; setSize(0.02F, 0.02F); this.noClip = true; this.motionX = 0.0D; this.motionY = 0.0D; this.motionZ = 0.0D; this.tX = tx; this.tY = ty; this.tZ = tz; this.prevYaw = this.rotYaw; this.prevPitch = this.rotPitch; this.particleMaxAge = age; EntityLivingBase renderentity = (FMLClientHandler.instance().getClient()).renderViewEntity; int visibleDistance = 50; if (!(FMLClientHandler.instance().getClient()).gameSettings.fancyGraphics) visibleDistance = 25;  if (renderentity.getDistance(this.posX, this.posY, this.posZ) > visibleDistance)
/*     */       this.particleMaxAge = 0;  }
/*     */   public void onUpdate() { this.prevPosX = this.posX; this.prevPosY = this.posY + this.offset; this.prevPosZ = this.posZ; this.ptX = this.tX; this.ptY = this.tY; this.ptZ = this.tZ; this.prevYaw = this.rotYaw; this.prevPitch = this.rotPitch; float xd = (float)(this.posX - this.tX); float yd = (float)(this.posY - this.tY); float zd = (float)(this.posZ - this.tZ); this.length = MathHelper.sqrt_float(xd * xd + yd * yd + zd * zd); double var7 = MathHelper.sqrt_double((xd * xd + zd * zd)); this.rotYaw = (float)(Math.atan2(xd, zd) * 180.0D / Math.PI); this.rotPitch = (float)(Math.atan2(yd, var7) * 180.0D / Math.PI); this.prevYaw = this.rotYaw; this.prevPitch = this.rotPitch; if (this.opacity > 0.3F)
/*     */       this.opacity -= 0.025F;  if (this.opacity < 0.3F)
/*     */       this.opacity = 0.3F;  if (this.particleAge++ >= this.particleMaxAge)
/* 135 */       setDead();  } public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) { tessellator.draw();
/*     */     
/* 137 */     GL11.glPushMatrix();
/* 138 */     float var9 = 1.0F;
/* 139 */     float slide = (Minecraft.getMinecraft()).thePlayer.ticksExisted;
/* 140 */     float size = 0.7F;
/*     */     
/* 142 */     UtilsFX.bindTexture("textures/misc/beam1.png");
/*     */     
/* 144 */     GL11.glTexParameterf(3553, 10242, 10497.0F);
/* 145 */     GL11.glTexParameterf(3553, 10243, 10497.0F);
/*     */     
/* 147 */     GL11.glDisable(2884);
/*     */     
/* 149 */     float var11 = slide + f;
/* 150 */     float var12 = -var11 * 0.2F - MathHelper.floor_float(-var11 * 0.1F);
/*     */ 
/*     */     
/* 153 */     GL11.glBlendFunc(770, 1);
/* 154 */     GL11.glDepthMask(false);
/*     */     
/* 156 */     float xx = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - interpPosX);
/* 157 */     float yy = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - interpPosY);
/* 158 */     float zz = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - interpPosZ);
/* 159 */     GL11.glTranslated(xx, yy, zz);
/*     */     
/* 161 */     float ry = (float)(this.prevYaw + (this.rotYaw - this.prevYaw) * f);
/* 162 */     float rp = (float)(this.prevPitch + (this.rotPitch - this.prevPitch) * f);
/* 163 */     GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/* 164 */     GL11.glRotatef(180.0F + ry, 0.0F, 0.0F, -1.0F);
/* 165 */     GL11.glRotatef(rp, 1.0F, 0.0F, 0.0F);
/*     */     
/* 167 */     double var44 = -0.15D * size;
/* 168 */     double var17 = 0.15D * size;
/*     */     
/* 170 */     float opmod = 0.1F;
/* 171 */     EntityLivingBase v = (FMLClientHandler.instance().getClient()).renderViewEntity;
/* 172 */     if (v instanceof EntityPlayer && 
/* 173 */       ((EntityPlayer)v).inventory.armorItemInSlot(3) != null && ((EntityPlayer)v).inventory.armorItemInSlot(3).getItem() instanceof thaumcraft.api.nodes.IRevealer)
/*     */     {
/* 175 */       opmod = 1.0F;
/*     */     }
/*     */ 
/*     */     
/* 179 */     for (int t = 0; t < 2; t++) {
/*     */       
/* 181 */       double var29 = (this.length * var9);
/* 182 */       double var31 = 0.0D;
/* 183 */       double var33 = 1.0D;
/* 184 */       double var35 = (-1.0F + var12 + t / 3.0F);
/* 185 */       double var37 = (this.length * var9) + var35;
/*     */       
/* 187 */       GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/* 188 */       tessellator.startDrawingQuads();
/* 189 */       tessellator.setBrightness(200);
/* 190 */       tessellator.setColorRGBA_F(this.particleRed, this.particleGreen, this.particleBlue, this.opacity * opmod);
/*     */ 
/*     */ 
/*     */       
/* 194 */       tessellator.addVertexWithUV(var44, var29, 0.0D, var33, var37);
/* 195 */       tessellator.addVertexWithUV(var44, 0.0D, 0.0D, var33, var35);
/* 196 */       tessellator.addVertexWithUV(var17, 0.0D, 0.0D, var31, var35);
/* 197 */       tessellator.addVertexWithUV(var17, var29, 0.0D, var31, var37);
/* 198 */       tessellator.draw();
/*     */     } 
/*     */ 
/*     */     
/* 202 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 203 */     GL11.glDepthMask(true);
/* 204 */     GL11.glBlendFunc(770, 771);
/*     */     
/* 206 */     GL11.glEnable(2884);
/* 207 */     GL11.glPopMatrix();
/*     */     
/* 209 */     renderFlare(tessellator, f, f1, f2, f3, f4, f5);
/*     */     
/* 211 */     (Minecraft.getMinecraft()).renderEngine.bindTexture(UtilsFX.getParticleTexture());
/* 212 */     tessellator.startDrawingQuads();
/* 213 */     this.prevSize = size; } public void setRGB(float r, float g, float b) { this.particleRed = r; this.particleGreen = g;
/*     */     this.particleBlue = b; }
/*     */   public void setPulse(boolean pulse, float r, float g, float b) { setRGB(r, g, b);
/*     */     if (pulse)
/*     */       this.opacity = 0.8F;  }
/* 218 */   public void renderFlare(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) { float opmod = 0.2F;
/* 219 */     EntityLivingBase v = (FMLClientHandler.instance().getClient()).renderViewEntity;
/* 220 */     if (v instanceof EntityPlayer && 
/* 221 */       ((EntityPlayer)v).inventory.armorItemInSlot(3) != null && ((EntityPlayer)v).inventory.armorItemInSlot(3).getItem() instanceof thaumcraft.api.nodes.IRevealer)
/*     */     {
/* 223 */       opmod = 1.0F;
/*     */     }
/*     */ 
/*     */     
/* 227 */     GL11.glPushMatrix();
/* 228 */     GL11.glDepthMask(false);
/*     */     
/* 230 */     GL11.glBlendFunc(770, 1);
/*     */     
/* 232 */     UtilsFX.bindTexture(ParticleEngine.particleTexture);
/*     */     
/* 234 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.66F);
/* 235 */     int part = this.particleAge % 16;
/*     */     
/* 237 */     float var8 = part / 16.0F;
/* 238 */     float var9 = var8 + 0.0624375F;
/* 239 */     float var10 = 0.3125F;
/* 240 */     float var11 = var10 + 0.0624375F;
/* 241 */     float var12 = 0.66F * this.opacity;
/*     */     
/* 243 */     float var13 = (float)(this.ptX + (this.tX - this.ptX) * f - interpPosX);
/* 244 */     float var14 = (float)(this.ptY + (this.tY - this.ptY) * f - interpPosY);
/* 245 */     float var15 = (float)(this.ptZ + (this.tZ - this.ptZ) * f - interpPosZ);
/* 246 */     float var16 = 1.0F;
/*     */     
/* 248 */     tessellator.startDrawingQuads();
/* 249 */     tessellator.setBrightness(200);
/* 250 */     tessellator.setColorRGBA_F(this.particleRed, this.particleGreen, this.particleBlue, this.opacity * opmod);
/* 251 */     tessellator.addVertexWithUV((var13 - f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 - f3 * var12 - f5 * var12), var9, var11);
/* 252 */     tessellator.addVertexWithUV((var13 - f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 - f3 * var12 + f5 * var12), var9, var10);
/* 253 */     tessellator.addVertexWithUV((var13 + f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 + f3 * var12 + f5 * var12), var8, var10);
/* 254 */     tessellator.addVertexWithUV((var13 + f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 + f3 * var12 - f5 * var12), var8, var11);
/*     */     
/* 256 */     tessellator.draw();
/*     */ 
/*     */     
/* 259 */     GL11.glBlendFunc(770, 771);
/* 260 */     GL11.glDepthMask(true);
/* 261 */     GL11.glPopMatrix(); }
/*     */ 
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\beams\FXBeamPower.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */