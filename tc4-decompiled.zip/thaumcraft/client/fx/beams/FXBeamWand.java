/*     */ package thaumcraft.client.fx.beams;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.fx.ParticleEngine;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ 
/*     */ 
/*     */ public class FXBeamWand
/*     */   extends EntityFX
/*     */ {
/*  21 */   public int particle = 16;
/*  22 */   EntityPlayer player = null;
/*  23 */   private double offset = 0.0D; private float length; private float rotYaw; private float rotPitch; private float prevYaw; private float prevPitch; private Entity targetEntity; private double tX; private double tY; private double tZ; private double ptX; private double ptY; private double ptZ; private int type;
/*     */   private float endMod;
/*     */   private boolean reverse;
/*     */   private boolean pulse;
/*     */   private int rotationspeed;
/*     */   private float prevSize;
/*     */   public int impact;
/*     */   
/*  31 */   public FXBeamWand(World par1World, EntityPlayer player, double tx, double ty, double tz, float red, float green, float blue, int age) { super(par1World, player.posX, player.posY, player.posZ, 0.0D, 0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     this.length = 0.0F;
/* 179 */     this.rotYaw = 0.0F;
/* 180 */     this.rotPitch = 0.0F;
/* 181 */     this.prevYaw = 0.0F;
/* 182 */     this.prevPitch = 0.0F;
/* 183 */     this.targetEntity = null;
/* 184 */     this.tX = 0.0D;
/* 185 */     this.tY = 0.0D;
/* 186 */     this.tZ = 0.0D;
/* 187 */     this.ptX = 0.0D;
/* 188 */     this.ptY = 0.0D;
/* 189 */     this.ptZ = 0.0D;
/*     */     
/* 191 */     this.type = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     this.endMod = 1.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     this.reverse = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 206 */     this.pulse = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     this.rotationspeed = 5;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     this.prevSize = 0.0F; if (player.getEntityId() != (Minecraft.getMinecraft()).renderViewEntity.getEntityId()) this.offset = (player.height / 2.0F) + 0.25D;  this.particleRed = red; this.particleGreen = green; this.particleBlue = blue; this.player = player; setSize(0.02F, 0.02F); this.noClip = true; this.motionX = 0.0D; this.motionY = 0.0D; this.motionZ = 0.0D; this.tX = tx; this.tY = ty; this.tZ = tz; float xd = (float)(player.posX - this.tX); float yd = (float)(player.posY + this.offset - this.tY); float zd = (float)(player.posZ - this.tZ); this.length = MathHelper.sqrt_float(xd * xd + yd * yd + zd * zd); double var7 = MathHelper.sqrt_double((xd * xd + zd * zd)); this.rotYaw = (float)(Math.atan2(xd, zd) * 180.0D / Math.PI); this.rotPitch = (float)(Math.atan2(yd, var7) * 180.0D / Math.PI); this.prevYaw = this.rotYaw; this.prevPitch = this.rotPitch; this.particleMaxAge = age; EntityLivingBase renderentity = (FMLClientHandler.instance().getClient()).renderViewEntity; int visibleDistance = 50; if (!(FMLClientHandler.instance().getClient()).gameSettings.fancyGraphics) visibleDistance = 25;  if (renderentity.getDistance(player.posX, player.posY, player.posZ) > visibleDistance) this.particleMaxAge = 0;  }
/*     */   public void updateBeam(double x, double y, double z) { this.tX = x; this.tY = y; this.tZ = z; for (; this.particleMaxAge - this.particleAge < 4; this.particleMaxAge++); }
/*     */   public void onUpdate() { this.prevPosX = this.player.posX; this.prevPosY = this.player.posY + this.offset; this.prevPosZ = this.player.posZ; this.ptX = this.tX; this.ptY = this.tY; this.ptZ = this.tZ; this.prevYaw = this.rotYaw; this.prevPitch = this.rotPitch; float xd = (float)(this.player.posX - this.tX); float yd = (float)(this.player.posY + this.offset - this.tY); float zd = (float)(this.player.posZ - this.tZ); this.length = MathHelper.sqrt_float(xd * xd + yd * yd + zd * zd); double var7 = MathHelper.sqrt_double((xd * xd + zd * zd)); this.rotYaw = (float)(Math.atan2(xd, zd) * 180.0D / Math.PI); for (this.rotPitch = (float)(Math.atan2(yd, var7) * 180.0D / Math.PI); this.rotPitch - this.prevPitch < -180.0F; this.prevPitch -= 360.0F); while (this.rotPitch - this.prevPitch >= 180.0F) this.prevPitch += 360.0F;  while (this.rotYaw - this.prevYaw < -180.0F)
/*     */       this.prevYaw -= 360.0F;  while (this.rotYaw - this.prevYaw >= 180.0F)
/*     */       this.prevYaw += 360.0F;  if (this.impact > 0)
/*     */       this.impact--;  if (this.particleAge++ >= this.particleMaxAge)
/* 222 */       setDead();  } public void renderParticle(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) { tessellator.draw();
/*     */     
/* 224 */     GL11.glPushMatrix();
/* 225 */     float var9 = 1.0F;
/* 226 */     float slide = (Minecraft.getMinecraft()).thePlayer.ticksExisted;
/* 227 */     float rot = (float)(this.worldObj.provider.getWorldTime() % (360 / this.rotationspeed) * this.rotationspeed) + this.rotationspeed * f;
/*     */     
/* 229 */     float size = 1.0F;
/* 230 */     if (this.pulse) {
/* 231 */       size = Math.min(this.particleAge / 4.0F, 1.0F);
/* 232 */       size = (float)(this.prevSize + (size - this.prevSize) * f);
/*     */     } 
/*     */     
/* 235 */     float op = 0.4F;
/* 236 */     if (this.pulse && this.particleMaxAge - this.particleAge <= 4) {
/* 237 */       op = 0.4F - (4 - this.particleMaxAge - this.particleAge) * 0.1F;
/*     */     }
/* 239 */     switch (this.type) { default:
/* 240 */         UtilsFX.bindTexture("textures/misc/beam.png"); break;
/* 241 */       case 1: UtilsFX.bindTexture("textures/misc/beam1.png"); break;
/* 242 */       case 2: UtilsFX.bindTexture("textures/misc/beam2.png"); break;
/* 243 */       case 3: UtilsFX.bindTexture("textures/misc/beam3.png");
/*     */         break; }
/*     */     
/* 246 */     GL11.glTexParameterf(3553, 10242, 10497.0F);
/* 247 */     GL11.glTexParameterf(3553, 10243, 10497.0F);
/*     */     
/* 249 */     GL11.glDisable(2884);
/*     */     
/* 251 */     float var11 = slide + f;
/* 252 */     if (this.reverse) var11 *= -1.0F; 
/* 253 */     float var12 = -var11 * 0.2F - MathHelper.floor_float(-var11 * 0.1F);
/*     */     
/* 255 */     GL11.glEnable(3042);
/* 256 */     GL11.glBlendFunc(770, 1);
/* 257 */     GL11.glDepthMask(false);
/*     */     
/* 259 */     double prex = this.player.prevPosX;
/* 260 */     double prey = this.player.prevPosY + this.offset;
/* 261 */     double prez = this.player.prevPosZ;
/* 262 */     double px = this.player.posX;
/* 263 */     double py = this.player.posY + this.offset;
/* 264 */     double pz = this.player.posZ;
/*     */     
/* 266 */     prex -= (MathHelper.cos(this.player.prevRotationYaw / 180.0F * 3.141593F) * 0.066F);
/* 267 */     prey -= 0.06D;
/* 268 */     prez -= (MathHelper.sin(this.player.prevRotationYaw / 180.0F * 3.141593F) * 0.04F);
/* 269 */     Vec3 vec3d = this.player.getLook(1.0F);
/* 270 */     prex += vec3d.xCoord * 0.3D;
/* 271 */     prey += vec3d.yCoord * 0.3D;
/* 272 */     prez += vec3d.zCoord * 0.3D;
/*     */     
/* 274 */     px -= (MathHelper.cos(this.player.rotationYaw / 180.0F * 3.141593F) * 0.066F);
/* 275 */     py -= 0.06D;
/* 276 */     pz -= (MathHelper.sin(this.player.rotationYaw / 180.0F * 3.141593F) * 0.04F);
/* 277 */     vec3d = this.player.getLook(1.0F);
/* 278 */     px += vec3d.xCoord * 0.3D;
/* 279 */     py += vec3d.yCoord * 0.3D;
/* 280 */     pz += vec3d.zCoord * 0.3D;
/*     */     
/* 282 */     float xx = (float)(prex + (px - prex) * f - interpPosX);
/* 283 */     float yy = (float)(prey + (py - prey) * f - interpPosY);
/* 284 */     float zz = (float)(prez + (pz - prez) * f - interpPosZ);
/* 285 */     GL11.glTranslated(xx, yy, zz);
/*     */     
/* 287 */     float ry = (float)(this.prevYaw + (this.rotYaw - this.prevYaw) * f);
/* 288 */     float rp = (float)(this.prevPitch + (this.rotPitch - this.prevPitch) * f);
/* 289 */     GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/* 290 */     GL11.glRotatef(180.0F + ry, 0.0F, 0.0F, -1.0F);
/* 291 */     GL11.glRotatef(rp, 1.0F, 0.0F, 0.0F);
/*     */     
/* 293 */     double var44 = -0.15D * size;
/* 294 */     double var17 = 0.15D * size;
/* 295 */     double var44b = -0.15D * size * this.endMod;
/* 296 */     double var17b = 0.15D * size * this.endMod;
/*     */     
/* 298 */     GL11.glRotatef(rot, 0.0F, 1.0F, 0.0F);
/* 299 */     for (int t = 0; t < 3; t++) {
/*     */       
/* 301 */       double var29 = (this.length * size * var9);
/* 302 */       double var31 = 0.0D;
/* 303 */       double var33 = 1.0D;
/* 304 */       double var35 = (-1.0F + var12 + t / 3.0F);
/* 305 */       double var37 = (this.length * size * var9) + var35;
/*     */       
/* 307 */       GL11.glRotatef(60.0F, 0.0F, 1.0F, 0.0F);
/* 308 */       tessellator.startDrawingQuads();
/* 309 */       tessellator.setBrightness(200);
/* 310 */       tessellator.setColorRGBA_F(this.particleRed, this.particleGreen, this.particleBlue, op);
/* 311 */       tessellator.addVertexWithUV(var44b, var29, 0.0D, var33, var37);
/* 312 */       tessellator.addVertexWithUV(var44, 0.0D, 0.0D, var33, var35);
/* 313 */       tessellator.addVertexWithUV(var17, 0.0D, 0.0D, var31, var35);
/* 314 */       tessellator.addVertexWithUV(var17b, var29, 0.0D, var31, var37);
/* 315 */       tessellator.draw();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 320 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 321 */     GL11.glDepthMask(true);
/* 322 */     GL11.glDisable(3042);
/* 323 */     GL11.glEnable(2884);
/*     */     
/* 325 */     GL11.glPopMatrix();
/*     */ 
/*     */     
/* 328 */     if (this.impact > 0) renderImpact(tessellator, f, f1, f2, f3, f4, f5);
/*     */     
/* 330 */     (Minecraft.getMinecraft()).renderEngine.bindTexture(UtilsFX.getParticleTexture());
/* 331 */     tessellator.startDrawingQuads();
/* 332 */     this.prevSize = size; }
/*     */   public void setRGB(float r, float g, float b) { this.particleRed = r; this.particleGreen = g;
/*     */     this.particleBlue = b; }
/*     */   public void setType(int type) { this.type = type; }
/*     */   public void setEndMod(float endMod) { this.endMod = endMod; }
/*     */   public void setReverse(boolean reverse) { this.reverse = reverse; }
/*     */   public void setPulse(boolean pulse) { this.pulse = pulse; }
/* 339 */   public void setRotationspeed(int rotationspeed) { this.rotationspeed = rotationspeed; } public void renderImpact(Tessellator tessellator, float f, float f1, float f2, float f3, float f4, float f5) { GL11.glPushMatrix();
/* 340 */     GL11.glDepthMask(false);
/* 341 */     GL11.glEnable(3042);
/* 342 */     GL11.glBlendFunc(770, 1);
/*     */     
/* 344 */     UtilsFX.bindTexture(ParticleEngine.particleTexture);
/*     */     
/* 346 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.66F);
/* 347 */     int part = this.particleAge % 16;
/*     */     
/* 349 */     float var8 = part / 16.0F;
/* 350 */     float var9 = var8 + 0.0624375F;
/* 351 */     float var10 = 0.3125F;
/* 352 */     float var11 = var10 + 0.0624375F;
/* 353 */     float var12 = this.endMod / 2.0F / (6 - this.impact);
/*     */     
/* 355 */     float var13 = (float)(this.ptX + (this.tX - this.ptX) * f - interpPosX);
/* 356 */     float var14 = (float)(this.ptY + (this.tY - this.ptY) * f - interpPosY);
/* 357 */     float var15 = (float)(this.ptZ + (this.tZ - this.ptZ) * f - interpPosZ);
/* 358 */     float var16 = 1.0F;
/*     */     
/* 360 */     tessellator.startDrawingQuads();
/* 361 */     tessellator.setBrightness(200);
/* 362 */     tessellator.setColorRGBA_F(this.particleRed, this.particleGreen, this.particleBlue, 0.66F);
/* 363 */     tessellator.addVertexWithUV((var13 - f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 - f3 * var12 - f5 * var12), var9, var11);
/* 364 */     tessellator.addVertexWithUV((var13 - f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 - f3 * var12 + f5 * var12), var9, var10);
/* 365 */     tessellator.addVertexWithUV((var13 + f1 * var12 + f4 * var12), (var14 + f2 * var12), (var15 + f3 * var12 + f5 * var12), var8, var10);
/* 366 */     tessellator.addVertexWithUV((var13 + f1 * var12 - f4 * var12), (var14 - f2 * var12), (var15 + f3 * var12 - f5 * var12), var8, var11);
/*     */     
/* 368 */     tessellator.draw();
/*     */     
/* 370 */     GL11.glDisable(3042);
/* 371 */     GL11.glDepthMask(true);
/* 372 */     GL11.glPopMatrix(); }
/*     */ 
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\fx\beams\FXBeamWand.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */