/*     */ package thaumcraft.client.renderers.item;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.entity.RenderPlayer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraftforge.client.IItemRenderer;
/*     */ import net.minecraftforge.client.model.AdvancedModelLoader;
/*     */ import net.minecraftforge.client.model.IModelCustom;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.api.ThaumcraftApi;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.nodes.INode;
/*     */ import thaumcraft.api.research.IScanEventHandler;
/*     */ import thaumcraft.api.research.ScanResult;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.common.lib.research.ScanManager;
/*     */ import thaumcraft.common.lib.utils.BlockUtils;
/*     */ import thaumcraft.common.lib.utils.EntityUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemThaumometerRenderer
/*     */   implements IItemRenderer
/*     */ {
/*  45 */   private static final ResourceLocation SCANNER = new ResourceLocation("thaumcraft", "textures/models/scanner.obj");
/*     */ 
/*     */   
/*  48 */   private IModelCustom model = AdvancedModelLoader.loadModel(SCANNER);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/*  53 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/*  60 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data) {
/*  67 */     Minecraft mc = Minecraft.getMinecraft();
/*  68 */     int rve_id = 0;
/*  69 */     int player_id = 0;
/*  70 */     if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/*  71 */       rve_id = mc.renderViewEntity.getEntityId();
/*  72 */       player_id = ((EntityLivingBase)data[1]).getEntityId();
/*     */     } 
/*  74 */     EntityClientPlayerMP entityClientPlayerMP = mc.thePlayer;
/*     */     
/*  76 */     float par1 = (UtilsFX.getTimer(mc)).renderPartialTicks;
/*  77 */     float var7 = 0.8F;
/*  78 */     EntityPlayerSP playersp = (EntityPlayerSP)entityClientPlayerMP;
/*     */     
/*  80 */     GL11.glPushMatrix();
/*     */     
/*  82 */     if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON && player_id == rve_id && mc.gameSettings.thirdPersonView == 0) {
/*     */       
/*  84 */       GL11.glTranslatef(1.0F, 0.75F, -1.0F);
/*  85 */       GL11.glRotatef(135.0F, 0.0F, -1.0F, 0.0F);
/*     */       
/*  87 */       float f3 = playersp.prevRenderArmPitch + (playersp.renderArmPitch - playersp.prevRenderArmPitch) * par1;
/*  88 */       float f4 = playersp.prevRenderArmYaw + (playersp.renderArmYaw - playersp.prevRenderArmYaw) * par1;
/*  89 */       GL11.glRotatef((((EntityPlayer)entityClientPlayerMP).rotationPitch - f3) * 0.1F, 1.0F, 0.0F, 0.0F);
/*  90 */       GL11.glRotatef((((EntityPlayer)entityClientPlayerMP).rotationYaw - f4) * 0.1F, 0.0F, 1.0F, 0.0F);
/*     */       
/*  92 */       float var4 = ((EntityPlayer)entityClientPlayerMP).prevRotationPitch + (((EntityPlayer)entityClientPlayerMP).rotationPitch - ((EntityPlayer)entityClientPlayerMP).prevRotationPitch) * par1;
/*     */ 
/*     */ 
/*     */       
/*  96 */       float f1 = UtilsFX.getPrevEquippedProgress(mc.entityRenderer.itemRenderer) + (UtilsFX.getEquippedProgress(mc.entityRenderer.itemRenderer) - UtilsFX.getPrevEquippedProgress(mc.entityRenderer.itemRenderer)) * par1;
/*     */ 
/*     */ 
/*     */       
/* 100 */       GL11.glTranslatef(-0.7F * var7, -(-0.65F * var7) + (1.0F - f1) * 1.5F, 0.9F * var7);
/*     */       
/* 102 */       GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/*     */       
/* 104 */       GL11.glTranslatef(0.0F, 0.0F * var7, -0.9F * var7);
/* 105 */       GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/* 106 */       GL11.glRotatef(0.0F, 0.0F, 0.0F, 1.0F);
/* 107 */       GL11.glEnable(32826);
/*     */       
/* 109 */       GL11.glPushMatrix();
/* 110 */       GL11.glScalef(5.0F, 5.0F, 5.0F);
/*     */       
/* 112 */       mc.renderEngine.bindTexture(mc.thePlayer.getLocationSkin());
/*     */ 
/*     */       
/* 115 */       for (int var9 = 0; var9 < 2; var9++) {
/*     */         
/* 117 */         int var22 = var9 * 2 - 1;
/* 118 */         GL11.glPushMatrix();
/* 119 */         GL11.glTranslatef(-0.0F, -0.6F, 1.1F * var22);
/* 120 */         GL11.glRotatef((-45 * var22), 1.0F, 0.0F, 0.0F);
/* 121 */         GL11.glRotatef(-90.0F, 0.0F, 0.0F, 1.0F);
/* 122 */         GL11.glRotatef(59.0F, 0.0F, 0.0F, 1.0F);
/* 123 */         GL11.glRotatef((-65 * var22), 0.0F, 1.0F, 0.0F);
/* 124 */         Render var24 = RenderManager.instance.getEntityRenderObject((Entity)mc.thePlayer);
/* 125 */         RenderPlayer var26 = (RenderPlayer)var24;
/* 126 */         float var13 = 1.0F;
/* 127 */         GL11.glScalef(var13, var13, var13);
/* 128 */         var26.renderFirstPersonArm((EntityPlayer)mc.thePlayer);
/* 129 */         GL11.glPopMatrix();
/*     */       } 
/* 131 */       GL11.glPopMatrix();
/* 132 */       GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
/*     */ 
/*     */       
/* 135 */       GL11.glTranslatef(0.4F, -0.4F, 0.0F);
/* 136 */       GL11.glEnable(32826);
/* 137 */       GL11.glScalef(2.0F, 2.0F, 2.0F);
/*     */     } else {
/* 139 */       GL11.glScalef(0.5F, 0.5F, 0.5F);
/* 140 */       if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/* 141 */         GL11.glTranslatef(1.6F, 0.3F, 2.0F);
/* 142 */         GL11.glRotatef(90.0F, -1.0F, 0.0F, 0.0F);
/* 143 */         GL11.glRotatef(30.0F, 0.0F, 0.0F, -1.0F);
/*     */       }
/* 145 */       else if (type == IItemRenderer.ItemRenderType.INVENTORY) {
/* 146 */         GL11.glRotatef(60.0F, 1.0F, 0.0F, 0.0F);
/* 147 */         GL11.glRotatef(30.0F, 0.0F, 0.0F, -1.0F);
/* 148 */         GL11.glRotatef(248.0F, 0.0F, -1.0F, 0.0F);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 153 */     UtilsFX.bindTexture("textures/models/scanner.png");
/* 154 */     this.model.renderAll();
/*     */     
/* 156 */     GL11.glPushMatrix();
/* 157 */     GL11.glTranslatef(0.0F, 0.11F, 0.0F);
/* 158 */     GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/* 159 */     GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
/* 160 */     UtilsFX.renderQuadCenteredFromTexture("textures/models/scanscreen.png", 2.5F, 1.0F, 1.0F, 1.0F, (int)(190.0F + MathHelper.sin((((EntityPlayer)entityClientPlayerMP).ticksExisted - ((EntityPlayer)entityClientPlayerMP).worldObj.rand.nextInt(2))) * 10.0F + 10.0F), 771, 1.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     if (entityClientPlayerMP instanceof EntityPlayer && type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON && player_id == rve_id && mc.gameSettings.thirdPersonView == 0) {
/*     */ 
/*     */ 
/*     */       
/* 169 */       RenderHelper.disableStandardItemLighting();
/*     */       
/* 171 */       int j = (int)(190.0F + MathHelper.sin((((EntityPlayer)entityClientPlayerMP).ticksExisted - ((EntityPlayer)entityClientPlayerMP).worldObj.rand.nextInt(2))) * 10.0F + 10.0F);
/* 172 */       int k = j % 65536;
/* 173 */       int l = j / 65536;
/* 174 */       OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, k / 1.0F, l / 1.0F);
/*     */       
/* 176 */       ScanResult scan = doScan(((EntityPlayer)entityClientPlayerMP).inventory.getCurrentItem(), (EntityPlayer)entityClientPlayerMP);
/*     */       
/* 178 */       if (scan != null) {
/* 179 */         AspectList aspects = null;
/* 180 */         GL11.glTranslatef(0.0F, 0.0F, -0.01F);
/* 181 */         String text = "?";
/* 182 */         ItemStack stack = null;
/*     */         
/* 184 */         if (scan.id > 0) {
/* 185 */           stack = new ItemStack(Item.getItemById(scan.id), 1, scan.meta);
/* 186 */           if (ScanManager.hasBeenScanned((EntityPlayer)entityClientPlayerMP, scan)) {
/* 187 */             aspects = ScanManager.getScanAspects(scan, ((EntityPlayer)entityClientPlayerMP).worldObj);
/*     */           }
/*     */         } 
/*     */         
/* 191 */         if (scan.type == 2) {
/* 192 */           if (scan.entity instanceof EntityItem) {
/* 193 */             stack = ((EntityItem)scan.entity).getEntityItem();
/*     */           } else {
/* 195 */             text = scan.entity.getCommandSenderName();
/*     */           } 
/* 197 */           if (ScanManager.hasBeenScanned((EntityPlayer)entityClientPlayerMP, scan)) {
/* 198 */             aspects = ScanManager.getScanAspects(scan, ((EntityPlayer)entityClientPlayerMP).worldObj);
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 203 */         if (scan.type == 3 && 
/* 204 */           scan.phenomena.startsWith("NODE") && ScanManager.hasBeenScanned((EntityPlayer)entityClientPlayerMP, scan)) {
/* 205 */           MovingObjectPosition mop = null;
/* 206 */           if (stack != null && stack.getItem() != null)
/* 207 */             mop = EntityUtils.getMovingObjectPositionFromPlayer(((EntityPlayer)entityClientPlayerMP).worldObj, (EntityPlayer)entityClientPlayerMP, true); 
/* 208 */           if (mop != null && mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
/* 209 */             TileEntity tile = ((EntityPlayer)entityClientPlayerMP).worldObj.getTileEntity(mop.blockX, mop.blockY, mop.blockZ);
/* 210 */             if (tile != null && tile instanceof INode) {
/* 211 */               aspects = ((INode)tile).getAspects();
/*     */               
/* 213 */               GL11.glPushMatrix();
/* 214 */               GL11.glEnable(3042);
/* 215 */               GL11.glBlendFunc(770, 1);
/* 216 */               String t = StatCollector.translateToLocal("nodetype." + ((INode)tile).getNodeType() + ".name");
/* 217 */               if (((INode)tile).getNodeModifier() != null)
/* 218 */                 t = t + ", " + StatCollector.translateToLocal("nodemod." + ((INode)tile).getNodeModifier() + ".name"); 
/* 219 */               int sw = mc.fontRenderer.getStringWidth(t);
/* 220 */               float scale = 0.004F;
/* 221 */               GL11.glScalef(scale, scale, scale);
/* 222 */               mc.fontRenderer.drawString(t, -sw / 2, -40, 15642134);
/* 223 */               GL11.glDisable(3042);
/* 224 */               GL11.glPopMatrix();
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 230 */         if (stack != null) {
/* 231 */           if (stack.getItem() != null) {
/*     */             try {
/* 233 */               text = stack.getDisplayName();
/* 234 */             } catch (Exception e) {}
/*     */           }
/* 236 */           else if (stack.getItem() != null) {
/*     */             try {
/* 238 */               text = stack.getItem().getItemStackDisplayName(stack);
/* 239 */             } catch (Exception e) {}
/*     */           } 
/*     */         }
/*     */         
/* 243 */         if (aspects != null) {
/* 244 */           int posX = 0;
/* 245 */           int posY = 0;
/* 246 */           int aa = aspects.size();
/* 247 */           int baseX = Math.min(5, aa) * 8;
/* 248 */           for (Aspect aspect : aspects.getAspectsSorted()) {
/* 249 */             GL11.glPushMatrix();
/* 250 */             GL11.glScalef(0.0075F, 0.0075F, 0.0075F);
/* 251 */             j = (int)(190.0F + MathHelper.sin((posX + ((EntityPlayer)entityClientPlayerMP).ticksExisted - ((EntityPlayer)entityClientPlayerMP).worldObj.rand.nextInt(2))) * 10.0F + 10.0F);
/* 252 */             k = j % 65536;
/* 253 */             l = j / 65536;
/* 254 */             OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, k / 1.0F, l / 1.0F);
/* 255 */             UtilsFX.drawTag(-baseX + posX * 16, -8 + posY * 16, aspect, aspects.getAmount(aspect), 0, 0.01D, 1, 1.0F, false);
/* 256 */             GL11.glPopMatrix();
/* 257 */             posX++;
/* 258 */             if (posX >= 5 - posY) {
/* 259 */               posX = 0;
/* 260 */               posY++;
/* 261 */               aa -= 5 - posY;
/* 262 */               baseX = Math.min(5 - posY, aa) * 8;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 267 */         if (text == null) text = "?"; 
/* 268 */         if (text.length() > 0) {
/* 269 */           RenderHelper.disableStandardItemLighting();
/* 270 */           GL11.glPushMatrix();
/*     */           
/* 272 */           GL11.glEnable(3042);
/* 273 */           GL11.glBlendFunc(770, 1);
/* 274 */           GL11.glTranslatef(0.0F, -0.25F, 0.0F);
/* 275 */           int sw = mc.fontRenderer.getStringWidth(text);
/* 276 */           float scale = 0.005F;
/* 277 */           if (sw > 90) scale -= 2.5E-5F * (sw - 90); 
/* 278 */           GL11.glScalef(scale, scale, scale);
/* 279 */           mc.fontRenderer.drawString(text, -sw / 2, 0, 16777215);
/* 280 */           GL11.glDisable(3042);
/* 281 */           GL11.glPopMatrix();
/*     */         } 
/*     */       } 
/* 284 */       RenderHelper.enableGUIStandardItemLighting();
/*     */     } 
/*     */     
/* 287 */     GL11.glPopMatrix();
/* 288 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ScanResult doScan(ItemStack stack, EntityPlayer p) {
/* 294 */     if (stack == null || p == null) return null;
/*     */ 
/*     */     
/* 297 */     Entity pointedEntity = EntityUtils.getPointedEntity(p.worldObj, (Entity)p, 0.5D, 10.0D, 0.0F, true);
/* 298 */     if (pointedEntity != null) {
/* 299 */       ScanResult sr = new ScanResult((byte)2, 0, 0, pointedEntity, "");
/* 300 */       return sr;
/*     */     } 
/*     */ 
/*     */     
/* 304 */     MovingObjectPosition mop = EntityUtils.getMovingObjectPositionFromPlayer(p.worldObj, p, true);
/* 305 */     if (mop != null && mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
/* 306 */       Block bi = p.worldObj.getBlock(mop.blockX, mop.blockY, mop.blockZ);
/*     */       
/* 308 */       TileEntity tile = p.worldObj.getTileEntity(mop.blockX, mop.blockY, mop.blockZ);
/* 309 */       if (tile != null && tile instanceof INode) {
/* 310 */         int md = bi.getDamageValue(p.worldObj, mop.blockX, mop.blockY, mop.blockZ);
/* 311 */         ScanResult sr = new ScanResult((byte)3, Block.getIdFromBlock(bi), md, null, "NODE" + ((INode)tile).getId());
/* 312 */         return sr;
/*     */       } 
/* 314 */       if (bi != Blocks.air) {
/* 315 */         ItemStack is = bi.getPickBlock(mop, p.worldObj, mop.blockX, mop.blockY, mop.blockZ);
/* 316 */         ScanResult sr = null;
/* 317 */         int md = p.worldObj.getBlockMetadata(mop.blockX, mop.blockY, mop.blockZ);
/*     */         
/*     */         try {
/* 320 */           if (is == null) {
/* 321 */             is = BlockUtils.createStackedBlock(bi, md);
/*     */           }
/* 323 */         } catch (Exception e) {}
/*     */         
/*     */         try {
/* 326 */           if (is == null)
/* 327 */           { sr = new ScanResult((byte)1, Block.getIdFromBlock(bi), md, null, ""); }
/*     */           else
/* 329 */           { sr = new ScanResult((byte)1, Item.getIdFromItem(is.getItem()), is.getItemDamage(), null, ""); } 
/* 330 */         } catch (Exception e) {}
/*     */ 
/*     */         
/* 333 */         return sr;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 340 */     for (IScanEventHandler seh : ThaumcraftApi.scanEventhandlers) {
/* 341 */       ScanResult scan = seh.scanPhenomena(stack, p.worldObj, p);
/* 342 */       if (scan != null) {
/* 343 */         return scan;
/*     */       }
/*     */     } 
/* 346 */     return null;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\item\ItemThaumometerRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */