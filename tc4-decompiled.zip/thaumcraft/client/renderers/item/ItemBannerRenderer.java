/*    */ package thaumcraft.client.renderers.item;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.client.IItemRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.api.aspects.Aspect;
/*    */ import thaumcraft.common.tiles.TileBanner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemBannerRenderer
/*    */   implements IItemRenderer
/*    */ {
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
/* 20 */     if (!item.hasTagCompound() || item.getItemDamage() != 8) return false; 
/* 21 */     if (item.stackTagCompound.getString("aspect") == null || item.stackTagCompound.getByte("color") < 0) {
/* 22 */       return false;
/*    */     }
/* 24 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
/* 29 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data) {
/* 34 */     Minecraft mc = Minecraft.getMinecraft();
/*    */     
/* 36 */     GL11.glPushMatrix();
/* 37 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 38 */     short var11 = 0;
/*    */     
/* 40 */     if (type == IItemRenderer.ItemRenderType.EQUIPPED || type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON) {
/* 41 */       GL11.glTranslatef(1.0F, 1.0F, 1.0F);
/*    */     } else {
/* 43 */       GL11.glRotatef(var11, 0.0F, 1.0F, 0.0F);
/*    */     } 
/*    */     
/* 46 */     GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/*    */     
/* 48 */     GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/* 49 */     GL11.glTranslatef(-0.5F, -1.0F, -0.5F);
/* 50 */     TileBanner tb = new TileBanner();
/* 51 */     tb.setColor(item.stackTagCompound.getByte("color"));
/* 52 */     if (item.stackTagCompound.getString("aspect") != null)
/* 53 */       tb.setAspect(Aspect.getAspect(item.stackTagCompound.getString("aspect"))); 
/* 54 */     TileEntityRendererDispatcher.instance.renderTileEntityAt((TileEntity)tb, 0.0D, 0.0D, 0.0D, 0.0F);
/*    */     
/* 56 */     GL11.glPopMatrix();
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\item\ItemBannerRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */