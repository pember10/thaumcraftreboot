/*     */ package thaumcraft.client.renderers.models.gear;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelBiped;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelRobe
/*     */   extends ModelBiped
/*     */ {
/*     */   ModelRenderer Hood1;
/*     */   ModelRenderer Hood2;
/*     */   ModelRenderer Hood3;
/*     */   ModelRenderer Hood4;
/*     */   ModelRenderer Chestthing;
/*     */   ModelRenderer Mbelt;
/*     */   ModelRenderer MbeltB;
/*     */   ModelRenderer ClothchestL;
/*     */   ModelRenderer ClothchestR;
/*     */   ModelRenderer Book;
/*     */   ModelRenderer Scroll;
/*     */   ModelRenderer BeltR;
/*     */   ModelRenderer Backplate;
/*     */   ModelRenderer MbeltL;
/*     */   ModelRenderer MbeltR;
/*     */   ModelRenderer BeltL;
/*     */   ModelRenderer Chestplate;
/*     */   ModelRenderer ShoulderplateR1;
/*     */   ModelRenderer ShoulderplateR2;
/*     */   ModelRenderer ShoulderplateR3;
/*     */   ModelRenderer ShoulderplateTopR;
/*     */   ModelRenderer RArm1;
/*     */   ModelRenderer RArm2;
/*     */   ModelRenderer RArm3;
/*     */   ModelRenderer LArm1;
/*     */   ModelRenderer LArm2;
/*     */   ModelRenderer LArm3;
/*     */   ModelRenderer ShoulderplateL1;
/*     */   ModelRenderer ShoulderplateL2;
/*     */   ModelRenderer ShoulderplateL3;
/*     */   ModelRenderer ShoulderplateTopL;
/*     */   ModelRenderer ShoulderL;
/*     */   ModelRenderer ShoulderR;
/*     */   ModelRenderer ClothBackR3;
/*     */   ModelRenderer FrontclothR2;
/*     */   ModelRenderer FrontclothR1;
/*     */   ModelRenderer SideclothR2;
/*     */   ModelRenderer SideclothR1;
/*     */   ModelRenderer SideclothR3;
/*     */   ModelRenderer ClothBackR1;
/*     */   ModelRenderer ClothBackR2;
/*     */   ModelRenderer SidepanelR1;
/*     */   ModelRenderer LegpanelR6;
/*     */   ModelRenderer LegpanelR5;
/*     */   ModelRenderer LegpanelR4;
/*     */   ModelRenderer FrontclothL2;
/*     */   ModelRenderer ClothBackL3;
/*     */   ModelRenderer ClothBackL1;
/*     */   ModelRenderer FrontclothL1;
/*     */   ModelRenderer SideclothL2;
/*     */   ModelRenderer SideclothL3;
/*     */   ModelRenderer Focipouch;
/*     */   ModelRenderer SideclothL1;
/*     */   ModelRenderer ClothBackL2;
/*     */   ModelRenderer LegpanelL4;
/*     */   ModelRenderer LegpanelL5;
/*     */   ModelRenderer LegpanelL6;
/*     */   ModelRenderer SidepanelL1;
/*     */   
/*     */   public ModelRobe(float f) {
/*  81 */     super(f, 0.0F, 128, 64);
/*  82 */     this.textureWidth = 128;
/*  83 */     this.textureHeight = 64;
/*     */ 
/*     */     
/*  86 */     this.Hood1 = new ModelRenderer((ModelBase)this, 16, 7);
/*  87 */     this.Hood1.addBox(-4.5F, -9.0F, -4.6F, 9, 9, 9);
/*  88 */     this.Hood1.setTextureSize(128, 64);
/*  89 */     setRotation(this.Hood1, 0.0F, 0.0F, 0.0F);
/*     */     
/*  91 */     this.Hood2 = new ModelRenderer((ModelBase)this, 52, 13);
/*  92 */     this.Hood2.addBox(-4.0F, -9.7F, 2.0F, 8, 9, 3);
/*  93 */     this.Hood2.setTextureSize(128, 64);
/*  94 */     setRotation(this.Hood2, -0.2268928F, 0.0F, 0.0F);
/*     */     
/*  96 */     this.Hood3 = new ModelRenderer((ModelBase)this, 52, 14);
/*  97 */     this.Hood3.addBox(-3.5F, -10.0F, 3.5F, 7, 8, 3);
/*  98 */     this.Hood3.setTextureSize(128, 64);
/*  99 */     setRotation(this.Hood3, -0.3490659F, 0.0F, 0.0F);
/*     */     
/* 101 */     this.Hood4 = new ModelRenderer((ModelBase)this, 53, 15);
/* 102 */     this.Hood4.addBox(-3.0F, -10.7F, 3.5F, 6, 7, 3);
/* 103 */     this.Hood4.setTextureSize(128, 64);
/* 104 */     setRotation(this.Hood4, -0.5759587F, 0.0F, 0.0F);
/*     */ 
/*     */     
/* 107 */     this.Chestthing = new ModelRenderer((ModelBase)this, 56, 50);
/* 108 */     this.Chestthing.addBox(-2.5F, 1.0F, -4.0F, 5, 7, 1);
/* 109 */     this.Chestthing.setTextureSize(128, 64);
/* 110 */     setRotation(this.Chestthing, 0.0F, 0.0F, 0.0F);
/*     */     
/* 112 */     this.Mbelt = new ModelRenderer((ModelBase)this, 16, 55);
/* 113 */     this.Mbelt.addBox(-4.0F, 7.0F, -3.0F, 8, 5, 1);
/* 114 */     this.Mbelt.setTextureSize(128, 64);
/* 115 */     setRotation(this.Mbelt, 0.0F, 0.0F, 0.0F);
/*     */     
/* 117 */     this.MbeltB = new ModelRenderer((ModelBase)this, 16, 55);
/* 118 */     this.MbeltB.addBox(-4.0F, 7.0F, -4.0F, 8, 5, 1);
/* 119 */     this.MbeltB.setTextureSize(128, 64);
/* 120 */     setRotation(this.MbeltB, 0.0F, 3.141593F, 0.0F);
/*     */     
/* 122 */     this.ClothchestL = new ModelRenderer((ModelBase)this, 108, 38);
/* 123 */     this.ClothchestL.mirror = true;
/* 124 */     this.ClothchestL.addBox(2.1F, 0.5F, -3.5F, 2, 8, 1);
/* 125 */     this.ClothchestL.setTextureSize(128, 64);
/* 126 */     setRotation(this.ClothchestL, 0.0F, 0.0F, 0.0F);
/*     */     
/* 128 */     this.ClothchestR = new ModelRenderer((ModelBase)this, 108, 38);
/* 129 */     this.ClothchestR.addBox(-4.1F, 0.5F, -3.5F, 2, 8, 1);
/* 130 */     this.ClothchestR.setTextureSize(128, 64);
/* 131 */     setRotation(this.ClothchestR, 0.0F, 0.0F, 0.0F);
/*     */     
/* 133 */     this.Book = new ModelRenderer((ModelBase)this, 81, 16);
/* 134 */     this.Book.addBox(1.0F, 0.0F, 4.0F, 5, 7, 2);
/* 135 */     this.Book.setTextureSize(128, 64);
/* 136 */     setRotation(this.Book, 0.0F, 0.0F, 0.7679449F);
/*     */     
/* 138 */     this.Scroll = new ModelRenderer((ModelBase)this, 78, 25);
/* 139 */     this.Scroll.addBox(-2.0F, 9.5F, 4.0F, 8, 3, 3);
/* 140 */     this.Scroll.setTextureSize(128, 64);
/* 141 */     setRotation(this.Scroll, 0.0F, 0.0F, 0.1919862F);
/*     */     
/* 143 */     this.BeltR = new ModelRenderer((ModelBase)this, 16, 36);
/* 144 */     this.BeltR.addBox(-5.0F, 4.0F, -3.0F, 1, 3, 6);
/* 145 */     this.BeltR.setTextureSize(128, 64);
/* 146 */     setRotation(this.BeltR, 0.0F, 0.0F, 0.0F);
/*     */     
/* 148 */     this.Backplate = new ModelRenderer((ModelBase)this, 36, 45);
/* 149 */     this.Backplate.addBox(-4.0F, 1.0F, 1.9F, 8, 11, 2);
/* 150 */     this.Backplate.setTextureSize(128, 64);
/* 151 */     setRotation(this.Backplate, 0.0F, 0.0F, 0.0F);
/*     */     
/* 153 */     this.MbeltL = new ModelRenderer((ModelBase)this, 16, 36);
/* 154 */     this.MbeltL.addBox(4.0F, 8.0F, -3.0F, 1, 3, 6);
/* 155 */     this.MbeltL.setTextureSize(128, 64);
/* 156 */     setRotation(this.MbeltL, 0.0F, 0.0F, 0.0F);
/*     */     
/* 158 */     this.MbeltR = new ModelRenderer((ModelBase)this, 16, 36);
/* 159 */     this.MbeltR.addBox(-5.0F, 8.0F, -3.0F, 1, 3, 6);
/* 160 */     this.MbeltR.setTextureSize(128, 64);
/* 161 */     setRotation(this.MbeltR, 0.0F, 0.0F, 0.0F);
/*     */     
/* 163 */     this.BeltL = new ModelRenderer((ModelBase)this, 16, 36);
/* 164 */     this.BeltL.addBox(4.0F, 4.0F, -3.0F, 1, 3, 6);
/* 165 */     this.BeltL.setTextureSize(128, 64);
/* 166 */     setRotation(this.BeltL, 0.0F, 0.0F, 0.0F);
/*     */     
/* 168 */     this.Chestplate = new ModelRenderer((ModelBase)this, 16, 25);
/* 169 */     this.Chestplate.addBox(-4.0F, 1.0F, -3.0F, 8, 6, 1);
/* 170 */     this.Chestplate.setTextureSize(128, 64);
/* 171 */     setRotation(this.Chestplate, 0.0F, 0.0F, 0.0F);
/*     */     
/* 173 */     this.ShoulderplateR1 = new ModelRenderer((ModelBase)this, 56, 33);
/* 174 */     this.ShoulderplateR1.addBox(-4.5F, -1.5F, -3.5F, 1, 4, 7);
/*     */     
/* 176 */     this.ShoulderplateR1.setTextureSize(128, 64);
/* 177 */     setRotation(this.ShoulderplateR1, 0.0F, 0.0F, 0.4363323F);
/*     */     
/* 179 */     this.ShoulderplateR2 = new ModelRenderer((ModelBase)this, 40, 33);
/* 180 */     this.ShoulderplateR2.addBox(-3.5F, 1.5F, -3.5F, 1, 3, 7);
/*     */     
/* 182 */     this.ShoulderplateR2.setTextureSize(128, 64);
/* 183 */     setRotation(this.ShoulderplateR2, 0.0F, 0.0F, 0.4363323F);
/*     */     
/* 185 */     this.ShoulderplateR3 = new ModelRenderer((ModelBase)this, 40, 33);
/* 186 */     this.ShoulderplateR3.addBox(-2.5F, 3.5F, -3.5F, 1, 3, 7);
/*     */     
/* 188 */     this.ShoulderplateR3.setTextureSize(128, 64);
/* 189 */     setRotation(this.ShoulderplateR3, 0.0F, 0.0F, 0.4363323F);
/*     */     
/* 191 */     this.ShoulderplateTopR = new ModelRenderer((ModelBase)this, 56, 25);
/* 192 */     this.ShoulderplateTopR.addBox(-5.5F, -2.5F, -3.5F, 2, 1, 7);
/*     */     
/* 194 */     this.ShoulderplateTopR.setTextureSize(128, 64);
/* 195 */     setRotation(this.ShoulderplateTopR, 0.0F, 0.0F, 0.4363323F);
/*     */     
/* 197 */     this.RArm1 = new ModelRenderer((ModelBase)this, 88, 39);
/* 198 */     this.RArm1.addBox(-3.5F, 2.5F, -2.5F, 5, 7, 5);
/*     */     
/* 200 */     this.RArm1.setTextureSize(128, 64);
/* 201 */     setRotation(this.RArm1, 0.0F, 0.0F, 0.0F);
/*     */     
/* 203 */     this.RArm2 = new ModelRenderer((ModelBase)this, 76, 32);
/* 204 */     this.RArm2.addBox(-3.0F, 5.5F, 2.5F, 4, 4, 2);
/*     */     
/* 206 */     this.RArm2.setTextureSize(128, 64);
/* 207 */     setRotation(this.RArm2, 0.0F, 0.0F, 0.0F);
/*     */     
/* 209 */     this.RArm3 = new ModelRenderer((ModelBase)this, 88, 32);
/* 210 */     this.RArm3.addBox(-2.5F, 3.5F, 2.5F, 3, 2, 1);
/*     */     
/* 212 */     this.RArm3.setTextureSize(128, 64);
/* 213 */     setRotation(this.RArm3, 0.0F, 0.0F, 0.0F);
/*     */     
/* 215 */     this.ShoulderplateL1 = new ModelRenderer((ModelBase)this, 56, 33);
/* 216 */     this.ShoulderplateL1.addBox(3.5F, -1.5F, -3.5F, 1, 4, 7);
/*     */     
/* 218 */     this.ShoulderplateL1.setTextureSize(128, 64);
/* 219 */     setRotation(this.ShoulderplateL1, 0.0F, 0.0F, -0.4363323F);
/*     */     
/* 221 */     this.ShoulderplateL2 = new ModelRenderer((ModelBase)this, 40, 33);
/* 222 */     this.ShoulderplateL2.addBox(2.5F, 1.5F, -3.5F, 1, 3, 7);
/*     */     
/* 224 */     this.ShoulderplateL2.setTextureSize(128, 64);
/* 225 */     setRotation(this.ShoulderplateL2, 0.0F, 0.0F, -0.4363323F);
/*     */     
/* 227 */     this.ShoulderplateL3 = new ModelRenderer((ModelBase)this, 40, 33);
/* 228 */     this.ShoulderplateL3.addBox(1.5F, 3.5F, -3.5F, 1, 3, 7);
/*     */     
/* 230 */     this.ShoulderplateL3.setTextureSize(128, 64);
/* 231 */     setRotation(this.ShoulderplateL3, 0.0F, 0.0F, -0.4363323F);
/*     */     
/* 233 */     this.ShoulderplateTopL = new ModelRenderer((ModelBase)this, 56, 25);
/* 234 */     this.ShoulderplateTopL.addBox(3.5F, -2.5F, -3.5F, 2, 1, 7);
/*     */     
/* 236 */     this.ShoulderplateTopL.setTextureSize(128, 64);
/* 237 */     setRotation(this.ShoulderplateTopL, 0.0F, 0.0F, -0.4363323F);
/*     */     
/* 239 */     this.ShoulderR = new ModelRenderer((ModelBase)this, 16, 45);
/* 240 */     this.ShoulderR.mirror = true;
/* 241 */     this.ShoulderR.addBox(-3.5F, -2.5F, -2.5F, 5, 5, 5);
/*     */     
/* 243 */     this.ShoulderR.setTextureSize(128, 64);
/* 244 */     setRotation(this.ShoulderR, 0.0F, 0.0F, 0.0F);
/*     */     
/* 246 */     this.LArm1 = new ModelRenderer((ModelBase)this, 88, 39);
/* 247 */     this.LArm1.mirror = true;
/* 248 */     this.LArm1.addBox(-1.5F, 2.5F, -2.5F, 5, 7, 5);
/*     */     
/* 250 */     this.LArm1.setTextureSize(128, 64);
/* 251 */     setRotation(this.LArm1, 0.0F, 0.0F, 0.0F);
/*     */     
/* 253 */     this.LArm2 = new ModelRenderer((ModelBase)this, 76, 32);
/* 254 */     this.LArm2.addBox(-1.0F, 5.5F, 2.5F, 4, 4, 2);
/*     */     
/* 256 */     this.LArm2.setTextureSize(128, 64);
/* 257 */     setRotation(this.LArm2, 0.0F, 0.0F, 0.0F);
/*     */     
/* 259 */     this.LArm3 = new ModelRenderer((ModelBase)this, 88, 32);
/* 260 */     this.LArm3.addBox(-0.5F, 3.5F, 2.5F, 3, 2, 1);
/*     */     
/* 262 */     this.LArm3.setTextureSize(128, 64);
/* 263 */     setRotation(this.LArm3, 0.0F, 0.0F, 0.0F);
/*     */     
/* 265 */     this.ShoulderL = new ModelRenderer((ModelBase)this, 16, 45);
/* 266 */     this.ShoulderL.addBox(-1.5F, -2.5F, -2.5F, 5, 5, 5);
/*     */     
/* 268 */     this.ShoulderL.setTextureSize(128, 64);
/* 269 */     this.ShoulderL.mirror = true;
/* 270 */     setRotation(this.ShoulderL, 0.0F, 0.0F, 0.0F);
/*     */     
/* 272 */     this.FrontclothR1 = new ModelRenderer((ModelBase)this, 108, 38);
/* 273 */     this.FrontclothR1.addBox(0.0F, 0.0F, 0.0F, 3, 8, 1);
/* 274 */     this.FrontclothR1.setRotationPoint(-3.0F, 11.0F, -2.9F);
/* 275 */     this.FrontclothR1.setTextureSize(128, 64);
/* 276 */     setRotation(this.FrontclothR1, -0.1047198F, 0.0F, 0.0F);
/*     */     
/* 278 */     this.FrontclothR2 = new ModelRenderer((ModelBase)this, 108, 47);
/* 279 */     this.FrontclothR2.addBox(0.0F, 7.5F, 1.7F, 3, 3, 1);
/* 280 */     this.FrontclothR2.setRotationPoint(-3.0F, 11.0F, -2.9F);
/* 281 */     this.FrontclothR2.setTextureSize(128, 64);
/* 282 */     setRotation(this.FrontclothR2, -0.3316126F, 0.0F, 0.0F);
/*     */     
/* 284 */     this.FrontclothL1 = new ModelRenderer((ModelBase)this, 108, 38);
/* 285 */     this.FrontclothL1.mirror = true;
/* 286 */     this.FrontclothL1.addBox(0.0F, 0.0F, 0.0F, 3, 8, 1);
/* 287 */     this.FrontclothL1.setRotationPoint(0.0F, 11.0F, -2.9F);
/* 288 */     this.FrontclothL1.setTextureSize(128, 64);
/* 289 */     setRotation(this.FrontclothL1, -0.1047198F, 0.0F, 0.0F);
/*     */     
/* 291 */     this.FrontclothL2 = new ModelRenderer((ModelBase)this, 108, 47);
/* 292 */     this.FrontclothL2.mirror = true;
/* 293 */     this.FrontclothL2.addBox(0.0F, 7.5F, 1.7F, 3, 3, 1);
/* 294 */     this.FrontclothL2.setRotationPoint(0.0F, 11.0F, -2.9F);
/* 295 */     this.FrontclothL2.setTextureSize(128, 64);
/* 296 */     setRotation(this.FrontclothL2, -0.3316126F, 0.0F, 0.0F);
/*     */ 
/*     */ 
/*     */     
/* 300 */     this.ClothBackR1 = new ModelRenderer((ModelBase)this, 118, 16);
/* 301 */     this.ClothBackR1.mirror = true;
/* 302 */     this.ClothBackR1.addBox(0.0F, 0.0F, 0.0F, 4, 8, 1);
/* 303 */     this.ClothBackR1.setRotationPoint(-4.0F, 11.5F, 2.9F);
/* 304 */     this.ClothBackR1.setTextureSize(128, 64);
/* 305 */     setRotation(this.ClothBackR1, 0.1047198F, 0.0F, 0.0F);
/*     */     
/* 307 */     this.ClothBackR2 = new ModelRenderer((ModelBase)this, 123, 9);
/* 308 */     this.ClothBackR2.addBox(0.0F, 7.8F, -0.9F, 1, 2, 1);
/* 309 */     this.ClothBackR2.setRotationPoint(-4.0F, 11.5F, 2.9F);
/* 310 */     this.ClothBackR2.setTextureSize(128, 64);
/* 311 */     setRotation(this.ClothBackR2, 0.2268928F, 0.0F, 0.0F);
/*     */     
/* 313 */     this.ClothBackR3 = new ModelRenderer((ModelBase)this, 120, 12);
/* 314 */     this.ClothBackR3.mirror = true;
/* 315 */     this.ClothBackR3.addBox(1.0F, 7.8F, -0.9F, 3, 3, 1);
/* 316 */     this.ClothBackR3.setRotationPoint(-4.0F, 11.5F, 2.9F);
/* 317 */     this.ClothBackR3.setTextureSize(128, 64);
/* 318 */     setRotation(this.ClothBackR3, 0.2268928F, 0.0F, 0.0F);
/*     */ 
/*     */     
/* 321 */     this.ClothBackL1 = new ModelRenderer((ModelBase)this, 118, 16);
/* 322 */     this.ClothBackL1.addBox(0.0F, 0.0F, 0.0F, 4, 8, 1);
/* 323 */     this.ClothBackL1.setRotationPoint(0.0F, 11.5F, 2.9F);
/* 324 */     this.ClothBackL1.setTextureSize(128, 64);
/* 325 */     setRotation(this.ClothBackL1, 0.1047198F, 0.0F, 0.0F);
/*     */     
/* 327 */     this.ClothBackL2 = new ModelRenderer((ModelBase)this, 123, 9);
/* 328 */     this.ClothBackL2.mirror = true;
/* 329 */     this.ClothBackL2.addBox(3.0F, 7.8F, -0.9F, 1, 2, 1);
/* 330 */     this.ClothBackL2.setRotationPoint(0.0F, 11.5F, 2.9F);
/* 331 */     this.ClothBackL2.setTextureSize(128, 64);
/* 332 */     setRotation(this.ClothBackL2, 0.2268928F, 0.0F, 0.0F);
/*     */     
/* 334 */     this.ClothBackL3 = new ModelRenderer((ModelBase)this, 120, 12);
/* 335 */     this.ClothBackL3.addBox(0.0F, 7.8F, -0.9F, 3, 3, 1);
/* 336 */     this.ClothBackL3.setRotationPoint(0.0F, 11.5F, 2.9F);
/* 337 */     this.ClothBackL3.setTextureSize(128, 64);
/* 338 */     setRotation(this.ClothBackL3, 0.2268928F, 0.0F, 0.0F);
/*     */ 
/*     */ 
/*     */     
/* 342 */     this.SideclothL2 = new ModelRenderer((ModelBase)this, 116, 34);
/* 343 */     this.SideclothL2.addBox(0.5F, 5.5F, -2.5F, 1, 3, 5);
/*     */     
/* 345 */     this.SideclothL2.setTextureSize(128, 64);
/* 346 */     setRotation(this.SideclothL2, 0.0F, 0.0F, -0.296706F);
/*     */     
/* 348 */     this.SideclothR1 = new ModelRenderer((ModelBase)this, 116, 42);
/* 349 */     this.SideclothR1.addBox(-2.5F, 0.5F, -2.5F, 1, 5, 5);
/*     */     
/* 351 */     this.SideclothR1.setTextureSize(128, 64);
/* 352 */     setRotation(this.SideclothR1, 0.0F, 0.0F, 0.122173F);
/*     */     
/* 354 */     this.SideclothR2 = new ModelRenderer((ModelBase)this, 116, 34);
/* 355 */     this.SideclothR2.addBox(-1.5F, 5.5F, -2.5F, 1, 3, 5);
/*     */     
/* 357 */     this.SideclothR2.setTextureSize(128, 64);
/* 358 */     setRotation(this.SideclothR2, 0.0F, 0.0F, 0.296706F);
/*     */     
/* 360 */     this.SideclothR3 = new ModelRenderer((ModelBase)this, 116, 1);
/* 361 */     this.SideclothR3.addBox(0.4F, 8.4F, -2.5F, 1, 3, 5);
/*     */     
/* 363 */     this.SideclothR3.setTextureSize(128, 64);
/* 364 */     setRotation(this.SideclothR3, 0.0F, 0.0F, 0.5235988F);
/*     */ 
/*     */ 
/*     */     
/* 368 */     this.SidepanelR1 = new ModelRenderer((ModelBase)this, 116, 25);
/* 369 */     this.SidepanelR1.addBox(-2.5F, 0.5F, -2.5F, 1, 4, 5);
/*     */     
/* 371 */     this.SidepanelR1.setTextureSize(128, 64);
/* 372 */     this.SidepanelR1.mirror = true;
/* 373 */     setRotation(this.SidepanelR1, 0.0F, 0.0F, 0.4363323F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 379 */     this.LegpanelR6 = new ModelRenderer((ModelBase)this, 82, 38);
/* 380 */     this.LegpanelR6.addBox(-3.0F, 4.5F, -1.5F, 2, 3, 1);
/*     */     
/* 382 */     this.LegpanelR6.setTextureSize(128, 64);
/* 383 */     setRotation(this.LegpanelR6, -0.4363323F, 0.0F, 0.0F);
/*     */     
/* 385 */     this.LegpanelR5 = new ModelRenderer((ModelBase)this, 76, 42);
/* 386 */     this.LegpanelR5.addBox(-3.0F, 2.5F, -2.5F, 2, 3, 1);
/*     */     
/* 388 */     this.LegpanelR5.setTextureSize(128, 64);
/* 389 */     setRotation(this.LegpanelR5, -0.4363323F, 0.0F, 0.0F);
/*     */     
/* 391 */     this.LegpanelR4 = new ModelRenderer((ModelBase)this, 76, 38);
/* 392 */     this.LegpanelR4.addBox(-3.0F, 0.5F, -3.5F, 2, 3, 1);
/*     */     
/* 394 */     this.LegpanelR4.setTextureSize(128, 64);
/* 395 */     setRotation(this.LegpanelR4, -0.4363323F, 0.0F, 0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 405 */     this.SideclothL3 = new ModelRenderer((ModelBase)this, 116, 1);
/* 406 */     this.SideclothL3.addBox(-1.4F, 8.4F, -2.5F, 1, 3, 5);
/*     */     
/* 408 */     this.SideclothL3.setTextureSize(128, 64);
/* 409 */     setRotation(this.SideclothL3, 0.0F, 0.0F, -0.5235988F);
/*     */     
/* 411 */     this.Focipouch = new ModelRenderer((ModelBase)this, 100, 20);
/* 412 */     this.Focipouch.addBox(3.5F, 0.5F, -2.5F, 3, 6, 5);
/*     */     
/* 414 */     this.Focipouch.setTextureSize(128, 64);
/* 415 */     setRotation(this.Focipouch, 0.0F, 0.0F, -0.122173F);
/*     */     
/* 417 */     this.SideclothL1 = new ModelRenderer((ModelBase)this, 116, 42);
/* 418 */     this.SideclothL1.addBox(1.5F, 0.5F, -2.5F, 1, 5, 5);
/*     */     
/* 420 */     this.SideclothL1.setTextureSize(128, 64);
/* 421 */     setRotation(this.SideclothL1, 0.0F, 0.0F, -0.122173F);
/*     */ 
/*     */ 
/*     */     
/* 425 */     this.LegpanelL4 = new ModelRenderer((ModelBase)this, 76, 38);
/* 426 */     this.LegpanelL4.mirror = true;
/* 427 */     this.LegpanelL4.addBox(1.0F, 0.5F, -3.5F, 2, 3, 1);
/*     */     
/* 429 */     this.LegpanelL4.setTextureSize(128, 64);
/* 430 */     setRotation(this.LegpanelL4, -0.4363323F, 0.0F, 0.0F);
/*     */     
/* 432 */     this.LegpanelL5 = new ModelRenderer((ModelBase)this, 76, 42);
/* 433 */     this.LegpanelL5.mirror = true;
/* 434 */     this.LegpanelL5.addBox(1.0F, 2.5F, -2.5F, 2, 3, 1);
/*     */     
/* 436 */     this.LegpanelL5.setTextureSize(128, 64);
/* 437 */     setRotation(this.LegpanelL5, -0.4363323F, 0.0F, 0.0F);
/*     */     
/* 439 */     this.LegpanelL6 = new ModelRenderer((ModelBase)this, 82, 38);
/* 440 */     this.LegpanelL6.mirror = true;
/* 441 */     this.LegpanelL6.addBox(1.0F, 4.5F, -1.5F, 2, 3, 1);
/*     */     
/* 443 */     this.LegpanelL6.setTextureSize(128, 64);
/* 444 */     setRotation(this.LegpanelL6, -0.4363323F, 0.0F, 0.0F);
/*     */     
/* 446 */     this.SidepanelL1 = new ModelRenderer((ModelBase)this, 116, 25);
/* 447 */     this.SidepanelL1.addBox(1.5F, 0.5F, -2.5F, 1, 4, 5);
/*     */     
/* 449 */     this.SidepanelL1.setTextureSize(128, 64);
/* 450 */     setRotation(this.SidepanelL1, 0.0F, 0.0F, -0.4363323F);
/*     */     
/* 452 */     this.bipedHeadwear.cubeList.clear();
/* 453 */     this.bipedHead.cubeList.clear();
/* 454 */     this.bipedHead.addChild(this.Hood1);
/* 455 */     this.bipedHead.addChild(this.Hood2);
/* 456 */     this.bipedHead.addChild(this.Hood3);
/* 457 */     this.bipedHead.addChild(this.Hood4);
/*     */     
/* 459 */     this.bipedBody.cubeList.clear();
/* 460 */     this.bipedRightLeg.cubeList.clear();
/* 461 */     this.bipedLeftLeg.cubeList.clear();
/* 462 */     this.bipedBody.addChild(this.Mbelt);
/* 463 */     this.bipedBody.addChild(this.MbeltB);
/* 464 */     this.bipedBody.addChild(this.MbeltL);
/* 465 */     this.bipedBody.addChild(this.MbeltR);
/* 466 */     if (f < 1.0F) {
/* 467 */       this.bipedLeftLeg.addChild(this.Focipouch);
/* 468 */       this.bipedBody.addChild(this.FrontclothR1);
/* 469 */       this.bipedBody.addChild(this.FrontclothR2);
/* 470 */       this.bipedBody.addChild(this.FrontclothL1);
/* 471 */       this.bipedBody.addChild(this.FrontclothL2);
/*     */       
/* 473 */       this.bipedBody.addChild(this.ClothBackR1);
/* 474 */       this.bipedBody.addChild(this.ClothBackR2);
/* 475 */       this.bipedBody.addChild(this.ClothBackR3);
/*     */       
/* 477 */       this.bipedBody.addChild(this.ClothBackL1);
/* 478 */       this.bipedBody.addChild(this.ClothBackL2);
/* 479 */       this.bipedBody.addChild(this.ClothBackL3);
/*     */     } else {
/* 481 */       this.bipedBody.addChild(this.Chestplate);
/* 482 */       this.bipedBody.addChild(this.Chestthing);
/* 483 */       this.bipedBody.addChild(this.Scroll);
/* 484 */       this.bipedBody.addChild(this.Backplate);
/* 485 */       this.bipedBody.addChild(this.Book);
/* 486 */       this.bipedBody.addChild(this.ClothchestL);
/* 487 */       this.bipedBody.addChild(this.ClothchestR);
/*     */     } 
/*     */     
/* 490 */     this.bipedRightArm.cubeList.clear();
/* 491 */     this.bipedRightArm.addChild(this.ShoulderR);
/* 492 */     this.bipedRightArm.addChild(this.RArm1);
/* 493 */     this.bipedRightArm.addChild(this.RArm2);
/* 494 */     this.bipedRightArm.addChild(this.RArm3);
/* 495 */     this.bipedRightArm.addChild(this.ShoulderplateTopR);
/* 496 */     this.bipedRightArm.addChild(this.ShoulderplateR1);
/* 497 */     this.bipedRightArm.addChild(this.ShoulderplateR2);
/* 498 */     this.bipedRightArm.addChild(this.ShoulderplateR3);
/*     */     
/* 500 */     this.bipedLeftArm.cubeList.clear();
/* 501 */     this.bipedLeftArm.addChild(this.ShoulderL);
/* 502 */     this.bipedLeftArm.addChild(this.LArm1);
/* 503 */     this.bipedLeftArm.addChild(this.LArm2);
/* 504 */     this.bipedLeftArm.addChild(this.LArm3);
/* 505 */     this.bipedLeftArm.addChild(this.ShoulderplateTopL);
/* 506 */     this.bipedLeftArm.addChild(this.ShoulderplateL1);
/* 507 */     this.bipedLeftArm.addChild(this.ShoulderplateL2);
/* 508 */     this.bipedLeftArm.addChild(this.ShoulderplateL3);
/*     */ 
/*     */ 
/*     */     
/* 512 */     this.bipedRightLeg.addChild(this.LegpanelR4);
/* 513 */     this.bipedRightLeg.addChild(this.LegpanelR5);
/* 514 */     this.bipedRightLeg.addChild(this.LegpanelR6);
/* 515 */     this.bipedRightLeg.addChild(this.SidepanelR1);
/*     */     
/* 517 */     this.bipedRightLeg.addChild(this.SideclothR1);
/* 518 */     this.bipedRightLeg.addChild(this.SideclothR2);
/* 519 */     this.bipedRightLeg.addChild(this.SideclothR3);
/*     */ 
/*     */ 
/*     */     
/* 523 */     this.bipedLeftLeg.addChild(this.LegpanelL4);
/* 524 */     this.bipedLeftLeg.addChild(this.LegpanelL5);
/* 525 */     this.bipedLeftLeg.addChild(this.LegpanelL6);
/* 526 */     this.bipedLeftLeg.addChild(this.SidepanelL1);
/*     */     
/* 528 */     this.bipedLeftLeg.addChild(this.SideclothL1);
/* 529 */     this.bipedLeftLeg.addChild(this.SideclothL2);
/* 530 */     this.bipedLeftLeg.addChild(this.SideclothL3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 536 */     if (entity instanceof net.minecraft.entity.monster.EntitySkeleton || entity instanceof net.minecraft.entity.monster.EntityZombie) {
/* 537 */       setRotationAnglesZombie(f, f1, f2, f3, f4, f5, entity);
/*     */     } else {
/* 539 */       setRotationAngles(f, f1, f2, f3, f4, f5, entity);
/*     */     } 
/*     */     
/* 542 */     float a = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
/* 543 */     float b = MathHelper.cos(f * 0.6662F + 3.1415927F) * 1.4F * f1;
/* 544 */     float c = Math.min(a, b);
/*     */     
/* 546 */     this.FrontclothL1.rotateAngleX = c - 0.1047198F;
/* 547 */     this.FrontclothL2.rotateAngleX = c - 0.3316126F;
/*     */     
/* 549 */     this.ClothBackL1.rotateAngleX = -c + 0.1047198F;
/* 550 */     this.ClothBackL3.rotateAngleX = -c + 0.2268928F;
/*     */ 
/*     */     
/* 553 */     if (this.isChild) {
/* 554 */       float f6 = 2.0F;
/* 555 */       GL11.glPushMatrix();
/* 556 */       GL11.glScalef(1.5F / f6, 1.5F / f6, 1.5F / f6);
/* 557 */       GL11.glTranslatef(0.0F, 16.0F * f5, 0.0F);
/*     */       
/* 559 */       this.bipedHead.render(f5);
/*     */       
/* 561 */       GL11.glPopMatrix();
/* 562 */       GL11.glPushMatrix();
/* 563 */       GL11.glScalef(1.0F / f6, 1.0F / f6, 1.0F / f6);
/* 564 */       GL11.glTranslatef(0.0F, 24.0F * f5, 0.0F);
/* 565 */       this.bipedBody.render(f5);
/* 566 */       this.bipedRightArm.render(f5);
/* 567 */       this.bipedLeftArm.render(f5);
/* 568 */       this.bipedRightLeg.render(f5);
/* 569 */       this.bipedLeftLeg.render(f5);
/*     */       
/* 571 */       this.bipedHeadwear.render(f5);
/*     */       
/* 573 */       GL11.glPopMatrix();
/*     */     } else {
/* 575 */       GL11.glPushMatrix();
/* 576 */       GL11.glScalef(1.01F, 1.01F, 1.01F);
/*     */       
/* 578 */       this.bipedHead.render(f5);
/* 579 */       GL11.glPopMatrix();
/* 580 */       this.bipedBody.render(f5);
/* 581 */       this.bipedRightArm.render(f5);
/* 582 */       this.bipedLeftArm.render(f5);
/* 583 */       this.bipedRightLeg.render(f5);
/* 584 */       this.bipedLeftLeg.render(f5);
/* 585 */       this.bipedHeadwear.render(f5);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setRotation(ModelRenderer model, float x, float y, float z) {
/* 590 */     model.rotateAngleX = x;
/* 591 */     model.rotateAngleY = y;
/* 592 */     model.rotateAngleZ = z;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRotationAnglesZombie(float p_78087_1_, float p_78087_2_, float p_78087_3_, float p_78087_4_, float p_78087_5_, float p_78087_6_, Entity p_78087_7_) {
/* 598 */     setRotationAngles(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, p_78087_7_);
/*     */     
/* 600 */     float f6 = MathHelper.sin(this.onGround * 3.1415927F);
/* 601 */     float f7 = MathHelper.sin((1.0F - (1.0F - this.onGround) * (1.0F - this.onGround)) * 3.1415927F);
/*     */ 
/*     */     
/* 604 */     this.bipedRightArm.rotateAngleZ = 0.0F;
/* 605 */     this.bipedLeftArm.rotateAngleZ = 0.0F;
/* 606 */     this.bipedRightArm.rotateAngleY = -(0.1F - f6 * 0.6F);
/* 607 */     this.bipedLeftArm.rotateAngleY = 0.1F - f6 * 0.6F;
/* 608 */     this.bipedRightArm.rotateAngleX = -1.5707964F;
/* 609 */     this.bipedLeftArm.rotateAngleX = -1.5707964F;
/* 610 */     this.bipedRightArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
/* 611 */     this.bipedLeftArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
/* 612 */     this.bipedRightArm.rotateAngleZ += MathHelper.cos(p_78087_3_ * 0.09F) * 0.05F + 0.05F;
/* 613 */     this.bipedLeftArm.rotateAngleZ -= MathHelper.cos(p_78087_3_ * 0.09F) * 0.05F + 0.05F;
/* 614 */     this.bipedRightArm.rotateAngleX += MathHelper.sin(p_78087_3_ * 0.067F) * 0.05F;
/* 615 */     this.bipedLeftArm.rotateAngleX -= MathHelper.sin(p_78087_3_ * 0.067F) * 0.05F;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\gear\ModelRobe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */