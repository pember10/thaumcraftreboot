/*     */ package thaumcraft.client.renderers.models.gear;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelBiped;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelKnightArmor
/*     */   extends ModelBiped
/*     */ {
/*     */   ModelRenderer Frontcloth1;
/*     */   ModelRenderer Helmet;
/*     */   ModelRenderer BeltR;
/*     */   ModelRenderer Mbelt;
/*     */   ModelRenderer MbeltL;
/*     */   ModelRenderer MbeltR;
/*     */   ModelRenderer BeltL;
/*     */   ModelRenderer Chestplate;
/*     */   ModelRenderer CloakAtL;
/*     */   ModelRenderer Backplate;
/*     */   ModelRenderer Cloak3;
/*     */   ModelRenderer CloakAtR;
/*     */   ModelRenderer Tabbard;
/*     */   ModelRenderer Cloak1;
/*     */   ModelRenderer Cloak2;
/*     */   ModelRenderer ShoulderR1;
/*     */   ModelRenderer GauntletR;
/*     */   ModelRenderer GauntletstrapR1;
/*     */   ModelRenderer GauntletstrapR2;
/*     */   ModelRenderer ShoulderR;
/*     */   ModelRenderer ShoulderR0;
/*     */   ModelRenderer ShoulderR2;
/*     */   ModelRenderer ShoulderL1;
/*     */   ModelRenderer GauntletL;
/*     */   ModelRenderer GauntletstrapL1;
/*     */   ModelRenderer GauntletstrapL2;
/*     */   ModelRenderer ShoulderL;
/*     */   ModelRenderer ShoulderL0;
/*     */   ModelRenderer ShoulderL2;
/*     */   ModelRenderer SidepanelR3;
/*     */   ModelRenderer SidepanelR2;
/*     */   ModelRenderer SidepanelL2;
/*     */   ModelRenderer SidepanelR0;
/*     */   ModelRenderer SidepanelL0;
/*     */   ModelRenderer SidepanelR1;
/*     */   ModelRenderer SidepanelL3;
/*     */   ModelRenderer Frontcloth2;
/*     */   ModelRenderer SidepanelL1;
/*     */   
/*     */   public ModelKnightArmor(float f) {
/*  66 */     super(f, 0.0F, 128, 64);
/*  67 */     this.textureWidth = 128;
/*  68 */     this.textureHeight = 64;
/*     */ 
/*     */ 
/*     */     
/*  72 */     this.Helmet = new ModelRenderer((ModelBase)this, 41, 8);
/*  73 */     this.Helmet.addBox(-4.5F, -9.0F, -4.5F, 9, 9, 9);
/*  74 */     this.Helmet.setTextureSize(128, 64);
/*  75 */     setRotation(this.Helmet, 0.0F, 0.0F, 0.0F);
/*     */     
/*  77 */     this.BeltR = new ModelRenderer((ModelBase)this, 76, 44);
/*  78 */     this.BeltR.addBox(-5.0F, 4.0F, -3.0F, 1, 3, 6);
/*  79 */     this.BeltR.setTextureSize(128, 64);
/*  80 */     setRotation(this.BeltR, 0.0F, 0.0F, 0.0F);
/*     */     
/*  82 */     this.Mbelt = new ModelRenderer((ModelBase)this, 56, 55);
/*  83 */     this.Mbelt.addBox(-4.0F, 8.0F, -3.0F, 8, 4, 1);
/*  84 */     this.Mbelt.setTextureSize(128, 64);
/*  85 */     setRotation(this.Mbelt, 0.0F, 0.0F, 0.0F);
/*     */     
/*  87 */     this.MbeltL = new ModelRenderer((ModelBase)this, 76, 44);
/*  88 */     this.MbeltL.addBox(4.0F, 8.0F, -3.0F, 1, 3, 6);
/*  89 */     this.MbeltL.setTextureSize(128, 64);
/*  90 */     setRotation(this.MbeltL, 0.0F, 0.0F, 0.0F);
/*     */     
/*  92 */     this.MbeltR = new ModelRenderer((ModelBase)this, 76, 44);
/*  93 */     this.MbeltR.addBox(-5.0F, 8.0F, -3.0F, 1, 3, 6);
/*  94 */     this.MbeltR.setTextureSize(128, 64);
/*  95 */     setRotation(this.MbeltR, 0.0F, 0.0F, 0.0F);
/*     */     
/*  97 */     this.BeltL = new ModelRenderer((ModelBase)this, 76, 44);
/*  98 */     this.BeltL.addBox(4.0F, 4.0F, -3.0F, 1, 3, 6);
/*  99 */     this.BeltL.setTextureSize(128, 64);
/* 100 */     setRotation(this.BeltL, 0.0F, 0.0F, 0.0F);
/*     */     
/* 102 */     this.Tabbard = new ModelRenderer((ModelBase)this, 114, 52);
/* 103 */     this.Tabbard.addBox(-3.0F, 1.2F, -3.5F, 6, 10, 1);
/* 104 */     this.Tabbard.setTextureSize(128, 64);
/* 105 */     setRotation(this.Tabbard, 0.0F, 0.0F, 0.0F);
/*     */     
/* 107 */     this.CloakAtL = new ModelRenderer((ModelBase)this, 0, 43);
/* 108 */     this.CloakAtL.addBox(2.5F, 1.0F, 2.0F, 2, 1, 3);
/* 109 */     this.CloakAtL.setTextureSize(128, 64);
/* 110 */     setRotation(this.CloakAtL, 0.1396263F, 0.0F, 0.0F);
/*     */     
/* 112 */     this.Backplate = new ModelRenderer((ModelBase)this, 36, 45);
/* 113 */     this.Backplate.addBox(-4.0F, 1.0F, 2.0F, 8, 11, 2);
/* 114 */     this.Backplate.setTextureSize(128, 64);
/* 115 */     setRotation(this.Backplate, 0.0F, 0.0F, 0.0F);
/*     */     
/* 117 */     this.Cloak1 = new ModelRenderer((ModelBase)this, 0, 47);
/* 118 */     this.Cloak1.addBox(0.0F, 0.0F, 0.0F, 9, 12, 1);
/* 119 */     this.Cloak1.setRotationPoint(-4.5F, 1.3F, 4.2F);
/* 120 */     this.Cloak1.setTextureSize(128, 64);
/* 121 */     setRotation(this.Cloak1, 0.1396263F, 0.0F, 0.0F);
/* 122 */     this.Cloak2 = new ModelRenderer((ModelBase)this, 0, 59);
/* 123 */     this.Cloak2.addBox(0.0F, 11.7F, -2.0F, 9, 4, 1);
/* 124 */     this.Cloak2.setRotationPoint(-4.5F, 1.3F, 4.2F);
/* 125 */     this.Cloak2.setTextureSize(128, 64);
/* 126 */     setRotation(this.Cloak2, 0.3069452F, 0.0F, 0.0F);
/* 127 */     this.Cloak3 = new ModelRenderer((ModelBase)this, 0, 59);
/* 128 */     this.Cloak3.addBox(0.0F, 15.2F, -4.2F, 9, 4, 1);
/* 129 */     this.Cloak3.setRotationPoint(-4.5F, 1.3F, 4.2F);
/* 130 */     this.Cloak3.setTextureSize(128, 64);
/* 131 */     setRotation(this.Cloak3, 0.4465716F, 0.0F, 0.0F);
/*     */     
/* 133 */     this.CloakAtR = new ModelRenderer((ModelBase)this, 0, 43);
/* 134 */     this.CloakAtR.addBox(-4.5F, 1.0F, 2.0F, 2, 1, 3);
/* 135 */     this.CloakAtR.setTextureSize(128, 64);
/* 136 */     setRotation(this.CloakAtR, 0.1396263F, 0.0F, 0.0F);
/*     */     
/* 138 */     this.Chestplate = new ModelRenderer((ModelBase)this, 56, 45);
/* 139 */     this.Chestplate.addBox(-4.0F, 1.0F, -3.0F, 8, 7, 1);
/* 140 */     this.Chestplate.setTextureSize(128, 64);
/* 141 */     setRotation(this.Chestplate, 0.0F, 0.0F, 0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     this.ShoulderR1 = new ModelRenderer((ModelBase)this, 0, 19);
/* 148 */     this.ShoulderR1.addBox(-3.3F, 3.5F, -2.5F, 1, 1, 5);
/*     */     
/* 150 */     this.ShoulderR1.setTextureSize(128, 64);
/* 151 */     setRotation(this.ShoulderR1, 0.0F, 0.0F, 0.7853982F);
/*     */     
/* 153 */     this.GauntletR = new ModelRenderer((ModelBase)this, 100, 26);
/* 154 */     this.GauntletR.addBox(-3.5F, 3.5F, -2.5F, 2, 6, 5);
/*     */     
/* 156 */     this.GauntletR.setTextureSize(128, 64);
/* 157 */     this.GauntletR.mirror = true;
/* 158 */     setRotation(this.GauntletR, 0.0F, 0.0F, 0.0F);
/*     */     
/* 160 */     this.GauntletstrapR1 = new ModelRenderer((ModelBase)this, 84, 31);
/* 161 */     this.GauntletstrapR1.addBox(-1.5F, 3.5F, -2.5F, 3, 1, 5);
/*     */     
/* 163 */     this.GauntletstrapR1.setTextureSize(128, 64);
/* 164 */     this.GauntletstrapR1.mirror = true;
/* 165 */     setRotation(this.GauntletstrapR1, 0.0F, 0.0F, 0.0F);
/*     */     
/* 167 */     this.GauntletstrapR2 = new ModelRenderer((ModelBase)this, 84, 31);
/* 168 */     this.GauntletstrapR2.addBox(-1.5F, 6.5F, -2.5F, 3, 1, 5);
/*     */     
/* 170 */     this.GauntletstrapR2.setTextureSize(128, 64);
/* 171 */     this.GauntletstrapR2.mirror = true;
/* 172 */     setRotation(this.GauntletstrapR2, 0.0F, 0.0F, 0.0F);
/*     */     
/* 174 */     this.ShoulderR = new ModelRenderer((ModelBase)this, 56, 35);
/* 175 */     this.ShoulderR.addBox(-3.5F, -2.5F, -2.5F, 5, 5, 5);
/*     */     
/* 177 */     this.ShoulderR.setTextureSize(128, 64);
/* 178 */     this.ShoulderR.mirror = true;
/* 179 */     setRotation(this.ShoulderR, 0.0F, 0.0F, 0.0F);
/*     */     
/* 181 */     this.ShoulderR0 = new ModelRenderer((ModelBase)this, 0, 0);
/* 182 */     this.ShoulderR0.addBox(-4.3F, -1.5F, -3.0F, 3, 5, 6);
/*     */     
/* 184 */     this.ShoulderR0.setTextureSize(128, 64);
/* 185 */     this.ShoulderR0.mirror = true;
/* 186 */     setRotation(this.ShoulderR0, 0.0F, 0.0F, 0.7853982F);
/*     */     
/* 188 */     this.ShoulderR2 = new ModelRenderer((ModelBase)this, 0, 11);
/* 189 */     this.ShoulderR2.addBox(-2.3F, 3.5F, -3.0F, 1, 2, 6);
/*     */     
/* 191 */     this.ShoulderR2.setTextureSize(128, 64);
/* 192 */     this.ShoulderR2.mirror = true;
/* 193 */     setRotation(this.ShoulderR2, 0.0F, 0.0F, 0.7853982F);
/*     */     
/* 195 */     this.ShoulderL1 = new ModelRenderer((ModelBase)this, 0, 19);
/* 196 */     this.ShoulderL1.mirror = true;
/* 197 */     this.ShoulderL1.addBox(2.3F, 3.5F, -2.5F, 1, 1, 5);
/*     */     
/* 199 */     this.ShoulderL1.setTextureSize(128, 64);
/*     */     
/* 201 */     setRotation(this.ShoulderL1, 0.0F, 0.0F, -0.7853982F);
/*     */     
/* 203 */     this.GauntletL = new ModelRenderer((ModelBase)this, 114, 26);
/* 204 */     this.GauntletL.addBox(1.5F, 3.5F, -2.5F, 2, 6, 5);
/*     */     
/* 206 */     this.GauntletL.setTextureSize(128, 64);
/* 207 */     setRotation(this.GauntletL, 0.0F, 0.0F, 0.0F);
/*     */     
/* 209 */     this.GauntletstrapL1 = new ModelRenderer((ModelBase)this, 84, 31);
/* 210 */     this.GauntletstrapL1.mirror = true;
/* 211 */     this.GauntletstrapL1.addBox(-1.5F, 3.5F, -2.5F, 3, 1, 5);
/*     */     
/* 213 */     this.GauntletstrapL1.setTextureSize(128, 64);
/* 214 */     setRotation(this.GauntletstrapL1, 0.0F, 0.0F, 0.0F);
/*     */     
/* 216 */     this.GauntletstrapL2 = new ModelRenderer((ModelBase)this, 84, 31);
/* 217 */     this.GauntletstrapL2.mirror = true;
/* 218 */     this.GauntletstrapL2.addBox(-1.5F, 6.5F, -2.5F, 3, 1, 5);
/*     */     
/* 220 */     this.GauntletstrapL2.setTextureSize(128, 64);
/* 221 */     setRotation(this.GauntletstrapL2, 0.0F, 0.0F, 0.0F);
/*     */     
/* 223 */     this.ShoulderL = new ModelRenderer((ModelBase)this, 56, 35);
/* 224 */     this.ShoulderL.addBox(-1.5F, -2.5F, -2.5F, 5, 5, 5);
/*     */     
/* 226 */     this.ShoulderL.setTextureSize(128, 64);
/* 227 */     setRotation(this.ShoulderL, 0.0F, 0.0F, 0.0F);
/*     */     
/* 229 */     this.ShoulderL0 = new ModelRenderer((ModelBase)this, 0, 0);
/* 230 */     this.ShoulderL0.addBox(1.3F, -1.5F, -3.0F, 3, 5, 6);
/*     */     
/* 232 */     this.ShoulderL0.setTextureSize(128, 64);
/* 233 */     setRotation(this.ShoulderL0, 0.0F, 0.0F, -0.7853982F);
/*     */     
/* 235 */     this.ShoulderL2 = new ModelRenderer((ModelBase)this, 0, 11);
/* 236 */     this.ShoulderL2.addBox(1.3F, 3.5F, -3.0F, 1, 2, 6);
/*     */     
/* 238 */     this.ShoulderL2.setTextureSize(128, 64);
/* 239 */     setRotation(this.ShoulderL2, 0.0F, 0.0F, -0.7853982F);
/*     */     
/* 241 */     this.SidepanelR3 = new ModelRenderer((ModelBase)this, 116, 13);
/* 242 */     this.SidepanelR3.addBox(-3.0F, 2.5F, -2.5F, 1, 4, 5);
/*     */     
/* 244 */     this.SidepanelR3.setTextureSize(128, 64);
/* 245 */     setRotation(this.SidepanelR3, 0.0F, 0.0F, 0.1396263F);
/*     */ 
/*     */     
/* 248 */     this.SidepanelR2 = new ModelRenderer((ModelBase)this, 114, 5);
/* 249 */     this.SidepanelR2.mirror = true;
/* 250 */     this.SidepanelR2.addBox(-2.0F, 2.5F, -2.5F, 2, 3, 5);
/*     */     
/* 252 */     this.SidepanelR2.setTextureSize(128, 64);
/* 253 */     setRotation(this.SidepanelR2, 0.0F, 0.0F, 0.1396263F);
/*     */     
/* 255 */     this.SidepanelL2 = new ModelRenderer((ModelBase)this, 114, 5);
/* 256 */     this.SidepanelL2.addBox(0.0F, 2.5F, -2.5F, 2, 3, 5);
/*     */     
/* 258 */     this.SidepanelL2.setTextureSize(128, 64);
/* 259 */     setRotation(this.SidepanelL2, 0.0F, 0.0F, -0.1396263F);
/*     */     
/* 261 */     this.SidepanelR0 = new ModelRenderer((ModelBase)this, 96, 14);
/* 262 */     this.SidepanelR0.addBox(-3.0F, -0.5F, -2.5F, 5, 3, 5);
/*     */     
/* 264 */     this.SidepanelR0.setTextureSize(128, 64);
/* 265 */     setRotation(this.SidepanelR0, 0.0F, 0.0F, 0.1396263F);
/*     */     
/* 267 */     this.SidepanelL0 = new ModelRenderer((ModelBase)this, 96, 14);
/* 268 */     this.SidepanelL0.addBox(-2.0F, -0.5F, -2.5F, 5, 3, 5);
/*     */     
/* 270 */     this.SidepanelL0.setTextureSize(128, 64);
/* 271 */     setRotation(this.SidepanelL0, 0.0F, 0.0F, -0.1396263F);
/*     */     
/* 273 */     this.SidepanelR1 = new ModelRenderer((ModelBase)this, 96, 7);
/* 274 */     this.SidepanelR1.mirror = true;
/* 275 */     this.SidepanelR1.addBox(0.0F, 2.5F, -2.5F, 2, 2, 5);
/*     */     
/* 277 */     this.SidepanelR1.setTextureSize(128, 64);
/* 278 */     setRotation(this.SidepanelR1, 0.0F, 0.0F, 0.1396263F);
/*     */     
/* 280 */     this.SidepanelL3 = new ModelRenderer((ModelBase)this, 116, 13);
/* 281 */     this.SidepanelL3.addBox(2.0F, 2.5F, -2.5F, 1, 4, 5);
/*     */     
/* 283 */     this.SidepanelL3.setTextureSize(128, 64);
/* 284 */     setRotation(this.SidepanelL3, 0.0F, 0.0F, -0.1396263F);
/*     */     
/* 286 */     this.SidepanelL1 = new ModelRenderer((ModelBase)this, 96, 7);
/* 287 */     this.SidepanelL1.addBox(-2.0F, 2.5F, -2.5F, 2, 2, 5);
/*     */     
/* 289 */     this.SidepanelL1.setTextureSize(128, 64);
/* 290 */     setRotation(this.SidepanelL1, 0.0F, 0.0F, -0.1396263F);
/*     */     
/* 292 */     this.Frontcloth1 = new ModelRenderer((ModelBase)this, 120, 39);
/* 293 */     this.Frontcloth1.addBox(0.0F, 0.0F, 0.0F, 6, 8, 1);
/* 294 */     this.Frontcloth1.setRotationPoint(-3.0F, 11.0F, -3.5F);
/* 295 */     this.Frontcloth1.setTextureSize(128, 64);
/* 296 */     setRotation(this.Frontcloth1, -0.1047198F, 0.0F, 0.0F);
/*     */     
/* 298 */     this.Frontcloth2 = new ModelRenderer((ModelBase)this, 100, 37);
/* 299 */     this.Frontcloth2.addBox(0.0F, 7.5F, 1.8F, 6, 3, 1);
/* 300 */     this.Frontcloth2.setRotationPoint(-3.0F, 11.0F, -3.5F);
/* 301 */     this.Frontcloth2.setTextureSize(128, 64);
/* 302 */     setRotation(this.Frontcloth2, -0.3316126F, 0.0F, 0.0F);
/*     */     
/* 304 */     this.bipedHeadwear.cubeList.clear();
/* 305 */     this.bipedHead.cubeList.clear();
/* 306 */     this.bipedHead.addChild(this.Helmet);
/*     */     
/* 308 */     this.bipedBody.cubeList.clear();
/* 309 */     this.bipedRightLeg.cubeList.clear();
/* 310 */     this.bipedLeftLeg.cubeList.clear();
/*     */     
/* 312 */     this.bipedBody.addChild(this.Mbelt);
/* 313 */     this.bipedBody.addChild(this.MbeltL);
/* 314 */     this.bipedBody.addChild(this.MbeltR);
/*     */     
/* 316 */     if (f >= 1.0F) {
/*     */ 
/*     */       
/* 319 */       this.bipedBody.addChild(this.Chestplate);
/* 320 */       this.bipedBody.addChild(this.Frontcloth1);
/* 321 */       this.bipedBody.addChild(this.Frontcloth2);
/* 322 */       this.bipedBody.addChild(this.Tabbard);
/* 323 */       this.bipedBody.addChild(this.Backplate);
/* 324 */       this.bipedBody.addChild(this.Cloak1);
/* 325 */       this.bipedBody.addChild(this.Cloak2);
/* 326 */       this.bipedBody.addChild(this.Cloak3);
/* 327 */       this.bipedBody.addChild(this.CloakAtL);
/* 328 */       this.bipedBody.addChild(this.CloakAtR);
/*     */     } 
/*     */     
/* 331 */     this.bipedRightArm.cubeList.clear();
/* 332 */     this.bipedRightArm.addChild(this.ShoulderR);
/* 333 */     this.bipedRightArm.addChild(this.ShoulderR0);
/* 334 */     this.bipedRightArm.addChild(this.ShoulderR1);
/* 335 */     this.bipedRightArm.addChild(this.ShoulderR2);
/* 336 */     this.bipedRightArm.addChild(this.GauntletR);
/* 337 */     this.bipedRightArm.addChild(this.GauntletstrapR1);
/* 338 */     this.bipedRightArm.addChild(this.GauntletstrapR2);
/*     */     
/* 340 */     this.bipedLeftArm.cubeList.clear();
/* 341 */     this.bipedLeftArm.addChild(this.ShoulderL);
/* 342 */     this.bipedLeftArm.addChild(this.ShoulderL0);
/* 343 */     this.bipedLeftArm.addChild(this.ShoulderL1);
/* 344 */     this.bipedLeftArm.addChild(this.ShoulderL2);
/* 345 */     this.bipedLeftArm.addChild(this.GauntletL);
/* 346 */     this.bipedLeftArm.addChild(this.GauntletstrapL1);
/* 347 */     this.bipedLeftArm.addChild(this.GauntletstrapL2);
/*     */     
/* 349 */     this.bipedRightLeg.addChild(this.SidepanelR0);
/* 350 */     this.bipedRightLeg.addChild(this.SidepanelR1);
/* 351 */     this.bipedRightLeg.addChild(this.SidepanelR2);
/* 352 */     this.bipedRightLeg.addChild(this.SidepanelR3);
/*     */     
/* 354 */     this.bipedLeftLeg.addChild(this.SidepanelL0);
/* 355 */     this.bipedLeftLeg.addChild(this.SidepanelL1);
/* 356 */     this.bipedLeftLeg.addChild(this.SidepanelL2);
/* 357 */     this.bipedLeftLeg.addChild(this.SidepanelL3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 363 */     if (entity instanceof net.minecraft.entity.monster.EntitySkeleton || entity instanceof net.minecraft.entity.monster.EntityZombie) {
/* 364 */       setRotationAnglesZombie(f, f1, f2, f3, f4, f5, entity);
/*     */     } else {
/* 366 */       setRotationAngles(f, f1, f2, f3, f4, f5, entity);
/*     */     } 
/*     */     
/* 369 */     float a = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
/* 370 */     float b = MathHelper.cos(f * 0.6662F + 3.1415927F) * 1.4F * f1;
/* 371 */     float c = Math.min(a, b);
/*     */     
/* 373 */     this.Frontcloth1.rotateAngleX = c - 0.1047198F;
/* 374 */     this.Frontcloth2.rotateAngleX = c - 0.3316126F;
/*     */     
/* 376 */     this.Cloak1.rotateAngleX = -c / 2.0F + 0.1396263F;
/* 377 */     this.Cloak2.rotateAngleX = -c / 2.0F + 0.3069452F;
/* 378 */     this.Cloak3.rotateAngleX = -c / 2.0F + 0.4465716F;
/*     */     
/* 380 */     if (this.isChild) {
/* 381 */       float f6 = 2.0F;
/* 382 */       GL11.glPushMatrix();
/* 383 */       GL11.glScalef(1.5F / f6, 1.5F / f6, 1.5F / f6);
/* 384 */       GL11.glTranslatef(0.0F, 16.0F * f5, 0.0F);
/* 385 */       this.bipedHead.render(f5);
/* 386 */       GL11.glPopMatrix();
/* 387 */       GL11.glPushMatrix();
/* 388 */       GL11.glScalef(1.0F / f6, 1.0F / f6, 1.0F / f6);
/* 389 */       GL11.glTranslatef(0.0F, 24.0F * f5, 0.0F);
/* 390 */       this.bipedBody.render(f5);
/* 391 */       this.bipedRightArm.render(f5);
/* 392 */       this.bipedLeftArm.render(f5);
/* 393 */       this.bipedRightLeg.render(f5);
/* 394 */       this.bipedLeftLeg.render(f5);
/* 395 */       this.bipedHeadwear.render(f5);
/* 396 */       GL11.glPopMatrix();
/*     */     } else {
/* 398 */       GL11.glPushMatrix();
/* 399 */       GL11.glScalef(1.01F, 1.01F, 1.01F);
/* 400 */       this.bipedHead.render(f5);
/* 401 */       GL11.glPopMatrix();
/* 402 */       this.bipedBody.render(f5);
/* 403 */       this.bipedRightArm.render(f5);
/* 404 */       this.bipedLeftArm.render(f5);
/* 405 */       this.bipedRightLeg.render(f5);
/* 406 */       this.bipedLeftLeg.render(f5);
/* 407 */       this.bipedHeadwear.render(f5);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setRotation(ModelRenderer model, float x, float y, float z) {
/* 412 */     model.rotateAngleX = x;
/* 413 */     model.rotateAngleY = y;
/* 414 */     model.rotateAngleZ = z;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRotationAnglesZombie(float p_78087_1_, float p_78087_2_, float p_78087_3_, float p_78087_4_, float p_78087_5_, float p_78087_6_, Entity p_78087_7_) {
/* 420 */     setRotationAngles(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, p_78087_7_);
/*     */     
/* 422 */     float f6 = MathHelper.sin(this.onGround * 3.1415927F);
/* 423 */     float f7 = MathHelper.sin((1.0F - (1.0F - this.onGround) * (1.0F - this.onGround)) * 3.1415927F);
/*     */ 
/*     */     
/* 426 */     this.bipedRightArm.rotateAngleZ = 0.0F;
/* 427 */     this.bipedLeftArm.rotateAngleZ = 0.0F;
/* 428 */     this.bipedRightArm.rotateAngleY = -(0.1F - f6 * 0.6F);
/* 429 */     this.bipedLeftArm.rotateAngleY = 0.1F - f6 * 0.6F;
/* 430 */     this.bipedRightArm.rotateAngleX = -1.5707964F;
/* 431 */     this.bipedLeftArm.rotateAngleX = -1.5707964F;
/* 432 */     this.bipedRightArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
/* 433 */     this.bipedLeftArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
/* 434 */     this.bipedRightArm.rotateAngleZ += MathHelper.cos(p_78087_3_ * 0.09F) * 0.05F + 0.05F;
/* 435 */     this.bipedLeftArm.rotateAngleZ -= MathHelper.cos(p_78087_3_ * 0.09F) * 0.05F + 0.05F;
/* 436 */     this.bipedRightArm.rotateAngleX += MathHelper.sin(p_78087_3_ * 0.067F) * 0.05F;
/* 437 */     this.bipedLeftArm.rotateAngleX -= MathHelper.sin(p_78087_3_ * 0.067F) * 0.05F;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\gear\ModelKnightArmor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */