/*     */ package thaumcraft.client.renderers.models.gear;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelBiped;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.client.model.AdvancedModelLoader;
/*     */ import net.minecraftforge.client.model.IModelCustom;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.fx.bolt.FXLightningBolt;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.common.items.armor.ItemHoverHarness;
/*     */ import thaumcraft.common.lib.utils.BlockUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ModelHoverHarness
/*     */   extends ModelBiped
/*     */ {
/*  29 */   HashMap<Integer, Long> timingShock = new HashMap<Integer, Long>();
/*  30 */   private static final ResourceLocation HARNESS = new ResourceLocation("thaumcraft", "textures/models/hoverharness.obj");
/*     */   
/*     */   private IModelCustom modelBack;
/*     */   
/*     */   public ModelHoverHarness() {
/*  35 */     this.bipedBody = new ModelRenderer((ModelBase)this, 16, 16);
/*  36 */     this.bipedBody.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, 0.6F);
/*  37 */     this.modelBack = AdvancedModelLoader.loadModel(HARNESS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(Entity entity, float par2, float par3, float par4, float par5, float par6, float par7) {
/*  45 */     GL11.glPushMatrix();
/*  46 */     GL11.glPushMatrix();
/*  47 */     if (entity != null && entity.isSneaking()) {
/*  48 */       GL11.glRotatef(28.64789F, 1.0F, 0.0F, 0.0F);
/*     */     }
/*  50 */     this.bipedBody.render(par7);
/*  51 */     GL11.glPopMatrix();
/*     */     
/*  53 */     GL11.glPushMatrix();
/*  54 */     GL11.glDisable(2896);
/*  55 */     GL11.glScalef(0.1F, 0.1F, 0.1F);
/*  56 */     GL11.glRotatef(90.0F, -1.0F, 0.0F, 0.0F);
/*  57 */     if (entity != null && entity.isSneaking()) {
/*  58 */       GL11.glRotatef(28.64789F, 1.0F, 0.0F, 0.0F);
/*     */     }
/*  60 */     GL11.glTranslatef(0.0F, 0.33F, -3.7F);
/*     */     
/*  62 */     (FMLClientHandler.instance().getClient()).renderEngine.bindTexture(new ResourceLocation("thaumcraft", "textures/models/hoverharness2.png"));
/*  63 */     this.modelBack.renderAll();
/*  64 */     GL11.glEnable(2896);
/*  65 */     GL11.glPopMatrix();
/*     */     
/*  67 */     if (entity != null && entity instanceof EntityPlayer && !GL11.glIsEnabled(3042) && GL11.glGetInteger(2976) == 5888 && ((EntityPlayer)entity).inventory.armorItemInSlot(2).hasTagCompound() && (((EntityPlayer)entity).inventory.armorItemInSlot(2)).stackTagCompound.hasKey("hover") && (((EntityPlayer)entity).inventory.armorItemInSlot(2)).stackTagCompound.getByte("hover") == 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  73 */       long currenttime = System.currentTimeMillis();
/*  74 */       long timeShock = 0L;
/*  75 */       if (this.timingShock.get(Integer.valueOf(entity.getEntityId())) != null) timeShock = ((Long)this.timingShock.get(Integer.valueOf(entity.getEntityId()))).longValue();
/*     */       
/*  77 */       GL11.glPushMatrix();
/*  78 */       float mod = 0.0F;
/*  79 */       if (entity.isSneaking()) {
/*  80 */         GL11.glRotatef(28.64789F, 1.0F, 0.0F, 0.0F);
/*  81 */         GL11.glTranslatef(0.0F, 0.075F, -0.05F);
/*  82 */         mod = 0.075F;
/*     */       } 
/*  84 */       GL11.glTranslatef(0.0F, 0.2F, 0.55F);
/*  85 */       GL11.glPushMatrix();
/*  86 */       UtilsFX.renderQuadCenteredFromIcon(false, ((ItemHoverHarness)((EntityPlayer)entity).inventory.armorItemInSlot(2).getItem()).iconLightningRing, 2.5F, 1.0F, 1.0F, 1.0F, 230, 1, 1.0F);
/*     */ 
/*     */       
/*  89 */       GL11.glPopMatrix();
/*  90 */       GL11.glPushMatrix();
/*  91 */       GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/*  92 */       GL11.glTranslatef(0.0F, 0.0F, 0.03F);
/*  93 */       UtilsFX.renderQuadCenteredFromIcon(false, ((ItemHoverHarness)((EntityPlayer)entity).inventory.armorItemInSlot(2).getItem()).iconLightningRing, 1.5F, 1.0F, 0.5F, 1.0F, 230, 1, 1.0F);
/*     */ 
/*     */       
/*  96 */       GL11.glPopMatrix();
/*  97 */       GL11.glPopMatrix();
/*     */ 
/*     */       
/* 100 */       if (timeShock < currenttime) {
/* 101 */         timeShock = currenttime + 50L + entity.worldObj.rand.nextInt(50);
/* 102 */         this.timingShock.put(Integer.valueOf(entity.getEntityId()), Long.valueOf(timeShock));
/*     */         
/* 104 */         MovingObjectPosition mop = BlockUtils.getTargetBlock(entity.worldObj, entity.posX, entity.posY - 0.44999998807907104D - mod, entity.posZ, ((EntityPlayer)entity).renderYawOffset - 90.0F - entity.worldObj.rand.nextInt(180), (-80 + entity.worldObj.rand.nextInt(160)), false, 6.0D);
/*     */ 
/*     */ 
/*     */         
/* 108 */         if (mop != null) {
/*     */           
/* 110 */           double px = mop.hitVec.xCoord;
/* 111 */           double py = mop.hitVec.yCoord;
/* 112 */           double pz = mop.hitVec.zCoord;
/*     */           
/* 114 */           FXLightningBolt bolt = new FXLightningBolt(entity.worldObj, entity.posX - (MathHelper.cos((((EntityPlayer)entity).renderYawOffset + 90.0F) / 180.0F * 3.141593F) * 0.5F), entity.posY - 0.44999998807907104D - mod, entity.posZ - (MathHelper.sin((((EntityPlayer)entity).renderYawOffset + 90.0F) / 180.0F * 3.141593F) * 0.5F), px, py, pz, entity.worldObj.rand.nextLong(), 1, 2.0F, 3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 120 */           bolt.defaultFractal();
/* 121 */           bolt.setType(6);
/* 122 */           bolt.setWidth(0.015F);
/* 123 */           bolt.finalizeBolt();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 129 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\gear\ModelHoverHarness.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */