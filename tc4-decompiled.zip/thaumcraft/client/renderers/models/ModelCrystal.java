/*    */ package thaumcraft.client.renderers.models;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelCrystal
/*    */   extends ModelBase
/*    */ {
/*    */   ModelRenderer Crystal;
/*    */   
/*    */   public ModelCrystal() {
/* 14 */     this.textureWidth = 64;
/* 15 */     this.textureHeight = 32;
/*    */     
/* 17 */     this.Crystal = new ModelRenderer(this, 0, 0);
/* 18 */     this.Crystal.addBox(-16.0F, -16.0F, 0.0F, 16, 16, 16);
/* 19 */     this.Crystal.setRotationPoint(0.0F, 32.0F, 0.0F);
/* 20 */     this.Crystal.setTextureSize(64, 32);
/* 21 */     this.Crystal.mirror = true;
/* 22 */     setRotation(this.Crystal, 0.7071F, 0.0F, 0.7071F);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void render() {
/* 29 */     this.Crystal.render(0.0625F);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRotation(ModelRenderer model, float x, float y, float z) {
/* 34 */     model.rotateAngleX = x;
/* 35 */     model.rotateAngleY = y;
/* 36 */     model.rotateAngleZ = z;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\ModelCrystal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */