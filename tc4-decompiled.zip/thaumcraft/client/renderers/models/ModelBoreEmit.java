/*    */ package thaumcraft.client.renderers.models;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelBoreEmit
/*    */   extends ModelBase
/*    */ {
/*    */   ModelRenderer Knob;
/*    */   ModelRenderer Cross1;
/*    */   ModelRenderer Cross3;
/*    */   ModelRenderer Cross2;
/*    */   ModelRenderer Rod;
/*    */   
/*    */   public ModelBoreEmit() {
/* 19 */     this.textureWidth = 128;
/* 20 */     this.textureHeight = 64;
/*    */     
/* 22 */     this.Knob = new ModelRenderer(this, 66, 0);
/* 23 */     this.Knob.addBox(-2.0F, 12.0F, -2.0F, 4, 4, 4);
/* 24 */     this.Knob.setRotationPoint(0.0F, 0.0F, 0.0F);
/* 25 */     this.Knob.setTextureSize(128, 64);
/* 26 */     this.Knob.mirror = true;
/* 27 */     setRotation(this.Knob, 0.0F, 0.0F, 0.0F);
/* 28 */     this.Cross1 = new ModelRenderer(this, 56, 16);
/* 29 */     this.Cross1.addBox(-2.0F, 0.0F, -2.0F, 4, 1, 4);
/* 30 */     this.Cross1.setRotationPoint(0.0F, 8.0F, 0.0F);
/* 31 */     this.Cross1.setTextureSize(128, 64);
/* 32 */     this.Cross1.mirror = true;
/* 33 */     setRotation(this.Cross1, 0.0F, 0.0F, 0.0F);
/* 34 */     this.Cross3 = new ModelRenderer(this, 56, 16);
/* 35 */     this.Cross3.addBox(-2.0F, 0.0F, -2.0F, 4, 1, 4);
/* 36 */     this.Cross3.setRotationPoint(0.0F, 0.0F, 0.0F);
/* 37 */     this.Cross3.setTextureSize(128, 64);
/* 38 */     this.Cross3.mirror = true;
/* 39 */     setRotation(this.Cross3, 0.0F, 0.0F, 0.0F);
/* 40 */     this.Cross2 = new ModelRenderer(this, 56, 24);
/* 41 */     this.Cross2.addBox(-3.0F, 4.0F, -3.0F, 6, 1, 6);
/* 42 */     this.Cross2.setRotationPoint(0.0F, 0.0F, 0.0F);
/* 43 */     this.Cross2.setTextureSize(128, 64);
/* 44 */     this.Cross2.mirror = true;
/* 45 */     setRotation(this.Cross2, 0.0F, 0.0F, 0.0F);
/* 46 */     this.Rod = new ModelRenderer(this, 56, 0);
/* 47 */     this.Rod.addBox(-1.0F, 1.0F, -1.0F, 2, 11, 2);
/* 48 */     this.Rod.setRotationPoint(0.0F, 0.0F, 0.0F);
/* 49 */     this.Rod.setTextureSize(128, 64);
/* 50 */     this.Rod.mirror = true;
/* 51 */     setRotation(this.Rod, 0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(boolean focus) {
/* 56 */     float f5 = 0.0625F;
/* 57 */     if (focus) this.Knob.render(f5); 
/* 58 */     this.Cross1.render(f5);
/* 59 */     this.Cross3.render(f5);
/* 60 */     this.Cross2.render(f5);
/* 61 */     this.Rod.render(f5);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void setRotation(ModelRenderer model, float x, float y, float z) {
/* 67 */     model.rotateAngleX = x;
/* 68 */     model.rotateAngleY = y;
/* 69 */     model.rotateAngleZ = z;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\ModelBoreEmit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */