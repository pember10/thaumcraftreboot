/*    */ package thaumcraft.client.renderers.models;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelTubeValve
/*    */   extends ModelBase
/*    */ {
/*    */   ModelRenderer ValveRod;
/*    */   ModelRenderer ValveRing;
/*    */   
/*    */   public ModelTubeValve() {
/* 15 */     this.textureWidth = 64;
/* 16 */     this.textureHeight = 32;
/*    */     
/* 18 */     this.ValveRod = new ModelRenderer(this, 0, 10);
/* 19 */     this.ValveRod.addBox(-1.0F, 2.0F, -1.0F, 2, 2, 2);
/* 20 */     this.ValveRod.setRotationPoint(0.0F, 0.0F, 0.0F);
/* 21 */     this.ValveRod.setTextureSize(64, 32);
/* 22 */     this.ValveRod.mirror = true;
/* 23 */     setRotation(this.ValveRod, 0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   
/*    */   public void render() {
/* 28 */     this.ValveRod.render(0.0625F);
/*    */   }
/*    */ 
/*    */   
/*    */   private void setRotation(ModelRenderer model, float x, float y, float z) {
/* 33 */     model.rotateAngleX = x;
/* 34 */     model.rotateAngleY = y;
/* 35 */     model.rotateAngleZ = z;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\ModelTubeValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */