/*    */ package thaumcraft.client.renderers.models.entities;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.client.renderer.OpenGlHelper;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.common.entities.monster.EntityTaintSporeSwarmer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelTaintSporeSwarmer
/*    */   extends ModelBase
/*    */ {
/*    */   ModelRenderer cube;
/*    */   ModelRenderer cube2;
/*    */   
/*    */   public ModelTaintSporeSwarmer() {
/* 23 */     this.textureWidth = 64;
/* 24 */     this.textureHeight = 64;
/*    */     
/* 26 */     this.cube = new ModelRenderer(this, 0, 0);
/* 27 */     this.cube.addBox(-8.0F, 0.0F, -8.0F, 16, 16, 16);
/* 28 */     this.cube.setRotationPoint(0.0F, 0.0F, 0.0F);
/*    */     
/* 30 */     this.cube2 = new ModelRenderer(this, 0, 32);
/* 31 */     this.cube2.addBox(-8.0F, -8.0F, -8.0F, 16, 16, 16);
/* 32 */     this.cube2.setRotationPoint(0.0F, 16.0F, 0.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
/* 38 */     setRotationAngles(par2, par3, par4, par5, par6, par7, par1Entity);
/*    */     
/* 40 */     EntityTaintSporeSwarmer spore = (EntityTaintSporeSwarmer)par1Entity;
/* 41 */     GL11.glPushMatrix();
/* 42 */     GL11.glEnable(3042);
/* 43 */     GL11.glBlendFunc(770, 771);
/*    */     
/* 45 */     GL11.glPushMatrix();
/* 46 */     float f1 = spore.displaySize;
/* 47 */     float f3 = -0.07F;
/* 48 */     float pulse = 0.025F * MathHelper.sin(spore.ticksExisted * 0.075F);
/* 49 */     GL11.glTranslatef(0.0F, 1.6F, 0.0F);
/* 50 */     GL11.glScalef(f3 * f1 - pulse, f3 * f1 + pulse, f3 * f1 - pulse);
/* 51 */     GL11.glTranslatef(0.0F, -(f3 * f1 + pulse) / 2.0F, 0.0F);
/* 52 */     int j = 15728880;
/* 53 */     int k = j % 65536;
/* 54 */     int l = j / 65536;
/* 55 */     OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, k / 1.0F, l / 1.0F);
/* 56 */     this.cube.render(par7);
/* 57 */     GL11.glPopMatrix();
/* 58 */     GL11.glPushMatrix();
/* 59 */     j = spore.getBrightnessForRender(par7);
/* 60 */     k = j % 65536;
/* 61 */     l = j / 65536;
/* 62 */     OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, k / 1.0F, l / 1.0F);
/* 63 */     this.cube2.render(par7);
/* 64 */     GL11.glPopMatrix();
/* 65 */     GL11.glDisable(3042);
/* 66 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity entity) {
/* 72 */     float intensity = 0.02F;
/* 73 */     if (((EntityLivingBase)entity).hurtTime > 0) intensity = 0.04F; 
/* 74 */     this.cube.rotateAngleX = intensity * MathHelper.sin(par3 * 0.05F);
/* 75 */     this.cube.rotateAngleZ = intensity * MathHelper.sin(par3 * 0.1F);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\entities\ModelTaintSporeSwarmer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */