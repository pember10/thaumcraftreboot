/*     */ package thaumcraft.client.renderers.models.entities;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelBox;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.GLAllocation;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class ModelRendererTaintacle
/*     */   extends ModelRenderer {
/*     */   private int textureOffsetX;
/*     */   private int textureOffsetY;
/*     */   
/*     */   public ModelRendererTaintacle(ModelBase par1ModelBase) {
/*  19 */     super(par1ModelBase);
/*     */   }
/*     */   private boolean compiled; private int displayList; private ModelBase baseModel;
/*     */   
/*     */   public ModelRendererTaintacle(ModelBase par1ModelBase, int par2, int par3) {
/*  24 */     this(par1ModelBase);
/*  25 */     setTextureOffset(par2, par3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void render(float par1, float scale) {
/*  47 */     if (!this.isHidden)
/*     */     {
/*  49 */       if (this.showModel) {
/*     */         
/*  51 */         if (!this.compiled)
/*     */         {
/*  53 */           compileDisplayList(par1);
/*     */         }
/*     */         
/*  56 */         GL11.glTranslatef(this.offsetX, this.offsetY, this.offsetZ);
/*     */ 
/*     */         
/*  59 */         if (this.rotateAngleX == 0.0F && this.rotateAngleY == 0.0F && this.rotateAngleZ == 0.0F) {
/*     */           
/*  61 */           if (this.rotationPointX == 0.0F && this.rotationPointY == 0.0F && this.rotationPointZ == 0.0F) {
/*     */             
/*  63 */             if (this.childModels == null) {
/*  64 */               int j = 15728880;
/*  65 */               int k = j % 65536;
/*  66 */               int l = j / 65536;
/*  67 */               OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, k / 1.0F, l / 1.0F);
/*     */             } 
/*  69 */             GL11.glCallList(this.displayList);
/*     */             
/*  71 */             if (this.childModels != null)
/*     */             {
/*  73 */               for (int i = 0; i < this.childModels.size(); i++)
/*     */               {
/*  75 */                 GL11.glPushMatrix();
/*  76 */                 GL11.glScalef(scale, scale, scale);
/*  77 */                 ((ModelRendererTaintacle)this.childModels.get(i)).render(par1, scale);
/*  78 */                 GL11.glPopMatrix();
/*     */               }
/*     */             
/*     */             }
/*     */           } else {
/*     */             
/*  84 */             GL11.glTranslatef(this.rotationPointX * par1, this.rotationPointY * par1, this.rotationPointZ * par1);
/*  85 */             if (this.childModels == null) {
/*  86 */               int j = 15728880;
/*  87 */               int k = j % 65536;
/*  88 */               int l = j / 65536;
/*  89 */               OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, k / 1.0F, l / 1.0F);
/*     */             } 
/*  91 */             GL11.glCallList(this.displayList);
/*     */             
/*  93 */             if (this.childModels != null)
/*     */             {
/*  95 */               for (int i = 0; i < this.childModels.size(); i++) {
/*     */                 
/*  97 */                 GL11.glPushMatrix();
/*  98 */                 GL11.glScalef(scale, scale, scale);
/*  99 */                 ((ModelRendererTaintacle)this.childModels.get(i)).render(par1, scale);
/* 100 */                 GL11.glPopMatrix();
/*     */               } 
/*     */             }
/*     */             
/* 104 */             GL11.glTranslatef(-this.rotationPointX * par1, -this.rotationPointY * par1, -this.rotationPointZ * par1);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 109 */           GL11.glPushMatrix();
/* 110 */           GL11.glTranslatef(this.rotationPointX * par1, this.rotationPointY * par1, this.rotationPointZ * par1);
/*     */           
/* 112 */           if (this.rotateAngleZ != 0.0F)
/*     */           {
/* 114 */             GL11.glRotatef(this.rotateAngleZ * 57.295776F, 0.0F, 0.0F, 1.0F);
/*     */           }
/*     */           
/* 117 */           if (this.rotateAngleY != 0.0F)
/*     */           {
/* 119 */             GL11.glRotatef(this.rotateAngleY * 57.295776F, 0.0F, 1.0F, 0.0F);
/*     */           }
/*     */           
/* 122 */           if (this.rotateAngleX != 0.0F)
/*     */           {
/* 124 */             GL11.glRotatef(this.rotateAngleX * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */           }
/*     */           
/* 127 */           if (this.childModels == null) {
/* 128 */             int j = 15728880;
/* 129 */             int k = j % 65536;
/* 130 */             int l = j / 65536;
/* 131 */             OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, k / 1.0F, l / 1.0F);
/*     */           } 
/* 133 */           GL11.glCallList(this.displayList);
/*     */           
/* 135 */           if (this.childModels != null)
/*     */           {
/* 137 */             for (int i = 0; i < this.childModels.size(); i++) {
/*     */               
/* 139 */               GL11.glPushMatrix();
/* 140 */               GL11.glScalef(scale, scale, scale);
/* 141 */               ((ModelRendererTaintacle)this.childModels.get(i)).render(par1, scale);
/* 142 */               GL11.glPopMatrix();
/*     */             } 
/*     */           }
/*     */           
/* 146 */           GL11.glPopMatrix();
/*     */         } 
/*     */         
/* 149 */         GL11.glTranslatef(-this.offsetX, -this.offsetY, -this.offsetZ);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private void compileDisplayList(float par1) {
/* 162 */     this.displayList = GLAllocation.generateDisplayLists(1);
/* 163 */     GL11.glNewList(this.displayList, 4864);
/* 164 */     Tessellator tessellator = Tessellator.instance;
/*     */     
/* 166 */     for (int i = 0; i < this.cubeList.size(); i++)
/*     */     {
/* 168 */       ((ModelBox)this.cubeList.get(i)).render(tessellator, par1);
/*     */     }
/*     */     
/* 171 */     GL11.glEndList();
/* 172 */     this.compiled = true;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\entities\ModelRendererTaintacle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */