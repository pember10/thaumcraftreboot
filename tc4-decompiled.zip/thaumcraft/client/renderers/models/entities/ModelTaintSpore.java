/*    */ package thaumcraft.client.renderers.models.entities;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelTaintSpore
/*    */   extends ModelBase
/*    */ {
/*    */   ModelRenderer cube;
/*    */   
/*    */   public ModelTaintSpore() {
/* 19 */     this.textureWidth = 64;
/* 20 */     this.textureHeight = 64;
/*    */     
/* 22 */     this.cube = new ModelRenderer(this, 0, 0);
/*    */     
/* 24 */     this.cube.addBox(-6.0F, 2.0F, -6.0F, 12, 12, 12);
/* 25 */     this.cube.addBox(-8.0F, 0.0F, -8.0F, 16, 16, 16);
/* 26 */     this.cube.setRotationPoint(0.0F, 24.0F, 0.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
/* 32 */     setRotationAngles(par2, par3, par4, par5, par6, par7, par1Entity);
/* 33 */     GL11.glPushMatrix();
/* 34 */     GL11.glEnable(3042);
/* 35 */     GL11.glBlendFunc(770, 771);
/* 36 */     this.cube.render(par7);
/* 37 */     GL11.glDisable(3042);
/* 38 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity entity) {
/* 44 */     float intensity = 0.02F;
/* 45 */     if (((EntityLivingBase)entity).hurtTime > 0) intensity = 0.04F; 
/* 46 */     this.cube.rotateAngleX = intensity * MathHelper.sin(par3 * 0.05F);
/* 47 */     this.cube.rotateAngleZ = intensity * MathHelper.sin(par3 * 0.1F);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\entities\ModelTaintSpore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */