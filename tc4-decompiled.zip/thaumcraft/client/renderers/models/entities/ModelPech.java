/*     */ package thaumcraft.client.renderers.models.entities;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import thaumcraft.common.entities.monster.EntityPech;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelPech
/*     */   extends ModelBase
/*     */ {
/*     */   ModelRenderer Body;
/*     */   ModelRenderer RightLeg;
/*     */   ModelRenderer LeftLeg;
/*     */   ModelRenderer Head;
/*     */   ModelRenderer Jowls;
/*     */   ModelRenderer LowerPack;
/*     */   ModelRenderer UpperPack;
/*     */   public ModelRenderer RightArm;
/*     */   ModelRenderer LeftArm;
/*     */   
/*     */   public ModelPech() {
/*  35 */     this.textureWidth = 128;
/*  36 */     this.textureHeight = 64;
/*     */     
/*  38 */     this.Body = new ModelRenderer(this, 34, 12);
/*  39 */     this.Body.addBox(-3.0F, 0.0F, 0.0F, 6, 10, 6);
/*  40 */     this.Body.setRotationPoint(0.0F, 9.0F, -3.0F);
/*  41 */     this.Body.setTextureSize(128, 64);
/*  42 */     this.Body.mirror = true;
/*  43 */     setRotation(this.Body, 0.3129957F, 0.0F, 0.0F);
/*     */     
/*  45 */     this.RightLeg = new ModelRenderer(this, 35, 1);
/*  46 */     this.RightLeg.mirror = true;
/*  47 */     this.RightLeg.addBox(-2.9F, 0.0F, 0.0F, 3, 6, 3);
/*  48 */     this.RightLeg.setRotationPoint(0.0F, 18.0F, 0.0F);
/*  49 */     this.RightLeg.setTextureSize(128, 64);
/*  50 */     this.RightLeg.mirror = true;
/*  51 */     setRotation(this.RightLeg, 0.0F, 0.0F, 0.0F);
/*  52 */     this.RightLeg.mirror = false;
/*     */     
/*  54 */     this.LeftLeg = new ModelRenderer(this, 35, 1);
/*  55 */     this.LeftLeg.addBox(-0.1F, 0.0F, 0.0F, 3, 6, 3);
/*  56 */     this.LeftLeg.setRotationPoint(0.0F, 18.0F, 0.0F);
/*  57 */     this.LeftLeg.setTextureSize(128, 64);
/*  58 */     this.LeftLeg.mirror = true;
/*  59 */     setRotation(this.LeftLeg, 0.0F, 0.0F, 0.0F);
/*     */     
/*  61 */     this.Head = new ModelRenderer(this, 2, 11);
/*  62 */     this.Head.addBox(-3.5F, -5.0F, -5.0F, 7, 5, 5);
/*  63 */     this.Head.setRotationPoint(0.0F, 8.0F, 0.0F);
/*  64 */     this.Head.setTextureSize(128, 64);
/*  65 */     this.Head.mirror = true;
/*  66 */     setRotation(this.Head, 0.0F, 0.0F, 0.0F);
/*     */     
/*  68 */     this.Jowls = new ModelRenderer(this, 1, 21);
/*  69 */     this.Jowls.addBox(-4.0F, -1.0F, -6.0F, 8, 3, 5);
/*  70 */     this.Jowls.setRotationPoint(0.0F, 8.0F, 0.0F);
/*  71 */     this.Jowls.setTextureSize(128, 64);
/*  72 */     this.Jowls.mirror = true;
/*  73 */     setRotation(this.Jowls, 0.0F, 0.0F, 0.0F);
/*     */     
/*  75 */     this.LowerPack = new ModelRenderer(this, 0, 0);
/*  76 */     this.LowerPack.addBox(-5.0F, 0.0F, 0.0F, 10, 5, 5);
/*  77 */     this.LowerPack.setRotationPoint(0.0F, 10.0F, 3.5F);
/*  78 */     this.LowerPack.setTextureSize(128, 64);
/*  79 */     this.LowerPack.mirror = true;
/*  80 */     setRotation(this.LowerPack, 0.3013602F, 0.0F, 0.0F);
/*     */     
/*  82 */     this.UpperPack = new ModelRenderer(this, 64, 1);
/*  83 */     this.UpperPack.addBox(-7.5F, -14.0F, 0.0F, 15, 14, 11);
/*  84 */     this.UpperPack.setRotationPoint(0.0F, 10.0F, 3.0F);
/*  85 */     this.UpperPack.setTextureSize(128, 64);
/*  86 */     this.UpperPack.mirror = true;
/*  87 */     setRotation(this.UpperPack, 0.4537856F, 0.0F, 0.0F);
/*     */ 
/*     */     
/*  90 */     this.RightArm = new ModelRenderer(this, 52, 2);
/*  91 */     this.RightArm.mirror = true;
/*  92 */     this.RightArm.addBox(-2.0F, 0.0F, -1.0F, 2, 6, 2);
/*  93 */     this.RightArm.setRotationPoint(-3.0F, 10.0F, -1.0F);
/*  94 */     this.RightArm.setTextureSize(128, 64);
/*  95 */     this.RightArm.mirror = true;
/*  96 */     setRotation(this.RightArm, 0.0F, 0.0F, 0.0F);
/*  97 */     this.RightArm.mirror = false;
/*     */     
/*  99 */     this.LeftArm = new ModelRenderer(this, 52, 2);
/* 100 */     this.LeftArm.addBox(0.0F, 0.0F, -1.0F, 2, 6, 2);
/* 101 */     this.LeftArm.setRotationPoint(3.0F, 10.0F, -1.0F);
/* 102 */     this.LeftArm.setTextureSize(128, 64);
/* 103 */     this.LeftArm.mirror = true;
/* 104 */     setRotation(this.LeftArm, 0.0F, 0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
/* 109 */     setRotationAngles(par2, par3, par4, par5, par6, par7, par1Entity);
/* 110 */     this.Body.render(par7);
/* 111 */     this.RightLeg.render(par7);
/* 112 */     this.LeftLeg.render(par7);
/* 113 */     this.Head.render(par7);
/* 114 */     this.Jowls.render(par7);
/* 115 */     this.LowerPack.render(par7);
/* 116 */     this.UpperPack.render(par7);
/* 117 */     this.RightArm.render(par7);
/* 118 */     this.LeftArm.render(par7);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setRotation(ModelRenderer model, float x, float y, float z) {
/* 123 */     model.rotateAngleX = x;
/* 124 */     model.rotateAngleY = y;
/* 125 */     model.rotateAngleZ = z;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity entity) {
/* 130 */     this.Head.rotateAngleY = par4 / 57.295776F;
/* 131 */     this.Head.rotateAngleX = par5 / 57.295776F;
/*     */     
/* 133 */     float mumble = 0.0F;
/* 134 */     if (entity instanceof EntityPech) {
/* 135 */       mumble = ((EntityPech)entity).mumble;
/*     */     }
/*     */     
/* 138 */     this.Jowls.rotateAngleY = this.Head.rotateAngleY;
/* 139 */     this.Jowls.rotateAngleX = this.Head.rotateAngleX + 0.2617994F + MathHelper.cos(par1 * 0.6662F) * par2 * 0.25F + 0.34906587F * Math.abs(MathHelper.sin(mumble));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     this.RightArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F;
/* 145 */     this.LeftArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F;
/* 146 */     this.RightArm.rotateAngleZ = 0.0F;
/* 147 */     this.LeftArm.rotateAngleZ = 0.0F;
/* 148 */     this.RightLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
/* 149 */     this.LeftLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2;
/* 150 */     this.RightLeg.rotateAngleY = 0.0F;
/* 151 */     this.LeftLeg.rotateAngleY = 0.0F;
/*     */     
/* 153 */     this.LowerPack.rotateAngleY = MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.125F;
/* 154 */     this.LowerPack.rotateAngleZ = MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.125F;
/*     */     
/* 156 */     if (this.isRiding) {
/*     */       
/* 158 */       this.RightArm.rotateAngleX += -0.62831855F;
/* 159 */       this.LeftArm.rotateAngleX += -0.62831855F;
/* 160 */       this.RightLeg.rotateAngleX = -1.2566371F;
/* 161 */       this.LeftLeg.rotateAngleX = -1.2566371F;
/* 162 */       this.RightLeg.rotateAngleY = 0.31415927F;
/* 163 */       this.LeftLeg.rotateAngleY = -0.31415927F;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     this.RightArm.rotateAngleY = 0.0F;
/* 177 */     this.LeftArm.rotateAngleY = 0.0F;
/*     */ 
/*     */ 
/*     */     
/* 181 */     if (this.onGround > -9990.0F) {
/*     */       
/* 183 */       float f6 = this.onGround;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 189 */       this.RightArm.rotateAngleY += this.Body.rotateAngleY;
/* 190 */       this.LeftArm.rotateAngleY += this.Body.rotateAngleY;
/* 191 */       this.LeftArm.rotateAngleX += this.Body.rotateAngleY;
/* 192 */       f6 = 1.0F - this.onGround;
/* 193 */       f6 *= f6;
/* 194 */       f6 *= f6;
/* 195 */       f6 = 1.0F - f6;
/* 196 */       float f7 = MathHelper.sin(f6 * 3.1415927F);
/* 197 */       float f8 = MathHelper.sin(this.onGround * 3.1415927F) * -(this.Head.rotateAngleX - 0.7F) * 0.75F;
/* 198 */       this.RightArm.rotateAngleX = (float)(this.RightArm.rotateAngleX - f7 * 1.2D + f8);
/* 199 */       this.RightArm.rotateAngleY += this.Body.rotateAngleY * 2.0F;
/* 200 */       this.RightArm.rotateAngleZ = MathHelper.sin(this.onGround * 3.1415927F) * -0.4F;
/*     */     } 
/*     */     
/* 203 */     if (entity.isSneaking()) {
/*     */ 
/*     */       
/* 206 */       this.RightArm.rotateAngleX += 0.4F;
/* 207 */       this.LeftArm.rotateAngleX += 0.4F;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     this.RightArm.rotateAngleZ += MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
/* 227 */     this.LeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
/* 228 */     this.RightArm.rotateAngleX += MathHelper.sin(par3 * 0.067F) * 0.05F;
/* 229 */     this.LeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.067F) * 0.05F;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\entities\ModelPech.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */