/*     */ package thaumcraft.client.renderers.models.entities;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import thaumcraft.common.entities.monster.EntityWatcher;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ModelWatcher
/*     */   extends ModelBase
/*     */ {
/*     */   private ModelRenderer guardianBody;
/*     */   private ModelRenderer guardianEye;
/*     */   private ModelRenderer[] guardianSpines;
/*     */   private ModelRenderer[] guardianTail;
/*     */   private static final String __OBFID = "CL_00002628";
/*     */   
/*     */   public ModelWatcher() {
/*  24 */     this.textureWidth = 64;
/*  25 */     this.textureHeight = 64;
/*  26 */     this.guardianSpines = new ModelRenderer[12];
/*  27 */     this.guardianBody = new ModelRenderer(this);
/*  28 */     this.guardianBody.setTextureOffset(0, 0).addBox(-6.0F, 10.0F, -8.0F, 12, 12, 16);
/*  29 */     this.guardianBody.setTextureOffset(0, 28).addBox(-8.0F, 10.0F, -6.0F, 2, 12, 12);
/*  30 */     this.guardianBody.mirror = true;
/*  31 */     this.guardianBody.setTextureOffset(0, 28).addBox(6.0F, 10.0F, -6.0F, 2, 12, 12);
/*  32 */     this.guardianBody.mirror = false;
/*  33 */     this.guardianBody.setTextureOffset(16, 40).addBox(-6.0F, 8.0F, -6.0F, 12, 2, 12);
/*  34 */     this.guardianBody.setTextureOffset(16, 40).addBox(-6.0F, 22.0F, -6.0F, 12, 2, 12);
/*     */     
/*  36 */     for (int i = 0; i < this.guardianSpines.length; i++) {
/*     */       
/*  38 */       this.guardianSpines[i] = new ModelRenderer(this, 0, 0);
/*  39 */       this.guardianSpines[i].addBox(-1.0F, -4.5F, -1.0F, 2, 9, 2);
/*  40 */       this.guardianBody.addChild(this.guardianSpines[i]);
/*     */     } 
/*     */     
/*  43 */     this.guardianEye = new ModelRenderer(this, 8, 0);
/*  44 */     this.guardianEye.addBox(-1.0F, 15.0F, 0.0F, 2, 2, 1);
/*  45 */     this.guardianBody.addChild(this.guardianEye);
/*  46 */     this.guardianTail = new ModelRenderer[3];
/*  47 */     this.guardianTail[0] = new ModelRenderer(this, 40, 0);
/*  48 */     this.guardianTail[0].addBox(-2.0F, 14.0F, 7.0F, 4, 4, 8);
/*  49 */     this.guardianTail[1] = new ModelRenderer(this, 0, 54);
/*  50 */     this.guardianTail[1].addBox(0.0F, 14.0F, 0.0F, 3, 3, 7);
/*  51 */     this.guardianTail[2] = new ModelRenderer(this);
/*  52 */     this.guardianTail[2].setTextureOffset(41, 32).addBox(0.0F, 14.0F, 0.0F, 2, 2, 6);
/*  53 */     this.guardianTail[2].setTextureOffset(25, 19).addBox(1.0F, 10.5F, 3.0F, 1, 9, 9);
/*  54 */     this.guardianBody.addChild(this.guardianTail[0]);
/*  55 */     this.guardianTail[0].addChild(this.guardianTail[1]);
/*  56 */     this.guardianTail[1].addChild(this.guardianTail[2]);
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_178706_a() {
/*  61 */     return 54;
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(Entity p_78088_1_, float p_78088_2_, float p_78088_3_, float p_78088_4_, float p_78088_5_, float p_78088_6_, float p_78088_7_) {
/*  66 */     setRotationAngles(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, p_78088_7_, p_78088_1_);
/*  67 */     this.guardianBody.render(p_78088_7_);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotationAngles(float p_78087_1_, float p_78087_2_, float p_78087_3_, float p_78087_4_, float p_78087_5_, float p_78087_6_, Entity p_78087_7_) {
/*  72 */     EntityWatcher entityguardian = (EntityWatcher)p_78087_7_;
/*  73 */     float f6 = p_78087_3_ - entityguardian.ticksExisted;
/*  74 */     this.guardianBody.rotateAngleY = p_78087_4_ / 57.295776F;
/*  75 */     this.guardianBody.rotateAngleX = p_78087_5_ / 57.295776F;
/*  76 */     float[] afloat = { 1.75F, 0.25F, 0.0F, 0.0F, 0.5F, 0.5F, 0.5F, 0.5F, 1.25F, 0.75F, 0.0F, 0.0F };
/*  77 */     float[] afloat1 = { 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 1.75F, 1.25F, 0.75F, 0.0F, 0.0F, 0.0F, 0.0F };
/*  78 */     float[] afloat2 = { 0.0F, 0.0F, 0.25F, 1.75F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.75F, 1.25F };
/*  79 */     float[] afloat3 = { 0.0F, 0.0F, 8.0F, -8.0F, -8.0F, 8.0F, 8.0F, -8.0F, 0.0F, 0.0F, 8.0F, -8.0F };
/*  80 */     float[] afloat4 = { -8.0F, -8.0F, -8.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.0F, 8.0F, 8.0F, 8.0F, 8.0F };
/*  81 */     float[] afloat5 = { 8.0F, -8.0F, 0.0F, 0.0F, -8.0F, -8.0F, 8.0F, 8.0F, 8.0F, -8.0F, 0.0F, 0.0F };
/*  82 */     float f7 = (1.0F - entityguardian.func_175469_o(f6)) * 0.55F;
/*     */     
/*  84 */     for (int i = 0; i < 12; i++) {
/*     */       
/*  86 */       (this.guardianSpines[i]).rotateAngleX = 3.1415927F * afloat[i];
/*  87 */       (this.guardianSpines[i]).rotateAngleY = 3.1415927F * afloat1[i];
/*  88 */       (this.guardianSpines[i]).rotateAngleZ = 3.1415927F * afloat2[i];
/*  89 */       (this.guardianSpines[i]).rotationPointX = afloat3[i] * (1.0F + MathHelper.cos(p_78087_3_ * 1.5F + i) * 0.01F - f7);
/*  90 */       (this.guardianSpines[i]).rotationPointY = 16.0F + afloat4[i] * (1.0F + MathHelper.cos(p_78087_3_ * 1.5F + i) * 0.01F - f7);
/*  91 */       (this.guardianSpines[i]).rotationPointZ = afloat5[i] * (1.0F + MathHelper.cos(p_78087_3_ * 1.5F + i) * 0.01F - f7);
/*     */     } 
/*     */     
/*  94 */     this.guardianEye.rotationPointZ = -8.25F;
/*  95 */     Object object = (Minecraft.getMinecraft()).renderViewEntity;
/*     */     
/*  97 */     if (entityguardian.func_175474_cn())
/*     */     {
/*  99 */       object = entityguardian.getTargetedEntity();
/*     */     }
/*     */     
/* 102 */     if (object != null) {
/*     */       
/* 104 */       Vec3 vec3 = getPositionEyes((Entity)object, 0.0F);
/* 105 */       Vec3 vec31 = getPositionEyes(p_78087_7_, 0.0F);
/* 106 */       double d0 = vec3.yCoord - vec31.yCoord;
/*     */       
/* 108 */       if (d0 > 0.0D) {
/*     */         
/* 110 */         this.guardianEye.rotationPointY = 0.0F;
/*     */       }
/*     */       else {
/*     */         
/* 114 */         this.guardianEye.rotationPointY = 1.0F;
/*     */       } 
/*     */       
/* 117 */       Vec3 vec32 = entityguardian.getLook(0.0F);
/* 118 */       vec32 = Vec3.createVectorHelper(vec32.xCoord, 0.0D, vec32.zCoord);
/* 119 */       Vec3 vec33 = Vec3.createVectorHelper(vec31.xCoord - vec3.xCoord, 0.0D, vec31.zCoord - vec3.zCoord).normalize();
/* 120 */       vec33.rotateAroundY(1.5707964F);
/* 121 */       double d1 = vec32.dotProduct(vec33);
/* 122 */       this.guardianEye.rotationPointX = MathHelper.sqrt_float((float)Math.abs(d1)) * 2.0F * (float)Math.signum(d1);
/*     */     } 
/*     */     
/* 125 */     this.guardianEye.showModel = true;
/* 126 */     float f8 = entityguardian.func_175471_a(f6);
/* 127 */     (this.guardianTail[0]).rotateAngleY = MathHelper.sin(f8) * 3.1415927F * 0.05F;
/* 128 */     (this.guardianTail[1]).rotateAngleY = MathHelper.sin(f8) * 3.1415927F * 0.1F;
/* 129 */     (this.guardianTail[1]).rotationPointX = -1.5F;
/* 130 */     (this.guardianTail[1]).rotationPointY = 0.5F;
/* 131 */     (this.guardianTail[1]).rotationPointZ = 14.0F;
/* 132 */     (this.guardianTail[2]).rotateAngleY = MathHelper.sin(f8) * 3.1415927F * 0.15F;
/* 133 */     (this.guardianTail[2]).rotationPointX = 0.5F;
/* 134 */     (this.guardianTail[2]).rotationPointY = 0.5F;
/* 135 */     (this.guardianTail[2]).rotationPointZ = 6.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   private Vec3 getPositionEyes(Entity e, float p_174824_1_) {
/* 140 */     if (p_174824_1_ == 1.0F)
/*     */     {
/* 142 */       return Vec3.createVectorHelper(e.posX, e.posY + e.getEyeHeight(), e.posZ);
/*     */     }
/*     */ 
/*     */     
/* 146 */     double d0 = e.prevPosX + (e.posX - e.prevPosX) * p_174824_1_;
/* 147 */     double d1 = e.prevPosY + (e.posY - e.prevPosY) * p_174824_1_ + e.getEyeHeight();
/* 148 */     double d2 = e.prevPosZ + (e.posZ - e.prevPosZ) * p_174824_1_;
/* 149 */     return Vec3.createVectorHelper(d0, d1, d2);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\entities\ModelWatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */