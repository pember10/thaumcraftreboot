/*     */ package thaumcraft.client.renderers.models;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.common.config.ConfigItems;
/*     */ import thaumcraft.common.entities.golems.EntityTravelingTrunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelTrunk
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer chestLid;
/*     */   public ModelRenderer chestBelow;
/*     */   public ModelRenderer chestKnob;
/*     */   
/*     */   public ModelTrunk() {
/*  33 */     this.chestLid = (new ModelRenderer(this, 0, 0)).setTextureSize(64, 64);
/*  34 */     this.chestLid.addBox(0.0F, -5.0F, -14.0F, 14, 5, 14, 0.0F);
/*  35 */     this.chestLid.rotationPointX = 1.0F;
/*  36 */     this.chestLid.rotationPointY = 7.0F;
/*  37 */     this.chestLid.rotationPointZ = 15.0F;
/*  38 */     this.chestKnob = (new ModelRenderer(this, 0, 0)).setTextureSize(64, 64);
/*  39 */     this.chestKnob.addBox(-1.0F, -2.0F, -15.0F, 2, 4, 1, 0.0F);
/*  40 */     this.chestKnob.rotationPointX = 8.0F;
/*  41 */     this.chestKnob.rotationPointY = 7.0F;
/*  42 */     this.chestKnob.rotationPointZ = 15.0F;
/*  43 */     this.chestBelow = (new ModelRenderer(this, 0, 19)).setTextureSize(64, 64);
/*  44 */     this.chestBelow.addBox(0.0F, 0.0F, 0.0F, 14, 10, 14, 0.0F);
/*  45 */     this.chestBelow.rotationPointX = 1.0F;
/*  46 */     this.chestBelow.rotationPointY = 6.0F;
/*  47 */     this.chestBelow.rotationPointZ = 1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/*  53 */     this.chestKnob.rotateAngleX = this.chestLid.rotateAngleX;
/*  54 */     this.chestLid.render(0.0625F);
/*  55 */     this.chestBelow.render(0.0625F);
/*  56 */     this.chestKnob.render(0.0625F);
/*     */     
/*  58 */     GL11.glPushMatrix();
/*     */     
/*  60 */     GL11.glTranslatef(this.chestKnob.offsetX, this.chestKnob.offsetY, this.chestKnob.offsetZ);
/*     */ 
/*     */     
/*  63 */     GL11.glEnable(3042);
/*  64 */     GL11.glBlendFunc(770, 771);
/*     */     
/*  66 */     GL11.glPushMatrix();
/*  67 */     GL11.glTranslatef(this.chestKnob.rotationPointX * 0.0625F, this.chestKnob.rotationPointY * 0.0625F, this.chestKnob.rotationPointZ * 0.0625F);
/*     */     
/*  69 */     if (this.chestKnob.rotateAngleZ != 0.0F)
/*     */     {
/*  71 */       GL11.glRotatef(this.chestKnob.rotateAngleZ * 57.295776F, 0.0F, 0.0F, 1.0F);
/*     */     }
/*     */     
/*  74 */     if (this.chestKnob.rotateAngleY != 0.0F)
/*     */     {
/*  76 */       GL11.glRotatef(this.chestKnob.rotateAngleY * 57.295776F, 0.0F, 1.0F, 0.0F);
/*     */     }
/*     */     
/*  79 */     if (this.chestKnob.rotateAngleX != 0.0F)
/*     */     {
/*  81 */       GL11.glRotatef(this.chestKnob.rotateAngleX * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */     }
/*     */     
/*  84 */     GL11.glTranslatef(-0.075F, -0.115F, -0.94301F);
/*     */     
/*  86 */     GL11.glScaled(0.15D, 0.15D, 0.15D);
/*  87 */     Tessellator tessellator = Tessellator.instance;
/*  88 */     IIcon icon = ConfigItems.itemGolemUpgrade.getIconFromDamage(((EntityTravelingTrunk)entity).getUpgrade());
/*  89 */     float ff1 = icon.getMaxU();
/*  90 */     float ff2 = icon.getMinV();
/*  91 */     float ff3 = icon.getMinU();
/*  92 */     float ff4 = icon.getMaxV();
/*  93 */     RenderManager.instance.renderEngine.bindTexture(TextureMap.locationItemsTexture);
/*  94 */     tessellator.startDrawingQuads();
/*  95 */     tessellator.setNormal(0.0F, 0.0F, 1.0F);
/*  96 */     tessellator.addVertexWithUV(0.0D, 0.0D, 0.0D, ff1, ff4);
/*  97 */     tessellator.addVertexWithUV(1.0D, 0.0D, 0.0D, ff3, ff4);
/*  98 */     tessellator.addVertexWithUV(1.0D, 1.0D, 0.0D, ff3, ff2);
/*  99 */     tessellator.addVertexWithUV(0.0D, 1.0D, 0.0D, ff1, ff2);
/* 100 */     tessellator.draw();
/*     */     
/* 102 */     GL11.glPopMatrix();
/*     */     
/* 104 */     GL11.glDisable(3042);
/*     */     
/* 106 */     GL11.glTranslatef(-this.chestKnob.offsetX, -this.chestKnob.offsetY, -this.chestKnob.offsetZ);
/*     */     
/* 108 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\models\ModelTrunk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */