/*    */ package thaumcraft.client.renderers.tile;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.client.lib.UtilsFX;
/*    */ import thaumcraft.common.tiles.TileWandPedestal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class TileWandPedestalRenderer
/*    */   extends TileEntitySpecialRenderer
/*    */ {
/*    */   public void renderTileEntityAt(TileWandPedestal ped, double par2, double par4, double par6, float partialTicks) {
/* 28 */     if (ped != null && ped.getWorldObj() != null && ped.getStackInSlot(0) != null) {
/* 29 */       EntityItem entityitem = null;
/* 30 */       float ticks = (Minecraft.getMinecraft()).renderViewEntity.ticksExisted + partialTicks;
/* 31 */       GL11.glPushMatrix();
/* 32 */       float h = MathHelper.sin(ticks % 32767.0F / 16.0F) * 0.05F;
/* 33 */       GL11.glTranslatef((float)par2 + 0.5F, (float)par4 + 1.15F + h, (float)par6 + 0.5F);
/* 34 */       GL11.glRotatef(ticks % 360.0F, 0.0F, 1.0F, 0.0F);
/*    */       
/* 36 */       ItemStack is = ped.getStackInSlot(0).copy();
/* 37 */       is.stackSize = 1;
/* 38 */       entityitem = new EntityItem(ped.getWorldObj(), 0.0D, 0.0D, 0.0D, is);
/* 39 */       entityitem.hoverStart = 0.0F;
/* 40 */       RenderManager.instance.renderEntityWithPosYaw((Entity)entityitem, 0.0D, 0.0D, 0.0D, 0.0F, 0.0F);
/* 41 */       GL11.glPopMatrix();
/*    */       
/* 43 */       if (ped.draining) {
/* 44 */         GL11.glPushMatrix();
/*    */         
/* 46 */         UtilsFX.drawFloatyLine(ped.xCoord + 0.5D, ped.yCoord + 1.65D - (h * 2.0F), ped.zCoord + 0.5D, ped.drainX + 0.5D, ped.drainY + 0.5D, ped.drainZ + 0.5D, partialTicks, ped.drainColor, "textures/misc/wispy.png", -0.02F, Math.min(ticks, 10.0F) / 10.0F);
/*    */ 
/*    */         
/* 49 */         GL11.glPopMatrix();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderTileEntityAt(TileEntity par1TileEntity, double par2, double par4, double par6, float par8) {
/* 58 */     renderTileEntityAt((TileWandPedestal)par1TileEntity, par2, par4, par6, par8);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\tile\TileWandPedestalRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */