/*     */ package thaumcraft.client.renderers.tile;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.Vec3;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.common.tiles.TileEldritchPortal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TileEldritchPortalRenderer
/*     */   extends TileEntitySpecialRenderer
/*     */ {
/*  29 */   public static final ResourceLocation portaltex = new ResourceLocation("thaumcraft", "textures/misc/eldritch_portal.png");
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderTileEntityAt(TileEntity te, double x, double y, double z, float f) {
/*  34 */     GL11.glPushMatrix();
/*  35 */     if (te.getWorldObj() != null) {
/*  36 */       renderPortal((TileEldritchPortal)te, x, y, z, f);
/*     */     }
/*  38 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderPortal(TileEldritchPortal te, double x, double y, double z, float f) {
/*  44 */     long nt = System.nanoTime();
/*  45 */     long time = nt / 50000000L;
/*     */     
/*  47 */     int c = (int)Math.min(30.0F, te.opencount + f);
/*  48 */     int e = (int)Math.min(5.0F, te.opencount + f);
/*  49 */     float scale = e / 5.0F;
/*  50 */     float scaley = c / 30.0F;
/*  51 */     UtilsFX.bindTexture(portaltex);
/*  52 */     GL11.glPushMatrix();
/*     */     
/*  54 */     GL11.glDepthMask(false);
/*     */ 
/*     */     
/*  57 */     GL11.glEnable(3042);
/*  58 */     GL11.glBlendFunc(770, 771);
/*  59 */     GL11.glColor4f(1.0F, 0.0F, 1.0F, 1.0F);
/*     */     
/*  61 */     if ((Minecraft.getMinecraft()).renderViewEntity instanceof EntityPlayer) {
/*     */       
/*  63 */       Tessellator tessellator = Tessellator.instance;
/*  64 */       float arX = ActiveRenderInfo.rotationX;
/*  65 */       float arZ = ActiveRenderInfo.rotationZ;
/*  66 */       float arYZ = ActiveRenderInfo.rotationYZ;
/*  67 */       float arXY = ActiveRenderInfo.rotationXY;
/*  68 */       float arXZ = ActiveRenderInfo.rotationXZ;
/*     */       
/*  70 */       EntityPlayer player = (EntityPlayer)(Minecraft.getMinecraft()).renderViewEntity;
/*  71 */       double iPX = player.prevPosX + (player.posX - player.prevPosX) * f;
/*  72 */       double iPY = player.prevPosY + (player.posY - player.prevPosY) * f;
/*  73 */       double iPZ = player.prevPosZ + (player.posZ - player.prevPosZ) * f;
/*     */       
/*  75 */       tessellator.startDrawingQuads();
/*  76 */       tessellator.setBrightness(220);
/*  77 */       tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 1.0F);
/*  78 */       double px = x + 0.5D;
/*  79 */       double py = y + 0.5D;
/*  80 */       double pz = z + 0.5D;
/*  81 */       Vec3 v1 = Vec3.createVectorHelper((-arX - arYZ), -arXZ, (-arZ - arXY));
/*  82 */       Vec3 v2 = Vec3.createVectorHelper((-arX + arYZ), arXZ, (-arZ + arXY));
/*  83 */       Vec3 v3 = Vec3.createVectorHelper((arX + arYZ), arXZ, (arZ + arXY));
/*  84 */       Vec3 v4 = Vec3.createVectorHelper((arX - arYZ), -arXZ, (arZ - arXY));
/*  85 */       int frame = (int)time % 16;
/*  86 */       float f2 = frame / 16.0F;
/*  87 */       float f3 = f2 + 0.0625F;
/*  88 */       float f4 = 0.0F;
/*  89 */       float f5 = 1.0F;
/*  90 */       tessellator.setNormal(0.0F, 0.0F, -1.0F);
/*  91 */       tessellator.addVertexWithUV(px + v1.xCoord * scale, py + v1.yCoord * scaley, pz + v1.zCoord * scale, f2, f5);
/*  92 */       tessellator.addVertexWithUV(px + v2.xCoord * scale, py + v2.yCoord * scaley, pz + v2.zCoord * scale, f3, f5);
/*  93 */       tessellator.addVertexWithUV(px + v3.xCoord * scale, py + v3.yCoord * scaley, pz + v3.zCoord * scale, f3, f4);
/*  94 */       tessellator.addVertexWithUV(px + v4.xCoord * scale, py + v4.yCoord * scaley, pz + v4.zCoord * scale, f2, f4);
/*     */       
/*  96 */       tessellator.draw();
/*     */     } 
/*     */     
/*  99 */     GL11.glDisable(3042);
/*     */ 
/*     */     
/* 102 */     GL11.glDepthMask(true);
/*     */     
/* 104 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\tile\TileEldritchPortalRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */