/*     */ package thaumcraft.client.renderers.tile;
/*     */ 
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.entity.RenderItem;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraftforge.client.model.AdvancedModelLoader;
/*     */ import net.minecraftforge.client.model.IModelCustom;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.config.ConfigItems;
/*     */ import thaumcraft.common.tiles.TileEldritchAltar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TileEldritchCapRenderer
/*     */   extends TileEntitySpecialRenderer
/*     */ {
/*     */   private IModelCustom model;
/*  36 */   private static final ResourceLocation CAP = new ResourceLocation("thaumcraft", "textures/models/obelisk_cap.obj");
/*     */ 
/*     */   
/*     */   private String tex;
/*     */   
/*     */   private String tex2;
/*     */   
/*     */   private ItemStack eye;
/*     */   
/*     */   EntityItem entityitem;
/*     */ 
/*     */   
/*     */   public TileEldritchCapRenderer(String texture) {
/*  49 */     this.tex = "textures/models/obelisk_cap.png";
/*  50 */     this.tex2 = "textures/models/obelisk_cap_2.png";
/*     */     
/*  52 */     this.eye = null;
/*  53 */     this.entityitem = null; this.tex = texture; this.model = AdvancedModelLoader.loadModel(CAP); } public TileEldritchCapRenderer() { this.tex = "textures/models/obelisk_cap.png"; this.tex2 = "textures/models/obelisk_cap_2.png"; this.eye = null; this.entityitem = null;
/*     */     this.model = AdvancedModelLoader.loadModel(CAP); }
/*     */ 
/*     */   
/*     */   public void renderTileEntityAt(TileEntity te, double x, double y, double z, float f) {
/*  58 */     String tempTex = this.tex;
/*  59 */     GL11.glPushMatrix();
/*     */     
/*  61 */     if (te.getWorldObj() != null) {
/*  62 */       int j = te.getBlockType().getMixedBrightnessForBlock((IBlockAccess)te.getWorldObj(), te.xCoord, te.yCoord, te.zCoord);
/*  63 */       int k = j % 65536;
/*  64 */       int l = j / 65536;
/*  65 */       OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, k / 1.0F, l / 1.0F);
/*  66 */       if ((te.getWorldObj()).provider.dimensionId == Config.dimensionOuterId) tempTex = this.tex2;
/*     */     
/*     */     } 
/*  69 */     GL11.glPushMatrix();
/*  70 */     UtilsFX.bindTexture(tempTex);
/*  71 */     GL11.glTranslated(x + 0.5D, y, z + 0.5D);
/*  72 */     GL11.glRotated(90.0D, -1.0D, 0.0D, 0.0D);
/*  73 */     this.model.renderPart("Cap");
/*  74 */     GL11.glPopMatrix();
/*     */     
/*  76 */     if (te.getWorldObj() != null && te instanceof TileEldritchAltar && ((TileEldritchAltar)te).getEyes() > 0) {
/*     */       
/*  78 */       GL11.glPushMatrix();
/*  79 */       GL11.glTranslatef((float)x + 0.5F, (float)y + 0.0F, (float)z + 0.5F);
/*     */       
/*  81 */       if (this.entityitem == null || this.eye == null) {
/*  82 */         this.eye = new ItemStack(ConfigItems.itemEldritchObject, 1, 0);
/*  83 */         this.entityitem = new EntityItem(te.getWorldObj(), 0.0D, 0.0D, 0.0D, this.eye);
/*  84 */         this.entityitem.hoverStart = 0.0F;
/*     */       } 
/*     */       
/*  87 */       if (this.entityitem != null && this.eye != null) {
/*  88 */         for (int a = 0; a < ((TileEldritchAltar)te).getEyes(); a++) {
/*  89 */           GL11.glPushMatrix();
/*  90 */           GL11.glRotated((a * 90), 0.0D, 1.0D, 0.0D);
/*  91 */           GL11.glTranslatef(0.46F, 0.2F, 0.0F);
/*  92 */           GL11.glRotated(90.0D, 0.0D, 1.0D, 0.0D);
/*  93 */           GL11.glRotated(18.0D, -1.0D, 0.0D, 0.0D);
/*  94 */           RenderItem.renderInFrame = true;
/*  95 */           RenderManager.instance.renderEntityWithPosYaw((Entity)this.entityitem, 0.0D, 0.0D, 0.0D, 0.0F, 0.0F);
/*  96 */           RenderItem.renderInFrame = false;
/*  97 */           GL11.glPopMatrix();
/*     */         } 
/*     */       }
/*     */       
/* 101 */       GL11.glPopMatrix();
/*     */     } 
/*     */ 
/*     */     
/* 105 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\tile\TileEldritchCapRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */