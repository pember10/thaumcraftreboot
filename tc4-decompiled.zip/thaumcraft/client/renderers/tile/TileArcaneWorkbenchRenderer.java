/*    */ package thaumcraft.client.renderers.tile;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.renderer.entity.RenderItem;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.client.lib.UtilsFX;
/*    */ import thaumcraft.client.renderers.models.ModelArcaneWorkbench;
/*    */ import thaumcraft.common.tiles.TileArcaneWorkbench;
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class TileArcaneWorkbenchRenderer
/*    */   extends TileEntitySpecialRenderer
/*    */ {
/* 23 */   private ModelArcaneWorkbench tableModel = new ModelArcaneWorkbench();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderTileEntityAt(TileArcaneWorkbench table, double par2, double par4, double par6, float par8) {
/* 33 */     GL11.glPushMatrix();
/* 34 */     UtilsFX.bindTexture("textures/models/worktable.png");
/* 35 */     GL11.glTranslatef((float)par2 + 0.5F, (float)par4 + 1.0F, (float)par6 + 0.5F);
/* 36 */     GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/* 37 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 38 */     this.tableModel.renderAll();
/* 39 */     GL11.glPopMatrix();
/* 40 */     if (table.getWorldObj() != null && table.getStackInSlot(10) != null && table.getStackInSlot(10).getItem() instanceof thaumcraft.common.items.wands.ItemWandCasting) {
/*    */ 
/*    */       
/* 43 */       GL11.glPushMatrix();
/* 44 */       GL11.glTranslatef((float)par2 + 0.65F, (float)par4 + 1.0625F, (float)par6 + 0.25F);
/* 45 */       GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/* 46 */       GL11.glRotatef(20.0F, 0.0F, 0.0F, 1.0F);
/*    */       
/* 48 */       ItemStack is = table.getStackInSlot(10).copy();
/* 49 */       is.stackSize = 1;
/* 50 */       EntityItem entityitem = new EntityItem(table.getWorldObj(), 0.0D, 0.0D, 0.0D, is);
/* 51 */       entityitem.hoverStart = 0.0F;
/* 52 */       RenderItem.renderInFrame = true;
/* 53 */       RenderManager.instance.renderEntityWithPosYaw((Entity)entityitem, 0.0D, 0.0D, 0.0D, 0.0F, 0.0F);
/* 54 */       RenderItem.renderInFrame = false;
/*    */       
/* 56 */       GL11.glPopMatrix();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void renderTileEntityAt(TileEntity par1TileEntity, double par2, double par4, double par6, float par8) {
/* 62 */     renderTileEntityAt((TileArcaneWorkbench)par1TileEntity, par2, par4, par6, par8);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\tile\TileArcaneWorkbenchRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */