/*     */ package thaumcraft.client.renderers.entity;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.renderer.RenderBlocks;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderItem;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.common.entities.EntitySpecialItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderSpecialItem
/*     */   extends Render
/*     */ {
/*  26 */   private RenderBlocks renderBlocks = new RenderBlocks();
/*     */ 
/*     */   
/*  29 */   private Random random = new Random();
/*     */   
/*     */   public boolean field_77024_a = true;
/*     */   
/*  33 */   public float zLevel = 0.0F;
/*     */ 
/*     */   
/*     */   public RenderSpecialItem() {
/*  37 */     this.shadowSize = 0.15F;
/*  38 */     this.shadowOpaque = 0.75F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doRenderItem(EntitySpecialItem par1EntityItem, double par2, double par4, double par6, float par8, float par9) {
/*  46 */     this.random.setSeed(187L);
/*  47 */     float var11 = MathHelper.sin((par1EntityItem.age + par9) / 10.0F + par1EntityItem.hoverStart) * 0.1F + 0.1F;
/*  48 */     GL11.glPushMatrix();
/*  49 */     GL11.glTranslatef((float)par2, (float)par4 + var11 + 0.15F, (float)par6);
/*     */     
/*  51 */     int q = !(FMLClientHandler.instance().getClient()).gameSettings.fancyGraphics ? 5 : 10;
/*     */     
/*  53 */     Tessellator tessellator = Tessellator.instance;
/*  54 */     RenderHelper.disableStandardItemLighting();
/*  55 */     float f1 = par1EntityItem.age / 500.0F;
/*  56 */     float f3 = 0.9F;
/*  57 */     float f2 = 0.0F;
/*     */     
/*  59 */     Random random = new Random(245L);
/*  60 */     GL11.glDisable(3553);
/*  61 */     GL11.glShadeModel(7425);
/*  62 */     GL11.glEnable(3042);
/*  63 */     GL11.glBlendFunc(770, 1);
/*  64 */     GL11.glDisable(3008);
/*  65 */     GL11.glEnable(2884);
/*  66 */     GL11.glDepthMask(false);
/*  67 */     GL11.glPushMatrix();
/*  68 */     for (int i = 0; i < q; i++) {
/*     */       
/*  70 */       GL11.glRotatef(random.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
/*  71 */       GL11.glRotatef(random.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
/*  72 */       GL11.glRotatef(random.nextFloat() * 360.0F, 0.0F, 0.0F, 1.0F);
/*  73 */       GL11.glRotatef(random.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
/*  74 */       GL11.glRotatef(random.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
/*  75 */       GL11.glRotatef(random.nextFloat() * 360.0F + f1 * 360.0F, 0.0F, 0.0F, 1.0F);
/*  76 */       tessellator.startDrawing(6);
/*  77 */       float fa = random.nextFloat() * 20.0F + 5.0F + f2 * 10.0F;
/*  78 */       float f4 = random.nextFloat() * 2.0F + 1.0F + f2 * 2.0F;
/*  79 */       fa /= 30.0F / Math.min(par1EntityItem.age, 10) / 10.0F;
/*  80 */       f4 /= 30.0F / Math.min(par1EntityItem.age, 10) / 10.0F;
/*  81 */       tessellator.setColorRGBA_I(16777215, (int)(255.0F * (1.0F - f2)));
/*  82 */       tessellator.addVertex(0.0D, 0.0D, 0.0D);
/*  83 */       tessellator.setColorRGBA_I(16711935, 0);
/*  84 */       tessellator.addVertex(-0.866D * f4, fa, (-0.5F * f4));
/*  85 */       tessellator.addVertex(0.866D * f4, fa, (-0.5F * f4));
/*  86 */       tessellator.addVertex(0.0D, fa, (1.0F * f4));
/*  87 */       tessellator.addVertex(-0.866D * f4, fa, (-0.5F * f4));
/*  88 */       tessellator.draw();
/*     */     } 
/*     */     
/*  91 */     GL11.glPopMatrix();
/*  92 */     GL11.glDepthMask(true);
/*  93 */     GL11.glDisable(2884);
/*  94 */     GL11.glDisable(3042);
/*  95 */     GL11.glShadeModel(7424);
/*  96 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  97 */     GL11.glEnable(3553);
/*  98 */     GL11.glEnable(3008);
/*  99 */     RenderHelper.enableStandardItemLighting();
/*     */     
/* 101 */     GL11.glPopMatrix();
/*     */     
/* 103 */     RenderItem ri = new RenderItem();
/* 104 */     ri.setRenderManager(RenderManager.instance);
/* 105 */     ItemStack var10 = par1EntityItem.getEntityItem();
/* 106 */     if (var10 != null) {
/* 107 */       EntityItem ei = new EntityItem(par1EntityItem.worldObj, par1EntityItem.posX, par1EntityItem.posY, par1EntityItem.posZ, var10);
/*     */       
/* 109 */       ei.age = par1EntityItem.age;
/* 110 */       ei.hoverStart = par1EntityItem.hoverStart;
/* 111 */       ri.doRender(ei, par2, par4, par6, par8, par9);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doRender(Entity par1Entity, double par2, double par4, double par6, float par8, float par9) {
/* 124 */     doRenderItem((EntitySpecialItem)par1Entity, par2, par4, par6, par8, par9);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ResourceLocation getEntityTexture(Entity entity) {
/* 129 */     return AbstractClientPlayer.locationStevePng;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\entity\RenderSpecialItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */