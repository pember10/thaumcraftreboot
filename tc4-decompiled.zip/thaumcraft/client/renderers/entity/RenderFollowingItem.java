/*    */ package thaumcraft.client.renderers.entity;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.client.renderer.RenderBlocks;
/*    */ import net.minecraft.client.renderer.entity.Render;
/*    */ import net.minecraft.client.renderer.entity.RenderItem;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import thaumcraft.common.entities.EntitySpecialItem;
/*    */ 
/*    */ 
/*    */ public class RenderFollowingItem
/*    */   extends Render
/*    */ {
/* 19 */   private RenderBlocks renderBlocks = new RenderBlocks();
/*    */ 
/*    */   
/* 22 */   private Random random = new Random();
/*    */   
/*    */   public boolean field_77024_a = true;
/*    */   
/* 26 */   public float zLevel = 0.0F;
/*    */   
/*    */   public RenderFollowingItem() {
/* 29 */     this.shadowSize = 0.15F;
/* 30 */     this.shadowOpaque = 0.75F;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void doRenderItem(EntitySpecialItem par1EntityItem, double par2, double par4, double par6, float par8, float pticks) {
/* 39 */     this.random.setSeed(187L);
/* 40 */     RenderItem ri = new RenderItem();
/* 41 */     ri.setRenderManager(RenderManager.instance);
/* 42 */     ItemStack var10 = par1EntityItem.getEntityItem();
/* 43 */     if (var10 != null) {
/* 44 */       EntityItem ei = new EntityItem(par1EntityItem.worldObj, par1EntityItem.posX, par1EntityItem.posY, par1EntityItem.posZ, var10);
/*    */ 
/*    */       
/* 47 */       ei.age = par1EntityItem.age;
/* 48 */       ei.hoverStart = par1EntityItem.hoverStart;
/* 49 */       ri.doRender(ei, par2, par4, par6, par8, pticks);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void doRender(Entity par1Entity, double par2, double par4, double par6, float par8, float par9) {
/* 63 */     doRenderItem((EntitySpecialItem)par1Entity, par2, par4, par6, par8, par9);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ResourceLocation getEntityTexture(Entity entity) {
/* 69 */     return AbstractClientPlayer.locationStevePng;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\entity\RenderFollowingItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */