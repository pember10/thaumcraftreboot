/*    */ package thaumcraft.client.renderers.entity;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.client.renderer.entity.Render;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.client.fx.ParticleEngine;
/*    */ import thaumcraft.client.lib.UtilsFX;
/*    */ import thaumcraft.common.entities.projectile.EntityEmber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderEmber
/*    */   extends Render
/*    */ {
/* 30 */   private Random random = new Random();
/*    */ 
/*    */   
/*    */   public void renderEntityAt(EntityEmber entity, double x, double y, double z, float fq, float pticks) {
/* 34 */     Tessellator tessellator = Tessellator.instance;
/*    */     
/* 36 */     GL11.glPushMatrix();
/* 37 */     GL11.glTranslated(x, y, z);
/* 38 */     GL11.glEnable(3042);
/* 39 */     GL11.glBlendFunc(770, 1);
/*    */     
/* 41 */     UtilsFX.bindTexture(ParticleEngine.particleTexture);
/* 42 */     int p = (int)(8.0F * entity.ticksExisted / entity.duration);
/* 43 */     float f2 = (7 + p) / 16.0F;
/* 44 */     float f3 = f2 + 0.0625F;
/* 45 */     float f4 = 0.5625F;
/* 46 */     float f5 = f4 + 0.0625F;
/*    */     
/* 48 */     float f6 = 1.0F;
/* 49 */     float f7 = 0.5F;
/* 50 */     float f8 = 0.5F;
/*    */     
/* 52 */     float fc = entity.ticksExisted / entity.duration;
/* 53 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.9F);
/*    */     
/* 55 */     float particleScale = 0.25F + fc;
/*    */     
/* 57 */     GL11.glScalef(particleScale, particleScale, particleScale);
/*    */     
/* 59 */     GL11.glRotatef(180.0F - this.renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
/* 60 */     GL11.glRotatef(-this.renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
/* 61 */     tessellator.startDrawingQuads();
/* 62 */     tessellator.setBrightness(220);
/* 63 */     tessellator.setNormal(0.0F, 1.0F, 0.0F);
/* 64 */     tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 0.9F);
/* 65 */     tessellator.addVertexWithUV(-f7, -f8, 0.0D, f2, f5);
/* 66 */     tessellator.addVertexWithUV((f6 - f7), -f8, 0.0D, f3, f5);
/* 67 */     tessellator.addVertexWithUV((f6 - f7), (1.0F - f8), 0.0D, f3, f4);
/* 68 */     tessellator.addVertexWithUV(-f7, (1.0F - f8), 0.0D, f2, f4);
/* 69 */     tessellator.draw();
/* 70 */     GL11.glDisable(3042);
/* 71 */     GL11.glDisable(32826);
/*    */ 
/*    */ 
/*    */     
/* 75 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void doRender(Entity entity, double d, double d1, double d2, float f, float f1) {
/* 82 */     renderEntityAt((EntityEmber)entity, d, d1, d2, f, f1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ResourceLocation getEntityTexture(Entity entity) {
/* 88 */     return AbstractClientPlayer.locationStevePng;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\entity\RenderEmber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */