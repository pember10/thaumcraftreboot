/*    */ package thaumcraft.client.renderers.entity;
/*    */ 
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.client.renderer.entity.Render;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import thaumcraft.common.entities.projectile.EntityPechBlast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderPechBlast
/*    */   extends Render
/*    */ {
/*    */   public void renderEntityAt(EntityPechBlast tg, double x, double y, double z, float fq) {}
/*    */   
/*    */   public void doRender(Entity entity, double d, double d1, double d2, float f, float f1) {
/* 27 */     renderEntityAt((EntityPechBlast)entity, d, d1, d2, f);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ResourceLocation getEntityTexture(Entity entity) {
/* 34 */     return AbstractClientPlayer.locationStevePng;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\entity\RenderPechBlast.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */