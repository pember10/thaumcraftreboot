/*    */ package thaumcraft.client.renderers.block;
/*    */ 
/*    */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.RenderBlocks;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.common.blocks.BlockCustomOre;
/*    */ import thaumcraft.common.blocks.BlockCustomOreItem;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockCustomOreRenderer
/*    */   extends BlockRenderer
/*    */   implements ISimpleBlockRenderingHandler
/*    */ {
/*    */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {
/* 24 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 25 */     renderer.setRenderBoundsFromBlock(block);
/*    */     
/* 27 */     if (metadata == 0) {
/* 28 */       drawFaces(renderer, block, ((BlockCustomOre)block).icon[0], false);
/*    */     }
/* 30 */     else if (metadata == 7) {
/* 31 */       drawFaces(renderer, block, ((BlockCustomOre)block).icon[3], false);
/* 32 */     } else if (metadata < 7) {
/* 33 */       drawFaces(renderer, block, ((BlockCustomOre)block).icon[1], false);
/* 34 */       Color c = new Color(BlockCustomOreItem.colors[metadata]);
/* 35 */       float r = c.getRed() / 255.0F;
/* 36 */       float g = c.getGreen() / 255.0F;
/* 37 */       float b = c.getBlue() / 255.0F;
/* 38 */       GL11.glColor3f(r, g, b);
/* 39 */       block.setBlockBounds(0.005F, 0.005F, 0.005F, 0.995F, 0.995F, 0.995F);
/* 40 */       renderer.setRenderBoundsFromBlock(block);
/* 41 */       drawFaces(renderer, block, ((BlockCustomOre)block).icon[2], false);
/* 42 */       GL11.glColor3f(1.0F, 1.0F, 1.0F);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
/* 50 */     int bb = setBrightness(world, x, y, z, block);
/* 51 */     int metadata = world.getBlockMetadata(x, y, z);
/* 52 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 53 */     renderer.setRenderBoundsFromBlock(block);
/* 54 */     renderer.renderStandardBlock(block, x, y, z);
/*    */     
/* 56 */     if (metadata != 0 && metadata != 7 && metadata < 7) {
/* 57 */       Tessellator t = Tessellator.instance;
/* 58 */       t.setColorOpaque_I(BlockCustomOreItem.colors[metadata]);
/* 59 */       t.setBrightness(Math.max(bb, 160));
/* 60 */       renderAllSides(world, x, y, z, block, renderer, ((BlockCustomOre)block).icon[2], false);
/*    */       
/* 62 */       if ((Minecraft.getMinecraft()).gameSettings.anisotropicFiltering > 1) {
/* 63 */         block.setBlockBounds(0.005F, 0.005F, 0.005F, 0.995F, 0.995F, 0.995F);
/* 64 */         renderer.setRenderBoundsFromBlock(block);
/* 65 */         t.setBrightness(bb);
/* 66 */         renderAllSides(world, x, y, z, block, renderer, Blocks.stone.getIcon(0, 0), false);
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 71 */     renderer.clearOverrideBlockTexture();
/* 72 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 73 */     renderer.setRenderBoundsFromBlock(block);
/* 74 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldRender3DInInventory(int modelId) {
/* 79 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRenderId() {
/* 84 */     return ConfigBlocks.blockCustomOreRI;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\block\BlockCustomOreRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */