/*     */ package thaumcraft.client.renderers.block;
/*     */ 
/*     */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.RenderBlocks;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.common.blocks.BlockStoneDevice;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileFluxScrubber;
/*     */ import thaumcraft.common.tiles.TileFocalManipulator;
/*     */ import thaumcraft.common.tiles.TileInfusionMatrix;
/*     */ import thaumcraft.common.tiles.TileNodeConverter;
/*     */ import thaumcraft.common.tiles.TileNodeStabilizer;
/*     */ 
/*     */ 
/*     */ public class BlockStoneDeviceRenderer
/*     */   extends BlockRenderer
/*     */   implements ISimpleBlockRenderingHandler
/*     */ {
/*     */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {
/*  24 */     if (metadata == 0) {
/*  25 */       block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  26 */       renderer.setRenderBoundsFromBlock(block);
/*  27 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconFurnace[1], ((BlockStoneDevice)block).iconFurnace[1], ((BlockStoneDevice)block).iconFurnace[2], ((BlockStoneDevice)block).iconFurnace[2], ((BlockStoneDevice)block).iconFurnace[2], ((BlockStoneDevice)block).iconFurnace[2], true);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  32 */     else if (metadata == 1) {
/*     */       
/*  34 */       block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.25F, 1.0F);
/*  35 */       renderer.setRenderBoundsFromBlock(block);
/*  36 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconPedestal[1], ((BlockStoneDevice)block).iconPedestal[1], ((BlockStoneDevice)block).iconPedestal[0], ((BlockStoneDevice)block).iconPedestal[0], ((BlockStoneDevice)block).iconPedestal[0], ((BlockStoneDevice)block).iconPedestal[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  43 */       block.setBlockBounds(0.25F, 0.25F, 0.25F, 0.75F, 0.75F, 0.75F);
/*  44 */       renderer.setRenderBoundsFromBlock(block);
/*  45 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconPedestal[1], ((BlockStoneDevice)block).iconPedestal[1], ((BlockStoneDevice)block).iconPedestal[0], ((BlockStoneDevice)block).iconPedestal[0], ((BlockStoneDevice)block).iconPedestal[0], ((BlockStoneDevice)block).iconPedestal[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  52 */       block.setBlockBounds(0.125F, 0.75F, 0.125F, 0.875F, 1.0F, 0.875F);
/*  53 */       renderer.setRenderBoundsFromBlock(block);
/*  54 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconPedestal[1], ((BlockStoneDevice)block).iconPedestal[1], ((BlockStoneDevice)block).iconPedestal[0], ((BlockStoneDevice)block).iconPedestal[0], ((BlockStoneDevice)block).iconPedestal[0], ((BlockStoneDevice)block).iconPedestal[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  61 */     else if (metadata == 2) {
/*  62 */       GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/*  63 */       TileEntityRendererDispatcher.instance.renderTileEntityAt((TileEntity)new TileInfusionMatrix(), 0.0D, 0.0D, 0.0D, 0.0F);
/*     */     }
/*  65 */     else if (metadata == 5) {
/*  66 */       block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.25F, 1.0F);
/*  67 */       renderer.setRenderBoundsFromBlock(block);
/*  68 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconPedestal[1], ((BlockStoneDevice)block).iconWandPedestal[1], ((BlockStoneDevice)block).iconWandPedestal[0], ((BlockStoneDevice)block).iconWandPedestal[0], ((BlockStoneDevice)block).iconWandPedestal[0], ((BlockStoneDevice)block).iconWandPedestal[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  75 */       block.setBlockBounds(0.125F, 0.25F, 0.125F, 0.875F, 0.5F, 0.875F);
/*  76 */       renderer.setRenderBoundsFromBlock(block);
/*  77 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconPedestal[1], ((BlockStoneDevice)block).iconWandPedestal[1], ((BlockStoneDevice)block).iconWandPedestal[0], ((BlockStoneDevice)block).iconWandPedestal[0], ((BlockStoneDevice)block).iconWandPedestal[0], ((BlockStoneDevice)block).iconWandPedestal[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  84 */       block.setBlockBounds(0.25F, 0.5F, 0.25F, 0.75F, 1.0F, 0.75F);
/*  85 */       renderer.setRenderBoundsFromBlock(block);
/*  86 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconPedestal[1], ((BlockStoneDevice)block).iconWandPedestal[1], ((BlockStoneDevice)block).iconWandPedestal[0], ((BlockStoneDevice)block).iconWandPedestal[0], ((BlockStoneDevice)block).iconWandPedestal[0], ((BlockStoneDevice)block).iconWandPedestal[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  93 */     else if (metadata == 8) {
/*  94 */       block.setBlockBounds(W5, 0.0F, W5, W11, W1, W11);
/*  95 */       renderer.setRenderBoundsFromBlock(block);
/*  96 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconWandPedestalFocus[2], ((BlockStoneDevice)block).iconWandPedestalFocus[1], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 102 */       block.setBlockBounds(W1, 0.0F, W7, W5, W1, W9);
/* 103 */       renderer.setRenderBoundsFromBlock(block);
/* 104 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconWandPedestalFocus[2], ((BlockStoneDevice)block).iconWandPedestalFocus[1], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 110 */       block.setBlockBounds(W11, 0.0F, W7, W15, W1, W9);
/* 111 */       renderer.setRenderBoundsFromBlock(block);
/* 112 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconWandPedestalFocus[2], ((BlockStoneDevice)block).iconWandPedestalFocus[1], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 118 */       block.setBlockBounds(W7, 0.0F, W1, W9, W1, W5);
/* 119 */       renderer.setRenderBoundsFromBlock(block);
/* 120 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconWandPedestalFocus[2], ((BlockStoneDevice)block).iconWandPedestalFocus[1], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 126 */       block.setBlockBounds(W7, 0.0F, W11, W9, W1, W15);
/* 127 */       renderer.setRenderBoundsFromBlock(block);
/* 128 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconWandPedestalFocus[2], ((BlockStoneDevice)block).iconWandPedestalFocus[1], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 134 */       block.setBlockBounds(W1, W1, W7, W3, W7, W9);
/* 135 */       renderer.setRenderBoundsFromBlock(block);
/* 136 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconWandPedestalFocus[2], ((BlockStoneDevice)block).iconWandPedestalFocus[1], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 142 */       block.setBlockBounds(W7, W1, W1, W9, W7, W3);
/* 143 */       renderer.setRenderBoundsFromBlock(block);
/* 144 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconWandPedestalFocus[2], ((BlockStoneDevice)block).iconWandPedestalFocus[1], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 150 */       block.setBlockBounds(W13, W1, W7, W15, W7, W9);
/* 151 */       renderer.setRenderBoundsFromBlock(block);
/* 152 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconWandPedestalFocus[2], ((BlockStoneDevice)block).iconWandPedestalFocus[1], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 158 */       block.setBlockBounds(W7, W1, W13, W9, W7, W15);
/* 159 */       renderer.setRenderBoundsFromBlock(block);
/* 160 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconWandPedestalFocus[2], ((BlockStoneDevice)block).iconWandPedestalFocus[1], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], ((BlockStoneDevice)block).iconWandPedestalFocus[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 167 */     else if (metadata == 9 || metadata == 10) {
/* 168 */       GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/* 169 */       TileEntityRendererDispatcher.instance.renderTileEntityAt((TileEntity)new TileNodeStabilizer(metadata), 0.0D, 0.0D, 0.0D, 0.0F);
/*     */     }
/* 171 */     else if (metadata == 9 || metadata == 11) {
/* 172 */       GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/* 173 */       TileEntityRendererDispatcher.instance.renderTileEntityAt((TileEntity)new TileNodeConverter(), 0.0D, 0.0D, 0.0D, 0.0F);
/*     */     }
/* 175 */     else if (metadata == 12) {
/* 176 */       block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 177 */       renderer.setRenderBoundsFromBlock(block);
/* 178 */       drawFaces(renderer, block, ((BlockStoneDevice)block).iconPedestal[1], ((BlockStoneDevice)block).iconSpa[1], ((BlockStoneDevice)block).iconSpa[0], ((BlockStoneDevice)block).iconSpa[0], ((BlockStoneDevice)block).iconSpa[0], ((BlockStoneDevice)block).iconSpa[0], true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 185 */     else if (metadata == 13) {
/* 186 */       GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/* 187 */       TileEntityRendererDispatcher.instance.renderTileEntityAt((TileEntity)new TileFocalManipulator(), 0.0D, 0.0D, 0.0D, 0.0F);
/*     */     }
/* 189 */     else if (metadata == 14) {
/* 190 */       GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/* 191 */       TileEntityRendererDispatcher.instance.renderTileEntityAt((TileEntity)new TileFluxScrubber(), 0.0D, 0.0D, 0.0D, 0.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
/* 198 */     int metadata = world.getBlockMetadata(x, y, z);
/*     */     
/* 200 */     if (metadata == 0 || metadata == 12) {
/* 201 */       block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 202 */       renderer.setRenderBoundsFromBlock(block);
/* 203 */       renderer.renderStandardBlock(block, x, y, z);
/*     */     
/*     */     }
/* 206 */     else if (metadata == 1) {
/* 207 */       block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.25F, 1.0F);
/* 208 */       renderer.setRenderBoundsFromBlock(block);
/* 209 */       renderer.renderStandardBlock(block, x, y, z);
/*     */       
/* 211 */       block.setBlockBounds(0.25F, 0.25F, 0.25F, 0.75F, 0.75F, 0.75F);
/* 212 */       renderer.setRenderBoundsFromBlock(block);
/* 213 */       renderer.renderStandardBlock(block, x, y, z);
/*     */       
/* 215 */       block.setBlockBounds(0.125F, 0.75F, 0.125F, 0.875F, 1.0F, 0.875F);
/* 216 */       renderer.setRenderBoundsFromBlock(block);
/* 217 */       renderer.renderStandardBlock(block, x, y, z);
/*     */     }
/* 219 */     else if (metadata == 5) {
/* 220 */       block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.25F, 1.0F);
/* 221 */       renderer.setRenderBoundsFromBlock(block);
/* 222 */       renderer.renderStandardBlock(block, x, y, z);
/*     */       
/* 224 */       block.setBlockBounds(0.125F, 0.25F, 0.125F, 0.875F, 0.5F, 0.875F);
/* 225 */       renderer.setRenderBoundsFromBlock(block);
/* 226 */       renderer.renderStandardBlock(block, x, y, z);
/*     */       
/* 228 */       block.setBlockBounds(0.25F, 0.5F, 0.25F, 0.75F, 1.0F, 0.75F);
/* 229 */       renderer.setRenderBoundsFromBlock(block);
/* 230 */       renderer.renderStandardBlock(block, x, y, z);
/*     */     
/*     */     }
/* 233 */     else if (metadata == 8) {
/* 234 */       block.setBlockBounds(W5, 0.0F, W5, W11, W1, W11);
/* 235 */       renderer.setRenderBoundsFromBlock(block);
/* 236 */       renderer.renderStandardBlock(block, x, y, z);
/* 237 */       block.setBlockBounds(W1, 0.0F, W7, W5, W1, W9);
/* 238 */       renderer.setRenderBoundsFromBlock(block);
/* 239 */       renderer.renderStandardBlock(block, x, y, z);
/* 240 */       block.setBlockBounds(W11, 0.0F, W7, W15, W1, W9);
/* 241 */       renderer.setRenderBoundsFromBlock(block);
/* 242 */       renderer.renderStandardBlock(block, x, y, z);
/* 243 */       block.setBlockBounds(W7, 0.0F, W1, W9, W1, W5);
/* 244 */       renderer.setRenderBoundsFromBlock(block);
/* 245 */       renderer.renderStandardBlock(block, x, y, z);
/* 246 */       block.setBlockBounds(W7, 0.0F, W11, W9, W1, W15);
/* 247 */       renderer.setRenderBoundsFromBlock(block);
/* 248 */       renderer.renderStandardBlock(block, x, y, z);
/* 249 */       block.setBlockBounds(W1, W1, W7, W3, W7, W9);
/* 250 */       renderer.setRenderBoundsFromBlock(block);
/* 251 */       renderer.renderStandardBlock(block, x, y, z);
/* 252 */       block.setBlockBounds(W7, W1, W1, W9, W7, W3);
/* 253 */       renderer.setRenderBoundsFromBlock(block);
/* 254 */       renderer.renderStandardBlock(block, x, y, z);
/* 255 */       block.setBlockBounds(W13, W1, W7, W15, W7, W9);
/* 256 */       renderer.setRenderBoundsFromBlock(block);
/* 257 */       renderer.renderStandardBlock(block, x, y, z);
/* 258 */       block.setBlockBounds(W7, W1, W13, W9, W7, W15);
/* 259 */       renderer.setRenderBoundsFromBlock(block);
/* 260 */       renderer.renderStandardBlock(block, x, y, z);
/*     */     } 
/*     */     
/* 263 */     renderer.clearOverrideBlockTexture();
/* 264 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 265 */     renderer.setRenderBoundsFromBlock(block);
/* 266 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldRender3DInInventory(int modelId) {
/* 271 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderId() {
/* 276 */     return ConfigBlocks.blockStoneDeviceRI;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\block\BlockStoneDeviceRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */