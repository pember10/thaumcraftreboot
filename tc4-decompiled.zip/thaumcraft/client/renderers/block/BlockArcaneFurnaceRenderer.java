/*    */ package thaumcraft.client.renderers.block;
/*    */ 
/*    */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.RenderBlocks;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import thaumcraft.common.blocks.BlockArcaneFurnace;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockArcaneFurnaceRenderer
/*    */   extends BlockRenderer
/*    */   implements ISimpleBlockRenderingHandler
/*    */ {
/*    */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {}
/*    */   
/*    */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
/* 22 */     setBrightness(world, x, y, z, block);
/* 23 */     int md = world.getBlockMetadata(x, y, z);
/* 24 */     if (md <= 9) {
/* 25 */       if (md == 0) {
/* 26 */         setBrightness(world, x, y, z, block);
/* 27 */         renderer.overrideBlockTexture = Blocks.lava.getBlockTextureFromSide(0);
/*    */       } 
/* 29 */       block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 30 */       renderer.setRenderBoundsFromBlock(block);
/* 31 */       renderer.renderStandardBlock(block, x, y, z);
/* 32 */     } else if (md == 10) {
/*    */       
/* 34 */       if (world.getBlock(x - 1, y, z) == block && world.getBlockMetadata(x - 1, y, z) == 0) {
/*    */ 
/*    */         
/* 37 */         renderer.renderFaceXPos(block, (x - W10), y, z, ((BlockArcaneFurnace)block).icon[13]);
/* 38 */         renderer.renderFaceXPos(block, (x - 0.8F), y, z, ((BlockArcaneFurnace)block).icon[15]);
/* 39 */         setBrightness(world, x, y, z, block);
/* 40 */         block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.5F, 1.0F);
/* 41 */         renderer.setRenderBoundsFromBlock(block);
/* 42 */         renderer.renderFaceXPos(block, (x - 0.9F), y, z, Blocks.fire.getBlockTextureFromSide(0));
/*    */       }
/* 44 */       else if (world.getBlock(x + 1, y, z) == block && world.getBlockMetadata(x + 1, y, z) == 0) {
/*    */ 
/*    */         
/* 47 */         renderer.renderFaceXNeg(block, (x + W10), y, z, ((BlockArcaneFurnace)block).icon[13]);
/* 48 */         renderer.renderFaceXNeg(block, (x + 0.8F), y, z, ((BlockArcaneFurnace)block).icon[15]);
/* 49 */         setBrightness(world, x, y, z, block);
/* 50 */         block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.5F, 1.0F);
/* 51 */         renderer.setRenderBoundsFromBlock(block);
/* 52 */         renderer.renderFaceXNeg(block, (x + 0.9F), y, z, Blocks.fire.getBlockTextureFromSide(0));
/*    */       }
/* 54 */       else if (world.getBlock(x, y, z - 1) == block && world.getBlockMetadata(x, y, z - 1) == 0) {
/*    */ 
/*    */         
/* 57 */         renderer.renderFaceZPos(block, x, y, (z - W10), ((BlockArcaneFurnace)block).icon[13]);
/* 58 */         renderer.renderFaceZPos(block, x, y, (z - 0.8F), ((BlockArcaneFurnace)block).icon[15]);
/* 59 */         setBrightness(world, x, y, z, block);
/* 60 */         block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.5F, 1.0F);
/* 61 */         renderer.setRenderBoundsFromBlock(block);
/* 62 */         renderer.renderFaceZPos(block, x, y, (z - 0.9F), Blocks.fire.getBlockTextureFromSide(0));
/*    */       } else {
/*    */         
/* 65 */         renderer.renderFaceZNeg(block, x, y, (z + W10), ((BlockArcaneFurnace)block).icon[13]);
/* 66 */         renderer.renderFaceZNeg(block, x, y, (z + 0.8F), ((BlockArcaneFurnace)block).icon[15]);
/* 67 */         setBrightness(world, x, y, z, block);
/* 68 */         block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.5F, 1.0F);
/* 69 */         renderer.setRenderBoundsFromBlock(block);
/* 70 */         renderer.renderFaceZNeg(block, x, y, (z + 0.9F), Blocks.fire.getBlockTextureFromSide(0));
/*    */       } 
/*    */     } 
/*    */     
/* 74 */     renderer.clearOverrideBlockTexture();
/* 75 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 76 */     renderer.setRenderBoundsFromBlock(block);
/* 77 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldRender3DInInventory(int modelId) {
/* 82 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRenderId() {
/* 87 */     return ConfigBlocks.blockArcaneFurnaceRI;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\block\BlockArcaneFurnaceRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */