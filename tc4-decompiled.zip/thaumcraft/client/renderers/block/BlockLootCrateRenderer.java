/*    */ package thaumcraft.client.renderers.block;
/*    */ 
/*    */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.RenderBlocks;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockLootCrateRenderer
/*    */   extends BlockRenderer
/*    */   implements ISimpleBlockRenderingHandler
/*    */ {
/*    */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {}
/*    */   
/*    */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
/* 18 */     int metadata = world.getBlockMetadata(x, y, z);
/* 19 */     block.setBlockBounds(W1, 0.0F, W1, W15, W14, W15);
/* 20 */     renderer.setRenderBoundsFromBlock(block);
/* 21 */     renderer.renderStandardBlock(block, x, y, z);
/*    */     
/* 23 */     renderer.clearOverrideBlockTexture();
/* 24 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 25 */     renderer.setRenderBoundsFromBlock(block);
/* 26 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldRender3DInInventory(int modelId) {
/* 31 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRenderId() {
/* 36 */     return ConfigBlocks.blockLootCrateRI;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\block\BlockLootCrateRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */