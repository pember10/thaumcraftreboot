/*    */ package thaumcraft.client.renderers.block;
/*    */ 
/*    */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.RenderBlocks;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ import thaumcraft.common.config.ConfigItems;
/*    */ import thaumcraft.common.tiles.TileArcaneWorkbench;
/*    */ import thaumcraft.common.tiles.TileDeconstructionTable;
/*    */ import thaumcraft.common.tiles.TileResearchTable;
/*    */ import thaumcraft.common.tiles.TileTable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockTableRenderer
/*    */   extends BlockRenderer
/*    */   implements ISimpleBlockRenderingHandler
/*    */ {
/*    */   TileResearchTable trt;
/*    */   
/*    */   public BlockTableRenderer() {
/* 28 */     this.trt = new TileResearchTable();
/*    */     this.trt.contents[0] = new ItemStack(ConfigItems.itemInkwell);
/*    */     this.trt.contents[1] = new ItemStack(ConfigItems.itemResearchNotes);
/*    */   } public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {
/* 32 */     GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/* 33 */     GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/* 34 */     if (metadata == 0) {
/* 35 */       TileEntityRendererDispatcher.instance.renderTileEntityAt((TileEntity)new TileTable(), 0.0D, 0.0D, 0.0D, 0.0F);
/* 36 */     } else if (metadata == 14) {
/* 37 */       TileEntityRendererDispatcher.instance.renderTileEntityAt((TileEntity)new TileDeconstructionTable(), 0.0D, 0.0D, 0.0D, 0.0F);
/* 38 */     } else if (metadata == 15) {
/* 39 */       TileEntityRendererDispatcher.instance.renderTileEntityAt((TileEntity)new TileArcaneWorkbench(), 0.0D, 0.0D, 0.0D, 0.0F);
/*    */     } else {
/* 41 */       GL11.glTranslatef(-0.5F, 0.0F, 0.0F);
/* 42 */       TileEntityRendererDispatcher.instance.renderTileEntityAt((TileEntity)this.trt, 0.0D, 0.0D, 0.0D, 0.0F);
/*    */     } 
/* 44 */     GL11.glEnable(32826);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
/* 49 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldRender3DInInventory(int modelId) {
/* 54 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRenderId() {
/* 59 */     return ConfigBlocks.blockTableRI;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\block\BlockTableRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */