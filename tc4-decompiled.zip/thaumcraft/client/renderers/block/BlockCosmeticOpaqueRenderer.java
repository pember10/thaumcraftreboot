/*    */ package thaumcraft.client.renderers.block;
/*    */ 
/*    */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.RenderBlocks;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraftforge.common.util.ForgeDirection;
/*    */ import thaumcraft.common.blocks.BlockCosmeticOpaque;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ 
/*    */ public class BlockCosmeticOpaqueRenderer
/*    */   extends BlockRenderer
/*    */   implements ISimpleBlockRenderingHandler {
/*    */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {
/* 15 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 16 */     renderer.setRenderBoundsFromBlock(block);
/* 17 */     drawFaces(renderer, block, block.getIcon(0, metadata), false);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
/* 22 */     if (block == null || !(block instanceof BlockCosmeticOpaque)) return false; 
/* 23 */     int bb = setBrightness(world, x, y, z, block);
/* 24 */     int metadata = world.getBlockMetadata(x, y, z);
/*    */     
/* 26 */     if (((BlockCosmeticOpaque)block).currentPass == 1) {
/*    */       
/* 28 */       if (metadata <= 1) {
/* 29 */         block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 30 */         renderer.setRenderBoundsFromBlock(block);
/* 31 */         renderer.renderStandardBlock(block, x, y, z);
/*    */       }
/* 33 */       else if (metadata == 2) {
/* 34 */         block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 35 */         renderer.setRenderBoundsFromBlock(block);
/*    */         
/* 37 */         for (int d = 0; d < 6; d++) {
/* 38 */           ForgeDirection dir1 = ForgeDirection.getOrientation(d);
/* 39 */           if (block.shouldSideBeRendered(world, x + dir1.offsetX, y + dir1.offsetY, z + dir1.offsetZ, d)) {
/* 40 */             switch (d) { case 0:
/* 41 */                 renderer.renderFaceYNeg(block, x, y, z, block.getIcon(world, x, y, z, d)); break;
/* 42 */               case 1: renderer.renderFaceYPos(block, x, y, z, block.getIcon(world, x, y, z, d)); break;
/* 43 */               case 2: renderer.renderFaceZNeg(block, x, y, z, block.getIcon(world, x, y, z, d)); break;
/* 44 */               case 3: renderer.renderFaceZPos(block, x, y, z, block.getIcon(world, x, y, z, d)); break;
/* 45 */               case 4: renderer.renderFaceXNeg(block, x, y, z, block.getIcon(world, x, y, z, d)); break;
/* 46 */               case 5: renderer.renderFaceXPos(block, x, y, z, block.getIcon(world, x, y, z, d)); break; }
/*    */             
/* 48 */             renderer.flipTexture = false;
/*    */           } 
/*    */         } 
/*    */       } 
/* 52 */       renderer.clearOverrideBlockTexture();
/* 53 */       block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 54 */       renderer.setRenderBoundsFromBlock(block);
/* 55 */       return true;
/*    */     } 
/*    */     
/* 58 */     renderer.setRenderBounds(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
/* 59 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldRender3DInInventory(int modelId) {
/* 67 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRenderId() {
/* 72 */     return ConfigBlocks.blockCosmeticOpaqueRI;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\block\BlockCosmeticOpaqueRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */