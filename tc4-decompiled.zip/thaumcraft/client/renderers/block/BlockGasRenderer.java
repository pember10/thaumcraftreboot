/*     */ package thaumcraft.client.renderers.block;
/*     */ 
/*     */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.RenderBlocks;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import net.minecraftforge.fluids.BlockFluidBase;
/*     */ import thaumcraft.common.blocks.BlockFluxGas;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ 
/*     */ public class BlockGasRenderer
/*     */   implements ISimpleBlockRenderingHandler
/*     */ {
/*  18 */   public static BlockGasRenderer instance = new BlockGasRenderer();
/*     */   
/*     */   static final float LIGHT_Y_NEG = 0.5F;
/*     */   
/*     */   static final float LIGHT_Y_POS = 1.0F;
/*     */   static final float LIGHT_XZ_NEG = 0.8F;
/*     */   static final float LIGHT_XZ_POS = 0.6F;
/*     */   static final double RENDER_OFFSET = 0.0010000000474974513D;
/*     */   
/*     */   public float getFluidHeightAverage(float[] flow) {
/*  28 */     float total = 0.0F;
/*  29 */     int count = 0;
/*     */     
/*  31 */     float end = 0.0F;
/*     */     
/*  33 */     for (int i = 0; i < flow.length; i++) {
/*     */       
/*  35 */       if (flow[i] >= 0.875F && end != 1.0F)
/*     */       {
/*  37 */         end = flow[i];
/*     */       }
/*     */       
/*  40 */       if (flow[i] >= 0.0F) {
/*     */         
/*  42 */         total += flow[i];
/*  43 */         count++;
/*     */       } 
/*     */     } 
/*     */     
/*  47 */     if (end == 0.0F) {
/*  48 */       end = total / count;
/*     */     }
/*  50 */     return end;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFluidHeightForRender(IBlockAccess world, int x, int y, int z, BlockFluxGas block) {
/*  55 */     if (world.getBlock(x, y, z) == block) {
/*     */       
/*  57 */       if (world.getBlock(x, y - block.getDensityDir(), z).getMaterial().isLiquid())
/*     */       {
/*  59 */         return 1.0F;
/*     */       }
/*     */       
/*  62 */       if (world.getBlockMetadata(x, y, z) == block.getMaxRenderHeightMeta())
/*     */       {
/*  64 */         return 0.875F;
/*     */       }
/*     */     } 
/*  67 */     return (!world.getBlock(x, y, z).getMaterial().isSolid() && world.getBlock(x, y - block.getDensityDir(), z) == block) ? 1.0F : (block.getQuantaPercentage(world, x, y, z) * 0.875F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {}
/*     */ 
/*     */   
/*     */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
/*     */     double heightNW, heightSW, heightSE, heightNE;
/*  77 */     if (!(block instanceof BlockFluxGas))
/*     */     {
/*  79 */       return false;
/*     */     }
/*     */     
/*  82 */     Tessellator tessellator = Tessellator.instance;
/*  83 */     int color = block.colorMultiplier(world, x, y, z);
/*  84 */     float red = (color >> 16 & 0xFF) / 255.0F;
/*  85 */     float green = (color >> 8 & 0xFF) / 255.0F;
/*  86 */     float blue = (color & 0xFF) / 255.0F;
/*     */     
/*  88 */     BlockFluxGas theFluid = (BlockFluxGas)block;
/*  89 */     int bMeta = world.getBlockMetadata(x, y, z);
/*     */     
/*  91 */     if (!world.isSideSolid(x, y + theFluid.getDensityDir(), z, ForgeDirection.DOWN, false)) {
/*     */       
/*  93 */       tessellator.setBrightness(block.getMixedBrightnessForBlock(world, x, y, z));
/*  94 */       tessellator.setColorOpaque_F(1.0F * red, 1.0F * green, 1.0F * blue);
/*     */       
/*  96 */       block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  97 */       renderer.setRenderBoundsFromBlock(block);
/*  98 */       renderer.renderStandardBlock(block, x, y, z);
/*  99 */       renderer.clearOverrideBlockTexture();
/* 100 */       renderer.setRenderBoundsFromBlock(block);
/*     */       
/* 102 */       return true;
/*     */     } 
/*     */     
/* 105 */     boolean renderTop = (world.getBlock(x, y - theFluid.getDensityDir(), z) != theFluid);
/*     */     
/* 107 */     boolean renderBottom = (block.shouldSideBeRendered(world, x, y + theFluid.getDensityDir(), z, 0) && world.getBlock(x, y + theFluid.getDensityDir(), z) != theFluid);
/*     */     
/* 109 */     boolean[] renderSides = { block.shouldSideBeRendered(world, x, y, z - 1, 2), block.shouldSideBeRendered(world, x, y, z + 1, 3), block.shouldSideBeRendered(world, x - 1, y, z, 4), block.shouldSideBeRendered(world, x + 1, y, z, 5) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     if (!renderTop && !renderBottom && !renderSides[0] && !renderSides[1] && !renderSides[2] && !renderSides[3])
/*     */     {
/* 119 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 123 */     boolean rendered = false;
/*     */     
/* 125 */     float flow11 = getFluidHeightForRender(world, x, y, z, theFluid);
/*     */     
/* 127 */     if (flow11 != 1.0F) {
/*     */       
/* 129 */       float flow00 = getFluidHeightForRender(world, x - 1, y, z - 1, theFluid);
/* 130 */       float flow01 = getFluidHeightForRender(world, x - 1, y, z, theFluid);
/* 131 */       float flow02 = getFluidHeightForRender(world, x - 1, y, z + 1, theFluid);
/* 132 */       float flow10 = getFluidHeightForRender(world, x, y, z - 1, theFluid);
/* 133 */       float flow12 = getFluidHeightForRender(world, x, y, z + 1, theFluid);
/* 134 */       float flow20 = getFluidHeightForRender(world, x + 1, y, z - 1, theFluid);
/* 135 */       float flow21 = getFluidHeightForRender(world, x + 1, y, z, theFluid);
/* 136 */       float flow22 = getFluidHeightForRender(world, x + 1, y, z + 1, theFluid);
/*     */       
/* 138 */       heightNW = getFluidHeightAverage(new float[] { flow00, flow01, flow10, flow11 });
/* 139 */       heightSW = getFluidHeightAverage(new float[] { flow01, flow02, flow12, flow11 });
/* 140 */       heightSE = getFluidHeightAverage(new float[] { flow12, flow21, flow22, flow11 });
/* 141 */       heightNE = getFluidHeightAverage(new float[] { flow10, flow20, flow21, flow11 });
/*     */     }
/*     */     else {
/*     */       
/* 145 */       heightNW = flow11;
/* 146 */       heightSW = flow11;
/* 147 */       heightSE = flow11;
/* 148 */       heightNE = flow11;
/*     */     } 
/*     */     
/* 151 */     boolean rises = (theFluid.getDensityDir() == 1);
/* 152 */     if (renderer.renderAllFaces || renderTop) {
/*     */       double u1, u2, u3, u4, v1, v2, v3, v4;
/* 154 */       rendered = true;
/* 155 */       IIcon iconStill = block.getIcon(1, bMeta);
/* 156 */       float flowDir = (float)BlockFluidBase.getFlowDirection(world, x, y, z);
/*     */       
/* 158 */       if (flowDir > -999.0F)
/*     */       {
/* 160 */         iconStill = block.getIcon(2, bMeta);
/*     */       }
/*     */       
/* 163 */       heightNW -= 0.0010000000474974513D;
/* 164 */       heightSW -= 0.0010000000474974513D;
/* 165 */       heightSE -= 0.0010000000474974513D;
/* 166 */       heightNE -= 0.0010000000474974513D;
/*     */ 
/*     */ 
/*     */       
/* 170 */       if (flowDir < -999.0F) {
/*     */         
/* 172 */         u2 = iconStill.getInterpolatedU(0.0D);
/* 173 */         v2 = iconStill.getInterpolatedV(0.0D);
/* 174 */         u1 = u2;
/* 175 */         v1 = iconStill.getInterpolatedV(16.0D);
/* 176 */         u4 = iconStill.getInterpolatedU(16.0D);
/* 177 */         v4 = v1;
/* 178 */         u3 = u4;
/* 179 */         v3 = v2;
/*     */       }
/*     */       else {
/*     */         
/* 183 */         float xFlow = MathHelper.sin(flowDir) * 0.25F;
/* 184 */         float zFlow = MathHelper.cos(flowDir) * 0.25F;
/* 185 */         u2 = iconStill.getInterpolatedU((8.0F + (-zFlow - xFlow) * 16.0F));
/* 186 */         v2 = iconStill.getInterpolatedV((8.0F + (-zFlow + xFlow) * 16.0F));
/* 187 */         u1 = iconStill.getInterpolatedU((8.0F + (-zFlow + xFlow) * 16.0F));
/* 188 */         v1 = iconStill.getInterpolatedV((8.0F + (zFlow + xFlow) * 16.0F));
/* 189 */         u4 = iconStill.getInterpolatedU((8.0F + (zFlow + xFlow) * 16.0F));
/* 190 */         v4 = iconStill.getInterpolatedV((8.0F + (zFlow - xFlow) * 16.0F));
/* 191 */         u3 = iconStill.getInterpolatedU((8.0F + (zFlow - xFlow) * 16.0F));
/* 192 */         v3 = iconStill.getInterpolatedV((8.0F + (-zFlow - xFlow) * 16.0F));
/*     */       } 
/*     */       
/* 195 */       tessellator.setBrightness(block.getMixedBrightnessForBlock(world, x, y, z));
/* 196 */       tessellator.setColorOpaque_F(1.0F * red, 1.0F * green, 1.0F * blue);
/*     */       
/* 198 */       if (!rises) {
/*     */         
/* 200 */         tessellator.addVertexWithUV((x + 0), y + heightNW, (z + 0), u2, v2);
/* 201 */         tessellator.addVertexWithUV((x + 0), y + heightSW, (z + 1), u1, v1);
/* 202 */         tessellator.addVertexWithUV((x + 1), y + heightSE, (z + 1), u4, v4);
/* 203 */         tessellator.addVertexWithUV((x + 1), y + heightNE, (z + 0), u3, v3);
/*     */       }
/*     */       else {
/*     */         
/* 207 */         tessellator.addVertexWithUV((x + 1), (y + 1) - heightNE, (z + 0), u3, v3);
/* 208 */         tessellator.addVertexWithUV((x + 1), (y + 1) - heightSE, (z + 1), u4, v4);
/* 209 */         tessellator.addVertexWithUV((x + 0), (y + 1) - heightSW, (z + 1), u1, v1);
/* 210 */         tessellator.addVertexWithUV((x + 0), (y + 1) - heightNW, (z + 0), u2, v2);
/*     */       } 
/*     */     } 
/*     */     
/* 214 */     if (renderer.renderAllFaces || renderBottom) {
/*     */       
/* 216 */       rendered = true;
/* 217 */       tessellator.setBrightness(block.getMixedBrightnessForBlock(world, x, y - 1, z));
/* 218 */       if (!rises) {
/*     */         
/* 220 */         tessellator.setColorOpaque_F(0.5F * red, 0.5F * green, 0.5F * blue);
/* 221 */         renderer.renderFaceYNeg(block, x, y + 0.0010000000474974513D, z, block.getIcon(0, bMeta));
/*     */       }
/*     */       else {
/*     */         
/* 225 */         tessellator.setColorOpaque_F(1.0F * red, 1.0F * green, 1.0F * blue);
/* 226 */         renderer.renderFaceYPos(block, x, y + 0.0010000000474974513D, z, block.getIcon(1, bMeta));
/*     */       } 
/*     */     } 
/*     */     
/* 230 */     for (int side = 0; side < 4; side++) {
/*     */       
/* 232 */       int x2 = x;
/* 233 */       int z2 = z;
/*     */       
/* 235 */       switch (side) {
/*     */         case 0:
/* 237 */           z2--; break;
/* 238 */         case 1: z2++; break;
/* 239 */         case 2: x2--; break;
/* 240 */         case 3: x2++;
/*     */           break;
/*     */       } 
/* 243 */       IIcon iconFlow = block.getIcon(side + 2, bMeta);
/* 244 */       if (renderer.renderAllFaces || renderSides[side]) {
/*     */         double ty1, tx1, ty2, tx2, tz1, tz2;
/* 246 */         rendered = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 255 */         if (side == 0) {
/*     */           
/* 257 */           ty1 = heightNW;
/* 258 */           ty2 = heightNE;
/* 259 */           tx1 = x;
/* 260 */           tx2 = (x + 1);
/* 261 */           tz1 = z + 0.0010000000474974513D;
/* 262 */           tz2 = z + 0.0010000000474974513D;
/*     */         }
/* 264 */         else if (side == 1) {
/*     */           
/* 266 */           ty1 = heightSE;
/* 267 */           ty2 = heightSW;
/* 268 */           tx1 = (x + 1);
/* 269 */           tx2 = x;
/* 270 */           tz1 = (z + 1) - 0.0010000000474974513D;
/* 271 */           tz2 = (z + 1) - 0.0010000000474974513D;
/*     */         }
/* 273 */         else if (side == 2) {
/*     */           
/* 275 */           ty1 = heightSW;
/* 276 */           ty2 = heightNW;
/* 277 */           tx1 = x + 0.0010000000474974513D;
/* 278 */           tx2 = x + 0.0010000000474974513D;
/* 279 */           tz1 = (z + 1);
/* 280 */           tz2 = z;
/*     */         }
/*     */         else {
/*     */           
/* 284 */           ty1 = heightNE;
/* 285 */           ty2 = heightSE;
/* 286 */           tx1 = (x + 1) - 0.0010000000474974513D;
/* 287 */           tx2 = (x + 1) - 0.0010000000474974513D;
/* 288 */           tz1 = z;
/* 289 */           tz2 = (z + 1);
/*     */         } 
/*     */         
/* 292 */         float u1Flow = iconFlow.getInterpolatedU(0.0D);
/* 293 */         float u2Flow = iconFlow.getInterpolatedU(8.0D);
/* 294 */         float v1Flow = iconFlow.getInterpolatedV((1.0D - ty1) * 16.0D * 0.5D);
/* 295 */         float v2Flow = iconFlow.getInterpolatedV((1.0D - ty2) * 16.0D * 0.5D);
/* 296 */         float v3Flow = iconFlow.getInterpolatedV(8.0D);
/* 297 */         tessellator.setBrightness(block.getMixedBrightnessForBlock(world, x2, y, z2));
/* 298 */         float sideLighting = 1.0F;
/*     */         
/* 300 */         if (side < 2) {
/*     */           
/* 302 */           sideLighting = 0.8F;
/*     */         }
/*     */         else {
/*     */           
/* 306 */           sideLighting = 0.6F;
/*     */         } 
/*     */         
/* 309 */         tessellator.setColorOpaque_F(1.0F * sideLighting * red, 1.0F * sideLighting * green, 1.0F * sideLighting * blue);
/*     */         
/* 311 */         if (!rises) {
/*     */           
/* 313 */           tessellator.addVertexWithUV(tx1, y + ty1, tz1, u1Flow, v1Flow);
/* 314 */           tessellator.addVertexWithUV(tx2, y + ty2, tz2, u2Flow, v2Flow);
/* 315 */           tessellator.addVertexWithUV(tx2, (y + 0), tz2, u2Flow, v3Flow);
/* 316 */           tessellator.addVertexWithUV(tx1, (y + 0), tz1, u1Flow, v3Flow);
/*     */         }
/*     */         else {
/*     */           
/* 320 */           tessellator.addVertexWithUV(tx1, (y + 1 - 0), tz1, u1Flow, v3Flow);
/* 321 */           tessellator.addVertexWithUV(tx2, (y + 1 - 0), tz2, u2Flow, v3Flow);
/* 322 */           tessellator.addVertexWithUV(tx2, (y + 1) - ty2, tz2, u2Flow, v2Flow);
/* 323 */           tessellator.addVertexWithUV(tx1, (y + 1) - ty1, tz1, u1Flow, v1Flow);
/*     */         } 
/*     */       } 
/*     */     } 
/* 327 */     renderer.renderMinY = 0.0D;
/* 328 */     renderer.renderMaxY = 1.0D;
/* 329 */     return rendered;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldRender3DInInventory(int modelId) {
/* 335 */     return false;
/*     */   }
/*     */   
/*     */   public int getRenderId() {
/* 339 */     return ConfigBlocks.blockFluxGasRI;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\block\BlockGasRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */