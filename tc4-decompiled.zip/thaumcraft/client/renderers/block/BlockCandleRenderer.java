/*    */ package thaumcraft.client.renderers.block;
/*    */ 
/*    */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*    */ import java.awt.Color;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.RenderBlocks;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.common.blocks.BlockCandle;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ import thaumcraft.common.lib.utils.Utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockCandleRenderer
/*    */   extends BlockRenderer
/*    */   implements ISimpleBlockRenderingHandler
/*    */ {
/*    */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {
/* 22 */     Color c = new Color(Utils.colors[metadata]);
/* 23 */     float r = c.getRed() / 255.0F;
/* 24 */     float g = c.getGreen() / 255.0F;
/* 25 */     float b = c.getBlue() / 255.0F;
/* 26 */     GL11.glColor3f(r, g, b);
/* 27 */     block.setBlockBounds(W6, 0.0F, W6, W10, 0.5F, W10);
/* 28 */     renderer.setRenderBoundsFromBlock(block);
/* 29 */     drawFaces(renderer, block, ((BlockCandle)block).icon, true);
/* 30 */     GL11.glColor3f(1.0F, 1.0F, 1.0F);
/*    */     
/* 32 */     block.setBlockBounds(0.475F, 0.5F, 0.475F, 0.525F, W10, 0.525F);
/* 33 */     renderer.setRenderBoundsFromBlock(block);
/* 34 */     drawFaces(renderer, block, ((BlockCandle)block).iconStub, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
/* 39 */     int type = 0;
/*    */     
/* 41 */     block.setBlockBounds(W6, 0.0F, W6, W10, 0.5F, W10);
/* 42 */     renderer.setRenderBoundsFromBlock(block);
/* 43 */     renderer.renderStandardBlock(block, x, y, z);
/*    */     
/* 45 */     Random rr = new Random((x + y * z));
/* 46 */     int q = 1 + rr.nextInt(5);
/* 47 */     for (int a = 0; a < q; a++) {
/* 48 */       boolean side = rr.nextBoolean();
/* 49 */       int loc = 2 + rr.nextInt(2);
/* 50 */       if (a % 2 == 0) {
/* 51 */         block.setBlockBounds(W5 + W1 * loc, 0.0F, side ? W5 : W10, W6 + W1 * loc, W1 * (1 + rr.nextInt(3)), side ? W6 : W11);
/*    */ 
/*    */         
/* 54 */         renderer.setRenderBoundsFromBlock(block);
/* 55 */         renderer.renderStandardBlock(block, x, y, z);
/*    */       } else {
/* 57 */         block.setBlockBounds(side ? W5 : W10, 0.0F, W5 + W1 * loc, side ? W6 : W11, W1 * (1 + rr.nextInt(3)), W6 + W1 * loc);
/*    */ 
/*    */         
/* 60 */         renderer.setRenderBoundsFromBlock(block);
/* 61 */         renderer.renderStandardBlock(block, x, y, z);
/*    */       } 
/*    */     } 
/*    */     
/* 65 */     renderer.overrideBlockTexture = ((BlockCandle)block).iconStub;
/* 66 */     block.setBlockBounds(0.475F, 0.5F, 0.475F, 0.525F, W10, 0.525F);
/* 67 */     renderer.setRenderBoundsFromBlock(block);
/* 68 */     renderer.renderStandardBlockWithColorMultiplier(block, x, y, z, 1.0F, 1.0F, 1.0F);
/*    */     
/* 70 */     renderer.clearOverrideBlockTexture();
/* 71 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 72 */     renderer.setRenderBoundsFromBlock(block);
/* 73 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldRender3DInInventory(int modelId) {
/* 78 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRenderId() {
/* 83 */     return ConfigBlocks.blockCandleRI;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\block\BlockCandleRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */