/*    */ package thaumcraft.client.renderers.block;
/*    */ 
/*    */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.RenderBlocks;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.common.blocks.BlockCustomOreItem;
/*    */ import thaumcraft.common.blocks.BlockLifter;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ import thaumcraft.common.tiles.TileLifter;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockLifterRenderer
/*    */   extends BlockRenderer
/*    */   implements ISimpleBlockRenderingHandler
/*    */ {
/*    */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {
/* 23 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 24 */     renderer.setRenderBoundsFromBlock(block);
/* 25 */     drawFaces(renderer, block, ((BlockLifter)block).iconBottom, ((BlockLifter)block).iconTop, ((BlockLifter)block).iconSide, ((BlockLifter)block).iconSide, ((BlockLifter)block).iconSide, ((BlockLifter)block).iconSide, false);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 30 */     Color c = new Color(BlockCustomOreItem.colors[4]);
/* 31 */     float r = c.getRed() / 255.0F;
/* 32 */     float g = c.getGreen() / 255.0F;
/* 33 */     float b = c.getBlue() / 255.0F;
/* 34 */     GL11.glColor3f(r, g, b);
/* 35 */     block.setBlockBounds(0.01F, 0.9F, 0.01F, 0.99F, 0.99F, 0.99F);
/* 36 */     renderer.setRenderBoundsFromBlock(block);
/* 37 */     drawFaces(renderer, block, ((BlockLifter)block).iconGlow, false);
/*    */ 
/*    */     
/* 40 */     c = new Color(BlockCustomOreItem.colors[5]);
/* 41 */     r = c.getRed() / 255.0F;
/* 42 */     g = c.getGreen() / 255.0F;
/* 43 */     b = c.getBlue() / 255.0F;
/* 44 */     GL11.glColor3f(r, g, b);
/* 45 */     block.setBlockBounds(0.01F, 0.1F, 0.01F, 0.99F, 0.9F, 0.99F);
/* 46 */     renderer.setRenderBoundsFromBlock(block);
/* 47 */     drawFaces(renderer, block, ((BlockLifter)block).iconGlow, false);
/*    */     
/* 49 */     GL11.glColor3f(1.0F, 1.0F, 1.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
/* 56 */     int bb = setBrightness(world, x, y, z, block);
/* 57 */     int metadata = world.getBlockMetadata(x, y, z);
/* 58 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 59 */     renderer.setRenderBoundsFromBlock(block);
/* 60 */     renderer.renderStandardBlock(block, x, y, z);
/*    */     
/* 62 */     Tessellator t = Tessellator.instance;
/* 63 */     t.setColorOpaque_I(BlockCustomOreItem.colors[4]);
/* 64 */     TileEntity te = world.getTileEntity(x, y, z);
/* 65 */     if (te != null && te instanceof TileLifter && !((TileLifter)te).gettingPower()) bb = 180;
/*    */     
/* 67 */     t.setBrightness(bb);
/*    */     
/* 69 */     if (block.shouldSideBeRendered(world, x, y + 1, z, 6)) renderer.renderFaceYPos(block, x, (y - 0.01F), z, ((BlockLifter)block).iconGlow); 
/* 70 */     t.setColorOpaque_I(14488063);
/* 71 */     if (block.shouldSideBeRendered(world, x + 1, y, z, 6)) renderer.renderFaceXPos(block, (x - 0.01F), y, z, ((BlockLifter)block).iconGlow); 
/* 72 */     if (block.shouldSideBeRendered(world, x - 1, y, z, 6)) renderer.renderFaceXNeg(block, (x + 0.01F), y, z, ((BlockLifter)block).iconGlow); 
/* 73 */     if (block.shouldSideBeRendered(world, x, y, z + 1, 6)) renderer.renderFaceZPos(block, x, y, (z - 0.01F), ((BlockLifter)block).iconGlow); 
/* 74 */     if (block.shouldSideBeRendered(world, x, y, z - 1, 6)) renderer.renderFaceZNeg(block, x, y, (z + 0.01F), ((BlockLifter)block).iconGlow);
/*    */     
/* 76 */     renderer.clearOverrideBlockTexture();
/* 77 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 78 */     renderer.setRenderBoundsFromBlock(block);
/* 79 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldRender3DInInventory(int modelId) {
/* 84 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRenderId() {
/* 89 */     return ConfigBlocks.blockLifterRI;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\block\BlockLifterRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */