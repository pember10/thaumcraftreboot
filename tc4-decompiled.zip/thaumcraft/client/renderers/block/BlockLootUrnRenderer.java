/*    */ package thaumcraft.client.renderers.block;
/*    */ 
/*    */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.RenderBlocks;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockLootUrnRenderer
/*    */   extends BlockRenderer
/*    */   implements ISimpleBlockRenderingHandler
/*    */ {
/*    */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {}
/*    */   
/*    */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
/* 18 */     int metadata = world.getBlockMetadata(x, y, z);
/* 19 */     block.setBlockBounds(W3, 0.0F, W3, W13, W1, W13);
/* 20 */     renderer.setRenderBoundsFromBlock(block);
/* 21 */     renderer.renderStandardBlock(block, x, y, z);
/*    */     
/* 23 */     block.setBlockBounds(W2, W1, W2, W14, W13, W14);
/* 24 */     renderer.setRenderBoundsFromBlock(block);
/* 25 */     renderer.renderStandardBlock(block, x, y, z);
/*    */     
/* 27 */     block.setBlockBounds(W4, W13, W4, W12, 1.0F, W12);
/* 28 */     renderer.setRenderBoundsFromBlock(block);
/* 29 */     renderer.renderStandardBlock(block, x, y, z);
/*    */     
/* 31 */     renderer.clearOverrideBlockTexture();
/* 32 */     block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 33 */     renderer.setRenderBoundsFromBlock(block);
/* 34 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldRender3DInInventory(int modelId) {
/* 39 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRenderId() {
/* 44 */     return ConfigBlocks.blockLootUrnRI;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\renderers\block\BlockLootUrnRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */