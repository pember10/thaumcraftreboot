/*     */ package thaumcraft.client.gui;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.wands.FocusUpgradeType;
/*     */ import thaumcraft.api.wands.ItemFocusBasic;
/*     */ import thaumcraft.client.fx.ParticleEngine;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.common.container.ContainerFocalManipulator;
/*     */ import thaumcraft.common.tiles.TileFocalManipulator;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class GuiFocalManipulator extends GuiContainer {
/*     */   private TileFocalManipulator table;
/*     */   private float xSize_lo;
/*     */   private float ySize_lo;
/*     */   int selected;
/*     */   int rank;
/*     */   long time;
/*     */   long nextSparkle;
/*     */   DecimalFormat myFormatter;
/*     */   ArrayList<FocusUpgradeType> possibleUpgrades;
/*     */   ArrayList<FocusUpgradeType> upgrades;
/*     */   AspectList aspects;
/*     */   HashMap<Long, Sparkle> sparkles;
/*     */   
/*  42 */   public GuiFocalManipulator(InventoryPlayer par1InventoryPlayer, TileFocalManipulator table) { super((Container)new ContainerFocalManipulator(par1InventoryPlayer, table));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     this.selected = -1;
/* 129 */     this.rank = 0;
/*     */     
/* 131 */     this.nextSparkle = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     this.myFormatter = new DecimalFormat("#######.#");
/* 257 */     this.possibleUpgrades = new ArrayList<FocusUpgradeType>();
/* 258 */     this.upgrades = new ArrayList<FocusUpgradeType>();
/* 259 */     this.aspects = new AspectList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 372 */     this.sparkles = new HashMap<Long, Sparkle>(); this.table = table; this.xSize = 192; this.ySize = 233; if (table.size > 0) { gatherInfo(); this.selected = table.upgrade; }  }
/*     */   public void drawScreen(int par1, int par2, float par3) { super.drawScreen(par1, par2, par3); this.xSize_lo = par1; this.ySize_lo = par2; int baseX = this.guiLeft; int baseY = this.guiTop; int mposx = 0; int mposy = 0; if (this.rank > 0) for (int i = 0; i < this.possibleUpgrades.size(); i++) { mposx = par1 - baseX + 48 + i * 16; mposy = par2 - baseY + 104; if (mposx >= 0 && mposy >= 0 && mposx < 16 && mposy < 16) { FocusUpgradeType u = this.possibleUpgrades.get(i); List<String> list = new ArrayList(); list.add(EnumChatFormatting.DARK_PURPLE + "" + EnumChatFormatting.UNDERLINE + u.getLocalizedName()); list.add(u.getLocalizedText()); drawHoveringTextFixed(list, baseX + this.xSize - 36, baseY + 24, this.fontRendererObj, this.width - baseX + this.xSize - 16); }  }   if (this.selected >= 0) { mposx = par1 - baseX + 48; mposy = par2 - baseY + 48; if (mposx >= 0 && mposy >= 0 && mposx < 36 && mposy < 36) { List<String> list = new ArrayList(); list.add(StatCollector.translateToLocal("wandtable.text1")); drawHoveringText(list, par1, par2, this.fontRendererObj); }  mposx = par1 - baseX + 108; mposy = par2 - baseY + 58; if (mposx >= 0 && mposy >= 0 && mposx < 36 && mposy < 16) { List<String> list = new ArrayList(); list.add(StatCollector.translateToLocal("wandtable.text2")); drawHoveringText(list, par1, par2, this.fontRendererObj); }  if (this.table.size == 0 && this.rank * 8 <= this.mc.thePlayer.experienceLevel) { mposx = par1 - baseX + 48; mposy = par2 - baseY + 88; if (mposx >= 0 && mposy >= 0 && mposx < 96 && mposy < 8) { List<String> list = new ArrayList(); list.add(StatCollector.translateToLocal("wandtable.text3")); drawHoveringText(list, par1, par2, this.fontRendererObj); }  }  }  for (int a = 0; a < this.upgrades.size(); a++) { mposx = par1 - baseX + 56 + a * 16; mposy = par2 - baseY + 32; if (mposx >= 0 && mposy >= 0 && mposx < 16 && mposy < 16) { FocusUpgradeType u = this.upgrades.get(a); List<String> list = new ArrayList(); list.add(EnumChatFormatting.DARK_PURPLE + "" + EnumChatFormatting.UNDERLINE + u.getLocalizedName()); list.add(u.getLocalizedText()); drawHoveringTextFixed(list, baseX + this.xSize - 36, baseY + 24, this.fontRendererObj, this.width - baseX + this.xSize - 16); }  }  }
/*     */   protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3) { this.time = System.currentTimeMillis(); GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F); UtilsFX.bindTexture("textures/gui/gui_wandtable.png"); int k = (this.width - this.xSize) / 2; int l = (this.height - this.ySize) / 2; GL11.glEnable(3042); GL11.glBlendFunc(770, 771); drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize); if (this.table.getStackInSlot(0) == null || this.table.rank < 0 || this.table.reset) { this.rank = 0; this.selected = -1; this.possibleUpgrades.clear(); this.upgrades.clear(); this.aspects = new AspectList(); this.table.reset = false; this.table.rank = 0; }  if (this.rank > 0) for (int i = 0; i < this.possibleUpgrades.size(); i++) { FocusUpgradeType u = this.possibleUpgrades.get(i); if (this.selected == u.id) drawTexturedModalRect(k + 48 + i * 16, l + 104, 200, 0, 16, 16);  }   if (this.rank > 0 && this.selected >= 0 && this.table.getStackInSlot(0) != null) { int xp = this.rank * 8; if (this.table.size == 0 && xp <= this.mc.thePlayer.experienceLevel) drawTexturedModalRect(k + 48, l + 88, 8, 240, 96, 8);  drawTexturedModalRect(k + 108, l + 59, 200, 16, 16, 16); int start = 0; if (this.table.aspects.size() > 0) for (Aspect aspect : this.table.aspects.getAspectsSorted()) { if (aspect != null && this.table.aspects.getAmount(aspect) != 0) { int size = (int)(this.table.aspects.getAmount(aspect) / this.table.size * 96.0F); Color c = new Color(aspect.getColor()); GL11.glColor4f(c.getRed() / 255.0F, c.getGreen() / 255.0F, c.getBlue() / 255.0F, 0.9F); drawTexturedModalRect(k + 48 + start, l + 88, 112 + start, 240, size, 8); start += size; if ((this.table.getWorldObj()).rand.nextInt(66) == 0) { float x = (48 + start); float y = 92.0F; float xx = ((46 + this.rank * 16) - x) / 9.0F; float yy = (38.0F - y) / 9.0F; this.sparkles.put(Long.valueOf(this.time), new Sparkle(x, y, xx, yy, c.getRed() / 255.0F, c.getGreen() / 255.0F, c.getBlue() / 255.0F)); }  }  }   this.fontRendererObj.drawStringWithShadow("" + xp, k + 125, l + 64, (xp > this.mc.thePlayer.experienceLevel) ? 16151160 : 10092429); AspectList al = this.aspects; if (this.table.size > 0) al = this.table.aspects;  int q = 0; for (Aspect aspect : al.getAspectsSorted()) { if (aspect != null) { GL11.glPushMatrix(); GL11.glTranslated((k + 49), (l + 68) - al.size() * 2.5D, 0.0D); GL11.glScaled(0.5D, 0.5D, 0.5D); this.fontRendererObj.drawStringWithShadow(aspect.getName(), 0, q * 10, aspect.getColor()); String s = this.myFormatter.format((al.getAmount(aspect) / 100.0F)); this.fontRendererObj.drawStringWithShadow(s, 48, q * 10, aspect.getColor()); GL11.glPopMatrix(); q++; }  }  }  if (this.rank > 0) { if (this.nextSparkle < this.time) { this.nextSparkle = this.time + ((this.table.size > 0) ? 10L : 500L) + (this.table.getWorldObj()).rand.nextInt(200); this.sparkles.put(Long.valueOf(this.time), new Sparkle((42 + this.rank * 16 + (this.table.getWorldObj()).rand.nextInt(12)), (34 + (this.table.getWorldObj()).rand.nextInt(12)), 0.0F, 0.0F, 0.5F + (this.table.getWorldObj()).rand.nextFloat() * 0.4F, 1.0F - (this.table.getWorldObj()).rand.nextFloat() * 0.4F, 1.0F - (this.table.getWorldObj()).rand.nextFloat() * 0.4F)); }  GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F); for (int i = 0; i < this.possibleUpgrades.size(); i++) { FocusUpgradeType u = this.possibleUpgrades.get(i); GL11.glPushMatrix(); GL11.glEnable(3042); GL11.glBlendFunc(770, 771); this.mc.renderEngine.bindTexture(u.icon); UtilsFX.drawTexturedQuadFull(k + 48 + i * 16, l + 104, this.zLevel); GL11.glPopMatrix(); }  } else if (this.rank == 0 && this.table.getStackInSlot(0) != null) { try { gatherInfo(); } catch (Exception e) {} }  GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F); for (int a = 0; a < this.upgrades.size(); a++) { FocusUpgradeType u = this.upgrades.get(a); GL11.glPushMatrix(); GL11.glEnable(3042); GL11.glBlendFunc(770, 771); this.mc.renderEngine.bindTexture(u.icon); UtilsFX.drawTexturedQuadFull(k + 56 + a * 16, l + 32, this.zLevel); GL11.glPopMatrix(); }  GL11.glDisable(3042); }
/*     */   private void gatherInfo() { this.possibleUpgrades.clear(); this.upgrades.clear(); this.aspects = new AspectList(); ItemFocusBasic focus = (ItemFocusBasic)this.table.getStackInSlot(0).getItem(); short[] s = focus.getAppliedUpgrades(this.table.getStackInSlot(0)); this.rank = 1; int fu = 0; for (; this.rank <= 5 && s[this.rank - 1] != -1; this.rank++) { this.upgrades.add(FocusUpgradeType.types[s[this.rank - 1]]); fu++; }  if (fu == 5) { this.rank = -1; } else { FocusUpgradeType[] ut = focus.getPossibleUpgradesByRank(this.table.getStackInSlot(0), this.rank); if (ut == null) return;  for (int a = 0; a < ut.length; a++) { if (focus.canApplyUpgrade(this.table.getStackInSlot(0), (EntityPlayer)(Minecraft.getMinecraft()).thePlayer, ut[a], this.rank)) this.possibleUpgrades.add(ut[a]);  }  }  if (this.table.size > 0)
/*     */       this.selected = this.table.upgrade;  }
/*     */   protected void drawGuiContainerForegroundLayer(int p_146979_1_, int p_146979_2_) { UtilsFX.bindTexture(ParticleEngine.particleTexture); Long[] keys = (Long[])this.sparkles.keySet().toArray((Object[])new Long[0]); for (Long key : keys) { Sparkle s = this.sparkles.get(key); drawSparkle(s.x, s.y, s.frame, s.r, s.g, s.b); if (s.nextframe < this.time) { s.frame++; s.nextframe = this.time + 50L; s.x += s.mx; s.y += s.my; }  if (s.frame == 9) { this.sparkles.remove(key); } else { this.sparkles.put(key, s); }  }  } protected void mouseClicked(int mx, int my, int par3) { super.mouseClicked(mx, my, par3); int gx = (this.width - this.xSize) / 2; int gy = (this.height - this.ySize) / 2; int var7 = mx - gx + 48; int var8 = my - gy + 88; if (this.table.size == 0 && this.selected >= 0 && this.rank * 8 <= this.mc.thePlayer.experienceLevel && var7 >= 0 && var8 >= 0 && var7 < 96 && var8 < 8) { this.mc.playerController.sendEnchantPacket(this.inventorySlots.windowId, this.selected); playButtonClick(); return; }  if (this.table.size == 0)
/*     */       for (int a = 0; a < this.possibleUpgrades.size(); a++) { FocusUpgradeType u = this.possibleUpgrades.get(a); var7 = mx - gx + 48 + a * 16; var8 = my - gy + 104; if (var7 >= 0 && var8 >= 0 && var7 < 16 && var8 < 16) { this.aspects = new AspectList(); if (this.selected == u.id) { this.selected = -1; } else { this.selected = u.id; int amt = 200; for (int q = 1; q < this.rank; ) { amt *= 2; q++; }  AspectList tal = new AspectList(); for (Aspect as : (FocusUpgradeType.types[this.selected]).aspects.getAspects())
/*     */               tal.add(as, amt);  this.aspects = ResearchManager.reduceToPrimals(tal); }  playButtonClick(); return; }  }   } private void playButtonClick() { this.mc.renderViewEntity.worldObj.playSound(this.mc.renderViewEntity.posX, this.mc.renderViewEntity.posY, this.mc.renderViewEntity.posZ, "thaumcraft:cameraclack", 0.4F, 1.0F, false); } private class Sparkle
/*     */   {
/* 381 */     float x; float y; float mx; float my; public Sparkle(float x, float y, float mx, float my, float r, float g, float b) { this.x = x;
/* 382 */       this.y = y;
/* 383 */       this.mx = mx;
/* 384 */       this.my = my;
/* 385 */       this.frame = 0;
/* 386 */       this.r = r;
/* 387 */       this.g = g;
/* 388 */       this.b = b;
/* 389 */       this.nextframe = System.currentTimeMillis() + 50L; }
/*     */     
/*     */     float r; float g; float b; long nextframe; int frame; }
/*     */   
/*     */   private void drawSparkle(double x, double y, int frame, float r, float g, float b) {
/* 394 */     GL11.glPushMatrix();
/* 395 */     GL11.glEnable(3042);
/* 396 */     GL11.glBlendFunc(770, 1);
/* 397 */     GL11.glColor4f(r, g, b, 0.9F);
/* 398 */     GL11.glTranslated(x, y, 200.0D);
/* 399 */     Tessellator tessellator = Tessellator.instance;
/* 400 */     float var8 = frame / 16.0F;
/* 401 */     float var9 = var8 + 0.0624375F;
/* 402 */     float var10 = 0.4375F;
/* 403 */     float var11 = var10 + 0.0624375F;
/* 404 */     tessellator.startDrawingQuads();
/* 405 */     tessellator.setBrightness(220);
/* 406 */     tessellator.setColorRGBA_F(r, g, b, 0.9F);
/* 407 */     tessellator.addVertexWithUV(-4.0D, 4.0D, this.zLevel, var9, var11);
/* 408 */     tessellator.addVertexWithUV(4.0D, 4.0D, this.zLevel, var9, var10);
/* 409 */     tessellator.addVertexWithUV(4.0D, -4.0D, this.zLevel, var8, var10);
/* 410 */     tessellator.addVertexWithUV(-4.0D, -4.0D, this.zLevel, var8, var11);
/* 411 */     tessellator.draw();
/* 412 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 413 */     GL11.glDisable(3042);
/* 414 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawHoveringTextFixed(List listin, int x, int y, FontRenderer font, int width) {
/* 419 */     if (!listin.isEmpty()) {
/*     */       
/* 421 */       List<String> list = new ArrayList();
/* 422 */       for (Object o : listin) {
/* 423 */         String s = (String)o;
/* 424 */         s = trimStringNewline(s);
/*     */         
/* 426 */         List list2 = font.listFormattedStringToWidth(s, width);
/*     */         
/* 428 */         for (Iterator<String> iterator1 = list2.iterator(); iterator1.hasNext(); ) {
/*     */           
/* 430 */           String s1 = iterator1.next();
/* 431 */           list.add(s1);
/*     */         } 
/*     */       } 
/*     */       
/* 435 */       GL11.glDisable(32826);
/* 436 */       RenderHelper.disableStandardItemLighting();
/* 437 */       GL11.glDisable(2896);
/* 438 */       GL11.glDisable(2929);
/* 439 */       int k = 0;
/* 440 */       Iterator<String> iterator = list.iterator();
/*     */       
/* 442 */       while (iterator.hasNext()) {
/*     */         
/* 444 */         String s = iterator.next();
/* 445 */         int l = font.getStringWidth(s);
/*     */         
/* 447 */         if (l > k)
/*     */         {
/* 449 */           k = l;
/*     */         }
/*     */       } 
/*     */       
/* 453 */       int j2 = x + 12;
/* 454 */       int k2 = y - 12;
/* 455 */       int i1 = 8;
/*     */       
/* 457 */       if (list.size() > 1)
/*     */       {
/* 459 */         i1 += 2 + (list.size() - 1) * 10;
/*     */       }
/*     */ 
/*     */       
/* 463 */       this.zLevel = 300.0F;
/* 464 */       itemRender.zLevel = 300.0F;
/* 465 */       int j1 = -267386864;
/* 466 */       drawGradientRect(j2 - 3, k2 - 4, j2 + k + 3, k2 - 3, j1, j1);
/* 467 */       drawGradientRect(j2 - 3, k2 + i1 + 3, j2 + k + 3, k2 + i1 + 4, j1, j1);
/* 468 */       drawGradientRect(j2 - 3, k2 - 3, j2 + k + 3, k2 + i1 + 3, j1, j1);
/* 469 */       drawGradientRect(j2 - 4, k2 - 3, j2 - 3, k2 + i1 + 3, j1, j1);
/* 470 */       drawGradientRect(j2 + k + 3, k2 - 3, j2 + k + 4, k2 + i1 + 3, j1, j1);
/* 471 */       int k1 = 1347420415;
/* 472 */       int l1 = (k1 & 0xFEFEFE) >> 1 | k1 & 0xFF000000;
/* 473 */       drawGradientRect(j2 - 3, k2 - 3 + 1, j2 - 3 + 1, k2 + i1 + 3 - 1, k1, l1);
/* 474 */       drawGradientRect(j2 + k + 2, k2 - 3 + 1, j2 + k + 3, k2 + i1 + 3 - 1, k1, l1);
/* 475 */       drawGradientRect(j2 - 3, k2 - 3, j2 + k + 3, k2 - 3 + 1, k1, k1);
/* 476 */       drawGradientRect(j2 - 3, k2 + i1 + 2, j2 + k + 3, k2 + i1 + 3, l1, l1);
/*     */       
/* 478 */       for (int i2 = 0; i2 < list.size(); i2++) {
/*     */         
/* 480 */         String s1 = list.get(i2);
/* 481 */         font.drawStringWithShadow(s1, j2, k2, -1);
/*     */         
/* 483 */         if (i2 == 0)
/*     */         {
/* 485 */           k2 += 2;
/*     */         }
/*     */         
/* 488 */         k2 += 10;
/*     */       } 
/*     */       
/* 491 */       this.zLevel = 0.0F;
/* 492 */       itemRender.zLevel = 0.0F;
/* 493 */       GL11.glEnable(2896);
/* 494 */       GL11.glEnable(2929);
/* 495 */       RenderHelper.enableStandardItemLighting();
/* 496 */       GL11.glEnable(32826);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String trimStringNewline(String p_78273_1_) {
/* 502 */     while (p_78273_1_ != null && p_78273_1_.endsWith("\n"))
/*     */     {
/* 504 */       p_78273_1_ = p_78273_1_.substring(0, p_78273_1_.length() - 1);
/*     */     }
/*     */     
/* 507 */     return p_78273_1_;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\gui\GuiFocalManipulator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */