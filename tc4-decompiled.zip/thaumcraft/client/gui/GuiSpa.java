/*     */ package thaumcraft.client.gui;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraftforge.fluids.FluidStack;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.common.container.ContainerSpa;
/*     */ import thaumcraft.common.tiles.TileSpa;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class GuiSpa
/*     */   extends GuiContainer
/*     */ {
/*     */   private TileSpa spa;
/*     */   private float xSize_lo;
/*     */   private float ySize_lo;
/*     */   
/*     */   public GuiSpa(InventoryPlayer par1InventoryPlayer, TileSpa teSpa) {
/*  41 */     super((Container)new ContainerSpa(par1InventoryPlayer, teSpa));
/*  42 */     this.spa = teSpa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawScreen(int par1, int par2, float par3) {
/*  55 */     super.drawScreen(par1, par2, par3);
/*  56 */     this.xSize_lo = par1;
/*  57 */     this.ySize_lo = par2;
/*     */     
/*  59 */     int baseX = this.guiLeft;
/*  60 */     int baseY = this.guiTop;
/*     */     
/*  62 */     int mposx = par1 - baseX + 104;
/*  63 */     int mposy = par2 - baseY + 10;
/*     */     
/*  65 */     if (mposx >= 0 && mposy >= 0 && mposx < 10 && mposy < 55) {
/*     */       
/*  67 */       List<String> list = new ArrayList();
/*  68 */       FluidStack fluid = this.spa.tank.getFluid();
/*  69 */       if (fluid != null) {
/*  70 */         list.add(fluid.getFluid().getLocalizedName(fluid));
/*  71 */         list.add(fluid.amount + " mb");
/*  72 */         drawHoveringText(list, par1, par2, this.fontRendererObj);
/*     */       } 
/*     */     } 
/*     */     
/*  76 */     mposx = par1 - baseX + 88;
/*  77 */     mposy = par2 - baseY + 34;
/*     */     
/*  79 */     if (mposx >= 0 && mposy >= 0 && mposx < 10 && mposy < 10) {
/*     */       
/*  81 */       List<String> list = new ArrayList();
/*  82 */       if (this.spa.getMix()) {
/*  83 */         list.add(StatCollector.translateToLocal("text.spa.mix.true"));
/*     */       } else {
/*  85 */         list.add(StatCollector.translateToLocal("text.spa.mix.false"));
/*     */       } 
/*  87 */       drawHoveringText(list, par1, par2, this.fontRendererObj);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3) {
/*  98 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  99 */     UtilsFX.bindTexture("textures/gui/gui_spa.png");
/* 100 */     int k = (this.width - this.xSize) / 2;
/* 101 */     int l = (this.height - this.ySize) / 2;
/*     */     
/* 103 */     GL11.glEnable(3042);
/* 104 */     GL11.glBlendFunc(770, 771);
/*     */     
/* 106 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*     */     
/* 108 */     if (this.spa.getMix()) {
/* 109 */       drawTexturedModalRect(k + 89, l + 35, 208, 16, 8, 8);
/*     */     } else {
/* 111 */       drawTexturedModalRect(k + 89, l + 35, 208, 32, 8, 8);
/*     */     } 
/*     */ 
/*     */     
/* 115 */     if (this.spa.tank.getFluidAmount() > 0) {
/* 116 */       FluidStack fluid = this.spa.tank.getFluid();
/* 117 */       if (fluid != null) {
/* 118 */         IIcon icon = fluid.getFluid().getIcon();
/* 119 */         if (icon != null) {
/* 120 */           float bar = this.spa.tank.getFluidAmount() / this.spa.tank.getCapacity();
/* 121 */           GL11.glPushMatrix();
/* 122 */           GL11.glTranslatef((this.guiLeft + 107), (this.guiTop + 15), 0.0F);
/* 123 */           renderFluid(icon);
/* 124 */           GL11.glPopMatrix();
/* 125 */           UtilsFX.bindTexture("textures/gui/gui_spa.png");
/* 126 */           drawTexturedModalRect(k + 107, l + 15, 107, 15, 10, (int)(48.0F - 48.0F * bar));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 131 */     drawTexturedModalRect(k + 106, l + 11, 232, 0, 10, 55);
/*     */ 
/*     */     
/* 134 */     GL11.glDisable(3042);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderFluid(IIcon icon) {
/* 139 */     (Minecraft.getMinecraft()).renderEngine.bindTexture(TextureMap.locationBlocksTexture);
/*     */     
/* 141 */     Tessellator tessellator = Tessellator.instance;
/*     */     
/* 143 */     float f1 = icon.getMaxU();
/* 144 */     float f2 = icon.getMinV();
/* 145 */     float f3 = icon.getMinU();
/* 146 */     float f4 = icon.getMaxV();
/*     */     
/* 148 */     GL11.glScalef(8.0F, 8.0F, 8.0F);
/*     */     
/* 150 */     for (int a = 0; a < 6; a++) {
/* 151 */       tessellator.startDrawingQuads();
/* 152 */       tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 1.0F);
/* 153 */       tessellator.setNormal(0.0F, 0.0F, 1.0F);
/* 154 */       tessellator.addVertexWithUV(0.0D, (1 + a), 0.0D, f1, f4);
/* 155 */       tessellator.addVertexWithUV(1.0D, (1 + a), 0.0D, f3, f4);
/* 156 */       tessellator.addVertexWithUV(1.0D, (0 + a), 0.0D, f3, f2);
/* 157 */       tessellator.addVertexWithUV(0.0D, (0 + a), 0.0D, f1, f2);
/* 158 */       tessellator.draw();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mouseClicked(int mx, int my, int par3) {
/* 165 */     super.mouseClicked(mx, my, par3);
/*     */     
/* 167 */     int gx = (this.width - this.xSize) / 2;
/* 168 */     int gy = (this.height - this.ySize) / 2;
/*     */ 
/*     */     
/* 171 */     int var7 = mx - gx + 89;
/* 172 */     int var8 = my - gy + 35;
/*     */     
/* 174 */     if (var7 >= 0 && var8 >= 0 && var7 < 8 && var8 < 8) {
/*     */ 
/*     */       
/* 177 */       this.mc.playerController.sendEnchantPacket(this.inventorySlots.windowId, 1);
/* 178 */       playButtonClick();
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void playButtonClick() {
/* 186 */     this.mc.renderViewEntity.worldObj.playSound(this.mc.renderViewEntity.posX, this.mc.renderViewEntity.posY, this.mc.renderViewEntity.posZ, "thaumcraft:cameraclack", 0.4F, 1.0F, false);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\gui\GuiSpa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */