/*    */ package thaumcraft.client.gui;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.world.World;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.client.lib.UtilsFX;
/*    */ import thaumcraft.common.container.ContainerHandMirror;
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class GuiHandMirror
/*    */   extends GuiContainer
/*    */ {
/*    */   public GuiHandMirror(InventoryPlayer par1InventoryPlayer, World world, int x, int y, int z) {
/* 20 */     super((Container)new ContainerHandMirror(par1InventoryPlayer, world, x, y, z));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void drawGuiContainerForegroundLayer() {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean checkHotbarKeys(int par1) {
/* 32 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3) {
/* 40 */     UtilsFX.bindTexture("textures/gui/guihandmirror.png");
/* 41 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 42 */     int var5 = (this.width - this.xSize) / 2;
/* 43 */     int var6 = (this.height - this.ySize) / 2;
/* 44 */     drawTexturedModalRect(var5, var6, 0, 0, this.xSize, this.ySize);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\gui\GuiHandMirror.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */