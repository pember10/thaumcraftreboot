/*    */ package thaumcraft.client.gui;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.client.lib.UtilsFX;
/*    */ import thaumcraft.common.container.ContainerAlchemyFurnace;
/*    */ import thaumcraft.common.tiles.TileAlchemyFurnace;
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class GuiAlchemyFurnace
/*    */   extends GuiContainer
/*    */ {
/*    */   private TileAlchemyFurnace furnaceInventory;
/*    */   
/*    */   public GuiAlchemyFurnace(InventoryPlayer par1InventoryPlayer, TileAlchemyFurnace par2TileEntityFurnace) {
/* 22 */     super((Container)new ContainerAlchemyFurnace(par1InventoryPlayer, par2TileEntityFurnace));
/* 23 */     this.furnaceInventory = par2TileEntityFurnace;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void drawGuiContainerForegroundLayer(int par1, int par2) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3) {
/* 41 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 42 */     UtilsFX.bindTexture("textures/gui/gui_alchemyfurnace.png");
/* 43 */     int k = (this.width - this.xSize) / 2;
/* 44 */     int l = (this.height - this.ySize) / 2;
/*    */     
/* 46 */     GL11.glEnable(3042);
/* 47 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*    */ 
/*    */     
/* 50 */     if (this.furnaceInventory.isBurning()) {
/*    */       
/* 52 */       int i = this.furnaceInventory.getBurnTimeRemainingScaled(20);
/* 53 */       drawTexturedModalRect(k + 80, l + 26 + 20 - i, 176, 20 - i, 16, i);
/*    */     } 
/*    */     
/* 56 */     int i1 = this.furnaceInventory.getCookProgressScaled(46);
/* 57 */     drawTexturedModalRect(k + 106, l + 13 + 46 - i1, 216, 46 - i1, 9, i1);
/*    */     
/* 59 */     i1 = this.furnaceInventory.getContentsScaled(48);
/* 60 */     drawTexturedModalRect(k + 61, l + 12 + 48 - i1, 200, 48 - i1, 8, i1);
/*    */ 
/*    */     
/* 63 */     drawTexturedModalRect(k + 60, l + 8, 232, 0, 10, 55);
/* 64 */     GL11.glDisable(3042);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\gui\GuiAlchemyFurnace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */