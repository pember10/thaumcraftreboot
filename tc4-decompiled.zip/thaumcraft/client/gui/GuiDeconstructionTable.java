/*     */ package thaumcraft.client.gui;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.common.container.ContainerDeconstructionTable;
/*     */ import thaumcraft.common.tiles.TileDeconstructionTable;
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class GuiDeconstructionTable
/*     */   extends GuiContainer
/*     */ {
/*     */   private TileDeconstructionTable tableInventory;
/*     */   
/*     */   public GuiDeconstructionTable(InventoryPlayer par1InventoryPlayer, TileDeconstructionTable par2TileEntityFurnace) {
/*  25 */     super((Container)new ContainerDeconstructionTable(par1InventoryPlayer, par2TileEntityFurnace));
/*  26 */     this.tableInventory = par2TileEntityFurnace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawGuiContainerForegroundLayer(int par1, int par2) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3) {
/*  44 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  45 */     UtilsFX.bindTexture("textures/gui/gui_decontable.png");
/*  46 */     int k = (this.width - this.xSize) / 2;
/*  47 */     int l = (this.height - this.ySize) / 2;
/*     */     
/*  49 */     GL11.glEnable(3042);
/*  50 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*     */ 
/*     */     
/*  53 */     if (this.tableInventory.breaktime > 0) {
/*     */       
/*  55 */       int i1 = this.tableInventory.getBreakTimeScaled(46);
/*  56 */       drawTexturedModalRect(k + 93, l + 15 + 46 - i1, 176, 46 - i1, 9, i1);
/*     */     } 
/*     */     
/*  59 */     if (this.tableInventory.aspect != null) {
/*  60 */       UtilsFX.drawTag(k + 64, l + 48, this.tableInventory.aspect, 0.0F, 0, this.zLevel);
/*  61 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  62 */       RenderHelper.disableStandardItemLighting();
/*     */       
/*  64 */       int var7 = par2 - k + 64;
/*  65 */       int var8 = par3 - l + 48;
/*  66 */       if (var7 >= 0 && var8 >= 0 && var7 < 16 && var8 < 16) {
/*     */         
/*  68 */         this; UtilsFX.drawCustomTooltip((GuiScreen)this, itemRender, this.fontRendererObj, Arrays.asList(new String[] { this.tableInventory.aspect.getName(), this.tableInventory.aspect.getLocalizedDescription() }, ), par2, par3 - 8, 11);
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  77 */     GL11.glDisable(3042);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mouseClicked(int mx, int my, int par3) {
/*  84 */     super.mouseClicked(mx, my, par3);
/*     */     
/*  86 */     int gx = (this.width - this.xSize) / 2;
/*  87 */     int gy = (this.height - this.ySize) / 2;
/*     */ 
/*     */     
/*  90 */     int var7 = mx - gx + 64;
/*  91 */     int var8 = my - gy + 48;
/*     */     
/*  93 */     if (var7 >= 0 && var8 >= 0 && var7 < 16 && var8 < 16 && this.tableInventory.aspect != null) {
/*     */ 
/*     */ 
/*     */       
/*  97 */       this.mc.playerController.sendEnchantPacket(this.inventorySlots.windowId, 1);
/*     */       
/*  99 */       playButtonAspect();
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void playButtonAspect() {
/* 107 */     this.mc.renderViewEntity.worldObj.playSound(this.mc.renderViewEntity.posX, this.mc.renderViewEntity.posY, this.mc.renderViewEntity.posZ, "thaumcraft:hhoff", 0.2F, 1.0F + this.mc.renderViewEntity.worldObj.rand.nextFloat() * 0.1F, false);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\gui\GuiDeconstructionTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */