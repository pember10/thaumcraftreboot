/*    */ package thaumcraft.client.gui;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.world.World;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.client.lib.UtilsFX;
/*    */ import thaumcraft.common.container.ContainerFocusPouch;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class GuiFocusPouch
/*    */   extends GuiContainer
/*    */ {
/*    */   private int blockSlot;
/*    */   
/*    */   public GuiFocusPouch(InventoryPlayer par1InventoryPlayer, World world, int x, int y, int z) {
/* 20 */     super((Container)new ContainerFocusPouch(par1InventoryPlayer, world, x, y, z));
/* 21 */     this.blockSlot = par1InventoryPlayer.currentItem;
/* 22 */     this.xSize = 175;
/* 23 */     this.ySize = 232;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void drawGuiContainerForegroundLayer(int par1, int par2) {
/* 30 */     UtilsFX.bindTexture("textures/gui/gui_focuspouch.png");
/* 31 */     float t = this.zLevel;
/* 32 */     this.zLevel = 200.0F;
/* 33 */     GL11.glEnable(3042);
/* 34 */     drawTexturedModalRect(8 + this.blockSlot * 18, 209, 240, 0, 16, 16);
/* 35 */     GL11.glDisable(3042);
/* 36 */     this.zLevel = t;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean checkHotbarKeys(int par1) {
/* 41 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3) {
/* 50 */     if (this.mc.thePlayer.inventory.mainInventory[this.blockSlot] == null) this.mc.thePlayer.closeScreen(); 
/* 51 */     UtilsFX.bindTexture("textures/gui/gui_focuspouch.png");
/* 52 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 53 */     int var5 = (this.width - this.xSize) / 2;
/* 54 */     int var6 = (this.height - this.ySize) / 2;
/* 55 */     GL11.glEnable(3042);
/* 56 */     drawTexturedModalRect(var5, var6, 0, 0, this.xSize, this.ySize);
/* 57 */     GL11.glDisable(3042);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\gui\GuiFocusPouch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */