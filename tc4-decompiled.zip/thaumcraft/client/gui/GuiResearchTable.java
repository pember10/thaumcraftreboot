/*     */ package thaumcraft.client.gui;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import org.lwjgl.input.Mouse;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.research.ResearchCategories;
/*     */ import thaumcraft.api.research.ResearchItem;
/*     */ import thaumcraft.client.fx.ParticleEngine;
/*     */ import thaumcraft.client.lib.PlayerNotifications;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.container.ContainerResearchTable;
/*     */ import thaumcraft.common.lib.network.PacketHandler;
/*     */ import thaumcraft.common.lib.network.playerdata.PacketAspectCombinationToServer;
/*     */ import thaumcraft.common.lib.network.playerdata.PacketAspectPlaceToServer;
/*     */ import thaumcraft.common.lib.research.ResearchManager;
/*     */ import thaumcraft.common.lib.research.ResearchNoteData;
/*     */ import thaumcraft.common.lib.utils.HexUtils;
/*     */ import thaumcraft.common.tiles.TileResearchTable;
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class GuiResearchTable
/*     */   extends GuiContainer
/*     */ {
/*     */   private static boolean RESEARCHER_1;
/*     */   private static boolean RESEARCHER_2;
/*     */   private static boolean RESEARCHDUPE;
/*  49 */   private final int HEX_SIZE = 9;
/*     */ 
/*     */ 
/*     */   
/*     */   private float xSize_lo;
/*     */ 
/*     */ 
/*     */   
/*     */   private float ySize_lo;
/*     */ 
/*     */ 
/*     */   
/*  61 */   private long butcount1 = 0L;
/*  62 */   private long butcount2 = 0L;
/*  63 */   private int page = 0;
/*  64 */   private int lastPage = 0;
/*     */   
/*  66 */   private int isMouseButtonDown = 0;
/*     */   
/*     */   private TileResearchTable tileEntity;
/*     */   
/*     */   private FontRenderer galFontRenderer;
/*     */   
/*     */   private String username;
/*     */   
/*     */   EntityPlayer player;
/*  75 */   public Aspect select1 = null;
/*  76 */   public Aspect select2 = null;
/*  77 */   private AspectList aspectlist = new AspectList();
/*     */   
/*  79 */   private HashMap<String, Rune> runes = new HashMap<String, Rune>(); private float popupScale; private Aspect draggedAspect; public ResearchNoteData note; long lastRuneCheck; private HashMap<String, HexUtils.Hex[]> lines; private ArrayList<String> checked;
/*     */   private ArrayList<String> highlight;
/*     */   
/*     */   private class Rune { int q;
/*     */     int r;
/*     */     long start;
/*     */     long decay;
/*     */     int rune;
/*     */     
/*  88 */     public Rune(int q, int r, long start, long decay, int rune) { this.q = q;
/*  89 */       this.r = r;
/*  90 */       this.start = start;
/*  91 */       this.decay = decay;
/*  92 */       this.rune = rune; } }
/*     */    protected void drawGuiContainerForegroundLayer(int mx, int my) { Minecraft mc = Minecraft.getMinecraft();
/*     */     long time = System.nanoTime() / 1000000L;
/*     */     if (PlayerNotifications.getListAndUpdate(time).size() > 0) {
/*     */       GL11.glPushMatrix();
/*     */       Thaumcraft.instance.renderEventHandler.notifyHandler.renderNotifyHUD(this.width, this.height, time);
/*     */       GL11.glPopMatrix();
/*  99 */     }  } public GuiResearchTable(EntityPlayer player, TileResearchTable e) { super((Container)new ContainerResearchTable(player.inventory, e));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     this.popupScale = 0.05F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 558 */     this.note = null;
/*     */     
/* 560 */     this.lastRuneCheck = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 680 */     this.lines = (HashMap)new HashMap<String, HexUtils.Hex>();
/* 681 */     this.checked = new ArrayList<String>();
/* 682 */     this.highlight = new ArrayList<String>(); this.tileEntity = e; this.xSize = 255; this.ySize = 255; this.galFontRenderer = (FMLClientHandler.instance().getClient()).standardGalacticFontRenderer; this.username = player.getCommandSenderName(); this.player = player; RESEARCHER_1 = ResearchManager.isResearchComplete(player.getCommandSenderName(), "RESEARCHER1"); RESEARCHER_2 = ResearchManager.isResearchComplete(player.getCommandSenderName(), "RESEARCHER2"); RESEARCHDUPE = ResearchManager.isResearchComplete(player.getCommandSenderName(), "RESEARCHDUPE"); int count = 0; for (Aspect aspect : Aspect.aspects.values()) { this.aspectlist.add(aspect, count); count++; }  }
/*     */   public void drawScreen(int mx, int my, float par3) { super.drawScreen(mx, my, par3); this.xSize_lo = mx; this.ySize_lo = my; int var5 = this.guiLeft; int var6 = this.guiTop; int gx = (this.width - this.xSize) / 2; int gy = (this.height - this.ySize) / 2; if (this.note != null && RESEARCHDUPE && this.note.isComplete()) { int var7 = mx - gx + 37; int var8 = my - gy + 5; if (var7 >= 0 && var8 >= 0 && var7 < 24 && var8 < 24) { RenderHelper.enableGUIStandardItemLighting(); GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F); ResearchItem rr = ResearchCategories.getResearch(this.note.key); String ss = StatCollector.translateToLocal("tc.research.copy"); GL11.glEnable(3042); UtilsFX.bindTexture("textures/gui/guiresearchtable2.png"); drawTexturedModalRect(gx + 100, gy + 21, 184, 224, 48, 16); AspectList al = rr.tags.copy(); for (Aspect aspect : al.getAspects()) al.add(aspect, this.note.copies);  int count = 0; for (Aspect aspect : al.getAspectsSorted()) { UtilsFX.drawTag(gx + 100 + 48 + count * 16, gy + 21, aspect, al.getAmount(aspect), 0, this.zLevel); count++; }  GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F); this.fontRendererObj.drawStringWithShadow(ss, gx + 100, gy + 12, -1); }  }  RenderHelper.disableStandardItemLighting(); GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F); if (Mouse.isButtonDown(0)) { int sx = gx + 10; int sy = gy + 40; if (this.isMouseButtonDown == 0 && mx >= sx && mx < sx + 80 && my >= sy && my < sy + 80) { Aspect aspect = getClickedAspect(mx, my, gx, gy, false); if (aspect != null) { playButtonAspect(); this.isMouseButtonDown = 1; this.draggedAspect = aspect; }  } else if (this.isMouseButtonDown == 1 && this.draggedAspect != null) { GL11.glEnable(3042); drawOrb((mx - 8), (my - 8), this.draggedAspect.getColor()); GL11.glDisable(3042); }  } else { if (this.isMouseButtonDown == 1 && this.draggedAspect != null) { if (this.note != null) { int mouseX = mx - gx + 169; int mouseY = my - gy + 83; HexUtils.Hex hp = (new HexUtils.Pixel(mouseX, mouseY)).toHex(9); if (this.note.hexEntries.containsKey(hp.toString()) && ((ResearchManager.HexEntry)this.note.hexEntries.get(hp.toString())).type == 0) { playButtonCombine(); playButtonWrite(); PacketHandler.INSTANCE.sendToServer((IMessage)new PacketAspectPlaceToServer(this.player, (byte)hp.q, (byte)hp.r, this.tileEntity.xCoord, this.tileEntity.yCoord, this.tileEntity.zCoord, this.draggedAspect)); this.draggedAspect = null; }  }  if (this.draggedAspect != null) { boolean skip = false; int mouseX = mx - gx + 20; int mouseY = my - gy + 146; if (mouseX >= -16 && mouseY >= -16 && mouseX < 16 && mouseY < 16) { playButtonAspect(); this.select1 = this.draggedAspect; skip = true; }  mouseX = mx - gx + 79; mouseY = my - gy + 146; if (!skip && mouseX >= -16 && mouseY >= -16 && mouseX < 16 && mouseY < 16) { playButtonAspect(); this.select2 = this.draggedAspect; skip = true; }  if (!skip) { Aspect aspect = getClickedAspect(mx, my, gx, gy, false); if (aspect == this.draggedAspect) if (this.select1 == null) { this.select1 = this.draggedAspect; } else if (this.select2 == null) { this.select2 = this.draggedAspect; }   }  }  }  this.isMouseButtonDown = 0; this.draggedAspect = null; }  drawAspectText(var5 + 10, var6 + 40, mx, my); if (this.note != null && (this.tileEntity.getStackInSlot(0) == null || this.tileEntity.getStackInSlot(0).getItemDamage() == this.tileEntity.getStackInSlot(0).getMaxDamage())) { int sx = Math.max(this.fontRendererObj.getStringWidth(StatCollector.translateToLocal("tile.researchtable.noink.0")), this.fontRendererObj.getStringWidth(StatCollector.translateToLocal("tile.researchtable.noink.1"))) / 2; this; UtilsFX.drawCustomTooltip((GuiScreen)this, itemRender, this.fontRendererObj, Arrays.asList(new String[] { StatCollector.translateToLocal("tile.researchtable.noink.0"), StatCollector.translateToLocal("tile.researchtable.noink.1") }, ), gx + 157 - sx, gy + 84, 11); }  }
/*     */   protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3) { int var5 = this.guiLeft; int var6 = this.guiTop; GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F); GL11.glEnable(3042); UtilsFX.bindTexture("textures/gui/guiresearchtable2.png"); drawTexturedModalRect(var5, var6, 0, 0, 255, 167); drawTexturedModalRect(var5 + 40, var6 + 167, 0, 166, 184, 88); if (this.page < this.lastPage) drawTexturedModalRect(var5 + 51, var6 + 121, 208, 208, 24, 8);  if (this.page > 0) drawTexturedModalRect(var5 + 27, var6 + 121, 184, 208, 24, 8);  if (this.butcount2 < System.nanoTime() && this.select1 != null && this.select2 != null) { drawTexturedModalRect(var5 + 35, var6 + 139, 184, 184, 32, 16); drawOrb((var5 + 43), (var6 + 139)); } else if (this.butcount2 >= System.nanoTime() && this.select1 != null && this.select2 != null) { drawTexturedModalRect(var5 + 35, var6 + 139, 184, 184, 32, 16); drawTexturedModalRect(var5 + 35, var6 + 139, 184, 168, 32, 16); }  if (RESEARCHDUPE && this.note != null && this.note.isComplete()) drawTexturedModalRect(var5 + 37, var6 + 5, 232, 200, 24, 24);  drawAspects(var5 + 10, var6 + 40); GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F); RenderHelper.disableStandardItemLighting(); drawResearchData(var5, var6, par2, par3); }
/* 685 */   private void drawAspects(int x, int y) { AspectList aspects = Thaumcraft.proxy.getPlayerKnowledge().getAspectsDiscovered(this.username); if (aspects != null) { int count = aspects.size(); this.lastPage = (count - 20) / 5; count = 0; int drawn = 0; for (Aspect aspect : aspects.getAspectsSorted()) { count++; if (count - 1 >= this.page * 5 && drawn < 25) { boolean faded = (aspects.getAmount(aspect) <= 0 && this.tileEntity.bonusAspects.getAmount(aspect) <= 0); int xx = drawn / 5 * 16; int yy = drawn % 5 * 16; UtilsFX.drawTag(x + xx, y + yy, aspect, aspects.getAmount(aspect), this.tileEntity.bonusAspects.getAmount(aspect), this.zLevel, 771, faded ? 0.33F : 1.0F); drawn++; }  }  }  if (this.select1 != null && Thaumcraft.proxy.playerKnowledge.getAspectPoolFor(this.player.getCommandSenderName(), this.select1) <= 0 && this.tileEntity.bonusAspects.getAmount(this.select1) <= 0) this.select1 = null;  if (this.select2 != null && Thaumcraft.proxy.playerKnowledge.getAspectPoolFor(this.player.getCommandSenderName(), this.select2) <= 0 && this.tileEntity.bonusAspects.getAmount(this.select2) <= 0) this.select2 = null;  if (this.select1 != null) UtilsFX.drawTag(x + 3, y + 99, this.select1, 0.0F, 0, this.zLevel);  if (this.select2 != null) UtilsFX.drawTag(x + 61, y + 99, this.select2, 0.0F, 0, this.zLevel);  } private void drawAspectText(int x, int y, int mx, int my) { int var7 = 0; int var8 = 0; AspectList aspects = Thaumcraft.proxy.getPlayerKnowledge().getAspectsDiscovered(this.username); if (aspects != null) { int count = 0; int drawn = 0; for (Aspect aspect : aspects.getAspectsSorted()) { count++; if (count - 1 >= this.page * 5 && drawn < 25) { int xx = drawn / 5 * 16; int yy = drawn % 5 * 16; var7 = mx - x + xx; var8 = my - y + yy; if (var7 >= 0 && var8 >= 0 && var7 < 16 && var8 < 16) { this; UtilsFX.drawCustomTooltip((GuiScreen)this, itemRender, this.fontRendererObj, Arrays.asList(new String[] { aspect.getName(), aspect.getLocalizedDescription() }, ), mx, my - 8, 11); if (RESEARCHER_1 && !aspect.isPrimal()) { GL11.glPushMatrix(); GL11.glEnable(3042); GL11.glBlendFunc(770, 771); UtilsFX.bindTexture("textures/aspects/_back.png"); GL11.glPushMatrix(); GL11.glTranslated((mx + 6), (my + 6), 0.0D); GL11.glScaled(1.25D, 1.25D, 0.0D); UtilsFX.drawTexturedQuadFull(0, 0, 0.0D); GL11.glPopMatrix(); GL11.glPushMatrix(); GL11.glTranslated((mx + 24), (my + 6), 0.0D); GL11.glScaled(1.25D, 1.25D, 0.0D); UtilsFX.drawTexturedQuadFull(0, 0, 0.0D); GL11.glPopMatrix(); UtilsFX.drawTag(mx + 26, my + 8, aspect.getComponents()[1], 0.0F, 0, 0.0D); UtilsFX.drawTag(mx + 8, my + 8, aspect.getComponents()[0], 0.0F, 0, 0.0D); GL11.glDisable(3042); GL11.glPopMatrix(); }  return; }  drawn++; }  }  }  if (this.select1 != null) { var7 = mx - x + 3; var8 = my - y + 99; if (var7 >= 0 && var8 >= 0 && var7 < 16 && var8 < 16) { this; UtilsFX.drawCustomTooltip((GuiScreen)this, itemRender, this.fontRendererObj, Arrays.asList(new String[] { this.select1.getName(), this.select1.getLocalizedDescription() }, ), mx, my - 8, 11); return; }  }  if (this.select2 != null) { var7 = mx - x + 61; var8 = my - y + 99; if (var7 >= 0 && var8 >= 0 && var7 < 16 && var8 < 16) { this; UtilsFX.drawCustomTooltip((GuiScreen)this, itemRender, this.fontRendererObj, Arrays.asList(new String[] { this.select2.getName(), this.select2.getLocalizedDescription() }, ), mx, my - 8, 11); return; }  }  } private void checkConnections(HexUtils.Hex hex) { this.checked.add(hex.toString());
/* 686 */     for (int a = 0; a < 6; a++) {
/* 687 */       HexUtils.Hex target = hex.getNeighbour(a);
/* 688 */       if (!this.checked.contains(target.toString()) && 
/* 689 */         this.note.hexEntries.containsKey(target.toString()) && ((ResearchManager.HexEntry)this.note.hexEntries.get(target.toString())).type >= 1) {
/*     */         
/* 691 */         Aspect aspect1 = ((ResearchManager.HexEntry)this.note.hexEntries.get(hex.toString())).aspect;
/* 692 */         Aspect aspect2 = ((ResearchManager.HexEntry)this.note.hexEntries.get(target.toString())).aspect;
/*     */         
/* 694 */         if (Thaumcraft.proxy.getPlayerKnowledge().hasDiscoveredAspect(this.username, aspect1) && Thaumcraft.proxy.getPlayerKnowledge().hasDiscoveredAspect(this.username, aspect2) && ((!aspect1.isPrimal() && (aspect1.getComponents()[0] == aspect2 || aspect1.getComponents()[1] == aspect2)) || (!aspect2.isPrimal() && (aspect2.getComponents()[0] == aspect1 || aspect2.getComponents()[1] == aspect1)))) {
/*     */ 
/*     */ 
/*     */           
/* 698 */           String k1 = hex.toString() + ":" + target.toString();
/* 699 */           String k2 = target.toString() + ":" + hex.toString();
/* 700 */           if (!this.lines.containsKey(k1) && !this.lines.containsKey(k2)) {
/* 701 */             this.lines.put(k1, new HexUtils.Hex[] { hex, target });
/* 702 */             this.highlight.add(target.toString());
/*     */           } 
/* 704 */           checkConnections(target);
/*     */         } 
/*     */       } 
/*     */     }  } class Coord2D {
/*     */     int x; int y; Coord2D(int x, int y) { this.x = x; this.y = y; } }
/*     */   private void drawResearchData(int x, int y, int mx, int my) { GL11.glPushMatrix(); GL11.glEnable(3042); drawSheet(x, y, mx, my); GL11.glPopMatrix(); }
/*     */   private void drawHex(HexUtils.Hex hex, int x, int y) { GL11.glPushMatrix(); GL11.glAlphaFunc(516, 0.003921569F); GL11.glEnable(3042); UtilsFX.bindTexture("textures/gui/hex1.png"); GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.25F); HexUtils.Pixel pix = hex.toPixel(9); GL11.glTranslated(x + pix.x, y + pix.y, 0.0D); Tessellator tessellator = Tessellator.instance; tessellator.startDrawingQuads(); tessellator.setBrightness(240); tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 0.25F); tessellator.addVertexWithUV(-8.0D, 8.0D, this.zLevel, 0.0D, 1.0D); tessellator.addVertexWithUV(8.0D, 8.0D, this.zLevel, 1.0D, 1.0D); tessellator.addVertexWithUV(8.0D, -8.0D, this.zLevel, 1.0D, 0.0D); tessellator.addVertexWithUV(-8.0D, -8.0D, this.zLevel, 0.0D, 0.0D); tessellator.draw(); GL11.glAlphaFunc(516, 0.1F);
/*     */     GL11.glPopMatrix(); }
/* 712 */   private void drawRune(double x, double y, int rune, float alpha) { GL11.glPushMatrix();
/* 713 */     UtilsFX.bindTexture("textures/misc/script.png");
/* 714 */     GL11.glColor4f(0.0F, 0.0F, 0.0F, alpha);
/*     */     
/* 716 */     GL11.glTranslated(x, y, 0.0D);
/* 717 */     if (rune < 16) {
/* 718 */       GL11.glRotatef(90.0F, 0.0F, 0.0F, -1.0F);
/*     */     }
/*     */     
/* 721 */     Tessellator tessellator = Tessellator.instance;
/* 722 */     float var8 = 0.0625F * rune;
/* 723 */     float var9 = var8 + 0.0625F;
/* 724 */     float var10 = 0.0F;
/* 725 */     float var11 = 1.0F;
/* 726 */     tessellator.startDrawingQuads();
/* 727 */     tessellator.setColorRGBA_F(0.0F, 0.0F, 0.0F, alpha);
/* 728 */     tessellator.addVertexWithUV(-5.0D, 5.0D, this.zLevel, var9, var11);
/* 729 */     tessellator.addVertexWithUV(5.0D, 5.0D, this.zLevel, var9, var10);
/* 730 */     tessellator.addVertexWithUV(5.0D, -5.0D, this.zLevel, var8, var10);
/* 731 */     tessellator.addVertexWithUV(-5.0D, -5.0D, this.zLevel, var8, var11);
/* 732 */     tessellator.draw();
/* 733 */     GL11.glPopMatrix(); } private void drawHexHighlight(HexUtils.Hex hex, int x, int y) { GL11.glPushMatrix(); GL11.glAlphaFunc(516, 0.003921569F); GL11.glEnable(3042); GL11.glBlendFunc(770, 1); UtilsFX.bindTexture("textures/gui/hex2.png"); GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F); HexUtils.Pixel pix = hex.toPixel(9); GL11.glTranslated(x + pix.x, y + pix.y, 0.0D); Tessellator tessellator = Tessellator.instance; tessellator.startDrawingQuads(); tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 1.0F); tessellator.addVertexWithUV(-8.0D, 8.0D, this.zLevel, 0.0D, 1.0D); tessellator.addVertexWithUV(8.0D, 8.0D, this.zLevel, 1.0D, 1.0D); tessellator.addVertexWithUV(8.0D, -8.0D, this.zLevel, 1.0D, 0.0D); tessellator.addVertexWithUV(-8.0D, -8.0D, this.zLevel, 0.0D, 0.0D); tessellator.draw(); GL11.glBlendFunc(770, 771); GL11.glAlphaFunc(516, 0.1F); GL11.glPopMatrix(); }
/*     */   private void drawLine(double x, double y, double x2, double y2) { int count = (FMLClientHandler.instance().getClient()).thePlayer.ticksExisted; float alpha = 0.3F + MathHelper.sin((float)(count + x)) * 0.3F + 0.3F; Tessellator var12 = Tessellator.instance; GL11.glPushMatrix(); GL11.glLineWidth(3.0F); GL11.glDisable(3553); GL11.glBlendFunc(770, 1); var12.startDrawing(3); var12.setColorRGBA_F(0.0F, 0.6F, 0.8F, alpha); var12.addVertex(x, y, 0.0D); var12.addVertex(x2, y2, 0.0D); var12.draw(); GL11.glBlendFunc(770, 771); GL11.glDisable(32826); GL11.glEnable(3553); GL11.glPopMatrix(); }
/*     */   private void drawSheet(int x, int y, int mx, int my) { this.note = ResearchManager.getData(this.tileEntity.getStackInSlot(1)); if (this.note == null || this.note.key == null || this.note.key.length() == 0) { this.runes.clear(); return; }  UtilsFX.bindTexture("textures/misc/parchment3.png"); drawTexturedModalRect(x + 94, y + 8, 0, 0, 150, 150); long time = System.currentTimeMillis(); if (this.lastRuneCheck < time) { this.lastRuneCheck = time + 250L; int k = this.mc.theWorld.rand.nextInt(120) - 60; int l = this.mc.theWorld.rand.nextInt(120) - 60; HexUtils.Hex hex = (new HexUtils.Pixel(k, l)).toHex(9); if (!this.runes.containsKey(hex.toString()) && !this.note.hexes.containsKey(hex.toString()))
/*     */         this.runes.put(hex.toString(), new Rune(hex.q, hex.r, time, this.lastRuneCheck + 15000L + this.mc.theWorld.rand.nextInt(10000), this.mc.theWorld.rand.nextInt(16)));  }  if (this.runes.size() > 0) { Rune[] rns = (Rune[])this.runes.values().toArray((Object[])new Rune[0]); for (int a = 0; a < rns.length; a++) { Rune rune = rns[a]; if (rune.decay < time) { this.runes.remove(rune.q + ":" + rune.r); } else { HexUtils.Pixel pix = (new HexUtils.Hex(rune.q, rune.r)).toPixel(9); float progress = (float)(time - rune.start) / (float)(rune.decay - rune.start); float alpha = 0.5F; if (progress < 0.25F) { alpha = progress * 2.0F; } else if (progress > 0.5F) { alpha = 1.0F - progress; }  drawRune((x + 169) + pix.x, (y + 83) + pix.y, rune.rune, alpha * 0.66F); }  }  }  int mouseX = mx - x + 169; int mouseY = my - y + 83; HexUtils.Hex hp = (new HexUtils.Pixel(mouseX, mouseY)).toHex(9); this.lines.clear(); this.checked.clear(); this.highlight.clear(); for (HexUtils.Hex hex : this.note.hexes.values()) { if (((ResearchManager.HexEntry)this.note.hexEntries.get(hex.toString())).type == 1 && Thaumcraft.proxy.getPlayerKnowledge().hasDiscoveredAspect(this.username, ((ResearchManager.HexEntry)this.note.hexEntries.get(hex.toString())).aspect))
/*     */         checkConnections(hex);  }  for (HexUtils.Hex[] con : this.lines.values()) { HexUtils.Pixel p1 = con[0].toPixel(9); HexUtils.Pixel p2 = con[1].toPixel(9); drawLine((x + 169) + p1.x, (y + 83) + p1.y, (x + 169) + p2.x, (y + 83) + p2.y); }  UtilsFX.bindTexture("textures/gui/hex1.png"); GL11.glPushMatrix(); if (!this.note.isComplete())
/*     */       for (HexUtils.Hex hex : this.note.hexes.values()) { if (((ResearchManager.HexEntry)this.note.hexEntries.get(hex.toString())).type != 1) { if (!this.note.isComplete()) { if (hex.equals(hp))
/*     */               drawHexHighlight(hex, x + 169, y + 83);  drawHex(hex, x + 169, y + 83); }  continue; }  drawOrb((x + 161) + (hex.toPixel(9)).x, (y + 75) + (hex.toPixel(9)).y); }   for (HexUtils.Hex hex : this.note.hexes.values()) { if (((ResearchManager.HexEntry)this.note.hexEntries.get(hex.toString())).aspect != null && !Thaumcraft.proxy.getPlayerKnowledge().hasDiscoveredAspect(this.username, ((ResearchManager.HexEntry)this.note.hexEntries.get(hex.toString())).aspect)) { HexUtils.Pixel pix = hex.toPixel(9); UtilsFX.bindTexture("textures/aspects/_unknown.png"); GL11.glPushMatrix(); GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.5F); GL11.glEnable(3042); GL11.glBlendFunc(770, 771); GL11.glTranslated((x + 161) + pix.x, (y + 75) + pix.y, 0.0D); UtilsFX.drawTexturedQuadFull(0, 0, this.zLevel); GL11.glDisable(3042); GL11.glPopMatrix(); continue; }  if (((ResearchManager.HexEntry)this.note.hexEntries.get(hex.toString())).type == 1 || this.highlight.contains(hex.toString())) { HexUtils.Pixel pix = hex.toPixel(9); UtilsFX.drawTag((x + 161) + pix.x, (y + 75) + pix.y, ((ResearchManager.HexEntry)this.note.hexEntries.get(hex.toString())).aspect, 0.0F, 0, this.zLevel, 771, 1.0F, false); continue; }  if (((ResearchManager.HexEntry)this.note.hexEntries.get(hex.toString())).type == 2) { HexUtils.Pixel pix = hex.toPixel(9); UtilsFX.drawTag((x + 161) + pix.x, (y + 75) + pix.y, ((ResearchManager.HexEntry)this.note.hexEntries.get(hex.toString())).aspect, 0.0F, 0, this.zLevel, 771, 0.66F, true); }  }
/*     */      GL11.glPopMatrix(); }
/* 741 */   protected void mouseClicked(int mx, int my, int par3) { super.mouseClicked(mx, my, par3);
/* 742 */     if (this.butcount1 > System.nanoTime() || this.butcount2 > System.nanoTime())
/*     */       return; 
/* 744 */     int gx = (this.width - this.xSize) / 2;
/* 745 */     int gy = (this.height - this.ySize) / 2;
/*     */ 
/*     */     
/* 748 */     int var7 = mx - gx + 35;
/* 749 */     int var8 = my - gy + 139;
/*     */     
/* 751 */     if (var7 >= 0 && var8 >= 0 && var7 < 32 && var8 < 16 && this.butcount2 < System.nanoTime() && this.select1 != null && this.select2 != null) {
/*     */ 
/*     */ 
/*     */       
/* 755 */       this.butcount2 = System.nanoTime() + 200000000L;
/* 756 */       playButtonClick();
/* 757 */       playButtonCombine();
/* 758 */       PacketHandler.INSTANCE.sendToServer((IMessage)new PacketAspectCombinationToServer(this.player, this.tileEntity.xCoord, this.tileEntity.yCoord, this.tileEntity.zCoord, this.select1, this.select2, (this.tileEntity.bonusAspects.getAmount(this.select1) > 0), (this.tileEntity.bonusAspects.getAmount(this.select2) > 0), true));
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 766 */     var7 = mx - gx + 27;
/* 767 */     var8 = my - gy + 121;
/* 768 */     if (this.page > 0 && var7 >= 0 && var8 >= 0 && var7 < 24 && var8 < 8) {
/*     */       
/* 770 */       this.page--;
/* 771 */       playButtonScroll();
/*     */       
/*     */       return;
/*     */     } 
/* 775 */     var7 = mx - gx + 51;
/* 776 */     var8 = my - gy + 121;
/* 777 */     if (this.page < this.lastPage && var7 >= 0 && var8 >= 0 && var7 < 24 && var8 < 8) {
/*     */       
/* 779 */       this.page++;
/* 780 */       playButtonScroll();
/*     */       
/*     */       return;
/*     */     } 
/* 784 */     if (this.select1 != null) {
/* 785 */       var7 = mx - gx + 11;
/* 786 */       var8 = my - gy + 137;
/* 787 */       if (var7 >= 0 && var8 >= 0 && var7 < 16 && var8 < 16) {
/*     */         
/* 789 */         this.select1 = null;
/* 790 */         playButtonAspect();
/*     */         return;
/*     */       } 
/*     */     } 
/* 794 */     if (this.select2 != null) {
/* 795 */       var7 = mx - gx + 71;
/* 796 */       var8 = my - gy + 137;
/* 797 */       if (var7 >= 0 && var8 >= 0 && var7 < 16 && var8 < 16) {
/*     */         
/* 799 */         this.select2 = null;
/* 800 */         playButtonAspect();
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 805 */     if (this.note != null) {
/* 806 */       checkClickedHex(mx, my, gx, gy);
/*     */       
/* 808 */       if (RESEARCHDUPE && this.note.isComplete()) {
/* 809 */         var7 = mx - gx + 37;
/* 810 */         var8 = my - gy + 5;
/* 811 */         if (var7 >= 0 && var8 >= 0 && var7 < 24 && var8 < 24) {
/*     */           
/* 813 */           this.mc.playerController.sendEnchantPacket(this.inventorySlots.windowId, 5);
/* 814 */           playButtonClick();
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/* 820 */     this; if (isShiftKeyDown() && RESEARCHER_2) {
/*     */ 
/*     */       
/* 823 */       Aspect aspect = getClickedAspect(mx, my, gx, gy, true);
/* 824 */       if (aspect != null && !aspect.isPrimal()) {
/* 825 */         AspectList aspects = Thaumcraft.proxy.getPlayerKnowledge().getAspectsDiscovered(this.username);
/* 826 */         if (aspects != null && (aspects.getAmount(aspect.getComponents()[0]) > 0 || this.tileEntity.bonusAspects.getAmount(aspect.getComponents()[0]) > 0) && (aspects.getAmount(aspect.getComponents()[1]) > 0 || this.tileEntity.bonusAspects.getAmount(aspect.getComponents()[1]) > 0)) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 831 */           this.draggedAspect = null;
/* 832 */           playButtonCombine();
/* 833 */           PacketHandler.INSTANCE.sendToServer((IMessage)new PacketAspectCombinationToServer(this.player, this.tileEntity.xCoord, this.tileEntity.yCoord, this.tileEntity.zCoord, aspect.getComponents()[0], aspect.getComponents()[1], (this.tileEntity.bonusAspects.getAmount(aspect.getComponents()[0]) > 0), (this.tileEntity.bonusAspects.getAmount(aspect.getComponents()[1]) > 0), true));
/*     */         } 
/*     */       } 
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkClickedHex(int mx, int my, int gx, int gy) {
/* 845 */     int mouseX = mx - gx + 169;
/* 846 */     int mouseY = my - gy + 83;
/* 847 */     HexUtils.Hex hp = (new HexUtils.Pixel(mouseX, mouseY)).toHex(9);
/*     */     
/* 849 */     if (this.note.hexes.containsKey(hp.toString()) && ((ResearchManager.HexEntry)this.note.hexEntries.get(hp.toString())).type == 2) {
/* 850 */       playButtonCombine();
/* 851 */       playButtonErase();
/* 852 */       PacketHandler.INSTANCE.sendToServer((IMessage)new PacketAspectPlaceToServer(this.player, (byte)hp.q, (byte)hp.r, this.tileEntity.xCoord, this.tileEntity.yCoord, this.tileEntity.zCoord, null));
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Aspect getClickedAspect(int mx, int my, int gx, int gy, boolean ignoreZero) {
/* 859 */     AspectList aspects = Thaumcraft.proxy.getPlayerKnowledge().getAspectsDiscovered(this.username);
/* 860 */     if (aspects != null) {
/* 861 */       int count = 0;
/* 862 */       int drawn = 0;
/* 863 */       for (Aspect aspect : aspects.getAspectsSorted()) {
/* 864 */         count++;
/* 865 */         if (count - 1 >= this.page * 5 && 
/* 866 */           drawn < 25) {
/* 867 */           int xx = drawn / 5 * 16;
/* 868 */           int yy = drawn % 5 * 16;
/* 869 */           int var7 = mx - gx + xx + 10;
/* 870 */           int var8 = my - gy + yy + 40;
/* 871 */           if ((ignoreZero || aspects.getAmount(aspect) > 0 || this.tileEntity.bonusAspects.getAmount(aspect) > 0) && 
/* 872 */             var7 >= 0 && var8 >= 0 && var7 < 16 && var8 < 16)
/*     */           {
/* 874 */             return aspect;
/*     */           }
/*     */           
/* 877 */           drawn++;
/*     */         } 
/*     */       } 
/*     */     } 
/* 881 */     return null;
/*     */   }
/*     */   
/*     */   private void playButtonClick() {
/* 885 */     this.mc.renderViewEntity.worldObj.playSound(this.mc.renderViewEntity.posX, this.mc.renderViewEntity.posY, this.mc.renderViewEntity.posZ, "thaumcraft:cameraclack", 0.4F, 1.0F, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void playButtonAspect() {
/* 891 */     this.mc.renderViewEntity.worldObj.playSound(this.mc.renderViewEntity.posX, this.mc.renderViewEntity.posY, this.mc.renderViewEntity.posZ, "thaumcraft:hhoff", 0.2F, 1.0F + this.mc.renderViewEntity.worldObj.rand.nextFloat() * 0.1F, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void playButtonCombine() {
/* 897 */     this.mc.renderViewEntity.worldObj.playSound(this.mc.renderViewEntity.posX, this.mc.renderViewEntity.posY, this.mc.renderViewEntity.posZ, "thaumcraft:hhon", 0.3F, 1.0F, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void playButtonWrite() {
/* 903 */     this.mc.renderViewEntity.worldObj.playSound(this.mc.renderViewEntity.posX, this.mc.renderViewEntity.posY, this.mc.renderViewEntity.posZ, "thaumcraft:write", 0.2F, 1.0F, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void playButtonErase() {
/* 909 */     this.mc.renderViewEntity.worldObj.playSound(this.mc.renderViewEntity.posX, this.mc.renderViewEntity.posY, this.mc.renderViewEntity.posZ, "thaumcraft:erase", 0.2F, 1.0F + this.mc.renderViewEntity.worldObj.rand.nextFloat() * 0.1F, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void playButtonScroll() {
/* 915 */     this.mc.renderViewEntity.worldObj.playSound(this.mc.renderViewEntity.posX, this.mc.renderViewEntity.posY, this.mc.renderViewEntity.posZ, "thaumcraft:key", 0.3F, 1.0F, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawOrb(double x, double y) {
/* 921 */     int count = (FMLClientHandler.instance().getClient()).thePlayer.ticksExisted;
/* 922 */     float red = 0.7F + MathHelper.sin((float)((count + x) / 10.0D)) * 0.15F + 0.15F;
/* 923 */     float green = 0.7F + MathHelper.sin((float)((count + x + y) / 11.0D)) * 0.15F + 0.15F;
/* 924 */     float blue = 0.7F + MathHelper.sin((float)((count + y) / 12.0D)) * 0.15F + 0.15F;
/* 925 */     Color c = new Color(red, green, blue);
/* 926 */     drawOrb(x, y, c.getRGB());
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawOrb(double x, double y, int color) {
/* 931 */     int count = (FMLClientHandler.instance().getClient()).thePlayer.ticksExisted;
/* 932 */     Color c = new Color(color);
/* 933 */     float red = c.getRed() / 255.0F;
/* 934 */     float green = c.getGreen() / 255.0F;
/* 935 */     float blue = c.getBlue() / 255.0F;
/* 936 */     if (Config.colorBlind) {
/* 937 */       red /= 1.8F;
/* 938 */       green /= 1.8F;
/* 939 */       blue /= 1.8F;
/*     */     } 
/* 941 */     GL11.glPushMatrix();
/* 942 */     UtilsFX.bindTexture(ParticleEngine.particleTexture);
/* 943 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 944 */     GL11.glTranslated(x, y, 0.0D);
/* 945 */     Tessellator tessellator = Tessellator.instance;
/* 946 */     int part = count % 8;
/* 947 */     float var8 = 0.5F + part / 8.0F;
/* 948 */     float var9 = var8 + 0.0624375F;
/* 949 */     float var10 = 0.5F;
/* 950 */     float var11 = var10 + 0.0624375F;
/* 951 */     tessellator.startDrawingQuads();
/* 952 */     tessellator.setBrightness(240);
/* 953 */     tessellator.setColorRGBA_F(red, green, blue, 1.0F);
/* 954 */     tessellator.addVertexWithUV(0.0D, 16.0D, this.zLevel, var9, var11);
/* 955 */     tessellator.addVertexWithUV(16.0D, 16.0D, this.zLevel, var9, var10);
/* 956 */     tessellator.addVertexWithUV(16.0D, 0.0D, this.zLevel, var8, var10);
/* 957 */     tessellator.addVertexWithUV(0.0D, 0.0D, this.zLevel, var8, var11);
/* 958 */     tessellator.draw();
/* 959 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\gui\GuiResearchTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */