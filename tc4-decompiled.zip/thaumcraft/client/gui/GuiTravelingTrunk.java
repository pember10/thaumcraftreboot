/*    */ package thaumcraft.client.gui;
/*    */ 
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.util.ChatComponentTranslation;
/*    */ import net.minecraft.util.IChatComponent;
/*    */ import net.minecraft.util.StatCollector;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import thaumcraft.client.lib.UtilsFX;
/*    */ import thaumcraft.common.entities.golems.ContainerTravelingTrunk;
/*    */ import thaumcraft.common.entities.golems.EntityTravelingTrunk;
/*    */ 
/*    */ public class GuiTravelingTrunk
/*    */   extends GuiContainer {
/*    */   private EntityPlayer theplayer;
/*    */   private EntityTravelingTrunk themob;
/*    */   private int inventoryRows;
/*    */   
/*    */   public GuiTravelingTrunk(EntityPlayer p, EntityTravelingTrunk m) {
/* 22 */     super((Container)new ContainerTravelingTrunk((IInventory)p.inventory, p.worldObj, m));
/* 23 */     this.theplayer = p;
/* 24 */     this.themob = m;
/* 25 */     this.inventoryRows = m.inventory.slotCount / 9;
/* 26 */     this.ySize = 200;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void drawGuiContainerForegroundLayer(int par1, int par2) {
/* 31 */     GL11.glPushMatrix();
/* 32 */     GL11.glScaled(0.5D, 0.5D, 0.5D);
/* 33 */     this.fontRendererObj.drawString(this.themob.func_152113_b() + StatCollector.translateToLocal("entity.trunk.guiname"), 8, 4, 12624112);
/* 34 */     GL11.glPopMatrix();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float f, int ii, int jj) {
/* 40 */     if (this.themob.isDead) this.mc.thePlayer.closeScreen();
/*    */     
/* 42 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 43 */     UtilsFX.bindTexture("textures/gui/guitrunkbase.png");
/* 44 */     GL11.glEnable(3042);
/* 45 */     int j = (this.width - this.xSize) / 2;
/* 46 */     int k = (this.height - this.ySize) / 2;
/* 47 */     drawTexturedModalRect(j, k, 0, 0, this.xSize, this.ySize);
/*    */     
/* 49 */     int hp = Math.round(this.themob.getHealth() / this.themob.getMaxHealth() * 39.0F);
/* 50 */     drawTexturedModalRect(j + 134, k + 2, 176, 16, hp, 6);
/*    */     
/* 52 */     if (this.themob.getUpgrade() == 1) {
/* 53 */       drawTexturedModalRect(j, k + 80, 0, 206, this.xSize, 27);
/*    */     }
/*    */     
/* 56 */     if (this.themob.getStay()) {
/* 57 */       drawTexturedModalRect(j + 112, k, 176, 0, 10, 10);
/*    */     }
/*    */ 
/*    */     
/* 61 */     GL11.glDisable(3042);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mouseClicked(int i, int j, int k) {
/* 66 */     super.mouseClicked(i, j, k);
/* 67 */     int sx = (this.width - this.xSize) / 2;
/* 68 */     int sy = (this.height - this.ySize) / 2;
/* 69 */     int k1 = i - sx + 112;
/* 70 */     int l1 = j - sy + 0;
/* 71 */     if (k1 >= 0 && l1 >= 0 && k1 < 10 && l1 <= 10) {
/*    */       
/* 73 */       this.themob.worldObj.playSound(this.themob.posX, this.themob.posY, this.themob.posZ, "random.click", 0.3F, 0.6F + (this.themob.getStay() ? 0.0F : 0.2F), false);
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 78 */       if (this.themob.getStay()) {
/* 79 */         this.theplayer.addChatMessage((IChatComponent)new ChatComponentTranslation("entity.trunk.move", new Object[0]));
/*    */       } else {
/* 81 */         this.theplayer.addChatMessage((IChatComponent)new ChatComponentTranslation("entity.trunk.stay", new Object[0]));
/*    */       } 
/*    */       
/* 84 */       this.mc.playerController.sendEnchantPacket(this.inventorySlots.windowId, 1);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean doesGuiPauseGame() {
/* 91 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onGuiClosed() {
/* 97 */     this.themob.setOpen(false);
/*    */     
/* 99 */     super.onGuiClosed();
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\client\gui\GuiTravelingTrunk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */