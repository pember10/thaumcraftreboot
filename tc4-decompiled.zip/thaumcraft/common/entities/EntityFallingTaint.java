/*     */ package thaumcraft.common.entities;
/*     */ 
/*     */ import cpw.mods.fml.common.registry.IEntityAdditionalSpawnData;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.crash.CrashReportCategory;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.blocks.BlockTaint;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityFallingTaint
/*     */   extends Entity
/*     */   implements IEntityAdditionalSpawnData
/*     */ {
/*     */   public Block block;
/*     */   public int metadata;
/*     */   public int oldX;
/*     */   public int oldY;
/*     */   public int oldZ;
/*     */   public int fallTime;
/*     */   private int fallHurtMax;
/*     */   private float fallHurtAmount;
/*     */   
/*     */   public EntityFallingTaint(World par1World) {
/*  38 */     super(par1World);
/*  39 */     this.fallTime = 0;
/*  40 */     this.fallHurtMax = 40;
/*  41 */     this.fallHurtAmount = 2.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityFallingTaint(World par1World, double par2, double par4, double par6, Block par8, int par9, int ox, int oy, int oz) {
/*  46 */     super(par1World);
/*  47 */     this.fallTime = 0;
/*  48 */     this.fallHurtMax = 40;
/*  49 */     this.fallHurtAmount = 2.0F;
/*  50 */     this.block = par8;
/*  51 */     this.metadata = par9;
/*  52 */     this.preventEntitySpawning = true;
/*  53 */     setSize(0.98F, 0.98F);
/*  54 */     this.yOffset = this.height / 2.0F;
/*  55 */     setPosition(par2, par4, par6);
/*  56 */     this.motionX = 0.0D;
/*  57 */     this.motionY = 0.0D;
/*  58 */     this.motionZ = 0.0D;
/*  59 */     this.prevPosX = par2;
/*  60 */     this.prevPosY = par4;
/*  61 */     this.prevPosZ = par6;
/*  62 */     this.oldX = ox;
/*  63 */     this.oldY = oy;
/*  64 */     this.oldZ = oz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canTriggerWalking() {
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void entityInit() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeSpawnData(ByteBuf data) {
/*  84 */     data.writeInt(Block.getIdFromBlock(this.block));
/*  85 */     data.writeByte(this.metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readSpawnData(ByteBuf data) {
/*     */     try {
/*  91 */       this.block = Block.getBlockById(data.readInt());
/*  92 */       this.metadata = data.readByte();
/*  93 */     } catch (Exception e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canBeCollidedWith() {
/* 103 */     return !this.isDead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 112 */     if (this.block == null || this.block == Blocks.air) {
/*     */       
/* 114 */       setDead();
/*     */     }
/*     */     else {
/*     */       
/* 118 */       this.prevPosX = this.posX;
/* 119 */       this.prevPosY = this.posY;
/* 120 */       this.prevPosZ = this.posZ;
/* 121 */       this.fallTime++;
/* 122 */       this.motionY -= 0.03999999910593033D;
/* 123 */       moveEntity(this.motionX, this.motionY, this.motionZ);
/* 124 */       this.motionX *= 0.9800000190734863D;
/* 125 */       this.motionY *= 0.9800000190734863D;
/* 126 */       this.motionZ *= 0.9800000190734863D;
/*     */       
/* 128 */       if (!this.worldObj.isRemote) {
/*     */         
/* 130 */         int i = MathHelper.floor_double(this.posX);
/* 131 */         int j = MathHelper.floor_double(this.posY);
/* 132 */         int k = MathHelper.floor_double(this.posZ);
/*     */         
/* 134 */         if (this.fallTime == 1) {
/*     */ 
/*     */           
/* 137 */           if (this.worldObj.getBlock(this.oldX, this.oldY, this.oldZ) != this.block) {
/*     */             
/* 139 */             setDead();
/*     */             
/*     */             return;
/*     */           } 
/* 143 */           this.worldObj.setBlockToAir(this.oldX, this.oldY, this.oldZ);
/*     */         } 
/*     */         
/* 146 */         if (this.onGround || (this.worldObj.getBlock(i, j - 1, k) == ConfigBlocks.blockFluxGoo && this.worldObj.getBlockMetadata(i, j - 1, k) >= 4))
/*     */         {
/* 148 */           this.motionX *= 0.699999988079071D;
/* 149 */           this.motionZ *= 0.699999988079071D;
/* 150 */           this.motionY *= -0.5D;
/*     */           
/* 152 */           if (this.worldObj.getBlock(i, j, k) != Blocks.piston && this.worldObj.getBlock(i, j, k) != Blocks.piston_extension && this.worldObj.getBlock(i, j, k) != Blocks.piston_head)
/*     */           {
/*     */ 
/*     */             
/* 156 */             this.worldObj.playSoundAtEntity(this, "thaumcraft:gore", 0.5F, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F) * 0.8F);
/* 157 */             setDead();
/*     */             
/* 159 */             if (canPlace(i, j, k) && !BlockTaint.canFallBelow(this.worldObj, i, j - 1, k) && this.worldObj.setBlock(i, j, k, this.block, this.metadata, 3))
/*     */             {
/*     */ 
/*     */               
/* 163 */               if (this.block instanceof BlockTaint)
/*     */               {
/* 165 */                 ((BlockTaint)this.block).onFinishFalling(this.worldObj, i, j, k, this.metadata);
/*     */               
/*     */               }
/*     */             
/*     */             }
/*     */           }
/*     */         
/*     */         }
/* 173 */         else if ((this.fallTime > 100 && !this.worldObj.isRemote && (j < 1 || j > 256)) || this.fallTime > 600)
/*     */         {
/*     */           
/* 176 */           setDead();
/*     */         }
/*     */       
/* 179 */       } else if (this.onGround || this.fallTime == 1) {
/*     */         
/* 181 */         for (int j = 0; j < 10; j++)
/*     */         {
/* 183 */           Thaumcraft.proxy.taintLandFX(this);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canPlace(int i, int j, int k) {
/* 192 */     return (this.worldObj.getBlock(i, j, k) == ConfigBlocks.blockTaintFibres || this.worldObj.getBlock(i, j, k) == ConfigBlocks.blockFluxGoo || this.worldObj.canPlaceEntityOnSide(this.block, i, j, k, true, 1, (Entity)null, (ItemStack)null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fall(float par1) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
/* 212 */     par1NBTTagCompound.setInteger("TileID", Block.getIdFromBlock(this.block));
/* 213 */     par1NBTTagCompound.setByte("Data", (byte)this.metadata);
/* 214 */     par1NBTTagCompound.setByte("Time", (byte)this.fallTime);
/* 215 */     par1NBTTagCompound.setFloat("FallHurtAmount", this.fallHurtAmount);
/* 216 */     par1NBTTagCompound.setInteger("FallHurtMax", this.fallHurtMax);
/* 217 */     par1NBTTagCompound.setInteger("OldX", this.oldX);
/* 218 */     par1NBTTagCompound.setInteger("OldY", this.oldY);
/* 219 */     par1NBTTagCompound.setInteger("OldZ", this.oldZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
/* 228 */     if (par1NBTTagCompound.hasKey("TileID"))
/*     */     {
/* 230 */       this.block = Block.getBlockById(par1NBTTagCompound.getInteger("TileID"));
/*     */     }
/*     */     
/* 233 */     this.metadata = par1NBTTagCompound.getByte("Data") & 0xFF;
/* 234 */     this.fallTime = par1NBTTagCompound.getByte("Time") & 0xFF;
/* 235 */     this.oldX = par1NBTTagCompound.getInteger("OldX");
/* 236 */     this.oldY = par1NBTTagCompound.getInteger("OldY");
/* 237 */     this.oldZ = par1NBTTagCompound.getInteger("OldZ");
/*     */     
/* 239 */     if (par1NBTTagCompound.hasKey("HurtEntities")) {
/*     */       
/* 241 */       this.fallHurtAmount = par1NBTTagCompound.getFloat("FallHurtAmount");
/* 242 */       this.fallHurtMax = par1NBTTagCompound.getInteger("FallHurtMax");
/*     */     } 
/*     */ 
/*     */     
/* 246 */     if (this.block == null)
/*     */     {
/* 248 */       this.block = (Block)Blocks.sand;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEntityCrashInfo(CrashReportCategory par1CrashReportCategory) {
/* 255 */     super.addEntityCrashInfo(par1CrashReportCategory);
/* 256 */     par1CrashReportCategory.addCrashSection("Immitating block ID", Integer.valueOf(Block.getIdFromBlock(this.block)));
/* 257 */     par1CrashReportCategory.addCrashSection("Immitating block data", Integer.valueOf(this.metadata));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public float getShadowSize() {
/* 264 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public World getWorld() {
/* 270 */     return this.worldObj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean canRenderOnFire() {
/* 281 */     return false;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\EntityFallingTaint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */