/*    */ package thaumcraft.common.entities;
/*    */ 
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityPermanentItem
/*    */   extends EntitySpecialItem
/*    */ {
/*    */   public EntityPermanentItem(World par1World) {
/* 12 */     super(par1World);
/*    */   }
/*    */ 
/*    */   
/*    */   public EntityPermanentItem(World par1World, double par2, double par4, double par6, ItemStack par8ItemStack) {
/* 17 */     super(par1World);
/* 18 */     setSize(0.25F, 0.25F);
/* 19 */     this.yOffset = this.height / 2.0F;
/* 20 */     setPosition(par2, par4, par6);
/* 21 */     setEntityItemStack(par8ItemStack);
/* 22 */     this.rotationYaw = (float)(Math.random() * 360.0D);
/* 23 */     this.motionX = (float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D);
/* 24 */     this.motionY = 0.20000000298023224D;
/* 25 */     this.motionZ = (float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 32 */     super.onUpdate();
/* 33 */     if (this.age + 5 >= this.lifespan) this.age = 0; 
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\EntityPermanentItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */