/*     */ package thaumcraft.common.entities.ai.misc;
/*     */ 
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.RandomPositionGenerator;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ 
/*     */ public class AIReturnHome extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*     */   private double movePosX;
/*     */   private double movePosY;
/*     */   private double movePosZ;
/*  16 */   private int pathingDelay = 0;
/*  17 */   private int pathingDelayInc = 5;
/*     */ 
/*     */   
/*     */   int count;
/*     */   
/*     */   int prevX;
/*     */   
/*     */   int prevY;
/*     */   
/*     */   int prevZ;
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  30 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*  31 */     if (this.pathingDelay > 0) this.pathingDelay--; 
/*  32 */     if (this.pathingDelay > 0 || this.theGolem.getDistanceSq((home.posX + 0.5F), (home.posY + 0.5F), (home.posZ + 0.5F)) < 3.0D) {
/*  33 */       return false;
/*     */     }
/*     */     
/*  36 */     this.movePosX = home.posX + 0.5D;
/*  37 */     this.movePosY = home.posY + 0.5D;
/*  38 */     this.movePosZ = home.posZ + 0.5D;
/*  39 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  47 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*  48 */     return (this.pathingDelay <= 0 && this.count > 0 && !this.theGolem.getNavigator().noPath() && this.theGolem.getDistanceSq((home.posX + 0.5F), (home.posY + 0.5F), (home.posZ + 0.5F)) >= 3.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public AIReturnHome(EntityGolemBase par1EntityCreature) {
/*  59 */     this.count = 0;
/*  60 */     this.prevX = 0;
/*  61 */     this.prevY = 0;
/*  62 */     this.prevZ = 0;
/*     */     this.theGolem = par1EntityCreature;
/*     */     setMutexBits(3);
/*     */   } public void updateTask() {
/*  66 */     this.count--;
/*  67 */     if (this.count == 0 && this.prevX == MathHelper.floor_double(this.theGolem.posX) && this.prevY == MathHelper.floor_double(this.theGolem.posY) && this.prevZ == MathHelper.floor_double(this.theGolem.posZ)) {
/*  68 */       Vec3 var2 = RandomPositionGenerator.findRandomTarget((EntityCreature)this.theGolem, 2, 1);
/*     */       
/*  70 */       if (var2 != null) {
/*     */         
/*  72 */         this.count = 20;
/*  73 */         boolean path = this.theGolem.getNavigator().tryMoveToXYZ(var2.xCoord + 0.5D, var2.yCoord + 0.5D, var2.zCoord + 0.5D, this.theGolem.getAIMoveSpeed());
/*  74 */         if (!path) {
/*  75 */           this.pathingDelay = this.pathingDelayInc;
/*  76 */           if (this.pathingDelayInc < 50) this.pathingDelayInc += 5; 
/*     */         } else {
/*  78 */           this.pathingDelayInc = 5;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  84 */     super.updateTask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/*  92 */     this.count = 20;
/*  93 */     this.prevX = MathHelper.floor_double(this.theGolem.posX);
/*  94 */     this.prevY = MathHelper.floor_double(this.theGolem.posY);
/*  95 */     this.prevZ = MathHelper.floor_double(this.theGolem.posZ);
/*  96 */     boolean path = this.theGolem.getNavigator().tryMoveToXYZ(this.movePosX, this.movePosY, this.movePosZ, this.theGolem.getAIMoveSpeed());
/*  97 */     if (!path) {
/*  98 */       this.pathingDelay = this.pathingDelayInc;
/*  99 */       if (this.pathingDelayInc < 50) this.pathingDelayInc += 5; 
/*     */     } else {
/* 101 */       this.pathingDelayInc = 5;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\misc\AIReturnHome.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */