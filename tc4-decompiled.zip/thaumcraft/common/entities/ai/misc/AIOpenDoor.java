/*    */ package thaumcraft.common.entities.ai.misc;
/*    */ 
/*    */ import net.minecraft.block.BlockDoor;
/*    */ import net.minecraft.block.BlockFenceGate;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*    */ 
/*    */ public class AIOpenDoor
/*    */   extends AIDoorInteract
/*    */ {
/*    */   boolean field_75361_i;
/*    */   int field_75360_j;
/*    */   
/*    */   public AIOpenDoor(EntityGolemBase par1EntityLiving, boolean par2) {
/* 17 */     super(par1EntityLiving);
/* 18 */     this.theEntity = par1EntityLiving;
/* 19 */     this.field_75361_i = par2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean continueExecuting() {
/* 27 */     return (this.field_75361_i && this.field_75360_j > 0 && super.continueExecuting());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void startExecuting() {
/* 36 */     this.field_75360_j = 20;
/* 37 */     if (this.targetDoor == Blocks.wooden_door) {
/* 38 */       ((BlockDoor)this.targetDoor).func_150014_a(this.theEntity.worldObj, this.entityPosX, this.entityPosY, this.entityPosZ, true);
/*    */     } else {
/* 40 */       int var10 = this.theEntity.worldObj.getBlockMetadata(this.entityPosX, this.entityPosY, this.entityPosZ);
/* 41 */       if (!BlockFenceGate.isFenceGateOpen(var10)) {
/* 42 */         int var11 = (MathHelper.floor_double((this.theEntity.rotationYaw * 4.0F / 360.0F) + 0.5D) & 0x3) % 4;
/* 43 */         int var12 = BlockFenceGate.getDirection(var10);
/*    */         
/* 45 */         if (var12 == (var11 + 2) % 4)
/*    */         {
/* 47 */           var10 = var11;
/*    */         }
/*    */         
/* 50 */         this.theEntity.worldObj.setBlock(this.entityPosX, this.entityPosY, this.entityPosZ, this.targetDoor, var10 | 0x4, 3);
/* 51 */         this.theEntity.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1003, this.entityPosX, this.entityPosY, this.entityPosZ, 0);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void resetTask() {
/* 61 */     if (this.field_75361_i)
/*    */     {
/* 63 */       if (this.targetDoor == Blocks.wooden_door) {
/* 64 */         ((BlockDoor)this.targetDoor).func_150014_a(this.theEntity.worldObj, this.entityPosX, this.entityPosY, this.entityPosZ, false);
/*    */       } else {
/* 66 */         int var10 = this.theEntity.worldObj.getBlockMetadata(this.entityPosX, this.entityPosY, this.entityPosZ);
/* 67 */         if (BlockFenceGate.isFenceGateOpen(var10)) {
/* 68 */           this.theEntity.worldObj.setBlock(this.entityPosX, this.entityPosY, this.entityPosZ, this.targetDoor, var10 & 0xFFFFFFFB, 3);
/* 69 */           this.theEntity.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1003, this.entityPosX, this.entityPosY, this.entityPosZ, 0);
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void updateTask() {
/* 80 */     this.field_75360_j--;
/* 81 */     super.updateTask();
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\misc\AIOpenDoor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */