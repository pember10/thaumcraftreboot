/*     */ package thaumcraft.common.entities.ai.misc;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.lib.utils.Utils;
/*     */ import thaumcraft.common.lib.world.ThaumcraftWorldGenerator;
/*     */ 
/*     */ public class AIConvertGrass extends EntityAIBase {
/*     */   private EntityLiving entity;
/*     */   private World world;
/*  17 */   int field_48399_a = 0;
/*     */ 
/*     */   
/*     */   public AIConvertGrass(EntityLiving par1EntityLiving) {
/*  21 */     this.entity = par1EntityLiving;
/*  22 */     this.world = par1EntityLiving.worldObj;
/*  23 */     setMutexBits(7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  31 */     if (this.entity.getRNG().nextInt(250) != 0)
/*     */     {
/*  33 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  37 */     int var1 = MathHelper.floor_double(this.entity.posX);
/*  38 */     int var2 = MathHelper.floor_double(this.entity.posY);
/*  39 */     int var3 = MathHelper.floor_double(this.entity.posZ);
/*  40 */     return (this.world.getBlock(var1, var2, var3) == Blocks.tallgrass && this.world.getBlockMetadata(var1, var2, var3) == 1) ? true : ((this.world.getBlock(var1, var2 - 1, var3) == Blocks.grass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/*  51 */     this.field_48399_a = 40;
/*  52 */     this.world.setEntityState((Entity)this.entity, (byte)10);
/*  53 */     this.entity.getNavigator().clearPathEntity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/*  61 */     this.field_48399_a = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  69 */     return (this.field_48399_a > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_48396_h() {
/*  74 */     return this.field_48399_a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTask() {
/*  82 */     this.field_48399_a = Math.max(0, this.field_48399_a - 1);
/*     */     
/*  84 */     if (this.field_48399_a == 4) {
/*     */       
/*  86 */       int var1 = MathHelper.floor_double(this.entity.posX);
/*  87 */       int var2 = MathHelper.floor_double(this.entity.posY);
/*  88 */       int var3 = MathHelper.floor_double(this.entity.posZ);
/*     */       
/*  90 */       if (this.world.getBlock(var1, var2, var3) == Blocks.tallgrass) {
/*     */         
/*  92 */         this.world.playAuxSFX(2001, var1, var2, var3, Block.getIdFromBlock((Block)Blocks.grass) + 4096);
/*  93 */         this.world.setBlockToAir(var1, var2, var3);
/*  94 */         this.world.setBlock(var1, var2, var3, ConfigBlocks.blockTaintFibres, 0, 3);
/*  95 */         Utils.setBiomeAt(this.world, var1, var3, ThaumcraftWorldGenerator.biomeTaint);
/*  96 */         this.entity.eatGrassBonus();
/*     */       }
/*  98 */       else if (this.world.getBlock(var1, var2 - 1, var3) == Blocks.grass) {
/*     */         
/* 100 */         this.world.playAuxSFX(2001, var1, var2 - 1, var3, Block.getIdFromBlock((Block)Blocks.grass));
/* 101 */         this.world.setBlock(var1, var2, var3, ConfigBlocks.blockTaintFibres, 0, 3);
/* 102 */         Utils.setBiomeAt(this.world, var1, var3, ThaumcraftWorldGenerator.biomeTaint);
/* 103 */         this.entity.eatGrassBonus();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\misc\AIConvertGrass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */