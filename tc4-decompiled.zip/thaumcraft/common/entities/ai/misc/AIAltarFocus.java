/*    */ package thaumcraft.common.entities.ai.misc;
/*    */ 
/*    */ import net.minecraft.entity.ai.EntityAIBase;
/*    */ import net.minecraft.world.World;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ import thaumcraft.common.entities.monster.EntityCultistCleric;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AIAltarFocus
/*    */   extends EntityAIBase
/*    */ {
/*    */   private EntityCultistCleric entity;
/*    */   private World world;
/* 15 */   int field_48399_a = 0;
/*    */ 
/*    */   
/*    */   public AIAltarFocus(EntityCultistCleric par1EntityLiving) {
/* 19 */     this.entity = par1EntityLiving;
/* 20 */     this.world = par1EntityLiving.worldObj;
/* 21 */     setMutexBits(7);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldExecute() {
/* 30 */     if (!this.entity.getIsRitualist() || this.entity.getHomePosition() == null)
/*    */     {
/* 32 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 36 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void startExecuting() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void resetTask() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean continueExecuting() {
/* 63 */     return (this.entity.getIsRitualist() && this.entity.getHomePosition() != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void updateTask() {
/* 72 */     if (this.entity.getHomePosition() != null)
/*    */     {
/* 74 */       if (this.entity.ticksExisted % 40 == 0 && (this.entity.getHomePosition().getDistanceSquared((int)this.entity.posX, (int)this.entity.posY, (int)this.entity.posZ) > 16.0F || this.world.getBlock((this.entity.getHomePosition()).posX, (this.entity.getHomePosition()).posY, (this.entity.getHomePosition()).posZ) != ConfigBlocks.blockEldritch))
/*    */       {
/*    */         
/* 77 */         this.entity.setIsRitualist(false);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\misc\AIAltarFocus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */