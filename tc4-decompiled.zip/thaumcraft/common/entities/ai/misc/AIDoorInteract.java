/*     */ package thaumcraft.common.entities.ai.misc;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.pathfinding.PathEntity;
/*     */ import net.minecraft.pathfinding.PathNavigate;
/*     */ import net.minecraft.pathfinding.PathPoint;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AIDoorInteract
/*     */   extends EntityAIBase
/*     */ {
/*     */   protected EntityGolemBase theEntity;
/*     */   protected int entityPosX;
/*     */   protected int entityPosY;
/*     */   protected int entityPosZ;
/*     */   protected Block targetDoor;
/*     */   boolean hasStoppedDoorInteraction;
/*     */   float entityPositionX;
/*     */   float entityPositionZ;
/*     */   int count;
/*     */   
/*     */   public boolean shouldExecute() {
/*     */     if (!this.theEntity.isCollidedHorizontally)
/*     */       return false; 
/*     */     PathNavigate var1 = this.theEntity.getNavigator();
/*     */     PathEntity var2 = var1.getPath();
/*     */     if (var2 != null && !var2.isFinished() && var1.getCanBreakDoors()) {
/*     */       for (int var3 = 0; var3 < Math.min(var2.getCurrentPathIndex() + 2, var2.getCurrentPathLength()); var3++) {
/*     */         PathPoint var4 = var2.getPathPointFromIndex(var3);
/*     */         this.entityPosX = var4.xCoord;
/*     */         this.entityPosY = var4.yCoord;
/*     */         this.entityPosZ = var4.zCoord;
/*     */         if (this.theEntity.getDistanceSq(this.entityPosX, this.theEntity.posY, this.entityPosZ) <= 2.25D) {
/*     */           this.targetDoor = findUsableDoor(this.entityPosX, this.entityPosY, this.entityPosZ);
/*     */           if (this.targetDoor != null && this.targetDoor != Blocks.air) {
/*     */             this.count = 200;
/*     */             return true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       this.entityPosX = MathHelper.floor_double(this.theEntity.posX);
/*     */       this.entityPosY = MathHelper.floor_double(this.theEntity.posY);
/*     */       this.entityPosZ = MathHelper.floor_double(this.theEntity.posZ);
/*     */       this.targetDoor = findUsableDoor(this.entityPosX, this.entityPosY, this.entityPosZ);
/*     */       if (this.targetDoor != null && this.targetDoor != Blocks.air)
/*     */         this.count = 200; 
/*     */       return (this.targetDoor != null && this.targetDoor != Blocks.air);
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   public AIDoorInteract(EntityGolemBase par1EntityLiving) {
/* 100 */     this.count = 0;
/*     */     this.theEntity = par1EntityLiving;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTask() {
/* 107 */     this.count--;
/* 108 */     float var1 = (float)((this.entityPosX + 0.5F) - this.theEntity.posX);
/* 109 */     float var2 = (float)((this.entityPosZ + 0.5F) - this.theEntity.posZ);
/* 110 */     float var3 = this.entityPositionX * var1 + this.entityPositionZ * var2;
/*     */     
/* 112 */     if (var3 < 0.0F)
/*     */     {
/* 114 */       this.hasStoppedDoorInteraction = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean continueExecuting() {
/*     */     return (this.count > 0 && !this.hasStoppedDoorInteraction);
/*     */   }
/*     */   
/*     */   private Block findUsableDoor(int par1, int par2, int par3) {
/* 123 */     Block var4 = this.theEntity.worldObj.getBlock(par1, par2, par3);
/* 124 */     return (var4 != Blocks.wooden_door && var4 != Blocks.fence_gate) ? Block.getBlockById(0) : var4;
/*     */   }
/*     */   
/*     */   public void startExecuting() {
/*     */     this.count = 100;
/*     */     this.hasStoppedDoorInteraction = false;
/*     */     this.entityPositionX = (float)((this.entityPosX + 0.5F) - this.theEntity.posX);
/*     */     this.entityPositionZ = (float)((this.entityPosZ + 0.5F) - this.theEntity.posZ);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\misc\AIDoorInteract.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */