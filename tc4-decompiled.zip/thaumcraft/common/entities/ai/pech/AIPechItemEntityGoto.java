/*     */ package thaumcraft.common.entities.ai.pech;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.pathfinding.PathPoint;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.monster.EntityPech;
/*     */ 
/*     */ 
/*     */ public class AIPechItemEntityGoto
/*     */   extends EntityAIBase
/*     */ {
/*     */   private EntityPech pech;
/*     */   private Entity targetEntity;
/*  20 */   float maxTargetDistance = 16.0F;
/*     */   private int count;
/*     */   
/*     */   public AIPechItemEntityGoto(EntityPech par1EntityCreature) {
/*  24 */     this.pech = par1EntityCreature;
/*  25 */     setMutexBits(3);
/*     */   }
/*     */ 
/*     */   
/*     */   private int failedPathFindingPenalty;
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  33 */     if (this.pech.ticksExisted % Config.golemDelay > 0) return false;
/*     */     
/*  35 */     if (--this.count > 0) return false;
/*     */     
/*  37 */     double range = Double.MAX_VALUE;
/*     */ 
/*     */     
/*  40 */     List<Entity> targets = this.pech.worldObj.getEntitiesWithinAABBExcludingEntity((Entity)this.pech, this.pech.boundingBox.expand(this.maxTargetDistance, this.maxTargetDistance, this.maxTargetDistance));
/*     */     
/*  42 */     if (targets.size() == 0) return false; 
/*  43 */     for (Entity e : targets) {
/*  44 */       if (e instanceof EntityItem && this.pech.canPickup(((EntityItem)e).getEntityItem())) {
/*     */         
/*  46 */         NBTTagCompound itemData = ((EntityItem)e).getEntityData();
/*  47 */         String username = ((EntityItem)e).func_145800_j();
/*  48 */         if (username != null && username.equals("PechDrop"))
/*     */           continue; 
/*  50 */         double distance = e.getDistanceSq(this.pech.posX, this.pech.posY, this.pech.posZ);
/*  51 */         if (distance < range && distance <= (this.maxTargetDistance * this.maxTargetDistance)) {
/*  52 */           range = distance;
/*  53 */           this.targetEntity = e;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  58 */     if (this.targetEntity == null)
/*     */     {
/*  60 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  65 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  75 */     return (this.targetEntity == null) ? false : (!this.targetEntity.isEntityAlive() ? false : ((!this.pech.getNavigator().noPath() && this.targetEntity.getDistanceSqToEntity((Entity)this.pech) < (this.maxTargetDistance * this.maxTargetDistance))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/*  85 */     this.targetEntity = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/*  96 */     this.pech.getNavigator().setPath(this.pech.getNavigator().getPathToEntityLiving(this.targetEntity), this.pech.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getAttributeValue() * 1.5D);
/*     */     
/*  98 */     this.count = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateTask() {
/* 103 */     this.pech.getLookHelper().setLookPositionWithEntity(this.targetEntity, 30.0F, 30.0F);
/*     */     
/* 105 */     if (this.pech.getEntitySenses().canSee(this.targetEntity) && --this.count <= 0) {
/*     */       
/* 107 */       this.count = this.failedPathFindingPenalty + 4 + this.pech.getRNG().nextInt(4);
/* 108 */       this.pech.getNavigator().tryMoveToEntityLiving(this.targetEntity, this.pech.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getAttributeValue() * 1.5D);
/* 109 */       if (this.pech.getNavigator().getPath() != null) {
/*     */         
/* 111 */         PathPoint finalPathPoint = this.pech.getNavigator().getPath().getFinalPathPoint();
/* 112 */         if (finalPathPoint != null && this.targetEntity.getDistanceSq(finalPathPoint.xCoord, finalPathPoint.yCoord, finalPathPoint.zCoord) < 1.0D)
/*     */         {
/* 114 */           this.failedPathFindingPenalty = 0;
/*     */         }
/*     */         else
/*     */         {
/* 118 */           this.failedPathFindingPenalty += 10;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 123 */         this.failedPathFindingPenalty += 10;
/*     */       } 
/*     */     } 
/* 126 */     double distance = this.pech.getDistanceSq(this.targetEntity.posX, this.targetEntity.boundingBox.minY, this.targetEntity.posZ);
/* 127 */     if (distance <= 1.5D) {
/*     */       
/* 129 */       this.count = 0;
/*     */       
/* 131 */       int am = (((EntityItem)this.targetEntity).getEntityItem()).stackSize;
/* 132 */       ItemStack is = this.pech.pickupItem(((EntityItem)this.targetEntity).getEntityItem());
/* 133 */       if (is != null && is.stackSize > 0) {
/* 134 */         ((EntityItem)this.targetEntity).setEntityItemStack(is);
/*     */       } else {
/* 136 */         this.targetEntity.setDead();
/*     */       } 
/* 138 */       if (is == null || is.stackSize != am)
/* 139 */         this.targetEntity.worldObj.playSoundAtEntity(this.targetEntity, "random.pop", 0.2F, ((this.targetEntity.worldObj.rand.nextFloat() - this.targetEntity.worldObj.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\pech\AIPechItemEntityGoto.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */