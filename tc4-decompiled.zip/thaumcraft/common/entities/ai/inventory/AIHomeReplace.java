/*     */ package thaumcraft.common.entities.ai.inventory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.tileentity.TileEntityChest;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ import thaumcraft.common.lib.utils.InventoryUtils;
/*     */ 
/*     */ public class AIHomeReplace
/*     */   extends EntityAIBase
/*     */ {
/*     */   private EntityGolemBase theGolem;
/*  20 */   private int countChest = 0;
/*     */   
/*     */   private IInventory inv;
/*     */   
/*     */   public AIHomeReplace(EntityGolemBase par1EntityCreature) {
/*  25 */     this.theGolem = par1EntityCreature;
/*  26 */     setMutexBits(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  34 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*     */     
/*  36 */     if (this.theGolem.getCarried() == null || this.theGolem.ticksExisted % Config.golemDelay > 0 || !this.theGolem.getNavigator().noPath() || this.theGolem.getDistanceSq((home.posX + 0.5F), (home.posY + 0.5F), (home.posZ + 0.5F)) > 5.0D)
/*     */     {
/*     */       
/*  39 */       return false;
/*     */     }
/*     */     
/*  42 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  43 */     int cX = home.posX - facing.offsetX;
/*  44 */     int cY = home.posY - facing.offsetY;
/*  45 */     int cZ = home.posZ - facing.offsetZ;
/*  46 */     if (GolemHelper.isOnTimeOut(this.theGolem, this.theGolem.getCarried())) return true; 
/*  47 */     switch (this.theGolem.getCore()) {
/*     */       case 1:
/*  49 */         return !GolemHelper.findSomethingEmptyCore(this.theGolem, this.theGolem.getCarried());
/*     */       case 8:
/*  51 */         return !GolemHelper.findSomethingUseCore(this.theGolem, this.theGolem.getCarried());
/*     */       case 10:
/*  53 */         return !GolemHelper.findSomethingSortCore(this.theGolem, this.theGolem.getCarried());
/*     */     } 
/*  55 */     TileEntity tile = this.theGolem.worldObj.getTileEntity(cX, cY, cZ);
/*  56 */     ArrayList<ItemStack> neededList = GolemHelper.getItemsNeeded(this.theGolem, (this.theGolem.getUpgradeAmount(5) > 0));
/*  57 */     if (neededList != null && neededList.size() > 0) {
/*  58 */       for (ItemStack stack : neededList) {
/*  59 */         if (InventoryUtils.areItemStacksEqual(stack, this.theGolem.itemCarried, this.theGolem.checkOreDict(), this.theGolem.ignoreDamage(), this.theGolem.ignoreNBT()))
/*     */         {
/*  61 */           return false;
/*     */         }
/*     */       } 
/*  64 */       return true;
/*     */     } 
/*     */ 
/*     */     
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  76 */     return (shouldExecute() || this.countChest > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/*     */     try {
/*  85 */       if (this.inv != null && Config.golemChestInteract) this.inv.closeInventory(); 
/*  86 */     } catch (Exception e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTask() {
/*  94 */     this.countChest--;
/*     */     
/*  96 */     super.updateTask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 105 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/* 106 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/* 107 */     int cX = home.posX - facing.offsetX;
/* 108 */     int cY = home.posY - facing.offsetY;
/* 109 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/* 111 */     TileEntity tile = this.theGolem.worldObj.getTileEntity(cX, cY, cZ);
/* 112 */     boolean repeat = true;
/* 113 */     boolean didRepeat = false;
/* 114 */     while (repeat) {
/* 115 */       if (didRepeat) repeat = false;
/*     */       
/* 117 */       if (tile != null && tile instanceof IInventory) {
/* 118 */         ItemStack result = InventoryUtils.placeItemStackIntoInventory(this.theGolem.getCarried(), (IInventory)tile, facing.ordinal(), true);
/*     */ 
/*     */         
/* 121 */         if (!ItemStack.areItemStacksEqual(result, this.theGolem.itemCarried)) {
/* 122 */           this.theGolem.setCarried(result);
/*     */           try {
/* 124 */             if (Config.golemChestInteract) ((IInventory)tile).openInventory(); 
/* 125 */           } catch (Exception e) {}
/*     */           
/* 127 */           this.countChest = 5;
/* 128 */           this.inv = (IInventory)tile;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 134 */       if (!didRepeat && InventoryUtils.getDoubleChest(tile) != null) {
/* 135 */         TileEntityChest tileEntityChest = InventoryUtils.getDoubleChest(tile);
/* 136 */         didRepeat = true; continue;
/* 137 */       }  repeat = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\inventory\AIHomeReplace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */