/*     */ package thaumcraft.common.entities.ai.inventory;
/*     */ 
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.tileentity.TileEntityChest;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.lib.utils.InventoryUtils;
/*     */ 
/*     */ public class AIHomePlace extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*  16 */   private int countChest = 0;
/*     */   
/*     */   private IInventory inv;
/*     */   
/*     */   public AIHomePlace(EntityGolemBase par1EntityCreature) {
/*  21 */     this.theGolem = par1EntityCreature;
/*  22 */     setMutexBits(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  30 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*     */     
/*  32 */     if (this.theGolem.getCarried() == null || this.theGolem.ticksExisted % Config.golemDelay > 0 || !this.theGolem.getNavigator().noPath() || this.theGolem.getDistanceSq((home.posX + 0.5F), (home.posY + 0.5F), (home.posZ + 0.5F)) > 5.0D)
/*     */     {
/*     */       
/*  35 */       return false;
/*     */     }
/*     */     
/*  38 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  39 */     int cX = home.posX - facing.offsetX;
/*  40 */     int cY = home.posY - facing.offsetY;
/*  41 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/*  43 */     TileEntity tile = this.theGolem.worldObj.getTileEntity(cX, cY, cZ);
/*     */     
/*  45 */     boolean repeat = true;
/*  46 */     boolean didRepeat = false;
/*  47 */     while (repeat) {
/*  48 */       if (didRepeat) repeat = false;
/*     */       
/*  50 */       if (tile != null && tile instanceof IInventory) {
/*  51 */         ItemStack result = InventoryUtils.placeItemStackIntoInventory(this.theGolem.getCarried(), (IInventory)tile, facing.ordinal(), false);
/*     */ 
/*     */ 
/*     */         
/*  55 */         if (!ItemStack.areItemStacksEqual(result, this.theGolem.itemCarried)) {
/*  56 */           return true;
/*     */         }
/*     */       } 
/*  59 */       if (!didRepeat && InventoryUtils.getDoubleChest(tile) != null) {
/*  60 */         TileEntityChest tileEntityChest = InventoryUtils.getDoubleChest(tile);
/*  61 */         didRepeat = true; continue;
/*  62 */       }  repeat = false;
/*     */     } 
/*     */     
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  74 */     return (shouldExecute() || this.countChest > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/*     */     try {
/*  83 */       if (this.inv != null && Config.golemChestInteract) this.inv.closeInventory(); 
/*  84 */     } catch (Exception e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTask() {
/*  92 */     this.countChest--;
/*     */     
/*  94 */     super.updateTask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 103 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/* 104 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/* 105 */     int cX = home.posX - facing.offsetX;
/* 106 */     int cY = home.posY - facing.offsetY;
/* 107 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/* 109 */     TileEntity tile = this.theGolem.worldObj.getTileEntity(cX, cY, cZ);
/* 110 */     boolean repeat = true;
/* 111 */     boolean didRepeat = false;
/* 112 */     while (repeat) {
/* 113 */       if (didRepeat) repeat = false;
/*     */       
/* 115 */       if (tile != null && tile instanceof IInventory) {
/* 116 */         ItemStack result = InventoryUtils.placeItemStackIntoInventory(this.theGolem.getCarried(), (IInventory)tile, facing.ordinal(), true);
/*     */ 
/*     */         
/* 119 */         if (!ItemStack.areItemStacksEqual(result, this.theGolem.itemCarried)) {
/* 120 */           this.theGolem.setCarried(result);
/*     */           try {
/* 122 */             if (Config.golemChestInteract) ((IInventory)tile).openInventory(); 
/* 123 */           } catch (Exception e) {}
/*     */           
/* 125 */           this.countChest = 5;
/* 126 */           this.inv = (IInventory)tile;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 132 */       if (!didRepeat && InventoryUtils.getDoubleChest(tile) != null) {
/* 133 */         TileEntityChest tileEntityChest = InventoryUtils.getDoubleChest(tile);
/* 134 */         didRepeat = true; continue;
/* 135 */       }  repeat = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\inventory\AIHomePlace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */