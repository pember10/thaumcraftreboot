/*    */ package thaumcraft.common.entities.ai.inventory;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.ai.EntityAIBase;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraft.util.ChunkCoordinates;
/*    */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*    */ import thaumcraft.common.entities.golems.GolemHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AIEmptyDrop
/*    */   extends EntityAIBase
/*    */ {
/*    */   private EntityGolemBase theGolem;
/*    */   int count;
/*    */   
/*    */   public boolean shouldExecute() {
/*    */     if (this.theGolem.itemCarried == null || !this.theGolem.getNavigator().noPath())
/*    */       return false; 
/*    */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*    */     ArrayList<Byte> matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemCarried);
/*    */     for (Iterator<Byte> i$ = matchingColors.iterator(); i$.hasNext(); ) {
/*    */       byte color = ((Byte)i$.next()).byteValue();
/*    */       ArrayList<ChunkCoordinates> mc = GolemHelper.getMarkedBlocksAdjacentToGolem(this.theGolem.worldObj, this.theGolem, color);
/*    */       for (ChunkCoordinates cc : mc) {
/*    */         if (cc != home)
/*    */           return true; 
/*    */       } 
/*    */     } 
/*    */     return false;
/*    */   }
/*    */   
/*    */   public AIEmptyDrop(EntityGolemBase par1EntityCreature) {
/* 60 */     this.count = 0;
/*    */     this.theGolem = par1EntityCreature;
/*    */     setMutexBits(3);
/*    */   } public void updateTask() {
/* 64 */     this.count--;
/* 65 */     super.updateTask();
/*    */   }
/*    */   public boolean continueExecuting() {
/*    */     return (this.count > 0 && shouldExecute());
/*    */   }
/*    */   public void resetTask() {}
/*    */   
/*    */   public void startExecuting() {
/* 73 */     this.count = 200;
/* 74 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*    */     
/* 76 */     ArrayList<Byte> matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemCarried); Iterator<Byte> i$;
/* 77 */     label18: for (i$ = matchingColors.iterator(); i$.hasNext(); ) { byte color = ((Byte)i$.next()).byteValue();
/* 78 */       ArrayList<ChunkCoordinates> mc = GolemHelper.getMarkedBlocksAdjacentToGolem(this.theGolem.worldObj, this.theGolem, color);
/* 79 */       for (ChunkCoordinates cc : mc) {
/* 80 */         if (cc == home)
/*    */           continue; 
/* 82 */         EntityItem item = new EntityItem(this.theGolem.worldObj, this.theGolem.posX, this.theGolem.posY + (this.theGolem.height / 2.0F), this.theGolem.posZ, this.theGolem.itemCarried.copy());
/*    */         
/* 84 */         if (item != null) {
/* 85 */           double distance = this.theGolem.getDistance(cc.posX + 0.5D, cc.posY + 0.5D, cc.posZ + 0.5D);
/* 86 */           item.motionX = (cc.posX + 0.5D - this.theGolem.posX) * distance / 3.0D;
/* 87 */           item.motionY = 0.1D + (cc.posY + 0.5D - this.theGolem.posY + (this.theGolem.height / 2.0F)) * distance / 3.0D;
/* 88 */           item.motionZ = (cc.posZ + 0.5D - this.theGolem.posZ) * distance / 3.0D;
/* 89 */           item.delayBeforeCanPickup = 10;
/* 90 */           this.theGolem.worldObj.spawnEntityInWorld((Entity)item);
/* 91 */           this.theGolem.itemCarried = null;
/* 92 */           this.theGolem.startActionTimer();
/*    */           
/*    */           break label18;
/*    */         } 
/*    */       }  }
/*    */ 
/*    */     
/* 99 */     this.theGolem.updateCarried();
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\inventory\AIEmptyDrop.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */