/*     */ package thaumcraft.common.entities.ai.inventory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.RandomPositionGenerator;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ 
/*     */ public class AIFillGoto extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*     */   private double movePosX;
/*     */   private double movePosY;
/*     */   private double movePosZ;
/*  25 */   private ChunkCoordinates dest = null;
/*     */ 
/*     */   
/*     */   int count;
/*     */   
/*     */   int prevX;
/*     */   
/*     */   int prevY;
/*     */   
/*     */   int prevZ;
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  38 */     if (this.theGolem.getCarried() != null || this.theGolem.ticksExisted % Config.golemDelay > 0 || !this.theGolem.hasSomething())
/*     */     {
/*  40 */       return false;
/*     */     }
/*     */     
/*  43 */     ArrayList<ItemStack> mi = GolemHelper.getMissingItems(this.theGolem);
/*  44 */     if (mi == null || mi.size() == 0) {
/*  45 */       return false;
/*     */     }
/*     */     
/*  48 */     ArrayList<ItemStack> missingItems = new ArrayList<ItemStack>();
/*     */ 
/*     */     
/*  51 */     if (this.theGolem.getUpgradeAmount(5) > 0) {
/*  52 */       for (ItemStack stack : mi) {
/*  53 */         int od = OreDictionary.getOreID(stack);
/*  54 */         if (od != -1) {
/*  55 */           ItemStack[] ores = (ItemStack[])OreDictionary.getOres(Integer.valueOf(od)).toArray((Object[])new ItemStack[0]);
/*  56 */           for (ItemStack ore : ores)
/*  57 */             missingItems.add(ore.copy()); 
/*     */           continue;
/*     */         } 
/*  60 */         missingItems.add(stack.copy());
/*     */       } 
/*     */     } else {
/*     */       
/*  64 */       for (ItemStack stack : mi) {
/*  65 */         missingItems.add(stack.copy());
/*     */       }
/*     */     } 
/*     */     
/*  69 */     ArrayList<IInventory> results = new ArrayList<IInventory>();
/*     */     
/*  71 */     for (ItemStack stack : missingItems) {
/*  72 */       this.theGolem.itemWatched = stack.copy();
/*  73 */       ArrayList<Byte> matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemWatched);
/*  74 */       for (Iterator<Byte> i$ = matchingColors.iterator(); i$.hasNext(); ) { byte color = ((Byte)i$.next()).byteValue();
/*  75 */         results = GolemHelper.getContainersWithGoods(this.theGolem.worldObj, this.theGolem, this.theGolem.itemWatched, color); }
/*     */ 
/*     */ 
/*     */       
/*  79 */       if (results.size() > 0) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/*  84 */     if (results == null || results.size() == 0) {
/*  85 */       return false;
/*     */     }
/*     */     
/*  88 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  89 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*  90 */     int cX = home.posX - facing.offsetX;
/*  91 */     int cY = home.posY - facing.offsetY;
/*  92 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/*  94 */     int tX = 0;
/*  95 */     int tY = 0;
/*  96 */     int tZ = 0;
/*  97 */     double range = Double.MAX_VALUE;
/*  98 */     float dmod = this.theGolem.getRange();
/*  99 */     for (IInventory i : results) {
/* 100 */       TileEntity te = (TileEntity)i;
/* 101 */       double distance = this.theGolem.getDistanceSq(te.xCoord + 0.5D, te.yCoord + 0.5D, te.zCoord + 0.5D);
/* 102 */       if (distance < range && distance <= (dmod * dmod) && (te.xCoord != cX || te.yCoord != cY || te.zCoord != cZ)) {
/* 103 */         range = distance;
/* 104 */         tX = te.xCoord;
/* 105 */         tY = te.yCoord;
/* 106 */         tZ = te.zCoord;
/* 107 */         this.dest = new ChunkCoordinates(tX, tY, tZ);
/*     */       } 
/*     */     } 
/*     */     
/* 111 */     if (this.dest != null) {
/* 112 */       this.movePosX = tX;
/* 113 */       this.movePosY = tY;
/* 114 */       this.movePosZ = tZ;
/* 115 */       return true;
/*     */     } 
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/* 126 */     return (this.count > 0 && !this.theGolem.getNavigator().noPath());
/*     */   }
/*     */ 
/*     */   
/*     */   public AIFillGoto(EntityGolemBase par1EntityCreature) {
/* 131 */     this.count = 0;
/* 132 */     this.prevX = 0;
/* 133 */     this.prevY = 0;
/* 134 */     this.prevZ = 0;
/*     */     this.theGolem = par1EntityCreature;
/*     */     setMutexBits(3);
/*     */   } public void updateTask() {
/* 138 */     this.count--;
/* 139 */     if (this.count == 0 && this.prevX == MathHelper.floor_double(this.theGolem.posX) && this.prevY == MathHelper.floor_double(this.theGolem.posY) && this.prevZ == MathHelper.floor_double(this.theGolem.posZ)) {
/* 140 */       Vec3 var2 = RandomPositionGenerator.findRandomTarget((EntityCreature)this.theGolem, 2, 1);
/*     */       
/* 142 */       if (var2 != null) {
/*     */         
/* 144 */         this.count = 20;
/* 145 */         this.theGolem.getNavigator().tryMoveToXYZ(var2.xCoord, var2.yCoord, var2.zCoord, this.theGolem.getAIMoveSpeed());
/*     */       } 
/*     */     } 
/* 148 */     super.updateTask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/* 156 */     this.dest = null;
/* 157 */     this.count = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 165 */     this.count = 200;
/* 166 */     this.prevX = MathHelper.floor_double(this.theGolem.posX);
/* 167 */     this.prevY = MathHelper.floor_double(this.theGolem.posY);
/* 168 */     this.prevZ = MathHelper.floor_double(this.theGolem.posZ);
/* 169 */     this.theGolem.getNavigator().tryMoveToXYZ(this.movePosX, this.movePosY, this.movePosZ, this.theGolem.getAIMoveSpeed());
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\inventory\AIFillGoto.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */