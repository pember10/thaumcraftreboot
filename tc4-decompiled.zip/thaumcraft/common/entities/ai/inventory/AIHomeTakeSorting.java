/*     */ package thaumcraft.common.entities.ai.inventory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.tileentity.TileEntityChest;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ import thaumcraft.common.lib.utils.InventoryUtils;
/*     */ 
/*     */ public class AIHomeTakeSorting
/*     */   extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*  19 */   private int countChest = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IInventory inv;
/*     */ 
/*     */ 
/*     */   
/*     */   int count;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  34 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*     */     
/*  36 */     if (this.theGolem.getCarried() != null || this.theGolem.ticksExisted % Config.golemDelay > 0 || !this.theGolem.getNavigator().noPath() || this.theGolem.getDistanceSq((home.posX + 0.5F), (home.posY + 0.5F), (home.posZ + 0.5F)) > 5.0D)
/*     */     {
/*  38 */       return false;
/*     */     }
/*     */     
/*  41 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  42 */     int cX = home.posX - facing.offsetX;
/*  43 */     int cY = home.posY - facing.offsetY;
/*  44 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/*  46 */     TileEntity tile = this.theGolem.worldObj.getTileEntity(cX, cY, cZ);
/*     */     
/*  48 */     boolean repeat = true;
/*  49 */     boolean didRepeat = false;
/*  50 */     while (repeat) {
/*  51 */       if (didRepeat) repeat = false;
/*     */       
/*  53 */       if (tile != null && tile instanceof IInventory) {
/*     */         
/*  55 */         ArrayList<ItemStack> neededList = GolemHelper.getItemsNeeded(this.theGolem, (this.theGolem.getUpgradeAmount(5) > 0));
/*     */         
/*  57 */         if (neededList != null && neededList.size() > 0) {
/*  58 */           for (ItemStack stack : neededList) {
/*  59 */             ItemStack needed = stack.copy();
/*  60 */             needed.stackSize = this.theGolem.getCarrySpace();
/*  61 */             if (InventoryUtils.extractStack((IInventory)tile, needed, facing.ordinal(), this.theGolem.checkOreDict(), this.theGolem.ignoreDamage(), this.theGolem.ignoreNBT(), false) != null) {
/*  62 */               return true;
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*  67 */       if (!didRepeat && InventoryUtils.getDoubleChest(tile) != null) {
/*  68 */         TileEntityChest tileEntityChest = InventoryUtils.getDoubleChest(tile);
/*  69 */         didRepeat = true; continue;
/*  70 */       }  repeat = false;
/*     */     } 
/*     */     
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  83 */     return (this.count > 0 && (shouldExecute() || this.countChest > 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/*     */     try {
/*  93 */       if (this.inv != null && Config.golemChestInteract) this.inv.closeInventory(); 
/*  94 */     } catch (Exception e) {}
/*     */   }
/*     */   
/*     */   public AIHomeTakeSorting(EntityGolemBase par1EntityCreature) {
/*  98 */     this.count = 0;
/*     */     this.theGolem = par1EntityCreature;
/*     */     setMutexBits(3);
/*     */   } public void updateTask() {
/* 102 */     this.countChest--;
/* 103 */     this.count--;
/* 104 */     super.updateTask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 113 */     this.count = 200;
/* 114 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/* 115 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/* 116 */     int cX = home.posX - facing.offsetX;
/* 117 */     int cY = home.posY - facing.offsetY;
/* 118 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/* 120 */     TileEntity tile = this.theGolem.worldObj.getTileEntity(cX, cY, cZ);
/* 121 */     boolean repeat = true;
/* 122 */     boolean didRepeat = false;
/* 123 */     while (repeat) {
/* 124 */       if (didRepeat) repeat = false;
/*     */       
/* 126 */       if (tile != null && tile instanceof IInventory) {
/* 127 */         ArrayList<ItemStack> neededList = GolemHelper.getItemsNeeded(this.theGolem, (this.theGolem.getUpgradeAmount(5) > 0));
/* 128 */         if (neededList != null && neededList.size() > 0) {
/* 129 */           for (ItemStack stack : neededList) {
/* 130 */             ItemStack needed = stack.copy();
/* 131 */             needed.stackSize = this.theGolem.getCarrySpace();
/* 132 */             ItemStack result = InventoryUtils.extractStack((IInventory)tile, needed, facing.ordinal(), this.theGolem.checkOreDict(), this.theGolem.ignoreDamage(), this.theGolem.ignoreNBT(), true);
/* 133 */             if (result == null)
/*     */               continue; 
/* 135 */             this.theGolem.setCarried(result);
/*     */             try {
/* 137 */               if (Config.golemChestInteract) ((IInventory)tile).openInventory(); 
/* 138 */             } catch (Exception e) {
/*     */               continue;
/* 140 */             }  this.countChest = 5;
/* 141 */             this.inv = (IInventory)tile;
/*     */           } 
/*     */         }
/*     */         
/* 145 */         if (this.theGolem.getCarried() != null)
/*     */           break; 
/*     */       } 
/* 148 */       if (!didRepeat && InventoryUtils.getDoubleChest(tile) != null) {
/* 149 */         TileEntityChest tileEntityChest = InventoryUtils.getDoubleChest(tile);
/* 150 */         didRepeat = true; continue;
/* 151 */       }  repeat = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\inventory\AIHomeTakeSorting.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */