/*     */ package thaumcraft.common.entities.ai.inventory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ import thaumcraft.common.lib.utils.InventoryUtils;
/*     */ 
/*     */ public class AIFillTake
/*     */   extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*  19 */   private int countChest = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IInventory inv;
/*     */ 
/*     */ 
/*     */   
/*     */   int count;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  34 */     if (this.theGolem.getCarried() != null || this.theGolem.itemWatched == null || !this.theGolem.getNavigator().noPath() || !this.theGolem.hasSomething())
/*     */     {
/*     */       
/*  37 */       return false;
/*     */     }
/*     */     
/*  40 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  41 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*  42 */     int cX = home.posX - facing.offsetX;
/*  43 */     int cY = home.posY - facing.offsetY;
/*  44 */     int cZ = home.posZ - facing.offsetZ;
/*     */ 
/*     */     
/*  47 */     ArrayList<IInventory> mc = GolemHelper.getMarkedContainersAdjacentToGolem(this.theGolem.worldObj, this.theGolem);
/*     */ 
/*     */     
/*  50 */     for (IInventory te : mc) {
/*  51 */       TileEntity tile = (TileEntity)te;
/*  52 */       if (tile != null && (tile.xCoord != cX || tile.yCoord != cY || tile.zCoord != cZ)) {
/*     */ 
/*     */         
/*  55 */         ArrayList<Byte> matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemWatched);
/*  56 */         for (Iterator<Byte> i$ = matchingColors.iterator(); i$.hasNext(); ) { byte color = ((Byte)i$.next()).byteValue();
/*     */           
/*  58 */           for (Integer side : GolemHelper.getMarkedSides(this.theGolem, tile, color)) {
/*  59 */             ItemStack target = this.theGolem.itemWatched.copy();
/*     */             
/*  61 */             target.stackSize = this.theGolem.getToggles()[0] ? this.theGolem.getCarrySpace() : Math.min(target.stackSize, this.theGolem.getCarrySpace());
/*  62 */             ItemStack result = InventoryUtils.extractStack(te, target, side.intValue(), this.theGolem.checkOreDict(), this.theGolem.ignoreDamage(), this.theGolem.ignoreNBT(), true);
/*     */             
/*  64 */             if (result == null && InventoryUtils.getDoubleChest(tile) != null) {
/*  65 */               result = InventoryUtils.extractStack((IInventory)InventoryUtils.getDoubleChest(tile), target, side.intValue(), this.theGolem.checkOreDict(), this.theGolem.ignoreDamage(), this.theGolem.ignoreNBT(), true);
/*     */             }
/*     */             
/*  68 */             if (result != null) {
/*  69 */               this.theGolem.setCarried(result);
/*     */               try {
/*  71 */                 if (Config.golemChestInteract) this.inv.openInventory(); 
/*  72 */               } catch (Exception e) {}
/*     */               
/*  74 */               this.countChest = 5;
/*  75 */               this.count = 200;
/*  76 */               this.theGolem.itemWatched = null;
/*  77 */               this.theGolem.updateCarried();
/*  78 */               return true;
/*     */             } 
/*     */           }  }
/*     */       
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  95 */     return (this.count > 0 && (!this.theGolem.getNavigator().noPath() || this.countChest > 0));
/*     */   }
/*     */   
/*  98 */   public AIFillTake(EntityGolemBase par1EntityCreature) { this.count = 0;
/*     */     this.theGolem = par1EntityCreature;
/*     */     setMutexBits(3); } public void updateTask() {
/* 101 */     this.count--;
/* 102 */     this.countChest--;
/* 103 */     super.updateTask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/*     */     try {
/* 112 */       if (this.inv != null && Config.golemChestInteract) this.inv.closeInventory(); 
/* 113 */     } catch (Exception e) {}
/*     */   }
/*     */   
/*     */   public void startExecuting() {}
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\inventory\AIFillTake.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */