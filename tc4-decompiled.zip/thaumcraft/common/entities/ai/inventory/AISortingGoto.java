/*     */ package thaumcraft.common.entities.ai.inventory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.RandomPositionGenerator;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ import thaumcraft.common.lib.utils.InventoryUtils;
/*     */ 
/*     */ public class AISortingGoto extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*     */   private double movePosX;
/*     */   private double movePosY;
/*     */   private double movePosZ;
/*  24 */   private ChunkCoordinates dest = null;
/*     */ 
/*     */   
/*     */   int count;
/*     */   
/*     */   int prevX;
/*     */   
/*     */   int prevY;
/*     */   
/*     */   int prevZ;
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  37 */     if (this.theGolem.itemCarried == null || this.theGolem.ticksExisted % Config.golemDelay > 0) {
/*  38 */       return false;
/*     */     }
/*     */     
/*  41 */     ArrayList<IInventory> results = GolemHelper.getContainersWithRoom(this.theGolem.worldObj, this.theGolem, (byte)-1);
/*     */     
/*  43 */     if (results.size() == 0) {
/*  44 */       return false;
/*     */     }
/*     */     
/*  47 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  48 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*  49 */     int cX = home.posX - facing.offsetX;
/*  50 */     int cY = home.posY - facing.offsetY;
/*  51 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/*  53 */     int tX = 0;
/*  54 */     int tY = 0;
/*  55 */     int tZ = 0;
/*  56 */     double range = Double.MAX_VALUE;
/*  57 */     float dmod = this.theGolem.getRange();
/*     */     
/*  59 */     for (IInventory te : results) {
/*  60 */       double distance = this.theGolem.getDistanceSq(((TileEntity)te).xCoord + 0.5D, ((TileEntity)te).yCoord + 0.5D, ((TileEntity)te).zCoord + 0.5D);
/*  61 */       if (distance < range && distance <= (dmod * dmod) && (((TileEntity)te).xCoord != cX || ((TileEntity)te).yCoord != cY || ((TileEntity)te).zCoord != cZ))
/*     */       {
/*  63 */         for (Iterator<Integer> i$ = GolemHelper.getMarkedSides(this.theGolem, (TileEntity)te, (byte)-1).iterator(); i$.hasNext(); ) { int side = ((Integer)i$.next()).intValue();
/*  64 */           if (InventoryUtils.inventoryContains(te, this.theGolem.itemCarried, side, this.theGolem.checkOreDict(), this.theGolem.ignoreDamage(), this.theGolem.ignoreNBT())) {
/*  65 */             tX = ((TileEntity)te).xCoord;
/*  66 */             tY = ((TileEntity)te).yCoord;
/*  67 */             tZ = ((TileEntity)te).zCoord;
/*  68 */             this.dest = new ChunkCoordinates(tX, tY, tZ);
/*  69 */             range = distance;
/*     */           }  }
/*     */       
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  76 */     if (this.dest != null) {
/*  77 */       this.movePosX = tX;
/*  78 */       this.movePosY = tY;
/*  79 */       this.movePosZ = tZ;
/*  80 */       return true;
/*     */     } 
/*     */     
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  92 */     return (this.count > 0 && !this.theGolem.getNavigator().noPath());
/*     */   }
/*     */ 
/*     */   
/*     */   public AISortingGoto(EntityGolemBase par1EntityCreature) {
/*  97 */     this.count = 0;
/*  98 */     this.prevX = 0;
/*  99 */     this.prevY = 0;
/* 100 */     this.prevZ = 0;
/*     */     this.theGolem = par1EntityCreature;
/*     */     setMutexBits(3);
/*     */   } public void updateTask() {
/* 104 */     this.count--;
/* 105 */     if (this.count == 0 && this.prevX == MathHelper.floor_double(this.theGolem.posX) && this.prevY == MathHelper.floor_double(this.theGolem.posY) && this.prevZ == MathHelper.floor_double(this.theGolem.posZ)) {
/* 106 */       Vec3 var2 = RandomPositionGenerator.findRandomTarget((EntityCreature)this.theGolem, 2, 1);
/*     */       
/* 108 */       if (var2 != null) {
/*     */         
/* 110 */         this.count = 20;
/* 111 */         this.theGolem.getNavigator().tryMoveToXYZ(var2.xCoord, var2.yCoord, var2.zCoord, this.theGolem.getAIMoveSpeed());
/*     */       } 
/*     */     } 
/*     */     
/* 115 */     super.updateTask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/* 123 */     this.count = 0;
/* 124 */     this.dest = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 132 */     this.count = 200;
/* 133 */     this.prevX = MathHelper.floor_double(this.theGolem.posX);
/* 134 */     this.prevY = MathHelper.floor_double(this.theGolem.posY);
/* 135 */     this.prevZ = MathHelper.floor_double(this.theGolem.posZ);
/* 136 */     this.theGolem.getNavigator().tryMoveToXYZ(this.movePosX, this.movePosY, this.movePosZ, this.theGolem.getAIMoveSpeed());
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\inventory\AISortingGoto.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */