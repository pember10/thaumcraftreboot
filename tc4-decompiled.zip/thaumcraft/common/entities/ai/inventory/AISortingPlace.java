/*     */ package thaumcraft.common.entities.ai.inventory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ import thaumcraft.common.lib.utils.InventoryUtils;
/*     */ 
/*     */ public class AISortingPlace
/*     */   extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*  19 */   private int countChest = 0;
/*     */ 
/*     */   
/*     */   private IInventory inv;
/*     */ 
/*     */   
/*     */   private int xx;
/*     */ 
/*     */   
/*     */   private int yy;
/*     */   
/*     */   private int zz;
/*     */   
/*     */   int count;
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  36 */     if (this.theGolem.itemCarried == null || !this.theGolem.getNavigator().noPath()) {
/*  37 */       return false;
/*     */     }
/*     */     
/*  40 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*  41 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  42 */     int cX = home.posX - facing.offsetX;
/*  43 */     int cY = home.posY - facing.offsetY;
/*  44 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/*  46 */     ArrayList<IInventory> mc = GolemHelper.getMarkedContainersAdjacentToGolem(this.theGolem.worldObj, this.theGolem);
/*     */     
/*  48 */     for (IInventory te : mc) {
/*  49 */       TileEntity tile = (TileEntity)te;
/*  50 */       if (tile != null && (tile.xCoord != cX || tile.yCoord != cY || tile.zCoord != cZ)) {
/*     */         
/*  52 */         for (Integer side : GolemHelper.getMarkedSides(this.theGolem, tile, (byte)-1)) {
/*  53 */           ItemStack is = InventoryUtils.placeItemStackIntoInventory(this.theGolem.itemCarried, te, side.intValue(), false);
/*  54 */           if (!ItemStack.areItemStacksEqual(is, this.theGolem.itemCarried) && InventoryUtils.inventoryContains(te, this.theGolem.itemCarried, side.intValue(), this.theGolem.checkOreDict(), this.theGolem.ignoreDamage(), this.theGolem.ignoreNBT())) {
/*     */             
/*  56 */             this.xx = tile.xCoord;
/*  57 */             this.yy = tile.yCoord;
/*  58 */             this.zz = tile.zCoord;
/*  59 */             return true;
/*     */           } 
/*     */         } 
/*  62 */         if (InventoryUtils.getDoubleChest(tile) != null) {
/*  63 */           for (Integer side : GolemHelper.getMarkedSides(this.theGolem, tile, (byte)-1)) {
/*  64 */             ItemStack is = InventoryUtils.placeItemStackIntoInventory(this.theGolem.itemCarried, (IInventory)InventoryUtils.getDoubleChest(tile), side.intValue(), false);
/*  65 */             if (!ItemStack.areItemStacksEqual(is, this.theGolem.itemCarried) && InventoryUtils.inventoryContains(te, this.theGolem.itemCarried, side.intValue(), this.theGolem.checkOreDict(), this.theGolem.ignoreDamage(), this.theGolem.ignoreNBT())) {
/*     */               
/*  67 */               this.xx = tile.xCoord;
/*  68 */               this.yy = tile.yCoord;
/*  69 */               this.zz = tile.zCoord;
/*  70 */               return true;
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  78 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  87 */     return (this.count > 0 && (shouldExecute() || this.countChest > 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/*     */     try {
/*  96 */       if (this.inv != null && Config.golemChestInteract) this.inv.closeInventory(); 
/*  97 */     } catch (Exception e) {}
/*     */   }
/*     */   
/*     */   public AISortingPlace(EntityGolemBase par1EntityCreature) {
/* 101 */     this.count = 0;
/*     */     this.theGolem = par1EntityCreature;
/*     */     setMutexBits(3);
/*     */   } public void updateTask() {
/* 105 */     this.countChest--;
/* 106 */     this.count--;
/* 107 */     super.updateTask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 115 */     this.count = 200;
/* 116 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/* 117 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/* 118 */     int cX = home.posX - facing.offsetX;
/* 119 */     int cY = home.posY - facing.offsetY;
/* 120 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/* 122 */     TileEntity tile = this.theGolem.worldObj.getTileEntity(this.xx, this.yy, this.zz);
/* 123 */     if (tile != null && (tile.xCoord != cX || tile.yCoord != cY || tile.zCoord != cZ))
/*     */     
/* 125 */     { IInventory te = (IInventory)tile;
/* 126 */       ArrayList<Byte> matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemCarried);
/* 127 */       Iterator<Byte> i$ = matchingColors.iterator(); while (true) { if (i$.hasNext()) { byte color = ((Byte)i$.next()).byteValue();
/* 128 */           for (Integer side : GolemHelper.getMarkedSides(this.theGolem, tile, color)) {
/* 129 */             this.theGolem.itemCarried = InventoryUtils.placeItemStackIntoInventory(this.theGolem.itemCarried, te, side.intValue(), true);
/* 130 */             this.countChest = 5;
/* 131 */             this.inv = (IInventory)tile;
/* 132 */             if (this.theGolem.itemCarried == null)
/*     */               break; 
/* 134 */           }  if (InventoryUtils.getDoubleChest(tile) != null && this.theGolem.itemCarried != null)
/* 135 */             for (Integer side : GolemHelper.getMarkedSides(this.theGolem, tile, color)) {
/* 136 */               ItemStack is = InventoryUtils.placeItemStackIntoInventory(this.theGolem.itemCarried, (IInventory)InventoryUtils.getDoubleChest(tile), side.intValue(), false);
/* 137 */               if (!ItemStack.areItemStacksEqual(is, this.theGolem.itemCarried)) {
/* 138 */                 this.theGolem.itemCarried = InventoryUtils.placeItemStackIntoInventory(this.theGolem.itemCarried, (IInventory)InventoryUtils.getDoubleChest(tile), side.intValue(), true);
/* 139 */                 this.countChest = 5;
/* 140 */                 this.inv = (IInventory)InventoryUtils.getDoubleChest(tile);
/* 141 */                 if (this.theGolem.itemCarried == null)
/*     */                   break; 
/*     */               } 
/*     */             }  
/* 145 */           if (this.countChest == 5) {
/*     */             try {
/* 147 */               if (Config.golemChestInteract) ((IInventory)tile).openInventory();  break;
/* 148 */             } catch (Exception e) {}
/*     */           } else {
/*     */             continue;
/*     */           }  }
/*     */         else
/*     */         { break; }
/* 154 */          this.theGolem.updateCarried(); return; }  }  this.theGolem.updateCarried();
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\inventory\AISortingPlace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */