/*     */ package thaumcraft.common.entities.ai.inventory;
/*     */ 
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ 
/*     */ public class AIHomeDrop extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*  15 */   private int countChest = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private IInventory inv;
/*     */ 
/*     */ 
/*     */   
/*     */   int count;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  29 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*     */     
/*  31 */     if (this.theGolem.getCarried() == null || !this.theGolem.getNavigator().noPath() || this.theGolem.getDistanceSq((home.posX + 0.5F), (home.posY + 0.5F), (home.posZ + 0.5F)) > 5.0D)
/*     */     {
/*  33 */       return false;
/*     */     }
/*     */     
/*  36 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  37 */     int cX = home.posX - facing.offsetX;
/*  38 */     int cY = home.posY - facing.offsetY;
/*  39 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/*  41 */     TileEntity tile = this.theGolem.worldObj.getTileEntity(cX, cY, cZ);
/*     */     
/*  43 */     if (tile == null || !(tile instanceof IInventory)) {
/*  44 */       return true;
/*     */     }
/*     */     
/*  47 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  56 */     return (this.count > 0 && (shouldExecute() || this.countChest > 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/*     */     try {
/*  65 */       if (this.inv != null && Config.golemChestInteract) this.inv.closeInventory(); 
/*  66 */     } catch (Exception e) {}
/*     */   }
/*     */   
/*     */   public AIHomeDrop(EntityGolemBase par1EntityCreature) {
/*  70 */     this.count = 0;
/*     */     this.theGolem = par1EntityCreature;
/*     */     setMutexBits(3);
/*     */   } public void updateTask() {
/*  74 */     this.countChest--;
/*  75 */     this.count--;
/*  76 */     super.updateTask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/*  84 */     this.count = 200;
/*  85 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*  86 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  87 */     int cX = home.posX - facing.offsetX;
/*  88 */     int cY = home.posY - facing.offsetY;
/*  89 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/*  91 */     EntityItem item = new EntityItem(this.theGolem.worldObj, this.theGolem.posX, this.theGolem.posY + (this.theGolem.height / 2.0F), this.theGolem.posZ, this.theGolem.itemCarried.copy());
/*     */     
/*  93 */     if (item != null) {
/*  94 */       double distance = this.theGolem.getDistance(cX + 0.5D, cY + 0.5D, cZ + 0.5D);
/*  95 */       item.motionX = (cX + 0.5D - this.theGolem.posX) * distance / 3.0D;
/*  96 */       item.motionY = 0.1D + (cY + 0.5D - this.theGolem.posY + (this.theGolem.height / 2.0F)) * distance / 3.0D;
/*  97 */       item.motionZ = (cZ + 0.5D - this.theGolem.posZ) * distance / 3.0D;
/*  98 */       item.delayBeforeCanPickup = 10;
/*  99 */       this.theGolem.worldObj.spawnEntityInWorld((Entity)item);
/* 100 */       this.theGolem.itemCarried = null;
/* 101 */       this.theGolem.startActionTimer();
/* 102 */       this.theGolem.updateCarried();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\inventory\AIHomeDrop.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */