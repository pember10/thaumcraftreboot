/*     */ package thaumcraft.common.entities.ai.inventory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.RandomPositionGenerator;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ import thaumcraft.common.entities.golems.Marker;
/*     */ 
/*     */ public class AIEmptyGoto extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*     */   private double movePosX;
/*     */   private double movePosY;
/*     */   private double movePosZ;
/*  24 */   private ChunkCoordinates dest = null;
/*     */ 
/*     */   
/*     */   int count;
/*     */   
/*     */   int prevX;
/*     */   
/*     */   int prevY;
/*     */   
/*     */   int prevZ;
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  37 */     if (this.theGolem.itemCarried == null || this.theGolem.ticksExisted % Config.golemDelay > 0) {
/*  38 */       return false;
/*     */     }
/*     */     
/*  41 */     ArrayList<Byte> matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemCarried);
/*  42 */     for (Iterator<Byte> iterator1 = matchingColors.iterator(); iterator1.hasNext(); ) { byte color = ((Byte)iterator1.next()).byteValue();
/*  43 */       ArrayList<IInventory> results = GolemHelper.getContainersWithRoom(this.theGolem.worldObj, this.theGolem, color);
/*     */       
/*  45 */       if (results.size() == 0) {
/*     */         continue;
/*     */       }
/*     */       
/*  49 */       ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  50 */       ChunkCoordinates home = this.theGolem.getHomePosition();
/*  51 */       int cX = home.posX - facing.offsetX;
/*  52 */       int cY = home.posY - facing.offsetY;
/*  53 */       int cZ = home.posZ - facing.offsetZ;
/*     */       
/*  55 */       int tX = 0;
/*  56 */       int tY = 0;
/*  57 */       int tZ = 0;
/*  58 */       double range = Double.MAX_VALUE;
/*  59 */       float dmod = this.theGolem.getRange();
/*  60 */       for (IInventory te : results) {
/*  61 */         double distance = this.theGolem.getDistanceSq(((TileEntity)te).xCoord + 0.5D, ((TileEntity)te).yCoord + 0.5D, ((TileEntity)te).zCoord + 0.5D);
/*  62 */         if (distance < range && distance <= (dmod * dmod) && (((TileEntity)te).xCoord != cX || ((TileEntity)te).yCoord != cY || ((TileEntity)te).zCoord != cZ)) {
/*  63 */           range = distance;
/*  64 */           tX = ((TileEntity)te).xCoord;
/*  65 */           tY = ((TileEntity)te).yCoord;
/*  66 */           tZ = ((TileEntity)te).zCoord;
/*  67 */           this.dest = new ChunkCoordinates(tX, tY, tZ);
/*     */         } 
/*     */       } 
/*     */       
/*  71 */       if (this.dest != null) {
/*  72 */         this.movePosX = tX;
/*  73 */         this.movePosY = tY;
/*  74 */         this.movePosZ = tZ;
/*  75 */         return true;
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/*  80 */     for (Iterator<Byte> i$ = matchingColors.iterator(); i$.hasNext(); ) { byte color = ((Byte)i$.next()).byteValue();
/*  81 */       ArrayList<Marker> markers = this.theGolem.getMarkers();
/*  82 */       for (Marker marker : markers) {
/*  83 */         if ((marker.color == color || color == -1) && (this.theGolem.worldObj.getTileEntity(marker.x, marker.y, marker.z) == null || !(this.theGolem.worldObj.getTileEntity(marker.x, marker.y, marker.z) instanceof IInventory))) {
/*     */ 
/*     */ 
/*     */           
/*  87 */           this.movePosX = marker.x;
/*  88 */           this.movePosY = marker.y;
/*  89 */           this.movePosZ = marker.z;
/*  90 */           return true;
/*     */         } 
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/* 105 */     return (this.count > 0 && !this.theGolem.getNavigator().noPath());
/*     */   }
/*     */ 
/*     */   
/*     */   public AIEmptyGoto(EntityGolemBase par1EntityCreature) {
/* 110 */     this.count = 0;
/* 111 */     this.prevX = 0;
/* 112 */     this.prevY = 0;
/* 113 */     this.prevZ = 0;
/*     */     this.theGolem = par1EntityCreature;
/*     */     setMutexBits(3);
/*     */   } public void updateTask() {
/* 117 */     this.count--;
/* 118 */     if (this.count == 0 && this.prevX == MathHelper.floor_double(this.theGolem.posX) && this.prevY == MathHelper.floor_double(this.theGolem.posY) && this.prevZ == MathHelper.floor_double(this.theGolem.posZ)) {
/* 119 */       Vec3 var2 = RandomPositionGenerator.findRandomTarget((EntityCreature)this.theGolem, 2, 1);
/*     */       
/* 121 */       if (var2 != null) {
/*     */         
/* 123 */         this.count = 20;
/* 124 */         this.theGolem.getNavigator().tryMoveToXYZ(var2.xCoord, var2.yCoord, var2.zCoord, this.theGolem.getAIMoveSpeed());
/*     */       } 
/*     */     } 
/*     */     
/* 128 */     super.updateTask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/* 136 */     this.count = 0;
/* 137 */     this.dest = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 145 */     this.count = 200;
/* 146 */     this.prevX = MathHelper.floor_double(this.theGolem.posX);
/* 147 */     this.prevY = MathHelper.floor_double(this.theGolem.posY);
/* 148 */     this.prevZ = MathHelper.floor_double(this.theGolem.posZ);
/* 149 */     this.theGolem.getNavigator().tryMoveToXYZ(this.movePosX, this.movePosY, this.movePosZ, this.theGolem.getAIMoveSpeed());
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\inventory\AIEmptyGoto.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */