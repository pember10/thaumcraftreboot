/*     */ package thaumcraft.common.entities.ai.interact;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemFishFood;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.FurnaceRecipes;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.util.WeightedRandom;
/*     */ import net.minecraft.util.WeightedRandomFishable;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBobber;
/*     */ 
/*     */ public class AIFish
/*     */   extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*     */   private float quality;
/*  32 */   private int maxDelay = 1; private float distance; private World theWorld;
/*  33 */   private int mod = 1;
/*  34 */   private int count = 0;
/*  35 */   private Vec3 target = null;
/*  36 */   private EntityGolemBobber bobber = null;
/*     */ 
/*     */   
/*     */   public AIFish(EntityGolemBase par1EntityCreature) {
/*  40 */     this.theGolem = par1EntityCreature;
/*  41 */     this.theWorld = par1EntityCreature.worldObj;
/*  42 */     setMutexBits(3);
/*  43 */     this.distance = MathHelper.ceiling_float_int(this.theGolem.getRange() / 2.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  51 */     if (this.target != null || this.count > 0 || this.theGolem.ticksExisted % Config.golemDelay > 0 || !this.theGolem.getNavigator().noPath())
/*     */     {
/*  53 */       return false;
/*     */     }
/*     */     
/*  56 */     if (this.bobber != null) {
/*  57 */       this.bobber.setDead();
/*     */     }
/*     */     
/*  60 */     Vec3 vv = findWater();
/*     */     
/*  62 */     if (vv == null)
/*     */     {
/*  64 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  68 */     this.target = Vec3.createVectorHelper(vv.xCoord, vv.yCoord, vv.zCoord);
/*  69 */     this.quality = 0.0F;
/*  70 */     int x = (int)this.target.xCoord;
/*  71 */     int y = (int)this.target.yCoord;
/*  72 */     int z = (int)this.target.zCoord;
/*  73 */     for (int a = 2; a <= 5; a++) {
/*  74 */       ForgeDirection dir = ForgeDirection.getOrientation(a);
/*  75 */       if (this.theWorld.getBlock(x + dir.offsetX, y + dir.offsetY, z + dir.offsetZ).getMaterial() == Material.water && this.theWorld.isAirBlock(x + dir.offsetX, y + 1 + dir.offsetY, z + dir.offsetZ)) {
/*     */         
/*  77 */         this.quality += 3.0E-5F;
/*  78 */         if (this.theWorld.canBlockSeeTheSky(x + dir.offsetX, y + 1 + dir.offsetY, z + dir.offsetZ)) {
/*  79 */           this.quality += 3.0E-5F;
/*     */         }
/*  81 */         for (int depth = 1; depth <= 3; depth++) {
/*  82 */           if (this.theWorld.getBlock(x + dir.offsetX, y - depth + dir.offsetY, z + dir.offsetZ).getMaterial() == Material.water) {
/*  83 */             this.quality += 1.5E-5F;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*  88 */     this.theWorld.playSoundAtEntity((Entity)this.theGolem, "random.bow", 0.5F, 0.4F / (this.theWorld.rand.nextFloat() * 0.4F + 0.8F));
/*  89 */     this.bobber = new EntityGolemBobber(this.theWorld, this.theGolem, x, y, z);
/*  90 */     return this.theWorld.spawnEntityInWorld((Entity)this.bobber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  99 */     return (this.bobber != null && !this.bobber.isDead && this.target != null && this.count-- > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateTask() {
/* 104 */     if (this.target != null) {
/* 105 */       this.theGolem.getLookHelper().setLookPosition(this.target.xCoord + 0.5D, this.target.yCoord + 1.0D, this.target.zCoord + 0.5D, 30.0F, 30.0F);
/*     */       
/* 107 */       float chance = this.quality + this.theGolem.getGolemStrength() * 1.5E-4F;
/*     */       
/* 109 */       if (this.theWorld.rand.nextFloat() < chance) {
/* 110 */         this.theGolem.startRightArmTimer();
/*     */         
/* 112 */         int qq = 1;
/*     */         
/* 114 */         if (this.theGolem.getUpgradeAmount(0) > 0 && 
/* 115 */           this.theWorld.rand.nextInt(10) < this.theGolem.getUpgradeAmount(0)) {
/* 116 */           qq++;
/*     */         }
/*     */ 
/*     */         
/* 120 */         for (int a = 0; a < qq; a++) {
/* 121 */           ItemStack fs = getFishingResult();
/*     */           
/* 123 */           if (this.theGolem.getUpgradeAmount(2) > 0) {
/* 124 */             ItemStack sr = FurnaceRecipes.smelting().getSmeltingResult(fs);
/* 125 */             if (sr != null)
/*     */             {
/* 127 */               fs = sr.copy();
/*     */             }
/*     */           } 
/*     */           
/* 131 */           EntityItem entityitem = new EntityItem(this.theWorld, this.target.xCoord + 0.5D, this.target.yCoord + 1.0D, this.target.zCoord + 0.5D, fs);
/*     */           
/* 133 */           if (this.theGolem.getUpgradeAmount(2) > 0) {
/* 134 */             entityitem.setFire(2);
/*     */           }
/* 136 */           entityitem.delayBeforeCanPickup = 20;
/* 137 */           double d1 = this.theGolem.posX + this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat() - this.target.xCoord + 0.5D;
/* 138 */           double d3 = this.theGolem.posY - this.target.yCoord + 1.0D;
/* 139 */           double d5 = this.theGolem.posZ + this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat() - this.target.zCoord + 0.5D;
/* 140 */           double d7 = MathHelper.sqrt_double(d1 * d1 + d3 * d3 + d5 * d5);
/* 141 */           double d9 = 0.1D;
/* 142 */           entityitem.motionX = d1 * d9;
/* 143 */           entityitem.motionY = d3 * d9 + MathHelper.sqrt_double(d7) * 0.08D;
/* 144 */           entityitem.motionZ = d5 * d9;
/* 145 */           this.theWorld.spawnEntityInWorld((Entity)entityitem);
/*     */         } 
/*     */         
/* 148 */         if (this.bobber != null) {
/* 149 */           this.bobber.playSound("random.splash", 0.15F, 1.0F + (this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat()) * 0.4F);
/* 150 */           ((WorldServer)this.theWorld).func_147487_a("splash", this.bobber.posX, this.bobber.posY + 0.5D, this.bobber.posZ, 20 + this.theWorld.rand.nextInt(20), 0.10000000149011612D, 0.0D, 0.10000000149011612D, 0.0D);
/*     */ 
/*     */           
/* 153 */           this.bobber.setDead();
/*     */         } 
/* 155 */         this.target = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/* 163 */     if (this.bobber != null) this.bobber.setDead(); 
/* 164 */     this.target = null;
/* 165 */     this.count = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 173 */     this.count = 300 + this.theWorld.rand.nextInt(200);
/* 174 */     this.theGolem.startRightArmTimer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Vec3 findWater() {
/* 180 */     Random rand = this.theGolem.getRNG();
/*     */     
/* 182 */     for (int var2 = 0; var2 < this.distance * 2.0F; var2++) {
/*     */       
/* 184 */       int x = (int)(((this.theGolem.getHomePosition()).posX + rand.nextInt((int)(1.0F + this.distance * 2.0F))) - this.distance);
/* 185 */       int y = (int)(((this.theGolem.getHomePosition()).posY + rand.nextInt((int)(1.0F + this.distance))) - this.distance / 2.0F);
/* 186 */       int z = (int)(((this.theGolem.getHomePosition()).posZ + rand.nextInt((int)(1.0F + this.distance * 2.0F))) - this.distance);
/* 187 */       if (this.theWorld.getBlock(x, y, z).getMaterial() == Material.water && this.theWorld.isAirBlock(x, y + 1, z)) {
/*     */         
/* 189 */         Vec3 v = Vec3.createVectorHelper(x, y, z);
/* 190 */         return v;
/*     */       } 
/*     */     } 
/* 193 */     return null;
/*     */   }
/*     */   
/* 196 */   private static final List LOOTCRAP = Arrays.asList(new WeightedRandomFishable[] { (new WeightedRandomFishable(new ItemStack((Item)Items.leather_boots), 10)).func_150709_a(0.9F), new WeightedRandomFishable(new ItemStack(Items.leather), 10), new WeightedRandomFishable(new ItemStack(Items.bone), 10), new WeightedRandomFishable(new ItemStack((Item)Items.potionitem), 10), new WeightedRandomFishable(new ItemStack(Items.string), 5), (new WeightedRandomFishable(new ItemStack((Item)Items.fishing_rod), 2)).func_150709_a(0.9F), new WeightedRandomFishable(new ItemStack(Items.bowl), 10), new WeightedRandomFishable(new ItemStack(Items.stick), 5), new WeightedRandomFishable(new ItemStack(Items.dye, 10, 0), 5), new WeightedRandomFishable(new ItemStack((Block)Blocks.tripwire_hook), 10), new WeightedRandomFishable(new ItemStack(Items.rotten_flesh), 10) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 208 */   private static final List LOOTRARE = Arrays.asList(new WeightedRandomFishable[] { new WeightedRandomFishable(new ItemStack(Blocks.waterlily), 1), new WeightedRandomFishable(new ItemStack(Items.name_tag), 1), new WeightedRandomFishable(new ItemStack(Items.saddle), 1), (new WeightedRandomFishable(new ItemStack((Item)Items.bow), 1)).func_150709_a(0.25F).func_150707_a(), (new WeightedRandomFishable(new ItemStack((Item)Items.fishing_rod), 1)).func_150709_a(0.25F).func_150707_a(), (new WeightedRandomFishable(new ItemStack(Items.book), 1)).func_150707_a() });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   private static final List LOOTFISH = Arrays.asList(new WeightedRandomFishable[] { new WeightedRandomFishable(new ItemStack(Items.fish, 1, ItemFishFood.FishType.COD.func_150976_a()), 60), new WeightedRandomFishable(new ItemStack(Items.fish, 1, ItemFishFood.FishType.SALMON.func_150976_a()), 25), new WeightedRandomFishable(new ItemStack(Items.fish, 1, ItemFishFood.FishType.CLOWNFISH.func_150976_a()), 2), new WeightedRandomFishable(new ItemStack(Items.fish, 1, ItemFishFood.FishType.PUFFERFISH.func_150976_a()), 13) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ItemStack getFishingResult() {
/* 224 */     float f = this.theWorld.rand.nextFloat();
/* 225 */     float f1 = 0.1F - this.theGolem.getUpgradeAmount(5) * 0.025F;
/* 226 */     float f2 = 0.05F + this.theGolem.getUpgradeAmount(4) * 0.0125F;
/*     */     
/* 228 */     int x = (int)this.target.xCoord;
/* 229 */     int y = (int)this.target.yCoord;
/* 230 */     int z = (int)this.target.zCoord;
/* 231 */     for (int a = 2; a <= 5; a++) {
/* 232 */       ForgeDirection dir = ForgeDirection.getOrientation(a);
/* 233 */       if (this.theWorld.getBlock(x + dir.offsetX, y + dir.offsetY, z + dir.offsetZ).getMaterial() == Material.water && this.theWorld.isAirBlock(x + dir.offsetX, y + 1 + dir.offsetY, z + dir.offsetZ)) {
/*     */         
/* 235 */         f1 -= 0.005F;
/* 236 */         f2 += 0.00125F;
/* 237 */         if (this.theWorld.canBlockSeeTheSky(x + dir.offsetX, y + 1 + dir.offsetY, z + dir.offsetZ)) {
/* 238 */           f1 -= 0.005F;
/* 239 */           f2 += 0.00125F;
/*     */         } 
/* 241 */         for (int depth = 1; depth <= 3; depth++) {
/* 242 */           if (this.theWorld.getBlock(x + dir.offsetX, y - depth + dir.offsetY, z + dir.offsetZ).getMaterial() == Material.water) {
/* 243 */             f2 += 0.001F;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 248 */     f1 = MathHelper.clamp_float(f1, 0.0F, 1.0F);
/* 249 */     f2 = MathHelper.clamp_float(f2, 0.0F, 1.0F);
/*     */     
/* 251 */     if (f < f1)
/*     */     {
/* 253 */       return ((WeightedRandomFishable)WeightedRandom.getRandomItem(this.theWorld.rand, LOOTCRAP)).func_150708_a(this.theWorld.rand);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 258 */     f -= f1;
/*     */     
/* 260 */     if (f < f2)
/*     */     {
/* 262 */       return ((WeightedRandomFishable)WeightedRandom.getRandomItem(this.theWorld.rand, LOOTRARE)).func_150708_a(this.theWorld.rand);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 267 */     float f3 = f - f2;
/* 268 */     return ((WeightedRandomFishable)WeightedRandom.getRandomItem(this.theWorld.rand, LOOTFISH)).func_150708_a(this.theWorld.rand);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\interact\AIFish.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */