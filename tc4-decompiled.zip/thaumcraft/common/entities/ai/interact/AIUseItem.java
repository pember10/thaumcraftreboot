/*     */ package thaumcraft.common.entities.ai.interact;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.server.management.ItemInWorldManager;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraftforge.common.util.FakePlayer;
/*     */ import net.minecraftforge.common.util.FakePlayerFactory;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ import thaumcraft.common.entities.golems.Marker;
/*     */ 
/*     */ public class AIUseItem
/*     */   extends EntityAIBase
/*     */ {
/*     */   private EntityGolemBase theGolem;
/*     */   private int xx;
/*     */   private int yy;
/*     */   private int zz;
/*     */   private float movementSpeed;
/*     */   private float distance;
/*     */   private World theWorld;
/*  34 */   private Block block = Blocks.air;
/*  35 */   private int blockMd = 0;
/*     */   FakePlayer player;
/*  37 */   private int count = 0;
/*  38 */   private int color = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   ItemInWorldManager im;
/*     */ 
/*     */ 
/*     */   
/*     */   int nextTick;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AIUseItem(EntityGolemBase par1EntityCreature) {
/*  52 */     this.nextTick = 0; this.theGolem = par1EntityCreature; this.theWorld = par1EntityCreature.worldObj;
/*     */     setMutexBits(3);
/*     */     this.distance = MathHelper.ceiling_float_int(this.theGolem.getRange() / 3.0F);
/*     */     if (this.theWorld instanceof WorldServer)
/*     */       this.player = FakePlayerFactory.get((WorldServer)this.theWorld, new GameProfile((UUID)null, "FakeThaumcraftGolem")); 
/*     */     try {
/*     */       this.nextTick = this.theGolem.ticksExisted + this.theWorld.rand.nextInt(6);
/*  59 */     } catch (Exception e) {} } public boolean shouldExecute() { boolean ignoreItem = false;
/*  60 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*  61 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  62 */     int cX = home.posX - facing.offsetX;
/*  63 */     int cY = home.posY - facing.offsetY;
/*  64 */     int cZ = home.posZ - facing.offsetZ;
/*  65 */     TileEntity tile = this.theGolem.worldObj.getTileEntity(cX, cY, cZ);
/*  66 */     if (tile == null || !(tile instanceof net.minecraft.inventory.IInventory)) {
/*  67 */       ignoreItem = true;
/*     */     }
/*     */     
/*  70 */     int d = 5 - this.theGolem.ticksExisted;
/*  71 */     if (d < 1) d = 1;
/*     */     
/*  73 */     if ((this.theGolem.itemCarried == null && !ignoreItem) || this.theGolem.ticksExisted < this.nextTick || !this.theGolem.getNavigator().noPath())
/*     */     {
/*     */       
/*  76 */       return false;
/*     */     }
/*     */     
/*  79 */     this.nextTick = this.theGolem.ticksExisted + d * 3;
/*  80 */     return findSomething(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  88 */     return (this.theWorld.getBlock(this.xx, this.yy, this.zz) == this.block && this.theWorld.getBlockMetadata(this.xx, this.yy, this.zz) == this.blockMd && this.count-- > 0 && !this.theGolem.getNavigator().noPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTask() {
/*  95 */     this.theGolem.getLookHelper().setLookPosition(this.xx + 0.5D, this.yy + 0.5D, this.zz + 0.5D, 30.0F, 30.0F);
/*  96 */     double dist = this.theGolem.getDistanceSq(this.xx + 0.5D, this.yy + 0.5D, this.zz + 0.5D);
/*  97 */     if (dist <= 4.0D)
/*     */     {
/*  99 */       click();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/* 107 */     this.count = 0;
/* 108 */     this.theGolem.getNavigator().clearPathEntity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 116 */     this.count = 200;
/* 117 */     this.theGolem.getNavigator().tryMoveToXYZ(this.xx + 0.5D, this.yy + 0.5D, this.zz + 0.5D, this.theGolem.getAIMoveSpeed());
/*     */   }
/*     */   
/*     */   void click() {
/* 121 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/* 122 */     boolean ignoreItem = false;
/* 123 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/* 124 */     int cX = home.posX - facing.offsetX;
/* 125 */     int cY = home.posY - facing.offsetY;
/* 126 */     int cZ = home.posZ - facing.offsetZ;
/* 127 */     TileEntity tile = this.theGolem.worldObj.getTileEntity(cX, cY, cZ);
/* 128 */     if (tile == null || !(tile instanceof net.minecraft.inventory.IInventory)) {
/* 129 */       ignoreItem = true;
/*     */     }
/*     */     
/* 132 */     this.player.setPositionAndRotation(this.theGolem.posX, this.theGolem.posY, this.theGolem.posZ, this.theGolem.rotationYaw, this.theGolem.rotationPitch);
/* 133 */     this.player.setCurrentItemOrArmor(0, this.theGolem.itemCarried);
/* 134 */     this.player.setSneaking(this.theGolem.getToggles()[2]);
/*     */     
/* 136 */     Iterator<Integer> i$ = GolemHelper.getMarkedSides(this.theGolem, this.xx, this.yy, this.zz, this.theGolem.worldObj.provider.dimensionId, (byte)this.color).iterator(); if (i$.hasNext()) { Integer side = i$.next();
/*     */       
/* 138 */       int x = 0;
/* 139 */       int y = 0;
/* 140 */       int z = 0;
/* 141 */       if (this.theGolem.worldObj.isAirBlock(this.xx, this.yy, this.zz)) {
/* 142 */         x = (ForgeDirection.getOrientation(side.intValue()).getOpposite()).offsetX;
/* 143 */         y = (ForgeDirection.getOrientation(side.intValue()).getOpposite()).offsetY;
/* 144 */         z = (ForgeDirection.getOrientation(side.intValue()).getOpposite()).offsetZ;
/*     */       } 
/* 146 */       if (this.im == null) {
/* 147 */         this.im = new ItemInWorldManager(this.theGolem.worldObj);
/*     */       }
/* 149 */       if (this.theGolem.itemCarried == null && !ignoreItem) {
/* 150 */         resetTask();
/*     */         return;
/*     */       } 
/*     */       try {
/* 154 */         if (this.theGolem.getToggles()[1]) {
/* 155 */           this.theGolem.startLeftArmTimer();
/* 156 */           this.im.onBlockClicked(this.xx + x, this.yy + y, this.zz + z, side.intValue());
/*     */         }
/* 158 */         else if (this.im.activateBlockOrUseItem((EntityPlayer)this.player, this.theGolem.worldObj, this.theGolem.itemCarried, this.xx + x, this.yy + y, this.zz + z, side.intValue(), 0.5F, 0.5F, 0.5F)) {
/*     */           
/* 160 */           this.theGolem.startRightArmTimer();
/*     */         } 
/*     */         
/* 163 */         this.theGolem.itemCarried = this.player.getCurrentEquippedItem();
/* 164 */         if (this.theGolem.itemCarried.stackSize <= 0) this.theGolem.itemCarried = null; 
/* 165 */         for (int a = 1; a < this.player.inventory.mainInventory.length; a++) {
/* 166 */           if (this.player.inventory.getStackInSlot(a) != null) {
/* 167 */             if (this.theGolem.itemCarried == null) {
/* 168 */               this.theGolem.itemCarried = this.player.inventory.getStackInSlot(a).copy();
/*     */             } else {
/* 170 */               this.player.dropPlayerItemWithRandomChoice(this.player.inventory.getStackInSlot(a), false);
/*     */             } 
/* 172 */             this.player.inventory.setInventorySlotContents(a, null);
/*     */           } 
/*     */         } 
/* 175 */         this.theGolem.updateCarried();
/*     */         
/* 177 */         resetTask();
/*     */         
/*     */         return;
/* 180 */       } catch (Exception e) {
/* 181 */         resetTask();
/*     */         return;
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean findSomething() {
/* 190 */     ArrayList<Byte> matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemCarried);
/*     */     
/* 192 */     for (Iterator<Byte> i$ = matchingColors.iterator(); i$.hasNext(); ) { byte col = ((Byte)i$.next()).byteValue();
/* 193 */       ArrayList<Marker> markers = this.theGolem.getMarkers();
/*     */       
/* 195 */       for (Marker marker : markers) {
/* 196 */         if (marker.color == col || col == -1) {
/*     */           
/* 198 */           if (this.theGolem.getToggles()[0] && !this.theGolem.worldObj.isAirBlock(marker.x, marker.y, marker.z)) {
/*     */             continue;
/*     */           }
/* 201 */           if (!this.theGolem.getToggles()[0] && this.theGolem.worldObj.isAirBlock(marker.x, marker.y, marker.z)) {
/*     */             continue;
/*     */           }
/* 204 */           ForgeDirection opp = ForgeDirection.getOrientation(marker.side);
/*     */           
/* 206 */           if (!this.theGolem.worldObj.isAirBlock(marker.x + opp.offsetX, marker.y + opp.offsetY, marker.z + opp.offsetZ)) {
/*     */             continue;
/*     */           }
/* 209 */           this.color = col;
/* 210 */           this.xx = marker.x;
/* 211 */           this.yy = marker.y;
/* 212 */           this.zz = marker.z;
/* 213 */           this.block = this.theWorld.getBlock(this.xx, this.yy, this.zz);
/* 214 */           this.blockMd = this.theWorld.getBlockMetadata(this.xx, this.yy, this.zz);
/* 215 */           return true;
/*     */         } 
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/* 221 */     return false;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\interact\AIUseItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */