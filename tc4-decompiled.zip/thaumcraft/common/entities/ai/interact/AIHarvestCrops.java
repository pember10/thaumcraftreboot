/*     */ package thaumcraft.common.entities.ai.interact;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockDirectional;
/*     */ import net.minecraft.block.BlockLog;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraftforge.common.util.FakePlayer;
/*     */ import net.minecraftforge.common.util.FakePlayerFactory;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.api.BlockCoordinates;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.config.ConfigItems;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.lib.utils.BlockUtils;
/*     */ import thaumcraft.common.lib.utils.CropUtils;
/*     */ import thaumcraft.common.lib.utils.EntityUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AIHarvestCrops
/*     */   extends EntityAIBase
/*     */ {
/*     */   private EntityGolemBase theGolem;
/*     */   private int xx;
/*     */   private int yy;
/*     */   private int zz;
/*     */   private float movementSpeed;
/*     */   private float distance;
/*     */   private World theWorld;
/*  47 */   private Block block = Blocks.air;
/*  48 */   private int blockMd = 0;
/*  49 */   private int delay = -1;
/*  50 */   private int maxDelay = 1;
/*  51 */   private int mod = 1;
/*  52 */   private int count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayList<BlockCoordinates> checklist;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  67 */     if (this.delay >= 0 || this.theGolem.ticksExisted % Config.golemDelay > 0 || !this.theGolem.getNavigator().noPath()) {
/*  68 */       return false;
/*     */     }
/*     */     
/*  71 */     Vec3 var1 = findGrownCrop();
/*     */     
/*  73 */     if (var1 == null)
/*     */     {
/*  75 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  79 */     this.xx = (int)var1.xCoord;
/*  80 */     this.yy = (int)var1.yCoord;
/*  81 */     this.zz = (int)var1.zCoord;
/*     */     
/*  83 */     this.block = this.theWorld.getBlock(this.xx, this.yy, this.zz);
/*  84 */     this.blockMd = this.theWorld.getBlockMetadata(this.xx, this.yy, this.zz);
/*     */     
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  95 */     return (this.theWorld.getBlock(this.xx, this.yy, this.zz) == this.block && this.theWorld.getBlockMetadata(this.xx, this.yy, this.zz) == this.blockMd && this.count-- > 0 && (this.delay > 0 || !this.theGolem.getNavigator().noPath()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTask() {
/* 102 */     double dist = this.theGolem.getDistanceSq(this.xx + 0.5D, this.yy + 0.5D, this.zz + 0.5D);
/* 103 */     this.theGolem.getLookHelper().setLookPosition(this.xx + 0.5D, this.yy + 0.5D, this.zz + 0.5D, 30.0F, 30.0F);
/* 104 */     if (dist <= 4.0D) {
/*     */       
/* 106 */       if (this.delay < 0) {
/* 107 */         this.delay = (int)Math.max(10.0F, (20.0F - this.theGolem.getGolemStrength() * 2.0F) * this.block.getBlockHardness(this.theWorld, this.xx, this.yy, this.zz));
/* 108 */         this.maxDelay = this.delay;
/* 109 */         this.mod = this.delay / Math.round(this.delay / 6.0F);
/*     */       } 
/*     */       
/* 112 */       if (this.delay > 0) {
/* 113 */         if (--this.delay > 0 && this.delay % this.mod == 0 && this.theGolem.getNavigator().noPath()) {
/* 114 */           this.theGolem.startActionTimer();
/* 115 */           this.theWorld.playSoundEffect((this.xx + 0.5F), (this.yy + 0.5F), (this.zz + 0.5F), this.block.stepSound.getBreakSound(), (this.block.stepSound.getVolume() + 0.7F) / 8.0F, this.block.stepSound.getPitch() * 0.5F);
/*     */ 
/*     */           
/* 118 */           BlockUtils.destroyBlockPartially(this.theWorld, this.theGolem.getEntityId(), this.xx, this.yy, this.zz, (int)(9.0F * (1.0F - this.delay / this.maxDelay)));
/*     */         } 
/*     */ 
/*     */         
/* 122 */         if (this.delay == 0) {
/* 123 */           harvest();
/* 124 */           checkAdjacent();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkAdjacent() {
/* 135 */     for (int x2 = -2; x2 <= 2; x2++) {
/* 136 */       for (int z2 = -2; z2 <= 2; z2++) {
/* 137 */         for (int y2 = -1; y2 <= 1; y2++) {
/* 138 */           int x = this.xx + x2;
/* 139 */           int y = this.yy + y2;
/* 140 */           int z = this.zz + z2;
/*     */           
/* 142 */           if (Math.abs((this.theGolem.getHomePosition()).posX - x) <= this.distance && Math.abs((this.theGolem.getHomePosition()).posY - y) <= this.distance && Math.abs((this.theGolem.getHomePosition()).posZ - z) <= this.distance)
/*     */           {
/*     */ 
/*     */ 
/*     */             
/* 147 */             if (CropUtils.isGrownCrop(this.theWorld, x, y, z)) {
/*     */               
/* 149 */               Vec3 var1 = Vec3.createVectorHelper(x, y, z);
/*     */               
/* 151 */               if (var1 != null) {
/*     */                 
/* 153 */                 this.xx = (int)var1.xCoord;
/* 154 */                 this.yy = (int)var1.yCoord;
/* 155 */                 this.zz = (int)var1.zCoord;
/*     */                 
/* 157 */                 this.block = this.theWorld.getBlock(this.xx, this.yy, this.zz);
/* 158 */                 this.blockMd = this.theWorld.getBlockMetadata(this.xx, this.yy, this.zz);
/*     */                 
/* 160 */                 this.delay = -1;
/*     */                 
/* 162 */                 startExecuting();
/*     */                 return;
/*     */               } 
/*     */             }  } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void resetTask() {
/* 172 */     BlockUtils.destroyBlockPartially(this.theWorld, this.theGolem.getEntityId(), this.xx, this.yy, this.zz, -1);
/* 173 */     this.delay = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 181 */     this.count = 200;
/* 182 */     this.theGolem.getNavigator().tryMoveToXYZ(this.xx + 0.5D, this.yy + 0.5D, this.zz + 0.5D, this.theGolem.getAIMoveSpeed());
/*     */   }
/*     */   
/* 185 */   public AIHarvestCrops(EntityGolemBase par1EntityCreature) { this.checklist = new ArrayList<BlockCoordinates>();
/*     */     this.theGolem = par1EntityCreature;
/*     */     this.theWorld = par1EntityCreature.worldObj;
/*     */     setMutexBits(3);
/*     */     this.distance = MathHelper.ceiling_float_int(this.theGolem.getRange() / 4.0F); } private Vec3 findGrownCrop() {
/* 190 */     Random rand = this.theGolem.getRNG();
/*     */     
/* 192 */     if (this.checklist.size() == 0) {
/* 193 */       for (int a = (int)-this.distance; a <= this.distance; a++) {
/* 194 */         for (int b = (int)-this.distance; b <= this.distance; b++)
/* 195 */           this.checklist.add(new BlockCoordinates((this.theGolem.getHomePosition()).posX + a, 0, (this.theGolem.getHomePosition()).posZ + b)); 
/*     */       } 
/* 197 */       Collections.shuffle(this.checklist, rand);
/*     */     } 
/*     */     
/* 200 */     int x = ((BlockCoordinates)this.checklist.get(0)).x;
/* 201 */     int z = ((BlockCoordinates)this.checklist.get(0)).z;
/* 202 */     this.checklist.remove(0);
/*     */     
/* 204 */     int y = (this.theGolem.getHomePosition()).posY - 3;
/* 205 */     for (; y <= (this.theGolem.getHomePosition()).posY + 3; y++) {
/*     */       
/* 207 */       if (CropUtils.isGrownCrop(this.theWorld, x, y, z))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 213 */         return Vec3.createVectorHelper(x, y, z);
/*     */       }
/*     */     } 
/*     */     
/* 217 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   void harvest() {
/* 222 */     this.count = 200;
/* 223 */     int md = this.blockMd;
/* 224 */     FakePlayer fp = FakePlayerFactory.get((WorldServer)this.theWorld, new GameProfile((UUID)null, "FakeThaumcraftGolem"));
/* 225 */     fp.setPosition(this.theGolem.posX, this.theGolem.posY, this.theGolem.posZ);
/* 226 */     if (CropUtils.clickableCrops.contains(this.block.getUnlocalizedName() + md)) {
/* 227 */       this.block.onBlockActivated(this.theWorld, this.xx, this.yy, this.zz, (EntityPlayer)fp, 0, 0.0F, 0.0F, 0.0F);
/*     */     } else {
/*     */       
/* 230 */       this.theWorld.func_147480_a(this.xx, this.yy, this.zz, true);
/*     */ 
/*     */       
/* 233 */       if (this.theGolem.getUpgradeAmount(4) > 0) {
/* 234 */         ArrayList<ItemStack> items = new ArrayList<ItemStack>();
/* 235 */         ArrayList<Entity> drops = EntityUtils.getEntitiesInRange(this.theWorld, this.theGolem.posX, this.theGolem.posY, this.theGolem.posZ, (Entity)this.theGolem, EntityItem.class, 6.0D);
/* 236 */         if (drops.size() > 0)
/* 237 */           for (Entity e : drops) {
/* 238 */             if (e instanceof EntityItem) {
/* 239 */               if (e.ticksExisted < 2) {
/* 240 */                 Vec3 v = Vec3.createVectorHelper(e.posX - this.theGolem.posX, e.posY - this.theGolem.posY, e.posZ - this.theGolem.posZ);
/* 241 */                 v = v.normalize();
/* 242 */                 e.motionX = -v.xCoord / 4.0D;
/* 243 */                 e.motionY = 0.075D;
/* 244 */                 e.motionZ = -v.zCoord / 4.0D;
/*     */               } 
/*     */               
/* 247 */               boolean done = false;
/* 248 */               EntityItem item = (EntityItem)e;
/* 249 */               ItemStack st = item.getEntityItem();
/*     */               
/* 251 */               if (st.getItem() != null && st.getItem() == Items.dye && st.getItemDamage() == 3) {
/* 252 */                 int var5 = BlockDirectional.getDirection(this.blockMd);
/* 253 */                 int par2 = this.xx + Direction.offsetX[var5];
/* 254 */                 int par4 = this.zz + Direction.offsetZ[var5];
/* 255 */                 Block var6 = this.theWorld.getBlock(par2, this.yy, par4);
/* 256 */                 if (var6 == Blocks.log && BlockLog.func_150165_c(this.theWorld.getBlockMetadata(par2, this.yy, par4)) == 3) {
/* 257 */                   st.stackSize--;
/* 258 */                   this.theWorld.setBlock(this.xx, this.yy, this.zz, Blocks.cocoa, BlockDirectional.getDirection(this.blockMd), 3);
/*     */                 } 
/* 260 */                 done = true;
/*     */               }
/* 262 */               else if (st.getItem() != null && st.getItem() == ConfigItems.itemManaBean) {
/* 263 */                 if (this.block.canPlaceBlockOnSide(this.theWorld, this.xx, this.yy, this.zz, 0)) {
/* 264 */                   st.stackSize--;
/* 265 */                   if (!st.getItem().onItemUse(st.copy(), (EntityPlayer)fp, this.theWorld, this.xx, this.yy + 1, this.zz, 0, 0.5F, 0.5F, 0.5F)) {
/* 266 */                     this.theWorld.setBlock(this.xx, this.yy, this.zz, ConfigBlocks.blockManaPod, 0, 3);
/*     */                   }
/*     */                 } 
/* 269 */                 done = true;
/*     */ 
/*     */ 
/*     */               
/*     */               }
/*     */               else {
/*     */ 
/*     */ 
/*     */                 
/* 278 */                 int[] xm = { 0, 0, 1, 1, -1, 0, -1, -1, 1 };
/* 279 */                 int[] zm = { 0, 1, 0, 1, 0, -1, -1, 1, -1 };
/* 280 */                 int count = 0;
/* 281 */                 while (st != null && st.stackSize > 0 && count < 9) {
/* 282 */                   if (st.getItem() != null && (st.getItem() instanceof net.minecraftforge.common.IPlantable || st.getItem() instanceof net.minecraft.item.ItemSeedFood))
/*     */                   {
/*     */                     
/* 285 */                     if (st.getItem().onItemUse(st.copy(), (EntityPlayer)fp, this.theWorld, this.xx + xm[count], this.yy - 1, this.zz + zm[count], ForgeDirection.UP.ordinal(), 0.5F, 0.5F, 0.5F)) {
/* 286 */                       st.stackSize--;
/*     */                     }
/*     */                   }
/* 289 */                   count++;
/*     */                 } 
/*     */               } 
/*     */               
/* 293 */               if (st.stackSize <= 0) {
/* 294 */                 item.setDead();
/*     */               } else {
/* 296 */                 item.setEntityItemStack(st);
/*     */               } 
/*     */               
/* 299 */               if (done) {
/*     */                 break;
/*     */               }
/*     */             } 
/*     */           }  
/*     */       } 
/*     */     } 
/* 306 */     fp.setDead();
/* 307 */     this.theGolem.startActionTimer();
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\interact\AIHarvestCrops.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */