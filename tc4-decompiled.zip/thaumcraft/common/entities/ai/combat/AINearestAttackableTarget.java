/*    */ package thaumcraft.common.entities.ai.combat;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.minecraft.command.IEntitySelector;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityCreature;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.ai.EntityAITarget;
/*    */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*    */ 
/*    */ public class AINearestAttackableTarget
/*    */   extends EntityAITarget
/*    */ {
/*    */   EntityGolemBase theGolem;
/*    */   EntityLivingBase target;
/*    */   int targetChance;
/*    */   private final IEntitySelector entitySelector;
/* 20 */   private float targetDistance = 0.0F;
/*    */ 
/*    */   
/*    */   private AINearestAttackableTargetSorter theNearestAttackableTargetSorter;
/*    */ 
/*    */   
/*    */   public AINearestAttackableTarget(EntityGolemBase par1EntityLiving, int par4, boolean par5) {
/* 27 */     this(par1EntityLiving, 0.0F, par4, par5, false, (IEntitySelector)null);
/*    */   }
/*    */ 
/*    */   
/*    */   public AINearestAttackableTarget(EntityGolemBase par1, float par3, int par4, boolean par5, boolean par6, IEntitySelector par7IEntitySelector) {
/* 32 */     super((EntityCreature)par1, par5, par6);
/* 33 */     this.theGolem = par1;
/* 34 */     this.targetDistance = 0.0F;
/* 35 */     this.targetChance = par4;
/* 36 */     this.theNearestAttackableTargetSorter = new AINearestAttackableTargetSorter(this, (Entity)par1);
/* 37 */     this.entitySelector = par7IEntitySelector;
/* 38 */     setMutexBits(3);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldExecute() {
/* 46 */     this.targetDistance = this.theGolem.getRange();
/* 47 */     if (this.targetChance > 0 && this.taskOwner.getRNG().nextInt(this.targetChance) != 0)
/*    */     {
/* 49 */       return false;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 54 */     List<?> var5 = this.taskOwner.worldObj.selectEntitiesWithinAABB(EntityLivingBase.class, this.taskOwner.boundingBox.expand(this.targetDistance, 4.0D, this.targetDistance), this.entitySelector);
/*    */     
/* 56 */     Collections.sort(var5, this.theNearestAttackableTargetSorter);
/* 57 */     Iterator<?> var2 = var5.iterator();
/*    */     
/* 59 */     while (var2.hasNext()) {
/*    */       
/* 61 */       Entity var3 = (Entity)var2.next();
/* 62 */       EntityLivingBase var4 = (EntityLivingBase)var3;
/*    */       
/* 64 */       if (this.theGolem.isValidTarget(var3)) {
/*    */         
/* 66 */         this.target = var4;
/* 67 */         return true;
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 72 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void startExecuting() {
/* 81 */     this.taskOwner.setAttackTarget(this.target);
/* 82 */     super.startExecuting();
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\combat\AINearestAttackableTarget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */