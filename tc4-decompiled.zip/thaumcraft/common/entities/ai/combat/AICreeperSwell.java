/*    */ package thaumcraft.common.entities.ai.combat;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.ai.EntityAIBase;
/*    */ import thaumcraft.common.entities.monster.EntityTaintCreeper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AICreeperSwell
/*    */   extends EntityAIBase
/*    */ {
/*    */   EntityTaintCreeper swellingCreeper;
/*    */   EntityLivingBase creeperAttackTarget;
/*    */   
/*    */   public AICreeperSwell(EntityTaintCreeper par1EntityCreeper) {
/* 20 */     this.swellingCreeper = par1EntityCreeper;
/* 21 */     setMutexBits(1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldExecute() {
/* 29 */     EntityLivingBase entitylivingbase = this.swellingCreeper.getAttackTarget();
/* 30 */     return (this.swellingCreeper.getCreeperState() > 0 || (entitylivingbase != null && this.swellingCreeper.getDistanceSqToEntity((Entity)entitylivingbase) < 9.0D));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void startExecuting() {
/* 38 */     this.swellingCreeper.getNavigator().clearPathEntity();
/* 39 */     this.creeperAttackTarget = this.swellingCreeper.getAttackTarget();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void resetTask() {
/* 47 */     this.creeperAttackTarget = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void updateTask() {
/* 55 */     if (this.creeperAttackTarget == null) {
/*    */       
/* 57 */       this.swellingCreeper.setCreeperState(-1);
/*    */     }
/* 59 */     else if (this.swellingCreeper.getDistanceSqToEntity((Entity)this.creeperAttackTarget) > 49.0D) {
/*    */       
/* 61 */       this.swellingCreeper.setCreeperState(-1);
/*    */     }
/* 63 */     else if (!this.swellingCreeper.getEntitySenses().canSee((Entity)this.creeperAttackTarget)) {
/*    */       
/* 65 */       this.swellingCreeper.setCreeperState(-1);
/*    */     }
/*    */     else {
/*    */       
/* 69 */       this.swellingCreeper.setCreeperState(1);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\combat\AICreeperSwell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */