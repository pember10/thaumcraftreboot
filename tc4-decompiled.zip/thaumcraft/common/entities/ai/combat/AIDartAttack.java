/*     */ package thaumcraft.common.entities.ai.combat;
/*     */ 
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AIDartAttack
/*     */   extends EntityAIBase
/*     */ {
/*     */   private final EntityGolemBase theGolem;
/*     */   private EntityLivingBase attackTarget;
/*  22 */   private int rangedAttackTime = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private int maxRangedAttackTime;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AIDartAttack(EntityGolemBase par1IRangedAttackMob) {
/*  32 */     this.theGolem = par1IRangedAttackMob;
/*  33 */     this.maxRangedAttackTime = 30 - this.theGolem.getUpgradeAmount(0) * 8;
/*     */     
/*  35 */     this.rangedAttackTime = this.maxRangedAttackTime / 2;
/*  36 */     setMutexBits(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  44 */     EntityLivingBase var1 = this.theGolem.getAttackTarget();
/*     */     
/*  46 */     if (var1 == null)
/*     */     {
/*  48 */       return false;
/*     */     }
/*     */     
/*  51 */     if (!this.theGolem.isValidTarget((Entity)var1)) {
/*     */       
/*  53 */       this.theGolem.setAttackTarget(null);
/*  54 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  58 */     double ra = this.theGolem.getDistanceSq(var1.posX, var1.boundingBox.minY, var1.posZ);
/*  59 */     if (ra < 9.0D) return false; 
/*  60 */     this.attackTarget = var1;
/*  61 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  70 */     return (shouldExecute() && !this.theGolem.getNavigator().noPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/*  78 */     this.attackTarget = null;
/*  79 */     this.rangedAttackTime = this.maxRangedAttackTime / 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTask() {
/*  87 */     double var1 = this.theGolem.getDistanceSq(this.attackTarget.posX, this.attackTarget.boundingBox.minY, this.attackTarget.posZ);
/*  88 */     boolean var3 = this.theGolem.getEntitySenses().canSee((Entity)this.attackTarget);
/*     */ 
/*     */ 
/*     */     
/*  92 */     this.theGolem.getNavigator().tryMoveToEntityLiving((Entity)this.attackTarget, this.theGolem.getAIMoveSpeed());
/*     */     
/*  94 */     if (var3) {
/*     */       
/*  96 */       this.theGolem.getLookHelper().setLookPositionWithEntity((Entity)this.attackTarget, 30.0F, 30.0F);
/*  97 */       this.rangedAttackTime = Math.max(this.rangedAttackTime - 1, 0);
/*     */       
/*  99 */       if (this.rangedAttackTime <= 0) {
/*     */         
/* 101 */         float r = this.theGolem.getRange() * 0.8F;
/* 102 */         r *= r;
/* 103 */         if (var1 <= r && var3) {
/*     */           
/* 105 */           this.theGolem.attackEntityWithRangedAttack(this.attackTarget);
/* 106 */           this.rangedAttackTime = this.maxRangedAttackTime;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\combat\AIDartAttack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */