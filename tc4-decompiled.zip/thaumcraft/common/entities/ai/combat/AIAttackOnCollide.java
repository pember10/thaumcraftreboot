/*     */ package thaumcraft.common.entities.ai.combat;
/*     */ 
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.pathfinding.PathEntity;
/*     */ import net.minecraft.pathfinding.PathPoint;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AIAttackOnCollide
/*     */   extends EntityAIBase
/*     */ {
/*     */   World worldObj;
/*     */   EntityCreature attacker;
/*     */   int attackTick;
/*     */   double speedTowardsTarget;
/*     */   boolean longMemory;
/*     */   PathEntity entityPathEntity;
/*     */   Class classTarget;
/*     */   private int field_75445_i;
/*     */   private double field_151497_i;
/*     */   private double field_151495_j;
/*     */   private double field_151496_k;
/*     */   private static final String __OBFID = "CL_00001595";
/*     */   private int failedPathFindingPenalty;
/*     */   
/*     */   public AIAttackOnCollide(EntityCreature p_i1635_1_, Class p_i1635_2_, double p_i1635_3_, boolean p_i1635_5_) {
/*  34 */     this(p_i1635_1_, p_i1635_3_, p_i1635_5_);
/*  35 */     this.classTarget = p_i1635_2_;
/*     */   }
/*     */ 
/*     */   
/*     */   public AIAttackOnCollide(EntityCreature p_i1636_1_, double p_i1636_2_, boolean p_i1636_4_) {
/*  40 */     this.attacker = p_i1636_1_;
/*  41 */     this.worldObj = p_i1636_1_.worldObj;
/*  42 */     this.speedTowardsTarget = p_i1636_2_;
/*  43 */     this.longMemory = p_i1636_4_;
/*  44 */     setMutexBits(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  52 */     EntityLivingBase entitylivingbase = this.attacker.getAttackTarget();
/*     */     
/*  54 */     if (entitylivingbase == null)
/*     */     {
/*  56 */       return false;
/*     */     }
/*  58 */     if (!entitylivingbase.isEntityAlive())
/*     */     {
/*  60 */       return false;
/*     */     }
/*  62 */     if (this.classTarget != null && !this.classTarget.isAssignableFrom(entitylivingbase.getClass()))
/*     */     {
/*  64 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  68 */     if (--this.field_75445_i <= 0) {
/*     */       
/*  70 */       this.entityPathEntity = this.attacker.getNavigator().getPathToEntityLiving((Entity)entitylivingbase);
/*  71 */       this.field_75445_i = 4 + this.attacker.getRNG().nextInt(7);
/*  72 */       return (this.entityPathEntity != null);
/*     */     } 
/*     */ 
/*     */     
/*  76 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  86 */     EntityLivingBase entitylivingbase = this.attacker.getAttackTarget();
/*  87 */     return (entitylivingbase == null) ? false : (!entitylivingbase.isEntityAlive() ? false : (!this.longMemory ? (!this.attacker.getNavigator().noPath()) : this.attacker.isWithinHomeDistance(MathHelper.floor_double(entitylivingbase.posX), MathHelper.floor_double(entitylivingbase.posY), MathHelper.floor_double(entitylivingbase.posZ))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/*  95 */     this.attacker.getNavigator().setPath(this.entityPathEntity, this.speedTowardsTarget);
/*  96 */     this.field_75445_i = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/* 104 */     this.attacker.getNavigator().clearPathEntity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTask() {
/* 112 */     EntityLivingBase entitylivingbase = this.attacker.getAttackTarget();
/* 113 */     this.attacker.getLookHelper().setLookPositionWithEntity((Entity)entitylivingbase, 30.0F, 30.0F);
/* 114 */     double d0 = this.attacker.getDistanceSq(entitylivingbase.posX, entitylivingbase.boundingBox.minY, entitylivingbase.posZ);
/* 115 */     double d1 = (this.attacker.width * 2.0F * this.attacker.width * 2.0F + entitylivingbase.width);
/* 116 */     this.field_75445_i--;
/* 117 */     if (this.attackTick > 0) this.attackTick--;
/*     */     
/* 119 */     if ((this.longMemory || this.attacker.getEntitySenses().canSee((Entity)entitylivingbase)) && this.field_75445_i <= 0 && ((this.field_151497_i == 0.0D && this.field_151495_j == 0.0D && this.field_151496_k == 0.0D) || entitylivingbase.getDistanceSq(this.field_151497_i, this.field_151495_j, this.field_151496_k) >= 1.0D || this.attacker.getRNG().nextFloat() < 0.05F)) {
/*     */       
/* 121 */       this.field_151497_i = entitylivingbase.posX;
/* 122 */       this.field_151495_j = entitylivingbase.boundingBox.minY;
/* 123 */       this.field_151496_k = entitylivingbase.posZ;
/* 124 */       this.field_75445_i = this.failedPathFindingPenalty + 4 + this.attacker.getRNG().nextInt(7);
/*     */       
/* 126 */       if (this.attacker.getNavigator().getPath() != null) {
/*     */         
/* 128 */         PathPoint finalPathPoint = this.attacker.getNavigator().getPath().getFinalPathPoint();
/* 129 */         if (finalPathPoint != null && entitylivingbase.getDistanceSq(finalPathPoint.xCoord, finalPathPoint.yCoord, finalPathPoint.zCoord) < 1.0D)
/*     */         {
/* 131 */           this.failedPathFindingPenalty = 0;
/*     */         }
/*     */         else
/*     */         {
/* 135 */           this.failedPathFindingPenalty += 10;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 140 */         this.failedPathFindingPenalty += 10;
/*     */       } 
/*     */       
/* 143 */       if (d0 > 1024.0D) {
/*     */         
/* 145 */         this.field_75445_i += 10;
/*     */       }
/* 147 */       else if (d0 > 256.0D) {
/*     */         
/* 149 */         this.field_75445_i += 5;
/*     */       } 
/*     */       
/* 152 */       if (!this.attacker.getNavigator().tryMoveToEntityLiving((Entity)entitylivingbase, this.speedTowardsTarget))
/*     */       {
/* 154 */         this.field_75445_i += 15;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 160 */     if (d0 <= d1 && this.attackTick <= 0) {
/*     */       
/* 162 */       this.attackTick = 10;
/*     */       
/* 164 */       if (this.attacker.getHeldItem() != null)
/*     */       {
/* 166 */         this.attacker.swingItem();
/*     */       }
/*     */       
/* 169 */       this.attacker.attackEntityAsMob((Entity)entitylivingbase);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\combat\AIAttackOnCollide.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */