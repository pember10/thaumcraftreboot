/*    */ package thaumcraft.common.entities.ai.combat;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.EntityCreature;
/*    */ import net.minecraft.entity.ai.EntityAITarget;
/*    */ import net.minecraft.util.AxisAlignedBB;
/*    */ import thaumcraft.common.entities.monster.EntityCultist;
/*    */ import thaumcraft.common.entities.monster.EntityCultistCleric;
/*    */ 
/*    */ 
/*    */ public class AICultistHurtByTarget
/*    */   extends EntityAITarget
/*    */ {
/*    */   boolean entityCallsForHelp;
/*    */   private int field_142052_b;
/*    */   private static final String __OBFID = "CL_00001619";
/*    */   
/*    */   public AICultistHurtByTarget(EntityCreature p_i1660_1_, boolean p_i1660_2_) {
/* 20 */     super(p_i1660_1_, false);
/* 21 */     this.entityCallsForHelp = p_i1660_2_;
/* 22 */     setMutexBits(1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldExecute() {
/* 30 */     int i = this.taskOwner.func_142015_aE();
/* 31 */     return (i != this.field_142052_b && isSuitableTarget(this.taskOwner.getAITarget(), false));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void startExecuting() {
/* 39 */     this.taskOwner.setAttackTarget(this.taskOwner.getAITarget());
/* 40 */     this.field_142052_b = this.taskOwner.func_142015_aE();
/*    */     
/* 42 */     if (this.entityCallsForHelp) {
/*    */       
/* 44 */       double d0 = getTargetDistance();
/* 45 */       List list = this.taskOwner.worldObj.getEntitiesWithinAABB(EntityCultist.class, AxisAlignedBB.getBoundingBox(this.taskOwner.posX, this.taskOwner.posY, this.taskOwner.posZ, this.taskOwner.posX + 1.0D, this.taskOwner.posY + 1.0D, this.taskOwner.posZ + 1.0D).expand(d0, 10.0D, d0));
/* 46 */       Iterator<EntityCreature> iterator = list.iterator();
/*    */       
/* 48 */       while (iterator.hasNext()) {
/*    */         
/* 50 */         EntityCreature entitycreature = iterator.next();
/*    */         
/* 52 */         if (this.taskOwner != entitycreature && entitycreature.getAttackTarget() == null && !entitycreature.isOnSameTeam(this.taskOwner.getAITarget())) {
/*    */ 
/*    */           
/* 55 */           if (entitycreature instanceof EntityCultistCleric && ((EntityCultistCleric)entitycreature).getIsRitualist()) {
/*    */             
/* 57 */             if (this.taskOwner.worldObj.rand.nextInt(3) == 0) {
/* 58 */               ((EntityCultistCleric)entitycreature).setIsRitualist(false);
/* 59 */               entitycreature.setAttackTarget(this.taskOwner.getAITarget());
/*    */             }  continue;
/*    */           } 
/* 62 */           entitycreature.setAttackTarget(this.taskOwner.getAITarget());
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 67 */     super.startExecuting();
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\combat\AICultistHurtByTarget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */