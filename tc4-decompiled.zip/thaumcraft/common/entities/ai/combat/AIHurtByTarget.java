/*    */ package thaumcraft.common.entities.ai.combat;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.EntityCreature;
/*    */ import net.minecraft.entity.EntityLiving;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.AxisAlignedBB;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AIHurtByTarget
/*    */   extends AITarget
/*    */ {
/*    */   boolean field_75312_a;
/*    */   EntityCreature entityPathNavigate;
/*    */   
/*    */   public AIHurtByTarget(EntityCreature par1EntityLiving, boolean par2) {
/* 21 */     super(par1EntityLiving, 16.0F, false);
/* 22 */     this.field_75312_a = par2;
/* 23 */     setMutexBits(1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldExecute() {
/* 31 */     return isSuitableTarget(this.taskOwner.getAITarget(), false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean continueExecuting() {
/* 39 */     return (this.taskOwner.getAITarget() != null && this.taskOwner.getAITarget() != this.entityPathNavigate);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void startExecuting() {
/* 47 */     this.taskOwner.setAttackTarget(this.taskOwner.getAITarget());
/*    */ 
/*    */     
/* 50 */     if (this.field_75312_a) {
/*    */       
/* 52 */       List var1 = this.taskOwner.worldObj.getEntitiesWithinAABB(this.taskOwner.getClass(), AxisAlignedBB.getBoundingBox(this.taskOwner.posX, this.taskOwner.posY, this.taskOwner.posZ, this.taskOwner.posX + 1.0D, this.taskOwner.posY + 1.0D, this.taskOwner.posZ + 1.0D).expand(this.targetDistance, 4.0D, this.targetDistance));
/* 53 */       Iterator<EntityLiving> var2 = var1.iterator();
/*    */       
/* 55 */       while (var2.hasNext()) {
/*    */         
/* 57 */         EntityLiving var3 = var2.next();
/*    */         
/* 59 */         if (this.taskOwner != var3 && var3.getAttackTarget() == null)
/*    */         {
/* 61 */           var3.setAttackTarget(this.taskOwner.getAITarget());
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 66 */     super.startExecuting();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void resetTask() {
/* 74 */     if (this.taskOwner.getAttackTarget() != null && this.taskOwner.getAttackTarget() instanceof EntityPlayer && ((EntityPlayer)this.taskOwner.getAttackTarget()).capabilities.disableDamage) {
/*    */ 
/*    */       
/* 77 */       this.taskOwner.setAttackTarget(null);
/* 78 */       super.resetTask();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\combat\AIHurtByTarget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */