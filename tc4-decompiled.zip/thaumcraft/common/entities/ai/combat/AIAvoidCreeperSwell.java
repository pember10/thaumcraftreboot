/*     */ package thaumcraft.common.entities.ai.combat;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.RandomPositionGenerator;
/*     */ import net.minecraft.entity.monster.EntityCreeper;
/*     */ import net.minecraft.pathfinding.PathEntity;
/*     */ import net.minecraft.pathfinding.PathNavigate;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AIAvoidCreeperSwell
/*     */   extends EntityAIBase
/*     */ {
/*     */   private EntityGolemBase theGolem;
/*     */   private float farSpeed;
/*     */   private float nearSpeed;
/*     */   private Entity closestLivingEntity;
/*     */   private float distanceFromEntity;
/*     */   private PathEntity entityPathEntity;
/*     */   private PathNavigate entityPathNavigate;
/*     */   Vec3 targetBlock;
/*     */   
/*     */   public AIAvoidCreeperSwell(EntityGolemBase par1EntityCreature) {
/*  33 */     this.theGolem = par1EntityCreature;
/*  34 */     this.distanceFromEntity = 5.0F;
/*     */     
/*  36 */     this.entityPathNavigate = par1EntityCreature.getNavigator();
/*  37 */     setMutexBits(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  45 */     if (this.farSpeed == 0.0F) {
/*  46 */       this.farSpeed = this.theGolem.getAIMoveSpeed() * 1.125F;
/*  47 */       this.nearSpeed = this.theGolem.getAIMoveSpeed() * 1.25F;
/*     */     } 
/*     */     
/*  50 */     List<EntityCreeper> var1 = this.theGolem.worldObj.getEntitiesWithinAABB(EntityCreeper.class, this.theGolem.boundingBox.expand(this.distanceFromEntity, 3.0D, this.distanceFromEntity));
/*     */     
/*  52 */     if (var1.isEmpty())
/*     */     {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     if (((EntityCreeper)var1.get(0)).getCreeperState() != 1) return false; 
/*  58 */     this.closestLivingEntity = (Entity)var1.get(0);
/*     */ 
/*     */     
/*  61 */     if (!this.theGolem.getEntitySenses().canSee(this.closestLivingEntity))
/*     */     {
/*  63 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  67 */     Vec3 var2 = RandomPositionGenerator.findRandomTargetBlockAwayFrom((EntityCreature)this.theGolem, 16, 7, Vec3.createVectorHelper(this.closestLivingEntity.posX, this.closestLivingEntity.posY, this.closestLivingEntity.posZ));
/*     */     
/*  69 */     if (var2 == null)
/*     */     {
/*  71 */       return false;
/*     */     }
/*  73 */     if (this.closestLivingEntity.getDistanceSq(var2.xCoord, var2.yCoord, var2.zCoord) < this.closestLivingEntity.getDistanceSqToEntity((Entity)this.theGolem))
/*     */     {
/*  75 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  79 */     this.entityPathEntity = this.entityPathNavigate.getPathToXYZ(var2.xCoord, var2.yCoord, var2.zCoord);
/*  80 */     this.targetBlock = var2;
/*  81 */     return (this.entityPathEntity == null) ? false : this.entityPathEntity.isDestinationSame(var2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  93 */     return !this.entityPathNavigate.noPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 101 */     double var1 = this.targetBlock.xCoord + 0.5D - this.theGolem.posX;
/* 102 */     double var3 = this.targetBlock.zCoord + 0.5D - this.theGolem.posZ;
/* 103 */     float var5 = MathHelper.sqrt_double(var1 * var1 + var3 * var3);
/* 104 */     this.theGolem.motionX += var1 / var5 * 1.0D * 0.800000011920929D + this.theGolem.motionX * 0.20000000298023224D;
/* 105 */     this.theGolem.motionZ += var3 / var5 * 1.0D * 0.800000011920929D + this.theGolem.motionZ * 0.20000000298023224D;
/* 106 */     this.theGolem.motionY = 0.3D;
/* 107 */     this.entityPathNavigate.setPath(this.entityPathEntity, this.nearSpeed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/* 115 */     this.closestLivingEntity = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTask() {
/* 123 */     if (this.theGolem.getDistanceSqToEntity(this.closestLivingEntity) < 49.0D) {
/*     */       
/* 125 */       this.theGolem.getNavigator().setSpeed(this.nearSpeed);
/*     */     }
/*     */     else {
/*     */       
/* 129 */       this.theGolem.getNavigator().setSpeed(this.farSpeed);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\combat\AIAvoidCreeperSwell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */