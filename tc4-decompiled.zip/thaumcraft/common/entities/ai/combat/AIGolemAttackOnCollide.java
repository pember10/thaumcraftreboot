/*     */ package thaumcraft.common.entities.ai.combat;
/*     */ 
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.pathfinding.PathEntity;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AIGolemAttackOnCollide
/*     */   extends EntityAIBase
/*     */ {
/*     */   World worldObj;
/*     */   EntityGolemBase theGolem;
/*     */   EntityLivingBase entityTarget;
/*     */   int attackTick;
/*     */   PathEntity entityPathEntity;
/*     */   private int counter;
/*     */   
/*     */   public AIGolemAttackOnCollide(EntityGolemBase par1EntityLiving) {
/*  28 */     this.attackTick = 0;
/*  29 */     this.theGolem = par1EntityLiving;
/*  30 */     this.worldObj = par1EntityLiving.worldObj;
/*  31 */     setMutexBits(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  39 */     EntityLivingBase var1 = this.theGolem.getAttackTarget();
/*     */     
/*  41 */     if (var1 == null)
/*     */     {
/*  43 */       return false;
/*     */     }
/*  45 */     if (!this.theGolem.isValidTarget((Entity)var1)) {
/*     */       
/*  47 */       this.theGolem.setAttackTarget(null);
/*  48 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  52 */     this.entityTarget = var1;
/*  53 */     this.entityPathEntity = this.theGolem.getNavigator().getPathToEntityLiving((Entity)this.entityTarget);
/*  54 */     return (this.entityPathEntity != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  63 */     return (shouldExecute() && !this.theGolem.getNavigator().noPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/*  71 */     this.theGolem.getNavigator().setPath(this.entityPathEntity, this.theGolem.getAIMoveSpeed());
/*  72 */     this.counter = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/*  80 */     this.entityTarget = null;
/*  81 */     this.theGolem.getNavigator().clearPathEntity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTask() {
/*  89 */     this.theGolem.getLookHelper().setLookPositionWithEntity((Entity)this.entityTarget, 30.0F, 30.0F);
/*     */     
/*  91 */     if (this.theGolem.getEntitySenses().canSee((Entity)this.entityTarget) && --this.counter <= 0) {
/*     */       
/*  93 */       this.counter = 4 + this.theGolem.getRNG().nextInt(7);
/*  94 */       this.theGolem.getNavigator().tryMoveToEntityLiving((Entity)this.entityTarget, this.theGolem.getAIMoveSpeed());
/*     */     } 
/*     */     
/*  97 */     this.attackTick = Math.max(this.attackTick - 1, 0);
/*  98 */     double attackRange = (this.entityTarget.width * 2.0F * this.entityTarget.width * 2.0F) + 1.0D;
/*     */     
/* 100 */     if (this.theGolem.getDistanceSq(this.entityTarget.posX, this.entityTarget.boundingBox.minY, this.entityTarget.posZ) <= attackRange)
/*     */     {
/* 102 */       if (this.attackTick <= 0) {
/*     */         
/* 104 */         this.attackTick = this.theGolem.getAttackSpeed();
/*     */         
/* 106 */         if (this.theGolem.getHeldItem() != null) {
/*     */           
/* 108 */           this.theGolem.swingItem();
/*     */         } else {
/* 110 */           this.theGolem.startActionTimer();
/*     */         } 
/*     */         
/* 113 */         this.theGolem.attackEntityAsMob((Entity)this.entityTarget);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\combat\AIGolemAttackOnCollide.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */