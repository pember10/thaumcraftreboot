/*     */ package thaumcraft.common.entities.ai.fluid;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import net.minecraftforge.fluids.Fluid;
/*     */ import net.minecraftforge.fluids.FluidRegistry;
/*     */ import net.minecraftforge.fluids.FluidStack;
/*     */ import net.minecraftforge.fluids.IFluidBlock;
/*     */ import net.minecraftforge.fluids.IFluidHandler;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ import thaumcraft.common.entities.golems.Marker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AILiquidGather
/*     */   extends EntityAIBase
/*     */ {
/*     */   private EntityGolemBase theGolem;
/*     */   private int waterX;
/*     */   private int waterY;
/*     */   private int waterZ;
/*     */   private ForgeDirection markerOrientation;
/*     */   private World theWorld;
/*  38 */   private float pumpDist = 0.0F;
/*     */ 
/*     */   
/*     */   int count;
/*     */ 
/*     */   
/*     */   HashMap<ChunkCoordinates, ArrayList<SourceBlock>> queue;
/*     */ 
/*     */   
/*     */   ArrayList<ChunkCoordinates> cache;
/*     */ 
/*     */   
/*     */   ChunkCoordinates origin;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  55 */     ArrayList<FluidStack> fluids = GolemHelper.getMissingLiquids(this.theGolem);
/*  56 */     if (fluids == null) return false; 
/*  57 */     if (this.theGolem.itemWatched == null || fluids.size() == 0 || !this.theGolem.getNavigator().noPath())
/*     */     {
/*     */ 
/*     */       
/*  61 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  66 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/*  67 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*  68 */     int cX = home.posX - facing.offsetX;
/*  69 */     int cY = home.posY - facing.offsetY;
/*  70 */     int cZ = home.posZ - facing.offsetZ;
/*     */     
/*  72 */     int camt = 0;
/*  73 */     if (this.theGolem.fluidCarried != null) {
/*  74 */       camt = this.theGolem.fluidCarried.amount;
/*     */     }
/*  76 */     int max = this.theGolem.getFluidCarryLimit();
/*     */     
/*  78 */     for (FluidStack fluid : fluids) {
/*     */       
/*  80 */       ArrayList<Marker> markers = GolemHelper.getMarkedFluidHandlersAdjacentToGolem(fluid, this.theWorld, this.theGolem);
/*  81 */       for (Marker marker : markers) {
/*  82 */         TileEntity te = this.theWorld.getTileEntity(marker.x, marker.y, marker.z);
/*  83 */         if (te != null && te instanceof IFluidHandler) {
/*     */           
/*  85 */           FluidStack fs = ((IFluidHandler)te).drain(ForgeDirection.getOrientation(marker.side), new FluidStack(fluid.getFluid(), max - camt), false);
/*     */           
/*  87 */           if (fs != null && fs.amount > 0) {
/*  88 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*  94 */       ArrayList<ChunkCoordinates> coords = GolemHelper.getMarkedBlocksAdjacentToGolem(this.theWorld, this.theGolem, (byte)-1);
/*  95 */       for (ChunkCoordinates loc : coords) {
/*  96 */         Block bi = this.theWorld.getBlock(loc.posX, loc.posY, loc.posZ);
/*  97 */         if (FluidRegistry.getFluid(fluid.fluidID).getBlock() == bi) {
/*     */           
/*  99 */           if (bi instanceof IFluidBlock && ((IFluidBlock)bi).canDrain(this.theWorld, loc.posX, loc.posY, loc.posZ)) {
/* 100 */             FluidStack fs = ((IFluidBlock)bi).drain(this.theWorld, loc.posX, loc.posY, loc.posZ, false);
/* 101 */             return (fs != null && fs.amount <= max - camt);
/*     */           } 
/*     */           
/* 104 */           if (fluid.fluidID == FluidRegistry.WATER.getID() || fluid.fluidID == FluidRegistry.LAVA.getID()) {
/* 105 */             return (this.theWorld.getBlockMetadata(loc.posX, loc.posY, loc.posZ) == 0);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 111 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/* 116 */     return (this.count < 20 && this.theGolem.itemWatched != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInterruptible() {
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/* 127 */     this.count = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTask() {
/* 134 */     this.count = 0;
/* 135 */     this.theGolem.itemWatched = null;
/* 136 */     super.resetTask();
/*     */   }
/*     */   
/*     */   public AILiquidGather(EntityGolemBase par1EntityCreature)
/*     */   {
/* 141 */     this.count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     this.queue = new HashMap<ChunkCoordinates, ArrayList<SourceBlock>>();
/* 278 */     this.cache = new ArrayList<ChunkCoordinates>();
/* 279 */     this.origin = null; this.theGolem = par1EntityCreature; this.theWorld = par1EntityCreature.worldObj; setMutexBits(3); }
/*     */   public void updateTask() { this.count++; if (this.count < 10) return;  ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing); ChunkCoordinates home = this.theGolem.getHomePosition(); int cX = home.posX - facing.offsetX; int cY = home.posY - facing.offsetY; int cZ = home.posZ - facing.offsetZ; int camt = 0; if (this.theGolem.fluidCarried != null) camt = this.theGolem.fluidCarried.amount;  int max = this.theGolem.getFluidCarryLimit(); ArrayList<FluidStack> fluids = GolemHelper.getMissingLiquids(this.theGolem); if (fluids == null) return;  for (FluidStack fluidstack : fluids) { ArrayList<Marker> markers = GolemHelper.getMarkedFluidHandlersAdjacentToGolem(fluidstack, this.theWorld, this.theGolem); for (Marker marker : markers) { TileEntity te = this.theWorld.getTileEntity(marker.x, marker.y, marker.z); if (te != null && te instanceof IFluidHandler) { FluidStack fs = ((IFluidHandler)te).drain(ForgeDirection.getOrientation(marker.side), new FluidStack(fluidstack.getFluid(), max - camt), true); if (fs != null && fs.amount > 0) { if (this.theGolem.fluidCarried != null) { this.theGolem.fluidCarried.amount += fs.amount; } else { this.theGolem.fluidCarried = fs.copy(); }  if (fs.amount > 200) this.theWorld.playSoundAtEntity((Entity)this.theGolem, "game.neutral.swim", 0.2F * fs.amount / max, 1.0F + (this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat()) * 0.3F);  this.theGolem.updateCarried(); if (this.theGolem.fluidCarried.amount >= this.theGolem.getFluidCarryLimit()) this.theGolem.itemWatched = null;  this.count = 0; }  }  }  ArrayList<ChunkCoordinates> coords = GolemHelper.getMarkedBlocksAdjacentToGolem(this.theWorld, this.theGolem, (byte)-1); for (ChunkCoordinates loc : coords) { Block bi = this.theWorld.getBlock(loc.posX, loc.posY, loc.posZ); int md = this.theWorld.getBlockMetadata(loc.posX, loc.posY, loc.posZ); int i = loc.posX; int j = loc.posY; int k = loc.posZ; if (this.theGolem.getUpgradeAmount(5) > 0) { if (!this.queue.containsKey(loc) || ((ArrayList)this.queue.get(loc)).size() == 0) rebuildQueue(loc, fluidstack.getFluid());  if (this.queue.containsKey(loc) && ((ArrayList)this.queue.get(loc)).size() > 0) { ArrayList<SourceBlock> t = this.queue.get(loc); do { ChunkCoordinates current = ((SourceBlock)t.get(0)).loc; i = current.posX; j = current.posY; k = current.posZ; t.remove(0); } while (t.size() > 0 && !validFluidBlock(fluidstack.getFluid(), i, j, k)); this.queue.put(loc, t); }  }  if (FluidRegistry.getFluid(fluidstack.fluidID).getBlock() == bi) { if (bi instanceof net.minecraftforge.fluids.BlockFluidBase && ((IFluidBlock)bi).canDrain(this.theWorld, i, j, k)) { FluidStack fs = ((IFluidBlock)bi).drain(this.theWorld, i, j, k, false); if (fs != null && fs.amount <= max - camt) { ((IFluidBlock)bi).drain(this.theWorld, i, j, k, true); if (this.theGolem.fluidCarried != null) { this.theGolem.fluidCarried.amount += fs.amount; } else { this.theGolem.fluidCarried = fs.copy(); }  this.theWorld.setBlockToAir(i, j, k); this.theWorld.playSoundAtEntity((Entity)this.theGolem, "game.neutral.swim", 0.2F, 1.0F + (this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat()) * 0.3F); this.theGolem.updateCarried(); if (this.theGolem.fluidCarried.amount > this.theGolem.getFluidCarryLimit() - 1000)
/*     */                 this.theGolem.itemWatched = null;  this.count = 0; }  continue; }  if (fluidstack.fluidID == FluidRegistry.WATER.getID() || fluidstack.fluidID == FluidRegistry.LAVA.getID()) { int wmd = this.theWorld.getBlockMetadata(i, j, k); if (((FluidRegistry.lookupFluidForBlock(bi) == FluidRegistry.WATER && fluidstack.fluidID == FluidRegistry.WATER.getID()) || (FluidRegistry.lookupFluidForBlock(bi) == FluidRegistry.LAVA && fluidstack.fluidID == FluidRegistry.LAVA.getID())) && wmd == 0) { FluidStack fs = new FluidStack(fluidstack.fluidID, 1000); if (this.theGolem.fluidCarried != null) { this.theGolem.fluidCarried.amount += fs.amount; } else { this.theGolem.fluidCarried = fs.copy(); }  this.theWorld.setBlockToAir(i, j, k); this.theWorld.playSoundAtEntity((Entity)this.theGolem, "game.neutral.swim", 0.2F, 1.0F + (this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat()) * 0.3F); this.theGolem.updateCarried(); if (this.theGolem.fluidCarried.amount > this.theGolem.getFluidCarryLimit() - 1000)
/* 282 */                 this.theGolem.itemWatched = null;  this.count = 0; }  }  }  }  }  } private void rebuildQueue(ChunkCoordinates loc, Fluid fluid) { this.pumpDist = this.theGolem.getRange() * this.theGolem.getRange();
/* 283 */     this.cache.clear();
/* 284 */     this.origin = loc;
/* 285 */     ArrayList<SourceBlock> sources = new ArrayList<SourceBlock>();
/* 286 */     getConnectedFluidBlocks(this.theWorld, loc.posX, loc.posY, loc.posZ, fluid, sources);
/* 287 */     Collections.sort(sources, Collections.reverseOrder());
/* 288 */     this.queue.put(loc, sources); }
/*     */   private boolean validFluidBlock(Fluid fluid, int i, int j, int k) { Block bi = this.theWorld.getBlock(i, j, k); if (FluidRegistry.lookupFluidForBlock(bi) != fluid)
/*     */       return false;  if (bi instanceof net.minecraftforge.fluids.BlockFluidBase && ((IFluidBlock)bi).canDrain(this.theWorld, i, j, k)) { FluidStack fs = ((IFluidBlock)bi).drain(this.theWorld, i, j, k, false); if (fs != null)
/*     */         return true;  }
/*     */      if (((FluidRegistry.lookupFluidForBlock(bi) == FluidRegistry.WATER && fluid == FluidRegistry.WATER) || (FluidRegistry.lookupFluidForBlock(bi) == FluidRegistry.LAVA && fluid == FluidRegistry.LAVA)) && this.theWorld.getBlockMetadata(i, j, k) == 0)
/* 293 */       return true;  return false; } private void getConnectedFluidBlocks(World world, int x, int y, int z, Fluid fluid, ArrayList<SourceBlock> sources) { try { if (this.cache.contains(new ChunkCoordinates(x, y, z)))
/* 294 */         return;  this.cache.add(new ChunkCoordinates(x, y, z));
/* 295 */       for (int a = -1; a <= 1; ) { for (int b = -1; b <= 1; ) { for (int c = -1; c <= 1; c++)
/* 296 */           { if (a != 0 || b != 0 || c != 0)
/* 297 */             { int xx = x + a;
/* 298 */               int yy = y + b;
/* 299 */               int zz = z + c;
/* 300 */               ChunkCoordinates cc = new ChunkCoordinates(xx, yy, zz);
/* 301 */               float dist = cc.getDistanceSquaredToChunkCoordinates(this.origin);
/* 302 */               if (dist <= this.pumpDist)
/*     */               
/* 304 */               { Block bi = world.getBlock(xx, yy, zz);
/* 305 */                 if (bi == Blocks.flowing_lava) bi = Blocks.lava; 
/* 306 */                 if (bi == Blocks.flowing_water) bi = Blocks.water;
/*     */                 
/* 308 */                 Fluid fi = FluidRegistry.lookupFluidForBlock(bi);
/*     */                 
/* 310 */                 if (fi != null && fi == fluid)
/*     */                 
/* 312 */                 { if (validFluidBlock(fluid, xx, yy, zz)) {
/* 313 */                     sources.add(new SourceBlock(cc, dist));
/*     */                   }
/*     */                   
/* 316 */                   getConnectedFluidBlocks(world, xx, yy, zz, fluid, sources); }  }  }  }  b++; }  a++; }
/*     */        }
/* 318 */     catch (Exception e) {} }
/*     */ 
/*     */   
/*     */   private class SourceBlock implements Comparable {
/*     */     ChunkCoordinates loc;
/*     */     float dist;
/*     */     
/*     */     public SourceBlock(ChunkCoordinates loc, float dist) {
/* 326 */       this.loc = loc;
/* 327 */       this.dist = dist;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(SourceBlock target) {
/* 332 */       return (target.dist < this.dist) ? 1 : ((target.dist > this.dist) ? -1 : 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(Object target) {
/* 337 */       return compareTo((SourceBlock)target);
/*     */     }
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\fluid\AILiquidGather.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */