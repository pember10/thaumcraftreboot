/*     */ package thaumcraft.common.entities.ai.fluid;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.RandomPositionGenerator;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fluids.FluidStack;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AILiquidGoto
/*     */   extends EntityAIBase
/*     */ {
/*     */   private EntityGolemBase theGolem;
/*     */   private double waterX;
/*     */   private double waterY;
/*     */   private double waterZ;
/*     */   private World theWorld;
/*     */   int count;
/*     */   int prevX;
/*     */   int prevY;
/*     */   int prevZ;
/*     */   
/*     */   public boolean shouldExecute() {
/*     */     if (this.theGolem.ticksExisted % Config.golemDelay > 0 || (this.theGolem.fluidCarried != null && this.theGolem.fluidCarried.amount > this.theGolem.getFluidCarryLimit() - 1000))
/*     */       return false; 
/*     */     ArrayList<FluidStack> fluids = GolemHelper.getMissingLiquids(this.theGolem);
/*     */     for (FluidStack fluid : fluids) {
/*     */       Vec3 var1 = GolemHelper.findPossibleLiquid(fluid, this.theGolem);
/*     */       if (var1 != null) {
/*     */         this.theGolem.itemWatched = new ItemStack(Item.getItemById(fluid.fluidID), 1, fluid.amount);
/*     */         this.waterX = var1.xCoord;
/*     */         this.waterY = var1.yCoord;
/*     */         this.waterZ = var1.zCoord;
/*     */         double dd = this.theGolem.getDistance(this.waterX, this.waterY, this.waterZ);
/*     */         for (int xx = -1; xx <= 1; xx++) {
/*     */           for (int zz = -1; zz <= 1; zz++) {
/*     */             double dd2 = this.theGolem.getDistance(var1.xCoord + xx, this.waterY, var1.zCoord + zz);
/*     */             if (dd2 < dd && this.theGolem.worldObj.isBlockNormalCubeDefault((int)var1.xCoord + xx, (int)this.waterY, (int)var1.zCoord + zz, true)) {
/*     */               this.waterX = var1.xCoord + xx;
/*     */               this.waterZ = var1.zCoord + zz;
/*     */               dd = dd2;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         return true;
/*     */       } 
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   public AILiquidGoto(EntityGolemBase par1EntityCreature) {
/*  91 */     this.count = 0;
/*  92 */     this.prevX = 0;
/*  93 */     this.prevY = 0;
/*  94 */     this.prevZ = 0;
/*     */     this.theGolem = par1EntityCreature;
/*     */     this.theWorld = par1EntityCreature.worldObj;
/*     */     setMutexBits(3); } public void updateTask() {
/*  98 */     this.count--;
/*  99 */     if (this.count == 0 && this.prevX == MathHelper.floor_double(this.theGolem.posX) && this.prevY == MathHelper.floor_double(this.theGolem.posY) && this.prevZ == MathHelper.floor_double(this.theGolem.posZ)) {
/* 100 */       Vec3 var2 = RandomPositionGenerator.findRandomTarget((EntityCreature)this.theGolem, 2, 1);
/*     */       
/* 102 */       if (var2 != null) {
/*     */         
/* 104 */         this.count = 20;
/* 105 */         this.theGolem.getNavigator().tryMoveToXYZ(var2.xCoord, var2.yCoord, var2.zCoord, this.theGolem.getAIMoveSpeed());
/*     */       } 
/*     */     } 
/* 108 */     super.updateTask();
/*     */   }
/*     */   
/*     */   public boolean continueExecuting() {
/*     */     return (this.count > 0 && !this.theGolem.getNavigator().noPath());
/*     */   }
/*     */   
/*     */   public void startExecuting() {
/* 116 */     this.count = 200;
/* 117 */     this.prevX = MathHelper.floor_double(this.theGolem.posX);
/* 118 */     this.prevY = MathHelper.floor_double(this.theGolem.posY);
/* 119 */     this.prevZ = MathHelper.floor_double(this.theGolem.posZ);
/* 120 */     this.theGolem.getNavigator().tryMoveToXYZ(this.waterX, this.waterY, this.waterZ, this.theGolem.getAIMoveSpeed());
/*     */   }
/*     */   
/*     */   public void resetTask() {
/*     */     this.count = 0;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\fluid\AILiquidGoto.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */