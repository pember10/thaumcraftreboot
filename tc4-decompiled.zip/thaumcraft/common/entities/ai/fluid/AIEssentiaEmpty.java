/*     */ package thaumcraft.common.entities.ai.fluid;
/*     */ 
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChunkCoordinates;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.api.aspects.IEssentiaTransport;
/*     */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*     */ import thaumcraft.common.entities.golems.GolemHelper;
/*     */ import thaumcraft.common.tiles.TileEssentiaReservoir;
/*     */ import thaumcraft.common.tiles.TileJarFillable;
/*     */ 
/*     */ public class AIEssentiaEmpty
/*     */   extends EntityAIBase {
/*     */   private EntityGolemBase theGolem;
/*     */   private int jarX;
/*     */   private int jarY;
/*     */   private int jarZ;
/*     */   private ForgeDirection markerOrientation;
/*     */   private World theWorld;
/*     */   
/*     */   public AIEssentiaEmpty(EntityGolemBase par1EntityCreature) {
/*  25 */     this.theGolem = par1EntityCreature;
/*  26 */     this.theWorld = par1EntityCreature.worldObj;
/*  27 */     setMutexBits(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldExecute() {
/*  36 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/*  37 */     if (!this.theGolem.getNavigator().noPath() || this.theGolem.essentia == null || this.theGolem.essentiaAmount == 0)
/*     */     {
/*     */       
/*  40 */       return false;
/*     */     }
/*     */     
/*  43 */     ChunkCoordinates jarloc = GolemHelper.findJarWithRoom(this.theGolem);
/*  44 */     if (jarloc == null) {
/*  45 */       return false;
/*     */     }
/*  47 */     if (this.theGolem.getDistanceSq(jarloc.posX + 0.5D, jarloc.posY + 0.5D, jarloc.posZ + 0.5D) > 4.0D) {
/*  48 */       return false;
/*     */     }
/*  50 */     this.jarX = jarloc.posX;
/*  51 */     this.jarY = jarloc.posY;
/*  52 */     this.jarZ = jarloc.posZ;
/*  53 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  58 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startExecuting() {
/*  68 */     TileEntity tile = this.theWorld.getTileEntity(this.jarX, this.jarY, this.jarZ);
/*  69 */     if (tile != null && tile instanceof TileJarFillable) {
/*  70 */       TileJarFillable jar = (TileJarFillable)tile;
/*  71 */       this.theGolem.essentiaAmount = jar.addToContainer(this.theGolem.essentia, this.theGolem.essentiaAmount);
/*  72 */       if (this.theGolem.essentiaAmount == 0) {
/*  73 */         this.theGolem.essentia = null;
/*     */       }
/*  75 */       this.theWorld.playSoundAtEntity((Entity)this.theGolem, "game.neutral.swim", 0.2F, 1.0F + (this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat()) * 0.3F);
/*  76 */       this.theGolem.updateCarried();
/*  77 */       this.theWorld.markBlockForUpdate(this.jarX, this.jarY, this.jarZ);
/*     */     }
/*  79 */     else if (tile != null && tile instanceof TileEssentiaReservoir) {
/*  80 */       TileEssentiaReservoir trans = (TileEssentiaReservoir)tile;
/*  81 */       if (trans.getSuctionAmount(trans.facing) > 0 && (trans.getSuctionType(trans.facing) == null || trans.getSuctionType(trans.facing) == this.theGolem.essentia)) {
/*     */         
/*  83 */         int added = trans.addEssentia(this.theGolem.essentia, this.theGolem.essentiaAmount, trans.facing);
/*  84 */         if (added > 0) {
/*  85 */           this.theGolem.essentiaAmount -= added;
/*  86 */           if (this.theGolem.essentiaAmount == 0) {
/*  87 */             this.theGolem.essentia = null;
/*     */           }
/*  89 */           this.theWorld.playSoundAtEntity((Entity)this.theGolem, "game.neutral.swim", 0.2F, 1.0F + (this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat()) * 0.3F);
/*  90 */           this.theGolem.updateCarried();
/*  91 */           this.theWorld.markBlockForUpdate(this.jarX, this.jarY, this.jarZ);
/*     */         }
/*     */       
/*     */       } 
/*  95 */     } else if (tile != null && tile instanceof IEssentiaTransport) {
/*  96 */       for (Integer side : GolemHelper.getMarkedSides(this.theGolem, tile, (byte)-1)) {
/*  97 */         IEssentiaTransport trans = (IEssentiaTransport)tile;
/*  98 */         if (trans.canInputFrom(ForgeDirection.getOrientation(side.intValue())) && trans.getSuctionAmount(ForgeDirection.getOrientation(side.intValue())) > 0 && (trans.getSuctionType(ForgeDirection.getOrientation(side.intValue())) == null || trans.getSuctionType(ForgeDirection.getOrientation(side.intValue())) == this.theGolem.essentia)) {
/*     */ 
/*     */ 
/*     */           
/* 102 */           int added = trans.addEssentia(this.theGolem.essentia, this.theGolem.essentiaAmount, ForgeDirection.getOrientation(side.intValue()));
/* 103 */           if (added > 0) {
/* 104 */             this.theGolem.essentiaAmount -= added;
/* 105 */             if (this.theGolem.essentiaAmount == 0) {
/* 106 */               this.theGolem.essentia = null;
/*     */             }
/* 108 */             this.theWorld.playSoundAtEntity((Entity)this.theGolem, "game.neutral.swim", 0.2F, 1.0F + (this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat()) * 0.3F);
/* 109 */             this.theGolem.updateCarried();
/* 110 */             this.theWorld.markBlockForUpdate(this.jarX, this.jarY, this.jarZ);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\fluid\AIEssentiaEmpty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */