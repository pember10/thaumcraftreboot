/*    */ package thaumcraft.common.entities.ai.fluid;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.ai.EntityAIBase;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ChunkCoordinates;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.util.ForgeDirection;
/*    */ import net.minecraftforge.fluids.FluidStack;
/*    */ import net.minecraftforge.fluids.IFluidHandler;
/*    */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*    */ import thaumcraft.common.entities.golems.GolemHelper;
/*    */ 
/*    */ public class AILiquidEmpty
/*    */   extends EntityAIBase
/*    */ {
/*    */   private EntityGolemBase theGolem;
/*    */   private int waterX;
/*    */   private int waterY;
/*    */   private int waterZ;
/*    */   private ForgeDirection markerOrientation;
/*    */   private World theWorld;
/*    */   
/*    */   public AILiquidEmpty(EntityGolemBase par1EntityCreature) {
/* 26 */     this.theGolem = par1EntityCreature;
/* 27 */     this.theWorld = par1EntityCreature.worldObj;
/* 28 */     setMutexBits(3);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldExecute() {
/* 37 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/* 38 */     if (!this.theGolem.getNavigator().noPath() || this.theGolem.fluidCarried == null || this.theGolem.fluidCarried.amount == 0 || this.theGolem.getDistanceSq((home.posX + 0.5F), (home.posY + 0.5F), (home.posZ + 0.5F)) > 5.0D)
/*    */     {
/*    */ 
/*    */       
/* 42 */       return false;
/*    */     }
/*    */     
/* 45 */     ArrayList<FluidStack> fluids = GolemHelper.getMissingLiquids(this.theGolem);
/* 46 */     if (fluids == null) return false; 
/* 47 */     for (FluidStack fluid : fluids) {
/* 48 */       if (fluid.isFluidEqual(this.theGolem.fluidCarried)) {
/* 49 */         return true;
/*    */       }
/*    */     } 
/* 52 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean continueExecuting() {
/* 57 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void startExecuting() {
/* 67 */     ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
/* 68 */     ChunkCoordinates home = this.theGolem.getHomePosition();
/* 69 */     int cX = home.posX - facing.offsetX;
/* 70 */     int cY = home.posY - facing.offsetY;
/* 71 */     int cZ = home.posZ - facing.offsetZ;
/*    */     
/* 73 */     TileEntity tile = this.theWorld.getTileEntity(cX, cY, cZ);
/* 74 */     if (tile != null && tile instanceof IFluidHandler) {
/* 75 */       IFluidHandler fh = (IFluidHandler)tile;
/* 76 */       int amt = fh.fill(ForgeDirection.getOrientation(this.theGolem.homeFacing), this.theGolem.fluidCarried, true);
/* 77 */       this.theGolem.fluidCarried.amount -= amt;
/* 78 */       if (this.theGolem.fluidCarried.amount <= 0)
/* 79 */         this.theGolem.fluidCarried = null; 
/* 80 */       if (amt > 200)
/* 81 */         this.theWorld.playSoundAtEntity((Entity)this.theGolem, "game.neutral.swim", Math.min(0.2F, 0.2F * amt / this.theGolem.getFluidCarryLimit()), 1.0F + (this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat()) * 0.3F); 
/* 82 */       this.theGolem.updateCarried();
/* 83 */       this.theWorld.markBlockForUpdate(cX, cY, cZ);
/* 84 */       this.theGolem.itemWatched = null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\fluid\AILiquidEmpty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */