/*    */ package thaumcraft.common.entities.ai.fluid;
/*    */ 
/*    */ import net.minecraft.entity.EntityCreature;
/*    */ import net.minecraft.entity.ai.EntityAIBase;
/*    */ import net.minecraft.entity.ai.RandomPositionGenerator;
/*    */ import net.minecraft.util.ChunkCoordinates;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.util.Vec3;
/*    */ import net.minecraft.world.World;
/*    */ import thaumcraft.common.config.Config;
/*    */ import thaumcraft.common.entities.golems.EntityGolemBase;
/*    */ import thaumcraft.common.entities.golems.GolemHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AIEssentiaGoto
/*    */   extends EntityAIBase
/*    */ {
/*    */   private EntityGolemBase theGolem;
/*    */   private double jarX;
/*    */   private double jarY;
/*    */   private double jarZ;
/*    */   private World theWorld;
/*    */   int count;
/*    */   int prevX;
/*    */   int prevY;
/*    */   int prevZ;
/*    */   
/*    */   public boolean shouldExecute() {
/*    */     if (this.theGolem.ticksExisted % Config.golemDelay > 0 || this.theGolem.essentia == null || this.theGolem.essentiaAmount == 0)
/*    */       return false; 
/*    */     ChunkCoordinates jarloc = GolemHelper.findJarWithRoom(this.theGolem);
/*    */     if (jarloc == null)
/*    */       return false; 
/*    */     this.jarX = jarloc.posX;
/*    */     this.jarY = jarloc.posY;
/*    */     this.jarZ = jarloc.posZ;
/*    */     return true;
/*    */   }
/*    */   
/*    */   public AIEssentiaGoto(EntityGolemBase par1EntityCreature) {
/* 64 */     this.count = 0;
/* 65 */     this.prevX = 0;
/* 66 */     this.prevY = 0;
/* 67 */     this.prevZ = 0;
/*    */     this.theGolem = par1EntityCreature;
/*    */     this.theWorld = par1EntityCreature.worldObj;
/*    */     setMutexBits(3); } public void updateTask() {
/* 71 */     this.count--;
/* 72 */     if (this.count == 0 && this.prevX == MathHelper.floor_double(this.theGolem.posX) && this.prevY == MathHelper.floor_double(this.theGolem.posY) && this.prevZ == MathHelper.floor_double(this.theGolem.posZ)) {
/* 73 */       Vec3 var2 = RandomPositionGenerator.findRandomTarget((EntityCreature)this.theGolem, 2, 1);
/*    */       
/* 75 */       if (var2 != null) {
/*    */         
/* 77 */         this.count = 20;
/* 78 */         this.theGolem.getNavigator().tryMoveToXYZ(var2.xCoord, var2.yCoord, var2.zCoord, this.theGolem.getAIMoveSpeed());
/*    */       } 
/*    */     } 
/* 81 */     super.updateTask();
/*    */   }
/*    */   
/*    */   public boolean continueExecuting() {
/*    */     return (this.count > 0 && !this.theGolem.getNavigator().noPath());
/*    */   }
/*    */   
/*    */   public void startExecuting() {
/* 89 */     this.count = 200;
/* 90 */     this.prevX = MathHelper.floor_double(this.theGolem.posX);
/* 91 */     this.prevY = MathHelper.floor_double(this.theGolem.posY);
/* 92 */     this.prevZ = MathHelper.floor_double(this.theGolem.posZ);
/* 93 */     this.theGolem.getNavigator().tryMoveToXYZ(this.jarX, this.jarY, this.jarZ, this.theGolem.getAIMoveSpeed());
/*    */   }
/*    */   
/*    */   public void resetTask() {
/*    */     this.count = 0;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ai\fluid\AIEssentiaGoto.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */