/*     */ package thaumcraft.common.entities;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.ICrafting;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.WeightedRandomChestContent;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.ChestGenHooks;
/*     */ import thaumcraft.common.container.SlotOutput;
/*     */ import thaumcraft.common.entities.monster.EntityPech;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerPech
/*     */   extends Container
/*     */ {
/*     */   private EntityPech pech;
/*     */   private InventoryPech inventory;
/*     */   private EntityPlayer player;
/*     */   private final World theWorld;
/*     */   ChestGenHooks chest;
/*     */   
/*     */   public InventoryPech getMerchantInventory() {
/*     */     return this.inventory;
/*     */   }
/*     */   
/*     */   public void addCraftingToCrafters(ICrafting par1ICrafting) {
/*     */     super.addCraftingToCrafters(par1ICrafting);
/*     */   }
/*     */   
/*     */   public ContainerPech(InventoryPlayer par1InventoryPlayer, World par3World, EntityPech par2IMerchant) {
/*  96 */     this.chest = ChestGenHooks.getInfo("dungeonChest"); this.pech = par2IMerchant; this.theWorld = par3World; this.player = par1InventoryPlayer.player; this.inventory = new InventoryPech(par1InventoryPlayer.player, par2IMerchant, this); this.pech.trading = true; addSlotToContainer(new Slot(this.inventory, 0, 36, 29)); int i; for (i = 0; i < 2; i++) { for (int j = 0; j < 2; j++)
/*     */         addSlotToContainer((Slot)new SlotOutput(this.inventory, 1 + j + i * 2, 106 + 18 * j, 20 + 18 * i));  }  for (i = 0; i < 3; i++) { for (int j = 0; j < 9; j++)
/*     */         addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));  }  for (i = 0; i < 9; i++)
/*  99 */       addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, i, 8 + i * 18, 142));  } private boolean hasStuffInPack() { for (ItemStack stack : this.pech.loot) {
/* 100 */       if (stack != null && stack.stackSize > 0)
/* 101 */         return true; 
/*     */     } 
/* 103 */     return false; } public void detectAndSendChanges() { super.detectAndSendChanges(); }
/*     */   public boolean enchantItem(EntityPlayer par1EntityPlayer, int par2) { if (par2 == 0) {
/*     */       generateContents(); return true;
/*     */     } 
/*     */     return super.enchantItem(par1EntityPlayer, par2); }
/* 108 */   private void generateContents() { if (!this.theWorld.isRemote && this.inventory.getStackInSlot(0) != null && this.inventory.getStackInSlot(1) == null && this.inventory.getStackInSlot(2) == null && this.inventory.getStackInSlot(3) == null && this.inventory.getStackInSlot(4) == null)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 113 */       if (this.pech.isValued(this.inventory.getStackInSlot(0))) {
/* 114 */         int value = this.pech.getValue(this.inventory.getStackInSlot(0));
/* 115 */         if (this.theWorld.rand.nextInt(100) <= value / 2) {
/* 116 */           this.pech.setTamed(false);
/* 117 */           this.pech.updateAINextTick = true;
/* 118 */           this.pech.playSound("thaumcraft:pech_trade", 0.4F, 1.0F);
/*     */         } 
/*     */         
/* 121 */         if (this.theWorld.rand.nextInt(5) == 0) {
/* 122 */           value += this.theWorld.rand.nextInt(3);
/*     */         }
/* 124 */         else if (this.theWorld.rand.nextBoolean()) {
/* 125 */           value -= this.theWorld.rand.nextInt(3);
/*     */         } 
/*     */         
/* 128 */         ArrayList<List> pos = (ArrayList<List>)EntityPech.tradeInventory.get(Integer.valueOf(this.pech.getPechType()));
/* 129 */         while (value > 0) {
/* 130 */           int am = Math.min(5, Math.max((value + 1) / 2, this.theWorld.rand.nextInt(value) + 1));
/*     */ 
/*     */ 
/*     */           
/* 134 */           value -= am;
/*     */           
/* 136 */           if (am == 1 && this.theWorld.rand.nextBoolean() && hasStuffInPack()) {
/* 137 */             ArrayList<Integer> loot = new ArrayList<Integer>();
/* 138 */             for (int a = 0; a < this.pech.loot.length; a++) {
/* 139 */               if (this.pech.loot[a] != null && (this.pech.loot[a]).stackSize > 0)
/* 140 */                 loot.add(Integer.valueOf(a)); 
/*     */             } 
/* 142 */             int r = ((Integer)loot.get(this.theWorld.rand.nextInt(loot.size()))).intValue();
/* 143 */             ItemStack is = this.pech.loot[r].copy();
/* 144 */             is.stackSize = 1;
/* 145 */             mergeItemStack(is, 1, 5, false);
/* 146 */             (this.pech.loot[r]).stackSize--;
/* 147 */             if ((this.pech.loot[r]).stackSize <= 0) this.pech.loot[r] = null;  continue;
/*     */           } 
/* 149 */           if (am >= 4 && this.theWorld.rand.nextBoolean()) {
/* 150 */             WeightedRandomChestContent[] contents = this.chest.getItems(this.theWorld.rand);
/* 151 */             WeightedRandomChestContent wc = null;
/* 152 */             int cc = 0;
/*     */             do {
/* 154 */               wc = contents[this.theWorld.rand.nextInt(contents.length)];
/* 155 */               ++cc;
/* 156 */             } while (cc < 50 && (wc.theItemId == null || wc.itemWeight > 5 || wc.theMaximumChanceToGenerateItem > 1));
/*     */             
/* 158 */             if (wc == null || wc.theItemId == null) {
/* 159 */               value += am;
/*     */               continue;
/*     */             } 
/* 162 */             ItemStack is = wc.theItemId.copy();
/* 163 */             is.onCrafting(this.theWorld, this.player, 0);
/* 164 */             mergeItemStack(is, 1, 5, false); continue;
/*     */           } 
/* 166 */           List<Integer> it = null;
/*     */           while (true) {
/* 168 */             it = pos.get(this.theWorld.rand.nextInt(pos.size()));
/* 169 */             if (((Integer)it.get(0)).intValue() == am) {
/* 170 */               ItemStack is = ((ItemStack)it.get(1)).copy();
/* 171 */               is.onCrafting(this.theWorld, this.player, 0);
/* 172 */               mergeItemStack(is, 1, 5, false);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 177 */         this.inventory.decrStackSize(0, 1);
/*     */       } 
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void updateProgressBar(int par1, int par2) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer par1EntityPlayer) {
/* 191 */     return this.pech.isTamed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int par2) {
/* 200 */     ItemStack itemstack = null;
/* 201 */     Slot slot = this.inventorySlots.get(par2);
/*     */     
/* 203 */     if (slot != null && slot.getHasStack()) {
/*     */       
/* 205 */       ItemStack itemstack1 = slot.getStack();
/* 206 */       itemstack = itemstack1.copy();
/*     */       
/* 208 */       if (par2 == 0) {
/*     */         
/* 210 */         if (!mergeItemStack(itemstack1, 5, 41, true))
/*     */         {
/* 212 */           return null;
/*     */         
/*     */         }
/*     */       }
/* 216 */       else if (par2 >= 1 && par2 < 5) {
/*     */         
/* 218 */         if (!mergeItemStack(itemstack1, 5, 41, true))
/*     */         {
/* 220 */           return null;
/*     */         }
/*     */       }
/* 223 */       else if (par2 != 0) {
/*     */         
/* 225 */         if (par2 >= 5 && par2 < 41)
/*     */         {
/*     */           
/* 228 */           if (!mergeItemStack(itemstack1, 0, 1, true))
/*     */           {
/* 230 */             return null;
/*     */           }
/*     */         }
/*     */       } 
/*     */       
/* 235 */       if (itemstack1.stackSize == 0) {
/*     */         
/* 237 */         slot.putStack((ItemStack)null);
/*     */       }
/*     */       else {
/*     */         
/* 241 */         slot.onSlotChanged();
/*     */       } 
/*     */       
/* 244 */       if (itemstack1.stackSize == itemstack.stackSize)
/*     */       {
/* 246 */         return null;
/*     */       }
/*     */       
/* 249 */       slot.onPickupFromSlot(par1EntityPlayer, itemstack1);
/*     */     } 
/*     */     
/* 252 */     return itemstack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onContainerClosed(EntityPlayer par1EntityPlayer) {
/* 261 */     super.onContainerClosed(par1EntityPlayer);
/* 262 */     this.pech.trading = false;
/*     */     
/* 264 */     if (!this.theWorld.isRemote)
/*     */     {
/*     */       
/* 267 */       for (int a = 0; a < 5; a++) {
/*     */         
/* 269 */         ItemStack itemstack = this.inventory.getStackInSlotOnClosing(a);
/*     */         
/* 271 */         if (itemstack != null) {
/*     */           
/* 273 */           EntityItem ei = par1EntityPlayer.dropPlayerItemWithRandomChoice(itemstack, false);
/* 274 */           if (ei != null) {
/* 275 */             ei.func_145799_b("PechDrop");
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean mergeItemStack(ItemStack p_75135_1_, int p_75135_2_, int p_75135_3_, boolean p_75135_4_) {
/* 287 */     boolean flag1 = false;
/* 288 */     int k = p_75135_2_;
/*     */     
/* 290 */     if (p_75135_4_)
/*     */     {
/* 292 */       k = p_75135_3_ - 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 298 */     if (p_75135_1_.isStackable())
/*     */     {
/* 300 */       while (p_75135_1_.stackSize > 0 && ((!p_75135_4_ && k < p_75135_3_) || (p_75135_4_ && k >= p_75135_2_))) {
/*     */         
/* 302 */         Slot slot = this.inventorySlots.get(k);
/* 303 */         ItemStack itemstack1 = slot.getStack();
/*     */         
/* 305 */         if (itemstack1 != null && itemstack1.getItem() == p_75135_1_.getItem() && (!p_75135_1_.getHasSubtypes() || p_75135_1_.getItemDamage() == itemstack1.getItemDamage()) && ItemStack.areItemStackTagsEqual(p_75135_1_, itemstack1)) {
/*     */           
/* 307 */           int l = itemstack1.stackSize + p_75135_1_.stackSize;
/*     */           
/* 309 */           if (l <= p_75135_1_.getMaxStackSize()) {
/*     */             
/* 311 */             p_75135_1_.stackSize = 0;
/* 312 */             itemstack1.stackSize = l;
/* 313 */             slot.onSlotChanged();
/* 314 */             flag1 = true;
/*     */           }
/* 316 */           else if (itemstack1.stackSize < p_75135_1_.getMaxStackSize()) {
/*     */             
/* 318 */             p_75135_1_.stackSize -= p_75135_1_.getMaxStackSize() - itemstack1.stackSize;
/* 319 */             itemstack1.stackSize = p_75135_1_.getMaxStackSize();
/* 320 */             slot.onSlotChanged();
/* 321 */             flag1 = true;
/*     */           } 
/*     */         } 
/*     */         
/* 325 */         if (p_75135_4_) {
/*     */           
/* 327 */           k--;
/*     */           
/*     */           continue;
/*     */         } 
/* 331 */         k++;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 336 */     if (p_75135_1_.stackSize > 0) {
/*     */       
/* 338 */       if (p_75135_4_) {
/*     */         
/* 340 */         k = p_75135_3_ - 1;
/*     */       }
/*     */       else {
/*     */         
/* 344 */         k = p_75135_2_;
/*     */       } 
/*     */       
/* 347 */       while ((!p_75135_4_ && k < p_75135_3_) || (p_75135_4_ && k >= p_75135_2_)) {
/*     */         
/* 349 */         Slot slot = this.inventorySlots.get(k);
/* 350 */         ItemStack itemstack1 = slot.getStack();
/*     */         
/* 352 */         if (itemstack1 == null) {
/*     */           
/* 354 */           slot.putStack(p_75135_1_.copy());
/* 355 */           slot.onSlotChanged();
/* 356 */           p_75135_1_.stackSize = 0;
/* 357 */           flag1 = true;
/*     */           
/*     */           break;
/*     */         } 
/* 361 */         if (p_75135_4_) {
/*     */           
/* 363 */           k--;
/*     */           
/*     */           continue;
/*     */         } 
/* 367 */         k++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 372 */     return flag1;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\ContainerPech.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */