/*     */ package thaumcraft.common.entities;
/*     */ 
/*     */ import cpw.mods.fml.common.registry.IEntityAdditionalSpawnData;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ 
/*     */ public class EntityFollowingItem
/*     */   extends EntitySpecialItem implements IEntityAdditionalSpawnData {
/*  14 */   double targetX = 0.0D;
/*  15 */   double targetY = 0.0D;
/*  16 */   double targetZ = 0.0D;
/*  17 */   int type = 3;
/*  18 */   public Entity target = null;
/*  19 */   int age = 20;
/*  20 */   public double gravity = 0.03999999910593033D;
/*     */ 
/*     */   
/*     */   public EntityFollowingItem(World par1World, double par2, double par4, double par6, ItemStack par8ItemStack) {
/*  24 */     super(par1World);
/*  25 */     setSize(0.25F, 0.25F);
/*  26 */     this.yOffset = this.height / 2.0F;
/*  27 */     setPosition(par2, par4, par6);
/*  28 */     setEntityItemStack(par8ItemStack);
/*  29 */     this.rotationYaw = (float)(Math.random() * 360.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityFollowingItem(World par1World, double par2, double par4, double par6, ItemStack par8ItemStack, Entity target, int t) {
/*  35 */     this(par1World, par2, par4, par6, par8ItemStack);
/*  36 */     this.target = target;
/*  37 */     this.targetX = target.posX;
/*  38 */     this.targetY = target.boundingBox.minY + (target.height / 2.0F);
/*  39 */     this.targetZ = target.posZ;
/*  40 */     this.type = t;
/*  41 */     this.noClip = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityFollowingItem(World par1World, double par2, double par4, double par6, ItemStack par8ItemStack, double tx, double ty, double tz) {
/*  46 */     this(par1World, par2, par4, par6, par8ItemStack);
/*  47 */     this.targetX = tx;
/*  48 */     this.targetY = ty;
/*  49 */     this.targetZ = tz;
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityFollowingItem(World par1World) {
/*  54 */     super(par1World);
/*  55 */     setSize(0.25F, 0.25F);
/*  56 */     this.yOffset = this.height / 2.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  62 */     if (this.target != null) {
/*  63 */       this.targetX = this.target.posX;
/*  64 */       this.targetY = this.target.boundingBox.minY + (this.target.height / 2.0F);
/*  65 */       this.targetZ = this.target.posZ;
/*     */     } 
/*     */     
/*  68 */     if (this.targetX != 0.0D || this.targetY != 0.0D || this.targetZ != 0.0D) {
/*  69 */       float xd = (float)(this.targetX - this.posX);
/*  70 */       float yd = (float)(this.targetY - this.posY);
/*  71 */       float zd = (float)(this.targetZ - this.posZ);
/*  72 */       if (this.age > 1) this.age--;
/*     */       
/*  74 */       double distance = MathHelper.sqrt_float(xd * xd + yd * yd + zd * zd);
/*     */       
/*  76 */       if (distance > 0.5D) {
/*  77 */         distance *= this.age;
/*  78 */         this.motionX = xd / distance;
/*  79 */         this.motionY = yd / distance;
/*  80 */         this.motionZ = zd / distance;
/*     */       } else {
/*  82 */         this.motionX *= 0.10000000149011612D;
/*  83 */         this.motionY *= 0.10000000149011612D;
/*  84 */         this.motionZ *= 0.10000000149011612D;
/*  85 */         this.targetX = 0.0D;
/*  86 */         this.targetY = 0.0D;
/*  87 */         this.targetZ = 0.0D;
/*  88 */         this.target = null;
/*  89 */         this.noClip = false;
/*     */       } 
/*  91 */       if (this.worldObj.isRemote) {
/*  92 */         if (this.type != 10) {
/*  93 */           Thaumcraft.proxy.sparkle((float)this.prevPosX + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.125F, (float)this.prevPosY + this.yOffset + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.125F, (float)this.prevPosZ + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.125F, this.type);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/*  98 */           Thaumcraft.proxy.crucibleBubble(this.worldObj, (float)this.prevPosX + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.125F, (float)this.prevPosY + this.yOffset + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.125F, (float)this.prevPosZ + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.125F, 0.33F, 0.33F, 1.0F);
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 106 */       this.motionY -= this.gravity;
/*     */     } 
/*     */     
/* 109 */     super.onUpdate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
/* 119 */     super.writeEntityToNBT(par1NBTTagCompound);
/* 120 */     par1NBTTagCompound.setShort("type", (short)this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
/* 128 */     super.readEntityFromNBT(par1NBTTagCompound);
/* 129 */     this.type = par1NBTTagCompound.getShort("type");
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeSpawnData(ByteBuf data) {
/* 134 */     if (this.target != null) {
/* 135 */       data.writeInt((this.target == null) ? -1 : this.target.getEntityId());
/* 136 */       data.writeDouble(this.targetX);
/* 137 */       data.writeDouble(this.targetY);
/* 138 */       data.writeDouble(this.targetZ);
/* 139 */       data.writeByte(this.type);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void readSpawnData(ByteBuf data) {
/*     */     try {
/* 146 */       int ent = data.readInt();
/* 147 */       if (ent > -1) {
/* 148 */         this.target = this.worldObj.getEntityByID(ent);
/*     */       }
/* 150 */       this.targetX = data.readDouble();
/* 151 */       this.targetY = data.readDouble();
/* 152 */       this.targetZ = data.readDouble();
/* 153 */       this.type = data.readByte();
/* 154 */     } catch (Exception e) {}
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\entities\EntityFollowingItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */