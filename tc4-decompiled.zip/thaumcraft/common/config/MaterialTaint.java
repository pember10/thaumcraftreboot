/*    */ package thaumcraft.common.config;
/*    */ 
/*    */ import net.minecraft.block.material.MapColor;
/*    */ import net.minecraft.block.material.Material;
/*    */ 
/*    */ public class MaterialTaint extends Material {
/*    */   private int mobilityFlag;
/*    */   
/*    */   public MaterialTaint(MapColor par1MapColor) {
/* 10 */     super(par1MapColor);
/* 11 */     setNoPushMobility();
/* 12 */     setRequiresTool();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSolid() {
/* 18 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isReplaceable() {
/* 24 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getCanBlockGrass() {
/* 33 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean blocksMovement() {
/* 42 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Material setRequiresTool() {
/* 48 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Material setNoPushMobility() {
/* 55 */     this.mobilityFlag = 1;
/* 56 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMaterialMobility() {
/* 64 */     return this.mobilityFlag;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\config\MaterialTaint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */