/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.IIcon;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ import thaumcraft.common.lib.world.ThaumcraftWorldGenerator;
/*    */ 
/*    */ 
/*    */ public class BlockTaintFibresItem
/*    */   extends ItemBlock
/*    */ {
/*    */   public BlockTaintFibresItem(Block par1) {
/* 17 */     super(par1);
/* 18 */     setMaxDamage(0);
/* 19 */     setHasSubtypes(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int par1) {
/* 28 */     return par1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getColorFromItemStack(ItemStack par1ItemStack, int par2) {
/* 34 */     return ThaumcraftWorldGenerator.biomeTaint.color;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/* 40 */     return getUnlocalizedName() + "." + par1ItemStack.getItemDamage();
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public IIcon getIconFromDamage(int meta) {
/* 46 */     return ((BlockTaintFibres)ConfigBlocks.blockTaintFibres).icon[meta];
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockTaintFibresItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */