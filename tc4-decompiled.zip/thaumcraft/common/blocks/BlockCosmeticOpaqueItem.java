/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ public class BlockCosmeticOpaqueItem
/*    */   extends ItemBlock
/*    */ {
/*    */   public BlockCosmeticOpaqueItem(Block par1) {
/* 12 */     super(par1);
/* 13 */     setMaxDamage(0);
/* 14 */     setHasSubtypes(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int par1) {
/* 20 */     return par1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/* 26 */     return getUnlocalizedName() + "." + par1ItemStack.getItemDamage();
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockCosmeticOpaqueItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */