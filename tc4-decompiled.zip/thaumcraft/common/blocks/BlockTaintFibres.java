/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.ColorizerGrass;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.entities.monster.EntityTaintSpore;
/*     */ import thaumcraft.common.lib.CustomSoundType;
/*     */ import thaumcraft.common.lib.utils.BlockUtils;
/*     */ import thaumcraft.common.lib.utils.Utils;
/*     */ import thaumcraft.common.lib.world.ThaumcraftWorldGenerator;
/*     */ 
/*     */ public class BlockTaintFibres
/*     */   extends Block
/*     */ {
/*     */   public IIcon[] iconOver;
/*     */   public IIcon[] icon;
/*     */   protected int currentPass;
/*     */   
/*     */   public BlockTaintFibres() {
/*  40 */     super(Config.taintMaterial);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     this.iconOver = new IIcon[4];
/*  52 */     this.icon = new IIcon[5]; setHardness(1.0F); setResistance(5.0F);
/*     */     setStepSound((Block.SoundType)new CustomSoundType("gore", 0.5F, 0.8F));
/*     */     setTickRandomly(true);
/*     */     setCreativeTab(Thaumcraft.tabTC);
/*     */     float f = 0.2F;
/*     */     setBlockBounds(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f * 3.0F, 0.5F + f);
/*  58 */     this.currentPass = 1; } @SideOnly(Side.CLIENT) public void registerBlockIcons(IIconRegister ir) { this.icon[0] = ir.registerIcon("thaumcraft:taint_fibres");
/*  59 */     this.icon[1] = ir.registerIcon("thaumcraft:taintgrass1");
/*  60 */     this.icon[2] = ir.registerIcon("thaumcraft:taintgrass2");
/*  61 */     this.icon[3] = ir.registerIcon("thaumcraft:taint_spore_stalk_1");
/*  62 */     this.icon[4] = ir.registerIcon("thaumcraft:taint_spore_stalk_2");
/*  63 */     this.iconOver[0] = ir.registerIcon("thaumcraft:blank");
/*  64 */     for (int a = 1; a < 4; ) { this.iconOver[a] = ir.registerIcon("thaumcraft:taint_over_" + a); a++; }
/*     */      }
/*     */ 
/*     */ 
/*     */   
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/*  70 */     for (int var4 = 0; var4 <= 3; var4++)
/*     */     {
/*  72 */       par3List.add(new ItemStack(par1, 1, var4));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLightValue(IBlockAccess world, int x, int y, int z) {
/*  78 */     int md = world.getBlockMetadata(x, y, z);
/*  79 */     if (md == 2) return 8; 
/*  80 */     if (md == 4) return 10;
/*     */     
/*  82 */     return super.getLightValue(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getBlockColor() {
/*  89 */     double d0 = 0.5D;
/*  90 */     double d1 = 1.0D;
/*  91 */     return ColorizerGrass.getGrassColor(d0, d1);
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getRenderColor(int par1) {
/*  97 */     return getBlockColor();
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int colorMultiplier(IBlockAccess par1IBlockAccess, int par2, int par3, int par4) {
/* 103 */     int l = 0;
/* 104 */     int i1 = 0;
/* 105 */     int j1 = 0;
/*     */     
/* 107 */     for (int k1 = -1; k1 <= 1; k1++) {
/*     */       
/* 109 */       for (int l1 = -1; l1 <= 1; l1++) {
/*     */         
/* 111 */         int i2 = par1IBlockAccess.getBiomeGenForCoords(par2 + l1, par4 + k1).getBiomeGrassColor(par2, par3, par4);
/* 112 */         l += (i2 & 0xFF0000) >> 16;
/* 113 */         i1 += (i2 & 0xFF00) >> 8;
/* 114 */         j1 += i2 & 0xFF;
/*     */       } 
/*     */     } 
/*     */     
/* 118 */     return (l / 9 & 0xFF) << 16 | (i1 / 9 & 0xFF) << 8 | j1 / 9 & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getOverlayBlockTexture(int x, int y, int z, int side) {
/* 124 */     Random r = new Random((side + y + x * z));
/* 125 */     if (r.nextInt(100) < 95) return this.iconOver[0]; 
/* 126 */     return this.iconOver[r.nextInt(3) + 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int par1, int par2) {
/* 138 */     return this.icon[par2];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNeighborBlockChange(World world, int x, int y, int z, Block par5) {
/* 144 */     if (isOnlyAdjacentToTaint(world, x, y, z)) {
/* 145 */       world.setBlock(x, y, z, Blocks.air);
/*     */     }
/* 147 */     super.onNeighborBlockChange(world, x, y, z, par5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTick(World world, int x, int y, int z, Random random) {
/* 156 */     if (!world.isRemote) {
/*     */       
/* 158 */       int md = world.getBlockMetadata(x, y, z);
/*     */ 
/*     */       
/* 161 */       taintBiomeSpread(world, x, y, z, random, this);
/*     */ 
/*     */       
/* 164 */       if ((md == 0 && isOnlyAdjacentToTaint(world, x, y, z)) || (world.getBiomeGenForCoords(x, z)).biomeID != Config.biomeTaintID) {
/*     */         
/* 166 */         world.setBlock(x, y, z, Blocks.air);
/*     */         
/*     */         return;
/*     */       } 
/* 170 */       int xx = x + random.nextInt(3) - 1;
/* 171 */       int yy = y + random.nextInt(5) - 3;
/* 172 */       int zz = z + random.nextInt(3) - 1;
/*     */       
/* 174 */       if ((world.getBiomeGenForCoords(xx, zz)).biomeID == Config.biomeTaintID) {
/* 175 */         Block bi = world.getBlock(xx, yy, zz);
/*     */ 
/*     */         
/* 178 */         if (!spreadFibres(world, xx, yy, zz)) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 183 */           int adjacentTaint = getAdjacentTaint((IBlockAccess)world, xx, yy, zz);
/* 184 */           Material bm = world.getBlock(xx, yy, zz).getMaterial();
/*     */ 
/*     */           
/* 187 */           if (adjacentTaint >= 2 && (
/* 188 */             Utils.isWoodLog((IBlockAccess)world, xx, yy, zz) || bm == Material.gourd || bm == Material.cactus)) {
/*     */             
/* 190 */             world.setBlock(xx, yy, zz, ConfigBlocks.blockTaint, 0, 3);
/* 191 */             world.addBlockEvent(xx, yy, zz, ConfigBlocks.blockTaint, 1, 0);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 196 */           if (adjacentTaint >= 3 && bi != Blocks.air && (
/* 197 */             bm == Material.sand || bm == Material.ground || bm == Material.grass || bm == Material.clay)) {
/*     */             
/* 199 */             world.setBlock(xx, yy, zz, ConfigBlocks.blockTaint, 1, 3);
/* 200 */             world.addBlockEvent(xx, yy, zz, ConfigBlocks.blockTaint, 1, 0);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 205 */           if (md == 3 && Config.spawnTaintSpore && random.nextInt(10) == 0 && world.isAirBlock(x, y + 1, z)) {
/*     */ 
/*     */             
/* 208 */             world.setBlockMetadataWithNotify(x, y, z, 4, 3);
/* 209 */             EntityTaintSpore spore = new EntityTaintSpore(world);
/* 210 */             spore.setLocationAndAngles((x + 0.5F), (y + 1), (z + 0.5F), 0.0F, 0.0F);
/* 211 */             world.spawnEntityInWorld((Entity)spore);
/*     */           
/*     */           }
/* 214 */           else if (md == 4) {
/*     */             
/* 216 */             List<Entity> targets = world.getEntitiesWithinAABB(EntityTaintSpore.class, AxisAlignedBB.getBoundingBox(x, (y + 1), z, (x + 1), (y + 2), (z + 1)));
/*     */             
/* 218 */             if (targets.size() <= 0) {
/* 219 */               world.setBlockMetadataWithNotify(x, y, z, 3, 3);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean spreadFibres(World world, int x, int y, int z) {
/* 228 */     Block bi = world.getBlock(x, y, z);
/* 229 */     if (BlockUtils.isAdjacentToSolidBlock(world, x, y, z) && !isOnlyAdjacentToTaint(world, x, y, z) && !world.getBlock(x, y, z).getMaterial().isLiquid() && (world.isAirBlock(x, y, z) || bi.isReplaceable((IBlockAccess)world, x, y, z) || bi instanceof net.minecraft.block.BlockFlower || bi.isLeaves((IBlockAccess)world, x, y, z))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 237 */       if (world.rand.nextInt(10) == 0 && world.isAirBlock(x, y + 1, z) && world.isSideSolid(x, y - 1, z, ForgeDirection.UP))
/*     */       
/* 239 */       { if (world.rand.nextInt(10) < 9)
/* 240 */         { world.setBlock(x, y, z, ConfigBlocks.blockTaintFibres, 1, 3); }
/* 241 */         else if (world.rand.nextInt(12) < 10)
/* 242 */         { world.setBlock(x, y, z, ConfigBlocks.blockTaintFibres, 2, 3); }
/* 243 */         else { world.setBlock(x, y, z, ConfigBlocks.blockTaintFibres, 3, 3); }
/*     */          }
/* 245 */       else { world.setBlock(x, y, z, ConfigBlocks.blockTaintFibres, 0, 3); }
/*     */ 
/*     */       
/* 248 */       world.addBlockEvent(x, y, z, ConfigBlocks.blockTaintFibres, 1, 0);
/*     */       
/* 250 */       return true;
/*     */     } 
/* 252 */     return false;
/*     */   }
/*     */   
/*     */   public static void taintBiomeSpread(World world, int x, int y, int z, Random rand, Block block) {
/* 256 */     if (Config.taintSpreadRate > 0) {
/* 257 */       int xx = rand.nextInt(3) - 1;
/* 258 */       int zz = rand.nextInt(3) - 1;
/* 259 */       if ((world.getBiomeGenForCoords(x + xx, z + zz)).biomeID != Config.biomeTaintID)
/*     */       {
/* 261 */         if (rand.nextInt(Config.taintSpreadRate * 5) == 0 && getAdjacentTaint((IBlockAccess)world, x, y, z) >= 2) {
/* 262 */           Utils.setBiomeAt(world, x + xx, z + zz, ThaumcraftWorldGenerator.biomeTaint);
/* 263 */           world.addBlockEvent(x, y, z, block, 1, 0);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getAdjacentTaint(IBlockAccess world, int x, int y, int z) {
/* 271 */     int count = 0;
/* 272 */     for (int a = 0; a < 6; a++) {
/* 273 */       ForgeDirection d = ForgeDirection.getOrientation(a);
/* 274 */       int xx = x + d.offsetX;
/* 275 */       int yy = y + d.offsetY;
/* 276 */       int zz = z + d.offsetZ;
/* 277 */       Block bi = world.getBlock(xx, yy, zz);
/* 278 */       if (bi == ConfigBlocks.blockTaint || bi == ConfigBlocks.blockTaintFibres) {
/* 279 */         count++;
/*     */       }
/*     */     } 
/* 282 */     return count;
/*     */   }
/*     */   
/*     */   public static boolean isOnlyAdjacentToTaint(World world, int x, int y, int z) {
/* 286 */     for (int a = 0; a < 6; a++) {
/* 287 */       ForgeDirection d = ForgeDirection.getOrientation(a);
/* 288 */       int xx = x + d.offsetX;
/* 289 */       int yy = y + d.offsetY;
/* 290 */       int zz = z + d.offsetZ;
/* 291 */       Block bi = world.getBlock(xx, yy, zz);
/* 292 */       if (!world.isAirBlock(xx, yy, zz) && world.getBlock(xx, yy, zz).getMaterial() != Config.taintMaterial)
/* 293 */         return false; 
/*     */     } 
/* 295 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Item getItemDropped(int md, Random rand, int fortune) {
/* 306 */     return Item.getItemById(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity) {
/* 314 */     int md = world.getBlockMetadata(i, j, k);
/* 315 */     if (!world.isRemote && entity instanceof EntityLivingBase && !((EntityLivingBase)entity).isEntityUndead())
/*     */     {
/* 317 */       if (entity instanceof net.minecraft.entity.player.EntityPlayer && world.rand.nextInt(1000) == 0) {
/* 318 */         ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(Config.potionTaintPoisonID, 80, 0, false));
/*     */       }
/* 320 */       else if (!(entity instanceof net.minecraft.entity.player.EntityPlayer) && world.rand.nextInt(500) == 0) {
/* 321 */         ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(Config.potionTaintPoisonID, 160, 0, false));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean onBlockEventReceived(World world, int x, int y, int z, int id, int cd) {
/* 331 */     if (id == 1) {
/*     */       
/* 333 */       if (world.isRemote) {
/* 334 */         world.playSound(x, y, z, "thaumcraft:roots", 0.1F, 0.9F + world.rand.nextFloat() * 0.2F, false);
/*     */       }
/* 336 */       return true;
/*     */     } 
/*     */     
/* 339 */     return super.onBlockEventReceived(world, x, y, z, id, cd);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/* 345 */     return ConfigBlocks.blockTaintFibreRI;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRenderInPass(int pass) {
/* 351 */     return (pass == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRenderBlockPass() {
/* 358 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/* 366 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/* 372 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBlocksMovement(IBlockAccess par1iBlockAccess, int par2, int par3, int par4) {
/* 380 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
/* 389 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess world, int x, int y, int z) {
/* 396 */     int md = world.getBlockMetadata(x, y, z);
/*     */     
/* 398 */     if (md == 0) {
/* 399 */       float f = 0.0625F;
/*     */       try {
/* 401 */         for (int a = 0; a < 6; a++) {
/* 402 */           ForgeDirection side = ForgeDirection.getOrientation(a);
/* 403 */           if (world.isSideSolid(x + side.offsetX, y + side.offsetY, z + side.offsetZ, side.getOpposite(), false)) {
/* 404 */             switch (a) { case 0:
/* 405 */                 setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, f, 1.0F); break;
/* 406 */               case 1: setBlockBounds(0.0F, 1.0F - f, 0.0F, 1.0F, 1.0F, 1.0F); break;
/* 407 */               case 2: setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f); break;
/* 408 */               case 3: setBlockBounds(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F); break;
/* 409 */               case 4: setBlockBounds(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F); break;
/* 410 */               case 5: setBlockBounds(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); break; }
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 415 */       } catch (Throwable t) {}
/* 416 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, f, 1.0F);
/*     */     } else {
/* 418 */       setBlockBounds(0.2F, 0.0F, 0.2F, 0.8F, 0.8F, 0.8F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSideSolid(IBlockAccess world, int x, int y, int z, ForgeDirection side) {
/* 424 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canPlaceBlockAt(World par1World, int par2, int par3, int par4) {
/* 429 */     boolean biome = ((par1World.getBiomeGenForCoords(par2, par4)).biomeID == Config.biomeTaintID);
/* 430 */     return (biome && super.canPlaceBlockAt(par1World, par2, par3, par4));
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockTaintFibres.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */