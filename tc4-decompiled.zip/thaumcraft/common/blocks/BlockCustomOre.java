/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockCustomOre extends Block {
/*     */   public IIcon[] icon;
/*     */   private Random rand;
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*     */     this.icon[0] = ir.registerIcon("thaumcraft:cinnibar");
/*     */     this.icon[1] = ir.registerIcon("thaumcraft:infusedorestone");
/*     */     this.icon[2] = ir.registerIcon("thaumcraft:infusedore");
/*     */     this.icon[3] = ir.registerIcon("thaumcraft:amberore");
/*     */     this.icon[4] = ir.registerIcon("thaumcraft:frostshard");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int par1, int par2) {
/*     */     if (par2 == 0)
/*     */       return this.icon[0]; 
/*     */     if (par2 == 7)
/*     */       return this.icon[3]; 
/*     */     if (par2 == 15)
/*     */       return this.icon[4]; 
/*     */     return this.icon[1];
/*     */   }
/*     */   
/*     */   public boolean canSilkHarvest(World world, EntityPlayer player, int x, int y, int z, int metadata) {
/*     */     return true;
/*     */   }
/*     */   
/*  34 */   public BlockCustomOre() { super(Material.rock);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  42 */     this.icon = new IIcon[5];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     this.rand = new Random(); setResistance(5.0F); setHardness(1.5F); setStepSound(Block.soundTypeStone); setCreativeTab(Thaumcraft.tabTC); setTickRandomly(true); }
/*     */   public int damageDropped(int par1) { return par1; }
/*     */   @SideOnly(Side.CLIENT) public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) { par3List.add(new ItemStack(par1, 1, 0)); par3List.add(new ItemStack(par1, 1, 1)); par3List.add(new ItemStack(par1, 1, 2)); par3List.add(new ItemStack(par1, 1, 3)); par3List.add(new ItemStack(par1, 1, 4)); par3List.add(new ItemStack(par1, 1, 5)); par3List.add(new ItemStack(par1, 1, 6));
/* 152 */     par3List.add(new ItemStack(par1, 1, 7)); } public int getExpDrop(IBlockAccess world, int md, int fortune) { if (md != 0 && md != 7)
/* 153 */       return MathHelper.getRandomIntegerInRange(this.rand, 0, 3); 
/* 154 */     if (md == 7) {
/* 155 */       return MathHelper.getRandomIntegerInRange(this.rand, 1, 4);
/*     */     }
/* 157 */     return super.getExpDrop(world, md, fortune); } @SideOnly(Side.CLIENT) public boolean addHitEffects(World worldObj, MovingObjectPosition target, EffectRenderer effectRenderer) { int md = worldObj.getBlockMetadata(target.blockX, target.blockY, target.blockZ); if (md != 0 && md < 6) UtilsFX.infusedStoneSparkle(worldObj, target.blockX, target.blockY, target.blockZ, md);  return super.addHitEffects(worldObj, target, effectRenderer); }
/*     */   public boolean addDestroyEffects(World world, int x, int y, int z, int meta, EffectRenderer effectRenderer) { return super.addDestroyEffects(world, x, y, z, meta, effectRenderer); }
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess par1iBlockAccess, int par2, int par3, int par4) { setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); super.setBlockBoundsBasedOnState(par1iBlockAccess, par2, par3, par4); }
/*     */   public void addCollisionBoxesToList(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, List arraylist, Entity par7Entity) { setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity); }
/*     */   public ArrayList<ItemStack> getDrops(World world, int x, int y, int z, int md, int fortune) { ArrayList<ItemStack> ret = new ArrayList<ItemStack>(); if (md == 0) { ret.add(new ItemStack(ConfigBlocks.blockCustomOre, 1, 0)); } else if (md == 7) { ret.add(new ItemStack(ConfigItems.itemResource, 1 + world.rand.nextInt(fortune + 1), 6)); } else { int q = 1 + world.rand.nextInt(2 + fortune); for (int a = 0; a < q; a++) ret.add(new ItemStack(ConfigItems.itemShard, 1, md - 1));  }  return ret; }
/* 162 */   public boolean isSideSolid(IBlockAccess world, int x, int y, int z, ForgeDirection side) { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/* 174 */     return ConfigBlocks.blockCustomOreRI;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockCustomOre.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */