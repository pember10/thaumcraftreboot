/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.ChatComponentText;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import net.minecraftforge.fluids.FluidContainerRegistry;
/*     */ import net.minecraftforge.fluids.FluidStack;
/*     */ import thaumcraft.api.ThaumcraftApiHelper;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.items.wands.ItemWandCasting;
/*     */ import thaumcraft.common.lib.utils.InventoryUtils;
/*     */ import thaumcraft.common.tiles.TileAlchemyFurnace;
/*     */ import thaumcraft.common.tiles.TileFluxScrubber;
/*     */ import thaumcraft.common.tiles.TileFocalManipulator;
/*     */ import thaumcraft.common.tiles.TileInfusionMatrix;
/*     */ import thaumcraft.common.tiles.TileInfusionPillar;
/*     */ import thaumcraft.common.tiles.TileNodeConverter;
/*     */ import thaumcraft.common.tiles.TileNodeStabilizer;
/*     */ import thaumcraft.common.tiles.TilePedestal;
/*     */ import thaumcraft.common.tiles.TileSpa;
/*     */ import thaumcraft.common.tiles.TileWandPedestal;
/*     */ 
/*     */ public class BlockStoneDevice extends BlockContainer {
/*     */   public IIcon[] iconFurnace;
/*     */   public IIcon[] iconPedestal;
/*     */   public IIcon[] iconWandPedestal;
/*     */   public IIcon[] iconWandPedestalFocus;
/*     */   public IIcon[] iconSpa;
/*     */   
/*  55 */   public BlockStoneDevice() { super(Material.rock);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     this.iconFurnace = new IIcon[5];
/*  64 */     this.iconPedestal = new IIcon[2];
/*  65 */     this.iconWandPedestal = new IIcon[2];
/*  66 */     this.iconWandPedestalFocus = new IIcon[3];
/*  67 */     this.iconSpa = new IIcon[2];
/*     */     setHardness(3.0F);
/*     */     setResistance(25.0F);
/*     */     setStepSound(Block.soundTypeStone);
/*     */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  72 */     setCreativeTab(Thaumcraft.tabTC); } @SideOnly(Side.CLIENT) public void registerBlockIcons(IIconRegister ir) { this.iconPedestal[0] = ir.registerIcon("thaumcraft:pedestal_side");
/*  73 */     this.iconPedestal[1] = ir.registerIcon("thaumcraft:pedestal_top");
/*  74 */     this.iconWandPedestal[0] = ir.registerIcon("thaumcraft:wandpedestal_side");
/*  75 */     this.iconWandPedestal[1] = ir.registerIcon("thaumcraft:wandpedestal_top");
/*  76 */     this.iconWandPedestalFocus[0] = ir.registerIcon("thaumcraft:wandpedestal_focus_side");
/*  77 */     this.iconWandPedestalFocus[1] = ir.registerIcon("thaumcraft:wandpedestal_focus_top");
/*  78 */     this.iconWandPedestalFocus[2] = ir.registerIcon("thaumcraft:wandpedestal_focus_bot");
/*  79 */     this.iconFurnace[0] = ir.registerIcon("thaumcraft:al_furnace_side");
/*  80 */     this.iconFurnace[1] = ir.registerIcon("thaumcraft:al_furnace_top");
/*  81 */     this.iconFurnace[2] = ir.registerIcon("thaumcraft:al_furnace_front_off");
/*  82 */     this.iconFurnace[3] = ir.registerIcon("thaumcraft:al_furnace_front_on");
/*  83 */     this.iconFurnace[4] = ir.registerIcon("thaumcraft:al_furnace_top_filled");
/*  84 */     this.iconSpa[0] = ir.registerIcon("thaumcraft:spa_side");
/*  85 */     this.iconSpa[1] = ir.registerIcon("thaumcraft:spa_top"); }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/*  90 */     return ConfigBlocks.blockStoneDeviceRI;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIcon getIcon(int side, int md) {
/* 107 */     if (md == 0) {
/* 108 */       if (side == 1) return this.iconFurnace[1]; 
/* 109 */       if (side > 1) return this.iconFurnace[2];
/*     */     
/* 111 */     } else if (md == 1) {
/* 112 */       if (side <= 1) return this.iconPedestal[1]; 
/* 113 */       if (side > 1) return this.iconPedestal[0];
/*     */     
/*     */     }
/* 116 */     else if (md == 5) {
/* 117 */       if (side == 0) return this.iconPedestal[1]; 
/* 118 */       if (side == 1) return this.iconWandPedestal[1]; 
/* 119 */       if (side > 1) return this.iconWandPedestal[0];
/*     */     
/*     */     }
/* 122 */     else if (md == 8) {
/* 123 */       if (side == 0) return this.iconWandPedestalFocus[2]; 
/* 124 */       if (side == 1) return this.iconWandPedestalFocus[1]; 
/* 125 */       if (side > 1) return this.iconWandPedestalFocus[0];
/*     */     
/* 127 */     } else if (md == 12) {
/* 128 */       if (side == 0) return this.iconPedestal[1]; 
/* 129 */       if (side == 1) return this.iconSpa[1]; 
/* 130 */       if (side > 1) return this.iconSpa[0]; 
/*     */     } 
/* 132 */     return this.iconPedestal[1];
/*     */   }
/*     */ 
/*     */   
/*     */   public IIcon getIcon(IBlockAccess iblockaccess, int i, int j, int k, int side) {
/* 137 */     int metadata = iblockaccess.getBlockMetadata(i, j, k);
/* 138 */     if (metadata == 0) {
/* 139 */       TileEntity te = iblockaccess.getTileEntity(i, j, k);
/* 140 */       if (side == 1) {
/* 141 */         if (te != null && te instanceof TileAlchemyFurnace && ((TileAlchemyFurnace)te).vis > 0) {
/* 142 */           return this.iconFurnace[4];
/*     */         }
/* 144 */         return this.iconFurnace[1];
/*     */       } 
/* 146 */       if (side > 1)
/*     */       {
/* 148 */         if (te != null && te instanceof TileAlchemyFurnace && ((TileAlchemyFurnace)te).isBurning()) {
/* 149 */           return this.iconFurnace[3];
/*     */         }
/* 151 */         return this.iconFurnace[2];
/*     */       }
/*     */     
/*     */     }
/* 155 */     else if (metadata == 1 || metadata == 5 || metadata == 8 || metadata == 12) {
/* 156 */       return super.getIcon(iblockaccess, i, j, k, side);
/*     */     } 
/* 158 */     return this.iconFurnace[0];
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/* 164 */     par3List.add(new ItemStack(par1, 1, 0));
/* 165 */     par3List.add(new ItemStack(par1, 1, 1));
/* 166 */     par3List.add(new ItemStack(par1, 1, 2));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     par3List.add(new ItemStack(par1, 1, 5));
/* 172 */     par3List.add(new ItemStack(par1, 1, 8));
/* 173 */     par3List.add(new ItemStack(par1, 1, 9));
/* 174 */     par3List.add(new ItemStack(par1, 1, 10));
/* 175 */     par3List.add(new ItemStack(par1, 1, 11));
/* 176 */     par3List.add(new ItemStack(par1, 1, 12));
/* 177 */     par3List.add(new ItemStack(par1, 1, 13));
/* 178 */     par3List.add(new ItemStack(par1, 1, 14));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World w, int i, int j, int k, Random r) {
/* 186 */     TileEntity te = w.getTileEntity(i, j, k);
/* 187 */     if (te != null && te instanceof TileAlchemyFurnace && (
/* 188 */       (TileAlchemyFurnace)te).isBurning()) {
/* 189 */       float f = i + 0.5F;
/* 190 */       float f1 = j + 0.2F + r.nextFloat() * 5.0F / 16.0F;
/* 191 */       float f2 = k + 0.5F;
/* 192 */       float f3 = 0.52F;
/* 193 */       float f4 = r.nextFloat() * 0.5F - 0.25F;
/*     */       
/* 195 */       w.spawnParticle("smoke", (f - f3), f1, (f2 + f4), 0.0D, 0.0D, 0.0D);
/* 196 */       w.spawnParticle("flame", (f - f3), f1, (f2 + f4), 0.0D, 0.0D, 0.0D);
/*     */       
/* 198 */       w.spawnParticle("smoke", (f + f3), f1, (f2 + f4), 0.0D, 0.0D, 0.0D);
/* 199 */       w.spawnParticle("flame", (f + f3), f1, (f2 + f4), 0.0D, 0.0D, 0.0D);
/*     */       
/* 201 */       w.spawnParticle("smoke", (f + f4), f1, (f2 - f3), 0.0D, 0.0D, 0.0D);
/* 202 */       w.spawnParticle("flame", (f + f4), f1, (f2 - f3), 0.0D, 0.0D, 0.0D);
/*     */       
/* 204 */       w.spawnParticle("smoke", (f + f4), f1, (f2 + f3), 0.0D, 0.0D, 0.0D);
/* 205 */       w.spawnParticle("flame", (f + f4), f1, (f2 + f3), 0.0D, 0.0D, 0.0D);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightValue(IBlockAccess world, int x, int y, int z) {
/* 212 */     int meta = world.getBlockMetadata(x, y, z);
/* 213 */     if (meta == 0) {
/* 214 */       TileEntity te = world.getTileEntity(x, y, z);
/* 215 */       if (te != null && te instanceof TileAlchemyFurnace && ((TileAlchemyFurnace)te).isBurning())
/*     */       {
/* 217 */         return 12;
/*     */       }
/*     */     }
/* 220 */     else if (meta == 2) {
/* 221 */       return 10;
/*     */     } 
/* 223 */     return super.getLightValue(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int damageDropped(int metadata) {
/* 229 */     return (metadata == 3) ? 7 : ((metadata == 4) ? 6 : metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public Item getItemDropped(int metadata, Random par2Random, int par3) {
/* 234 */     return (metadata == 3 || metadata == 4) ? Item.getItemFromBlock(ConfigBlocks.blockCosmeticSolid) : super.getItemDropped(metadata, par2Random, par3);
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createTileEntity(World world, int metadata) {
/* 239 */     if (metadata == 0) return (TileEntity)new TileAlchemyFurnace(); 
/* 240 */     if (metadata == 1) return (TileEntity)new TilePedestal(); 
/* 241 */     if (metadata == 2) return (TileEntity)new TileInfusionMatrix(); 
/* 242 */     if (metadata == 3) return (TileEntity)new TileInfusionPillar(); 
/* 243 */     if (metadata == 5) return (TileEntity)new TileWandPedestal(); 
/* 244 */     if (metadata == 9 || metadata == 10) return (TileEntity)new TileNodeStabilizer(); 
/* 245 */     if (metadata == 11) return (TileEntity)new TileNodeConverter(); 
/* 246 */     if (metadata == 12) return (TileEntity)new TileSpa(); 
/* 247 */     if (metadata == 13) return (TileEntity)new TileFocalManipulator(); 
/* 248 */     if (metadata == 14) return (TileEntity)new TileFluxScrubber(); 
/* 249 */     return super.createTileEntity(world, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasComparatorInputOverride() {
/* 254 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getComparatorInputOverride(World world, int x, int y, int z, int rs) {
/* 260 */     TileEntity te = world.getTileEntity(x, y, z);
/* 261 */     if (te != null && (te instanceof TilePedestal || te instanceof TileAlchemyFurnace)) {
/* 262 */       return Container.calcRedstoneFromInventory((IInventory)te);
/*     */     }
/* 264 */     if (te != null && te instanceof TileWandPedestal && ((TileWandPedestal)te).getAspects() != null && ((TileWandPedestal)te).getStackInSlot(0) != null && ((TileWandPedestal)te).getStackInSlot(0).getItem() instanceof ItemWandCasting) {
/*     */ 
/*     */ 
/*     */       
/* 268 */       ItemWandCasting wand = (ItemWandCasting)((TileWandPedestal)te).getStackInSlot(0).getItem();
/* 269 */       float r = wand.getAllVis(((TileWandPedestal)te).getStackInSlot(0)).visSize() / wand.getMaxVis(((TileWandPedestal)te).getStackInSlot(0)) * 6.0F;
/*     */       
/* 271 */       return MathHelper.floor_float(r * 14.0F) + 1;
/*     */     } 
/* 273 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World var1, int md) {
/* 278 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void breakBlock(World par1World, int par2, int par3, int par4, Block par5, int par6) {
/* 284 */     InventoryUtils.dropItems(par1World, par2, par3, par4);
/* 285 */     TileEntity tileEntity = par1World.getTileEntity(par2, par3, par4);
/* 286 */     if (tileEntity != null && tileEntity instanceof TileInfusionMatrix && 
/* 287 */       ((TileInfusionMatrix)tileEntity).crafting) {
/* 288 */       par1World.createExplosion(null, par2 + 0.5D, par3 + 0.5D, par4 + 0.5D, 2.0F, true);
/*     */     }
/*     */     
/* 291 */     super.breakBlock(par1World, par2, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNeighborBlockChange(World world, int x, int y, int z, Block par5) {
/* 296 */     TileEntity te = world.getTileEntity(x, y, z);
/* 297 */     if (te != null && te instanceof TileAlchemyFurnace) {
/* 298 */       ((TileAlchemyFurnace)te).getBellows();
/*     */     }
/* 300 */     else if (te != null && te instanceof TileNodeConverter) {
/* 301 */       ((TileNodeConverter)te).checkStatus();
/*     */     } else {
/* 303 */       int metadata = world.getBlockMetadata(x, y, z);
/* 304 */       if (metadata == 1) {
/* 305 */         if (!world.isAirBlock(x, y + 1, z)) {
/* 306 */           InventoryUtils.dropItems(world, x, y, z);
/*     */         }
/*     */       }
/* 309 */       else if (metadata == 5) {
/* 310 */         if (!world.isAirBlock(x, y + 1, z) && (world.getBlock(x, y + 1, z) != this || world.getBlockMetadata(x, y + 1, z) != 8))
/*     */         {
/*     */           
/* 313 */           InventoryUtils.dropItems(world, x, y, z);
/*     */         }
/*     */       }
/* 316 */       else if (metadata == 3) {
/* 317 */         if (world.getBlock(x, y + 1, z) != this || world.getBlockMetadata(x, y + 1, z) != 4) {
/* 318 */           dropBlockAsItem(world, x, y, z, metadata, 0);
/* 319 */           world.setBlock(x, y, z, Blocks.air, 0, 3);
/*     */         }
/*     */       
/* 322 */       } else if (metadata == 4 && (
/* 323 */         world.getBlock(x, y - 1, z) != this || world.getBlockMetadata(x, y - 1, z) != 3)) {
/* 324 */         dropBlockAsItem(world, x, y, z, metadata, 0);
/* 325 */         world.setBlock(x, y, z, Blocks.air, 0, 3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float par7, float par8, float par9) {
/* 338 */     if (world.isRemote) return true; 
/* 339 */     int metadata = world.getBlockMetadata(x, y, z);
/* 340 */     TileEntity tileEntity = world.getTileEntity(x, y, z);
/*     */     
/* 342 */     if (metadata == 0 && tileEntity instanceof TileAlchemyFurnace && !player.isSneaking()) {
/* 343 */       player.openGui(Thaumcraft.instance, 9, world, x, y, z);
/* 344 */       return true;
/*     */     } 
/*     */     
/* 347 */     if (metadata == 1 && tileEntity instanceof TilePedestal) {
/* 348 */       TilePedestal ped = (TilePedestal)tileEntity;
/* 349 */       if (ped.getStackInSlot(0) != null) {
/* 350 */         InventoryUtils.dropItemsAtEntity(world, x, y, z, (Entity)player);
/*     */         
/* 352 */         world.playSoundEffect(x, y, z, "random.pop", 0.2F, ((world.rand.nextFloat() - world.rand.nextFloat()) * 0.7F + 1.0F) * 1.5F);
/*     */ 
/*     */         
/* 355 */         return true;
/*     */       } 
/* 357 */       if (player.getCurrentEquippedItem() != null) {
/* 358 */         ItemStack i = player.getCurrentEquippedItem().copy();
/* 359 */         i.stackSize = 1;
/* 360 */         ped.setInventorySlotContents(0, i);
/* 361 */         (player.getCurrentEquippedItem()).stackSize--;
/* 362 */         if ((player.getCurrentEquippedItem()).stackSize == 0) {
/* 363 */           player.setCurrentItemOrArmor(0, null);
/*     */         }
/* 365 */         player.inventory.markDirty();
/*     */         
/* 367 */         world.playSoundEffect(x, y, z, "random.pop", 0.2F, ((world.rand.nextFloat() - world.rand.nextFloat()) * 0.7F + 1.0F) * 1.6F);
/*     */         
/* 369 */         return true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 374 */     if (metadata == 8) {
/* 375 */       y--;
/* 376 */       metadata = world.getBlockMetadata(x, y, z);
/* 377 */       tileEntity = world.getTileEntity(x, y, z);
/*     */     } 
/*     */     
/* 380 */     if (metadata == 5 && tileEntity instanceof TileWandPedestal) {
/* 381 */       if (player.inventory.getCurrentItem() != null && player.inventory.getCurrentItem().isItemEqual(new ItemStack((Block)this, 1, 8)))
/*     */       {
/* 383 */         return false; } 
/* 384 */       TileWandPedestal ped = (TileWandPedestal)tileEntity;
/* 385 */       if (ped.getStackInSlot(0) != null) {
/* 386 */         InventoryUtils.dropItemsAtEntity(world, x, y, z, (Entity)player);
/* 387 */         world.markBlockForUpdate(x, y, z);
/* 388 */         ped.markDirty();
/* 389 */         world.playSoundEffect(x, y, z, "random.pop", 0.2F, ((world.rand.nextFloat() - world.rand.nextFloat()) * 0.7F + 1.0F) * 1.5F);
/*     */ 
/*     */         
/* 392 */         return true;
/*     */       } 
/* 394 */       if (player.getCurrentEquippedItem() != null && (player.getCurrentEquippedItem().getItem() instanceof ItemWandCasting || player.getCurrentEquippedItem().getItem() instanceof thaumcraft.common.items.baubles.ItemAmuletVis)) {
/*     */ 
/*     */         
/* 397 */         ItemStack i = player.getCurrentEquippedItem().copy();
/* 398 */         i.stackSize = 1;
/* 399 */         ped.setInventorySlotContents(0, i);
/* 400 */         (player.getCurrentEquippedItem()).stackSize--;
/* 401 */         if ((player.getCurrentEquippedItem()).stackSize == 0) {
/* 402 */           player.setCurrentItemOrArmor(0, null);
/*     */         }
/* 404 */         player.inventory.markDirty();
/* 405 */         world.markBlockForUpdate(x, y, z);
/* 406 */         ped.markDirty();
/* 407 */         world.playSoundEffect(x, y, z, "random.pop", 0.2F, ((world.rand.nextFloat() - world.rand.nextFloat()) * 0.7F + 1.0F) * 1.6F);
/*     */         
/* 409 */         return true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 414 */     if (metadata == 12 && tileEntity instanceof TileSpa && !player.isSneaking()) {
/*     */       
/* 416 */       FluidStack fs = FluidContainerRegistry.getFluidForFilledItem(player.inventory.getCurrentItem());
/* 417 */       if (fs != null) {
/* 418 */         int volume = fs.amount;
/* 419 */         TileSpa tile = (TileSpa)tileEntity;
/* 420 */         if (tile.tank.getFluidAmount() < tile.tank.getCapacity() && (tile.tank.getFluid() == null || tile.tank.getFluid().isFluidEqual(fs))) {
/*     */           
/* 422 */           tile.fill(ForgeDirection.UNKNOWN, FluidContainerRegistry.getFluidForFilledItem(player.inventory.getCurrentItem()), true);
/* 423 */           ItemStack emptyContainer = null;
/* 424 */           FluidContainerRegistry.FluidContainerData[] fcs = FluidContainerRegistry.getRegisteredFluidContainerData();
/* 425 */           for (FluidContainerRegistry.FluidContainerData fcd : fcs) {
/* 426 */             if (fcd.filledContainer.isItemEqual(player.inventory.getCurrentItem())) {
/* 427 */               emptyContainer = fcd.emptyContainer.copy();
/*     */             }
/*     */           } 
/*     */           
/* 431 */           player.inventory.decrStackSize(player.inventory.currentItem, 1);
/* 432 */           if (emptyContainer != null && 
/* 433 */             !player.inventory.addItemStackToInventory(emptyContainer)) {
/* 434 */             player.dropPlayerItemWithRandomChoice(emptyContainer, false);
/*     */           }
/*     */           
/* 437 */           player.inventoryContainer.detectAndSendChanges();
/* 438 */           tile.markDirty();
/* 439 */           world.markBlockForUpdate(x, y, z);
/* 440 */           world.playSoundEffect(x + 0.5D, y + 0.5D, z + 0.5D, "game.neutral.swim", 0.33F, 1.0F + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.3F);
/*     */         } 
/*     */       } else {
/*     */         
/* 444 */         player.openGui(Thaumcraft.instance, 19, world, x, y, z);
/*     */       } 
/* 446 */       return true;
/*     */     } 
/*     */     
/* 449 */     if (metadata == 13 && tileEntity instanceof TileFocalManipulator && !player.isSneaking()) {
/* 450 */       if (ThaumcraftApiHelper.isResearchComplete(player.getCommandSenderName(), "FOCALMANIPULATION")) {
/* 451 */         player.openGui(Thaumcraft.instance, 20, world, x, y, z);
/* 452 */       } else if (!world.isRemote) {
/* 453 */         player.addChatMessage((IChatComponent)new ChatComponentText(EnumChatFormatting.RED + StatCollector.translateToLocal("tc.researchmissing")));
/*     */       } 
/* 455 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 459 */     return super.onBlockActivated(world, x, y, z, player, side, par7, par8, par9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCollisionBoxesToList(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, List arraylist, Entity par7Entity) {
/* 467 */     int metadata = world.getBlockMetadata(i, j, k);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 477 */     if (metadata == 5) {
/* 478 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.25F, 1.0F);
/* 479 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/* 480 */       setBlockBounds(0.25F, 0.5F, 0.25F, 0.75F, 1.0F, 0.75F);
/* 481 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/* 482 */       setBlockBounds(0.125F, 0.25F, 0.125F, 0.875F, 0.5F, 0.875F);
/* 483 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */     } else {
/*     */       
/* 486 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 487 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess world, int i, int j, int k) {
/* 493 */     int metadata = world.getBlockMetadata(i, j, k);
/*     */     
/* 495 */     if (metadata == 1) {
/* 496 */       setBlockBounds(0.25F, 0.0F, 0.25F, 0.75F, 0.99F, 0.75F);
/*     */     }
/* 498 */     else if (metadata == 5) {
/* 499 */       setBlockBounds(0.25F, 0.0F, 0.25F, 0.75F, 1.0F, 0.75F);
/*     */     }
/* 501 */     else if (metadata == 3) {
/* 502 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
/*     */     }
/* 504 */     else if (metadata == 4) {
/* 505 */       setBlockBounds(0.0F, -1.0F, 0.0F, 1.0F, -0.5F, 1.0F);
/*     */     }
/* 507 */     else if (metadata == 8) {
/* 508 */       setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.4375F, 0.9375F);
/*     */     } else {
/* 510 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 511 */     }  super.setBlockBoundsBasedOnState(world, i, j, k);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBlockEventReceived(World par1World, int par2, int par3, int par4, int par5, int par6) {
/* 518 */     if (par5 == 1) {
/*     */       
/* 520 */       if (par1World.isRemote) {
/* 521 */         Thaumcraft.proxy.blockSparkle(par1World, par2, par3, par4, 11960575, 2);
/* 522 */         par1World.playAuxSFX(2001, par2, par3, par4, Block.getIdFromBlock(Blocks.stonebrick) + 0);
/*     */       } 
/* 524 */       return true;
/*     */     } 
/*     */     
/* 527 */     return super.onBlockEventReceived(par1World, par2, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSideSolid(IBlockAccess world, int x, int y, int z, ForgeDirection side) {
/* 533 */     int meta = world.getBlockMetadata(x, y, z);
/* 534 */     if (meta == 11 && side == ForgeDirection.UP) return true; 
/* 535 */     if (meta == 12) return true; 
/* 536 */     return super.isSideSolid(world, x, y, z, side);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockStoneDevice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */