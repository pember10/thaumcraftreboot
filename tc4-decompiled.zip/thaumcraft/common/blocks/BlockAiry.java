/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.client.particle.EffectRenderer;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.nodes.INode;
/*     */ import thaumcraft.client.fx.ParticleEngine;
/*     */ import thaumcraft.client.fx.particles.FXSpark;
/*     */ import thaumcraft.client.fx.particles.FXSparkle;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.config.ConfigItems;
/*     */ import thaumcraft.common.items.ItemWispEssence;
/*     */ import thaumcraft.common.lib.world.ThaumcraftWorldGenerator;
/*     */ import thaumcraft.common.tiles.TileNitor;
/*     */ import thaumcraft.common.tiles.TileNode;
/*     */ import thaumcraft.common.tiles.TileNodeEnergized;
/*     */ import thaumcraft.common.tiles.TileWardingStoneFence;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockAiry
/*     */   extends BlockContainer
/*     */ {
/*     */   public IIcon blankIcon;
/*     */   
/*     */   public BlockAiry() {
/*  54 */     super(Config.airyMaterial);
/*  55 */     setStepSound(new Block.SoundType("cloth", 0.0F, 1.0F));
/*  56 */     setCreativeTab(Thaumcraft.tabTC);
/*  57 */     setTickRandomly(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*  64 */     this.blankIcon = ir.registerIcon("thaumcraft:blank");
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int meta) {
/*  70 */     return this.blankIcon;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean addHitEffects(World worldObj, MovingObjectPosition target, EffectRenderer effectRenderer) {
/*  77 */     int md = worldObj.getBlockMetadata(target.blockX, target.blockY, target.blockZ);
/*  78 */     if ((md == 0 || md == 5) && worldObj.rand.nextBoolean())
/*  79 */       UtilsFX.infusedStoneSparkle(worldObj, target.blockX, target.blockY, target.blockZ, 0); 
/*  80 */     return super.addHitEffects(worldObj, target, effectRenderer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addDestroyEffects(World world, int x, int y, int z, int meta, EffectRenderer effectRenderer) {
/*  86 */     if (meta == 0 || meta == 5) {
/*  87 */       Thaumcraft.proxy.burst(world, x + 0.5D, y + 0.5D, z + 0.5D, 1.0F);
/*  88 */       world.playSound(x + 0.5D, y + 0.5D, z + 0.5D, "thaumcraft:craftfail", 1.0F, 1.0F, false);
/*     */     } 
/*  90 */     return super.addDestroyEffects(world, x, y, z, meta, effectRenderer);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBlockHardness(World world, int x, int y, int z) {
/*  95 */     int md = world.getBlockMetadata(x, y, z);
/*  96 */     if (md == 0 || md == 5) return 2.0F; 
/*  97 */     if (md == 10 || md == 11) return 100.0F; 
/*  98 */     if (md == 12) return -1.0F; 
/*  99 */     return super.getBlockHardness(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getExplosionResistance(Entity par1Entity, World world, int x, int y, int z, double explosionX, double explosionY, double explosionZ) {
/* 106 */     int md = world.getBlockMetadata(x, y, z);
/* 107 */     if (md == 0 || md == 5) return 200.0F; 
/* 108 */     if (md == 10 || md == 11) return 50.0F; 
/* 109 */     if (md == 12) return Float.MAX_VALUE; 
/* 110 */     return super.getExplosionResistance(par1Entity, world, x, y, z, explosionX, explosionY, explosionZ);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightValue(IBlockAccess world, int x, int y, int z) {
/* 116 */     int md = world.getBlockMetadata(x, y, z);
/* 117 */     if (md == 1 || md == 2 || md == 3) return 15; 
/* 118 */     if (md == 4 || md == 12) return 0; 
/* 119 */     if (md == 0 || md == 5 || md == 10 || md == 11) return 8; 
/* 120 */     return super.getLightValue(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess ba, int x, int y, int z) {
/* 125 */     int md = ba.getBlockMetadata(x, y, z);
/* 126 */     if (md == 3 || md == 4 || md == 10 || md == 11 || md == 12) {
/* 127 */       setBlockBounds(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
/*     */     } else {
/* 129 */       setBlockBounds(0.3F, 0.3F, 0.3F, 0.7F, 0.7F, 0.7F);
/*     */     } 
/* 131 */     super.setBlockBoundsBasedOnState(ba, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReplaceable(IBlockAccess world, int x, int y, int z) {
/* 136 */     int md = world.getBlockMetadata(x, y, z);
/* 137 */     if (md == 2 || md == 3 || md == 4 || md == 10 || md == 11) return true; 
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canBeReplacedByLeaves(IBlockAccess world, int x, int y, int z) {
/* 143 */     int md = world.getBlockMetadata(x, y, z);
/* 144 */     if (md == 2 || md == 3 || md == 4) return true; 
/* 145 */     return super.canBeReplacedByLeaves(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLeaves(IBlockAccess world, int x, int y, int z) {
/* 150 */     int md = world.getBlockMetadata(x, y, z);
/* 151 */     if (md == 2 || md == 3) return true; 
/* 152 */     return super.isLeaves(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCollisionBoxesToList(World world, int x, int y, int z, AxisAlignedBB par5AxisAlignedBB, List par6List, Entity par7Entity) {
/* 158 */     int metadata = world.getBlockMetadata(x, y, z);
/*     */     
/* 160 */     if (metadata == 4 && par7Entity != null && par7Entity instanceof EntityLivingBase && !(par7Entity instanceof EntityPlayer)) {
/*     */       
/* 162 */       int a = 1;
/* 163 */       if (world.getBlock(x, y - a, z) != ConfigBlocks.blockCosmeticSolid) a++; 
/* 164 */       if (!world.isBlockIndirectlyGettingPowered(x, y - a, z)) {
/* 165 */         setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 166 */         super.addCollisionBoxesToList(world, x, y, z, par5AxisAlignedBB, par6List, par7Entity);
/*     */       }
/*     */     
/* 169 */     } else if (metadata == 12) {
/* 170 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 171 */       super.addCollisionBoxesToList(world, x, y, z, par5AxisAlignedBB, par6List, par7Entity);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBlocksMovement(IBlockAccess world, int x, int y, int z) {
/* 177 */     int metadata = world.getBlockMetadata(x, y, z);
/* 178 */     if (metadata == 4) {
/* 179 */       int a = 1;
/* 180 */       while (a < 3) {
/* 181 */         TileEntity te = world.getTileEntity(x, y - a, z);
/* 182 */         if (te != null && te instanceof thaumcraft.common.tiles.TileWardingStone) {
/* 183 */           return te.getWorldObj().isBlockIndirectlyGettingPowered(x, y - a, z);
/*     */         }
/* 185 */         a++;
/*     */       } 
/*     */     } 
/* 188 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int x, int y, int z) {
/* 194 */     int metadata = world.getBlockMetadata(x, y, z);
/* 195 */     if (metadata != 4 && metadata != 12) return null; 
/* 196 */     return super.getCollisionBoundingBoxFromPool(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getSelectedBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
/* 202 */     int md = par1World.getBlockMetadata(par2, par3, par4);
/* 203 */     if (md == 0 || md == 2 || md == 3 || md == 4 || md == 5 || md == 10 || md == 11 || md == 12) return AxisAlignedBB.getBoundingBox(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D); 
/* 204 */     return super.getSelectedBoundingBoxFromPool(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSideSolid(IBlockAccess world, int x, int y, int z, ForgeDirection side) {
/* 209 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/* 216 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/* 222 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/* 228 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int damageDropped(int par1) {
/* 234 */     return par1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Item getItemDropped(int par1, Random par2Random, int par3) {
/* 239 */     return (par1 == 1) ? ConfigItems.itemResource : Item.getItemById(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Item getItem(World world, int x, int y, int z) {
/* 244 */     int md = world.getBlockMetadata(x, y, z);
/* 245 */     if (md == 1) return ConfigItems.itemResource; 
/* 246 */     return Item.getItemById(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockHarvested(World par1World, int par2, int par3, int par4, int par5, EntityPlayer par6EntityPlayer) {
/* 252 */     if (par5 == 0 && !par1World.isRemote) {
/*     */       
/* 254 */       TileEntity te = par1World.getTileEntity(par2, par3, par4);
/* 255 */       if (te != null && te instanceof INode && ((INode)te).getAspects().size() > 0) {
/* 256 */         for (Aspect aspect : ((INode)te).getAspects().getAspects()) {
/* 257 */           for (int a = 0; a <= ((INode)te).getAspects().getAmount(aspect) / 10; a++) {
/* 258 */             if (((INode)te).getAspects().getAmount(aspect) >= 5) {
/* 259 */               ItemStack ess = new ItemStack(ConfigItems.itemWispEssence);
/* 260 */               AspectList al = new AspectList();
/* 261 */               ((ItemWispEssence)ess.getItem()).setAspects(ess, (new AspectList()).add(aspect, 2));
/*     */               
/* 263 */               dropBlockAsItem(par1World, par2, par3, par4, ess);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 269 */     super.onBlockHarvested(par1World, par2, par3, par4, par5, par6EntityPlayer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World w, int i, int j, int k, Random r) {
/* 276 */     int md = w.getBlockMetadata(i, j, k);
/* 277 */     if (md == 1) {
/* 278 */       FXSparkle ef2 = new FXSparkle(w, (i + 0.5F), (j + 0.5F), (k + 0.5F), (i + 0.5F + (r.nextFloat() - r.nextFloat()) / 3.0F), (j + 0.5F + (r.nextFloat() - r.nextFloat()) / 3.0F), (k + 0.5F + (r.nextFloat() - r.nextFloat()) / 3.0F), 1.0F, 6, 3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 286 */       ef2.setGravity(0.05F);
/* 287 */       ef2.noClip = true;
/* 288 */       ParticleEngine.instance.addEffect(w, (EntityFX)ef2);
/*     */     
/*     */     }
/* 291 */     else if (md == 2 && r.nextInt(500) == 0) {
/* 292 */       int x1 = i + r.nextInt(3) - r.nextInt(3);
/* 293 */       int y1 = j + r.nextInt(3) - r.nextInt(3);
/* 294 */       int z1 = k + r.nextInt(3) - r.nextInt(3);
/*     */       
/* 296 */       int x2 = x1 + r.nextInt(3) - r.nextInt(3);
/* 297 */       int y2 = y1 + r.nextInt(3) - r.nextInt(3);
/* 298 */       int z2 = z1 + r.nextInt(3) - r.nextInt(3);
/*     */       
/* 300 */       Thaumcraft.proxy.wispFX3(w, x1, y1, z1, x2, y2, z2, 0.1F + r.nextFloat() * 0.1F, 7, false, r.nextBoolean() ? -0.033F : 0.033F);
/*     */ 
/*     */     
/*     */     }
/* 304 */     else if (md == 10 || md == 11) {
/*     */       
/* 306 */       float h = r.nextFloat() * 0.33F;
/* 307 */       FXSpark ef = new FXSpark(w, (i + w.rand.nextFloat()), (j + 0.1515F + h / 2.0F), (k + w.rand.nextFloat()), 0.33F + h);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 312 */       if (md == 10) {
/* 313 */         ef.setRBGColorF(0.65F + w.rand.nextFloat() * 0.1F, 1.0F, 1.0F);
/* 314 */         ef.setAlphaF(0.8F);
/*     */       } else {
/* 316 */         ef.setRBGColorF(0.3F - w.rand.nextFloat() * 0.1F, 0.0F, 0.5F + w.rand.nextFloat() * 0.2F);
/*     */       } 
/*     */       
/* 319 */       ParticleEngine.instance.addEffect(w, (EntityFX)ef);
/*     */       
/* 321 */       if (r.nextInt(50) == 0) {
/* 322 */         w.playSound(i, j, k, "thaumcraft:jacobs", 0.5F, 1.0F + (r.nextFloat() - r.nextFloat()) * 0.2F, false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createTileEntity(World world, int metadata) {
/* 329 */     if (metadata == 0) return (TileEntity)new TileNode(); 
/* 330 */     if (metadata == 1) return (TileEntity)new TileNitor(); 
/* 331 */     if (metadata == 4) return (TileEntity)new TileWardingStoneFence(); 
/* 332 */     if (metadata == 5) return (TileEntity)new TileNodeEnergized(); 
/* 333 */     return super.createTileEntity(world, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World var1, int md) {
/* 338 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/* 345 */     par3List.add(new ItemStack(par1, 1, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack stack) {
/* 354 */     if (stack.getItemDamage() == 0 && entity instanceof EntityPlayer) {
/* 355 */       ThaumcraftWorldGenerator.createRandomNodeAt(world, x, y, z, world.rand, false, false, false);
/*     */     }
/*     */     
/* 358 */     super.onBlockPlacedBy(world, x, y, z, entity, stack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAir(IBlockAccess world, int x, int y, int z) {
/* 364 */     int md = world.getBlockMetadata(x, y, z);
/* 365 */     if (md == 2 || md == 3 || md == 10 || md == 11) return true; 
/* 366 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNeighborBlockChange(World world, int x, int y, int z, Block block) {
/* 371 */     int md = world.getBlockMetadata(x, y, z);
/* 372 */     if (md == 5) {
/* 373 */       TileEntity te = world.getTileEntity(x, y - 1, z);
/* 374 */       if (world.isBlockIndirectlyGettingPowered(x, y - 1, z) || te == null || !(te instanceof thaumcraft.common.tiles.TileNodeStabilizer)) {
/*     */         
/* 376 */         explodify(world, x, y, z);
/*     */       } else {
/* 378 */         te = world.getTileEntity(x, y + 1, z);
/* 379 */         if (te == null || !(te instanceof thaumcraft.common.tiles.TileNodeConverter)) {
/* 380 */           explodify(world, x, y, z);
/*     */         }
/*     */       } 
/*     */     } 
/* 384 */     super.onNeighborBlockChange(world, x, y, z, block);
/*     */   }
/*     */   
/*     */   public static void explodify(World world, int x, int y, int z) {
/* 388 */     if (!world.isRemote) {
/* 389 */       world.setBlockToAir(x, y, z);
/* 390 */       world.createExplosion(null, x + 0.5D, y + 0.5D, z + 0.5D, 3.0F, false);
/* 391 */       for (int a = 0; a < 50; a++) {
/* 392 */         int xx = x + world.rand.nextInt(8) - world.rand.nextInt(8);
/* 393 */         int yy = y + world.rand.nextInt(8) - world.rand.nextInt(8);
/* 394 */         int zz = z + world.rand.nextInt(8) - world.rand.nextInt(8);
/* 395 */         if (world.isAirBlock(xx, yy, zz)) {
/* 396 */           if (yy < y) {
/* 397 */             world.setBlock(xx, yy, zz, ConfigBlocks.blockFluxGoo, 8, 3);
/*     */           } else {
/* 399 */             world.setBlock(xx, yy, zz, ConfigBlocks.blockFluxGas, 8, 3);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
/* 408 */     int md = world.getBlockMetadata(x, y, z);
/* 409 */     if (md == 10) {
/* 410 */       entity.attackEntityFrom(DamageSource.magic, (1 + world.rand.nextInt(2)));
/* 411 */       entity.motionX *= 0.8D;
/* 412 */       entity.motionZ *= 0.8D;
/* 413 */       if (!world.isRemote && world.rand.nextInt(100) == 0) {
/* 414 */         world.setBlockToAir(x, y, z);
/*     */       }
/*     */     }
/* 417 */     else if (md == 11 && !(entity instanceof thaumcraft.api.entities.IEldritchMob)) {
/* 418 */       if (world.rand.nextInt(100) == 0) entity.attackEntityFrom(DamageSource.wither, 1.0F); 
/* 419 */       entity.motionX *= 0.66D;
/* 420 */       entity.motionZ *= 0.66D;
/* 421 */       if (entity instanceof EntityPlayer) {
/* 422 */         ((EntityPlayer)entity).addExhaustion(0.05F);
/*     */       }
/* 424 */       if (entity instanceof EntityLivingBase) {
/* 425 */         PotionEffect pe = new PotionEffect(Potion.weakness.id, 100, 1, true);
/* 426 */         ((EntityLivingBase)entity).addPotionEffect(pe);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateTick(World world, int x, int y, int z, Random rand) {
/* 433 */     super.updateTick(world, x, y, z, rand);
/* 434 */     int md = world.getBlockMetadata(x, y, z);
/* 435 */     if ((md == 10 || md == 11) && !world.isRemote)
/* 436 */       world.setBlockToAir(x, y, z); 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockAiry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */