/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.EnumRarity;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockLootItem
/*    */   extends ItemBlock
/*    */ {
/*    */   public BlockLootItem(Block par1) {
/* 19 */     super(par1);
/* 20 */     setMaxDamage(0);
/* 21 */     setHasSubtypes(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int par1) {
/* 27 */     return par1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public EnumRarity getRarity(ItemStack stack) {
/* 33 */     switch (stack.getItemDamage()) { case 1:
/* 34 */         return EnumRarity.uncommon;
/* 35 */       case 2: return EnumRarity.rare; }
/*    */     
/* 37 */     return EnumRarity.common;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List<String> list, boolean par4) {
/* 42 */     super.addInformation(stack, player, list, par4);
/* 43 */     list.add((getRarity(stack)).rarityName);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockLootItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */