/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.particle.EffectRenderer;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.Facing;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.world.Explosion;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileOwned;
/*     */ 
/*     */ public class BlockCosmeticOpaque extends BlockContainer {
/*     */   public IIcon[] icon;
/*     */   
/*     */   public BlockCosmeticOpaque() {
/*  36 */     super(Material.rock);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  44 */     this.icon = new IIcon[3]; setResistance(5.0F); setHardness(1.5F); setStepSound(Block.soundTypeStone);
/*     */     setCreativeTab(Thaumcraft.tabTC);
/*  46 */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); } public static IIcon[] wardedGlassIcon = new IIcon[47];
/*     */   
/*     */   public int currentPass;
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*  53 */     this.icon[0] = ir.registerIcon("thaumcraft:amberblock");
/*  54 */     this.icon[1] = ir.registerIcon("thaumcraft:amberbrick");
/*  55 */     this.icon[2] = ir.registerIcon("thaumcraft:amberblock_top");
/*  56 */     for (int a = 0; a < 47; a++) {
/*  57 */       wardedGlassIcon[a] = ir.registerIcon("thaumcraft:warded_glass_" + (a + 1));
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int par1, int par2) {
/*  63 */     if (par2 == 0 && par1 < 2) return this.icon[2]; 
/*  64 */     if (par2 == 2) return wardedGlassIcon[0]; 
/*  65 */     return this.icon[par2];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/*  70 */     return ConfigBlocks.blockCosmeticOpaqueRI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addHitEffects(World worldObj, MovingObjectPosition target, EffectRenderer effectRenderer) {
/*  78 */     int md = worldObj.getBlockMetadata(target.blockX, target.blockY, target.blockZ);
/*  79 */     if (md == 2) {
/*  80 */       float f = (float)target.hitVec.xCoord - target.blockX;
/*  81 */       float f1 = (float)target.hitVec.yCoord - target.blockY;
/*  82 */       float f2 = (float)target.hitVec.zCoord - target.blockZ;
/*  83 */       Thaumcraft.proxy.blockWard(worldObj, target.blockX, target.blockY, target.blockZ, ForgeDirection.getOrientation(target.sideHit), f, f1, f2);
/*     */       
/*  85 */       return true;
/*  86 */     }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(IBlockAccess world, int x, int y, int z, int side) {
/*  92 */     int md = world.getBlockMetadata(x, y, z);
/*  93 */     if (md == 2) {
/*  94 */       boolean[] bitMatrix = new boolean[8];
/*  95 */       if (side == 0 || side == 1) {
/*  96 */         bitMatrix[0] = (world.getBlock(x - 1, y, z - 1) == this && world.getBlockMetadata(x - 1, y, z - 1) == 2);
/*  97 */         bitMatrix[1] = (world.getBlock(x, y, z - 1) == this && world.getBlockMetadata(x, y, z - 1) == 2);
/*  98 */         bitMatrix[2] = (world.getBlock(x + 1, y, z - 1) == this && world.getBlockMetadata(x + 1, y, z - 1) == 2);
/*  99 */         bitMatrix[3] = (world.getBlock(x - 1, y, z) == this && world.getBlockMetadata(x - 1, y, z) == 2);
/* 100 */         bitMatrix[4] = (world.getBlock(x + 1, y, z) == this && world.getBlockMetadata(x + 1, y, z) == 2);
/* 101 */         bitMatrix[5] = (world.getBlock(x - 1, y, z + 1) == this && world.getBlockMetadata(x - 1, y, z + 1) == 2);
/* 102 */         bitMatrix[6] = (world.getBlock(x, y, z + 1) == this && world.getBlockMetadata(x, y, z + 1) == 2);
/* 103 */         bitMatrix[7] = (world.getBlock(x + 1, y, z + 1) == this && world.getBlockMetadata(x + 1, y, z + 1) == 2);
/*     */       } 
/* 105 */       if (side == 2 || side == 3) {
/* 106 */         bitMatrix[0] = (world.getBlock(x + ((side == 2) ? 1 : -1), y + 1, z) == this && world.getBlockMetadata(x + ((side == 2) ? 1 : -1), y + 1, z) == 2);
/* 107 */         bitMatrix[1] = (world.getBlock(x, y + 1, z) == this && world.getBlockMetadata(x, y + 1, z) == 2);
/* 108 */         bitMatrix[2] = (world.getBlock(x + ((side == 3) ? 1 : -1), y + 1, z) == this && world.getBlockMetadata(x + ((side == 3) ? 1 : -1), y + 1, z) == 2);
/* 109 */         bitMatrix[3] = (world.getBlock(x + ((side == 2) ? 1 : -1), y, z) == this && world.getBlockMetadata(x + ((side == 2) ? 1 : -1), y, z) == 2);
/* 110 */         bitMatrix[4] = (world.getBlock(x + ((side == 3) ? 1 : -1), y, z) == this && world.getBlockMetadata(x + ((side == 3) ? 1 : -1), y, z) == 2);
/* 111 */         bitMatrix[5] = (world.getBlock(x + ((side == 2) ? 1 : -1), y - 1, z) == this && world.getBlockMetadata(x + ((side == 2) ? 1 : -1), y - 1, z) == 2);
/* 112 */         bitMatrix[6] = (world.getBlock(x, y - 1, z) == this && world.getBlockMetadata(x, y - 1, z) == 2);
/* 113 */         bitMatrix[7] = (world.getBlock(x + ((side == 3) ? 1 : -1), y - 1, z) == this && world.getBlockMetadata(x + ((side == 3) ? 1 : -1), y - 1, z) == 2);
/*     */       } 
/* 115 */       if (side == 4 || side == 5) {
/* 116 */         bitMatrix[0] = (world.getBlock(x, y + 1, z + ((side == 5) ? 1 : -1)) == this && world.getBlockMetadata(x, y + 1, z + ((side == 5) ? 1 : -1)) == 2);
/* 117 */         bitMatrix[1] = (world.getBlock(x, y + 1, z) == this && world.getBlockMetadata(x, y + 1, z) == 2);
/* 118 */         bitMatrix[2] = (world.getBlock(x, y + 1, z + ((side == 4) ? 1 : -1)) == this && world.getBlockMetadata(x, y + 1, z + ((side == 4) ? 1 : -1)) == 2);
/* 119 */         bitMatrix[3] = (world.getBlock(x, y, z + ((side == 5) ? 1 : -1)) == this && world.getBlockMetadata(x, y, z + ((side == 5) ? 1 : -1)) == 2);
/* 120 */         bitMatrix[4] = (world.getBlock(x, y, z + ((side == 4) ? 1 : -1)) == this && world.getBlockMetadata(x, y, z + ((side == 4) ? 1 : -1)) == 2);
/* 121 */         bitMatrix[5] = (world.getBlock(x, y - 1, z + ((side == 5) ? 1 : -1)) == this && world.getBlockMetadata(x, y - 1, z + ((side == 5) ? 1 : -1)) == 2);
/* 122 */         bitMatrix[6] = (world.getBlock(x, y - 1, z) == this && world.getBlockMetadata(x, y - 1, z) == 2);
/* 123 */         bitMatrix[7] = (world.getBlock(x, y - 1, z + ((side == 4) ? 1 : -1)) == this && world.getBlockMetadata(x, y - 1, z + ((side == 4) ? 1 : -1)) == 2);
/*     */       } 
/* 125 */       int idBuilder = 0;
/* 126 */       for (int i = 0; i <= 7; i++) {
/* 127 */         idBuilder += bitMatrix[i] ? ((i == 0) ? 1 : ((i == 1) ? 2 : ((i == 2) ? 4 : ((i == 3) ? 8 : ((i == 4) ? 16 : ((i == 5) ? 32 : ((i == 6) ? 64 : 128))))))) : 0;
/*     */       }
/*     */       
/* 130 */       return (idBuilder > 255 || idBuilder < 0) ? wardedGlassIcon[0] : wardedGlassIcon[UtilsFX.connectedTextureRefByID[idBuilder]];
/*     */     } 
/*     */     
/* 133 */     return super.getIcon(world, x, y, z, side);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRenderBlockPass() {
/* 139 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRenderInPass(int pass) {
/* 144 */     this.currentPass = pass;
/* 145 */     return (pass == 1 || pass == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLightOpacity(IBlockAccess world, int x, int y, int z) {
/* 150 */     int md = world.getBlockMetadata(x, y, z);
/* 151 */     if (md <= 1) return 3; 
/* 152 */     return super.getLightOpacity(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/* 157 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/* 168 */     par3List.add(new ItemStack(par1, 1, 0));
/* 169 */     par3List.add(new ItemStack(par1, 1, 1));
/* 170 */     par3List.add(new ItemStack(par1, 1, 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNormalCube(IBlockAccess world, int x, int y, int z) {
/* 175 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSideSolid(IBlockAccess world, int x, int y, int z, ForgeDirection side) {
/* 181 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean shouldSideBeRendered(IBlockAccess world, int x, int y, int z, int side) {
/* 188 */     Block block = world.getBlock(x, y, z);
/*     */     
/* 190 */     if (world.getBlockMetadata(x, y, z) != world.getBlockMetadata(x - Facing.offsetsXForSide[side], y - Facing.offsetsYForSide[side], z - Facing.offsetsZForSide[side]))
/*     */     {
/* 192 */       return true;
/*     */     }
/*     */     
/* 195 */     if (block == this)
/*     */     {
/* 197 */       return false;
/*     */     }
/*     */     
/* 200 */     return super.shouldSideBeRendered(world, x, y, z, side);
/*     */   }
/*     */ 
/*     */   
/*     */   public int quantityDropped(Random par1Random) {
/* 205 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int damageDropped(int par1) {
/* 210 */     return par1;
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createTileEntity(World world, int metadata) {
/* 215 */     if (metadata == 2) return (TileEntity)new TileOwned(); 
/* 216 */     return super.createTileEntity(world, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEntityDestroy(IBlockAccess world, int x, int y, int z, Entity entity) {
/* 221 */     int md = world.getBlockMetadata(x, y, z);
/* 222 */     if (md == 2) return false; 
/* 223 */     return super.canEntityDestroy(world, x, y, z, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockExploded(World world, int x, int y, int z, Explosion explosion) {
/* 229 */     int md = world.getBlockMetadata(x, y, z);
/* 230 */     if (md != 2) super.onBlockExploded(world, x, y, z, explosion);
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canDropFromExplosion(Explosion explosion) {
/* 236 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockPlacedBy(World w, int x, int y, int z, EntityLivingBase p, ItemStack is) {
/* 242 */     TileEntity tile = w.getTileEntity(x, y, z);
/* 243 */     if (tile != null && tile instanceof TileOwned && p instanceof EntityPlayer) {
/* 244 */       ((TileOwned)tile).owner = ((EntityPlayer)p).getCommandSenderName();
/* 245 */       tile.markDirty();
/*     */     } 
/* 247 */     super.onBlockPlacedBy(w, x, y, z, p, is);
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World var1, int var2) {
/* 252 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getBlockHardness(World world, int x, int y, int z) {
/* 258 */     int md = world.getBlockMetadata(x, y, z);
/* 259 */     if (md == 2) return Config.wardedStone ? -1.0F : 5.0F;
/*     */     
/* 261 */     return super.getBlockHardness(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getExplosionResistance(Entity par1Entity, World world, int x, int y, int z, double explosionX, double explosionY, double explosionZ) {
/* 267 */     int md = world.getBlockMetadata(x, y, z);
/* 268 */     if (md == 2) return 999.0F; 
/* 269 */     return super.getExplosionResistance(par1Entity, world, x, y, z, explosionX, explosionY, explosionZ);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockCosmeticOpaque.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */