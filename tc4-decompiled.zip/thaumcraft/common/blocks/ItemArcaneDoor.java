/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileOwned;
/*     */ 
/*     */ public class ItemArcaneDoor
/*     */   extends Item {
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon icon;
/*     */   
/*     */   public ItemArcaneDoor() {
/*  23 */     this.maxStackSize = 1;
/*  24 */     setCreativeTab(Thaumcraft.tabTC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerIcons(IIconRegister ir) {
/*  32 */     this.icon = ir.registerIcon("thaumcraft:arcanedoor");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIconFromDamage(int par1) {
/*  37 */     return this.icon;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int par4, int par5, int par6, int par7, float par8, float par9, float par10) {
/*  46 */     if (par7 != 1)
/*     */     {
/*  48 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  52 */     par5++;
/*  53 */     Block var11 = ConfigBlocks.blockArcaneDoor;
/*     */     
/*  55 */     if (player.canPlayerEdit(par4, par5, par6, par7, stack) && player.canPlayerEdit(par4, par5 + 1, par6, par7, stack)) {
/*     */       
/*  57 */       if (!var11.canPlaceBlockAt(world, par4, par5, par6))
/*     */       {
/*  59 */         return false;
/*     */       }
/*     */ 
/*     */       
/*  63 */       int var12 = MathHelper.floor_double(((player.rotationYaw + 180.0F) * 4.0F / 360.0F) - 0.5D) & 0x3;
/*  64 */       placeDoorBlock(world, par4, par5, par6, var12, var11, player);
/*  65 */       stack.stackSize--;
/*  66 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void placeDoorBlock(World world, int x, int y, int z, int par4, Block par5Block, EntityPlayer player) {
/*  78 */     byte var6 = 0;
/*  79 */     byte var7 = 0;
/*     */     
/*  81 */     if (par4 == 0)
/*     */     {
/*  83 */       var7 = 1;
/*     */     }
/*     */     
/*  86 */     if (par4 == 1)
/*     */     {
/*  88 */       var6 = -1;
/*     */     }
/*     */     
/*  91 */     if (par4 == 2)
/*     */     {
/*  93 */       var7 = -1;
/*     */     }
/*     */     
/*  96 */     if (par4 == 3)
/*     */     {
/*  98 */       var6 = 1;
/*     */     }
/*     */     
/* 101 */     int var8 = (world.isBlockNormalCubeDefault(x - var6, y, z - var7, false) ? 1 : 0) + (world.isBlockNormalCubeDefault(x - var6, y + 1, z - var7, false) ? 1 : 0);
/* 102 */     int var9 = (world.isBlockNormalCubeDefault(x + var6, y, z + var7, false) ? 1 : 0) + (world.isBlockNormalCubeDefault(x + var6, y + 1, z + var7, false) ? 1 : 0);
/* 103 */     boolean var10 = (world.getBlock(x - var6, y, z - var7) == par5Block || world.getBlock(x - var6, y + 1, z - var7) == par5Block);
/* 104 */     boolean var11 = (world.getBlock(x + var6, y, z + var7) == par5Block || world.getBlock(x + var6, y + 1, z + var7) == par5Block);
/* 105 */     boolean var12 = false;
/*     */     
/* 107 */     if (var10 && !var11) {
/*     */       
/* 109 */       var12 = true;
/*     */     }
/* 111 */     else if (var9 > var8) {
/*     */       
/* 113 */       var12 = true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 118 */     world.setBlock(x, y, z, par5Block, par4, 2);
/* 119 */     TileOwned tad = (TileOwned)world.getTileEntity(x, y, z);
/* 120 */     tad.owner = player.getCommandSenderName();
/*     */     
/* 122 */     world.setBlock(x, y + 1, z, par5Block, 0x8 | (var12 ? 1 : 0), 2);
/* 123 */     TileOwned tad2 = (TileOwned)world.getTileEntity(x, y + 1, z);
/* 124 */     tad2.owner = player.getCommandSenderName();
/*     */ 
/*     */ 
/*     */     
/* 128 */     world.notifyBlocksOfNeighborChange(x, y, z, par5Block);
/* 129 */     world.notifyBlocksOfNeighborChange(x, y + 1, z, par5Block);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\ItemArcaneDoor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */