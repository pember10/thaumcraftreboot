/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.util.IIcon;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fluids.BlockFluidClassic;
/*    */ import thaumcraft.client.fx.ParticleEngine;
/*    */ import thaumcraft.client.fx.particles.FXBubble;
/*    */ import thaumcraft.common.Thaumcraft;
/*    */ import thaumcraft.common.config.Config;
/*    */ import thaumcraft.common.config.ConfigBlocks;
/*    */ 
/*    */ public class BlockFluidPure
/*    */   extends BlockFluidClassic {
/*    */   public BlockFluidPure() {
/* 25 */     super(ConfigBlocks.FLUIDPURE, Material.water);
/* 26 */     setCreativeTab(Thaumcraft.tabTC);
/*    */   }
/*    */ 
/*    */   
/*    */   public IIcon iconStill;
/*    */   public IIcon iconFlow;
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void registerBlockIcons(IIconRegister ir) {
/* 35 */     this.iconStill = ir.registerIcon("thaumcraft:fluidpure");
/* 36 */     this.iconFlow = ir.registerIcon("thaumcraft:fluidpure");
/* 37 */     ConfigBlocks.FLUIDPURE.setIcons(this.iconStill, this.iconFlow);
/*    */   }
/*    */ 
/*    */   
/*    */   public IIcon getIcon(int par1, int par2) {
/* 42 */     return this.iconStill;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
/* 49 */     if (!world.isRemote && isSourceBlock((IBlockAccess)world, x, y, z) && entity instanceof EntityPlayer && !((EntityPlayer)entity).isPotionActive(Config.potionWarpWardID)) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 55 */       int warp = Thaumcraft.proxy.getPlayerKnowledge().getWarpPerm(((EntityPlayer)entity).getCommandSenderName());
/*    */       
/* 57 */       int div = 1;
/* 58 */       if (warp > 0) {
/* 59 */         div = (int)Math.sqrt(warp);
/* 60 */         if (div < 1)
/* 61 */           div = 1; 
/*    */       } 
/* 63 */       ((EntityPlayer)entity).addPotionEffect(new PotionEffect(Config.potionWarpWardID, Math.min(32000, 200000 / div), 0, true));
/*    */ 
/*    */       
/* 66 */       world.setBlockToAir(x, y, z);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void randomDisplayTick(World world, int x, int y, int z, Random rand) {
/* 74 */     int meta = world.getBlockMetadata(x, y, z);
/*    */     
/* 76 */     FXBubble fb = new FXBubble(world, (x + rand.nextFloat()), (y + 0.125F * (8 - meta)), (z + rand.nextFloat()), 0.0D, 0.0D, 0.0D, 0);
/*    */     
/* 78 */     fb.setAlphaF(0.25F);
/* 79 */     fb.setRGB(1.0F, 1.0F, 1.0F);
/* 80 */     ParticleEngine.instance.addEffect(world, (EntityFX)fb);
/*    */     
/* 82 */     if (rand.nextInt(25) == 0) {
/* 83 */       double var21 = (x + rand.nextFloat());
/* 84 */       double var22 = y + this.maxY;
/* 85 */       double var23 = (z + rand.nextFloat());
/* 86 */       world.playSound(var21, var22, var23, "liquid.lavapop", 0.1F + rand.nextFloat() * 0.1F, 0.9F + rand.nextFloat() * 0.15F, false);
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 91 */     super.randomDisplayTick(world, x, y, z, rand);
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockFluidPure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */