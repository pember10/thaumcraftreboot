/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ import thaumcraft.common.tiles.TileCrystal;
/*    */ 
/*    */ 
/*    */ public class BlockCrystalItem
/*    */   extends ItemBlock
/*    */ {
/*    */   public BlockCrystalItem(Block par1) {
/* 15 */     super(par1);
/* 16 */     setMaxDamage(0);
/* 17 */     setHasSubtypes(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int par1) {
/* 23 */     return par1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/* 29 */     return getUnlocalizedName() + "." + par1ItemStack.getItemDamage();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/* 34 */     boolean placed = super.placeBlockAt(stack, player, world, x, y, z, side, hitX, hitY, hitZ, metadata);
/*    */     
/* 36 */     if (placed && metadata <= 7) {
/*    */       try {
/* 38 */         TileCrystal ts = (TileCrystal)world.getTileEntity(x, y, z);
/* 39 */         ts.orientation = (short)side;
/* 40 */       } catch (Exception e) {}
/*    */     }
/*    */     
/* 43 */     return placed;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockCrystalItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */