/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.client.renderers.block.BlockRenderer;
/*     */ import thaumcraft.common.tiles.TileAlembic;
/*     */ 
/*     */ public class BlockMetalDevice extends BlockContainer {
/*     */   public IIcon[] icon;
/*     */   public IIcon iconGlow;
/*     */   private int delay;
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*     */     this.icon[0] = ir.registerIcon("thaumcraft:metalbase");
/*     */     for (int a = 1; a <= 6; ) {
/*     */       this.icon[a] = ir.registerIcon("thaumcraft:crucible" + a);
/*     */       a++;
/*     */     } 
/*     */     this.icon[7] = ir.registerIcon("thaumcraft:goldbase");
/*     */     this.icon[8] = ir.registerIcon("thaumcraft:grate");
/*     */     this.icon[9] = ir.registerIcon("thaumcraft:grate_hatch");
/*     */     this.icon[10] = ir.registerIcon("thaumcraft:lamp_side");
/*     */     this.icon[11] = ir.registerIcon("thaumcraft:lamp_top");
/*     */     this.icon[12] = ir.registerIcon("thaumcraft:lamp_grow_side");
/*     */     this.icon[13] = ir.registerIcon("thaumcraft:lamp_grow_top");
/*     */     this.icon[14] = ir.registerIcon("thaumcraft:lamp_grow_side_off");
/*     */     this.icon[15] = ir.registerIcon("thaumcraft:lamp_grow_top_off");
/*     */     this.icon[16] = ir.registerIcon("thaumcraft:alchemyblock");
/*     */     this.icon[17] = ir.registerIcon("thaumcraft:brainbox");
/*     */     this.icon[18] = ir.registerIcon("thaumcraft:lamp_fert_side");
/*     */     this.icon[19] = ir.registerIcon("thaumcraft:lamp_fert_top");
/*     */     this.icon[20] = ir.registerIcon("thaumcraft:lamp_fert_side_off");
/*     */     this.icon[21] = ir.registerIcon("thaumcraft:lamp_fert_top_off");
/*     */     this.icon[22] = ir.registerIcon("thaumcraft:alchemyblockadv");
/*     */     this.iconGlow = ir.registerIcon("thaumcraft:animatedglow");
/*     */   }
/*     */   
/*     */   public IIcon getIcon(int i, int md) {
/*     */     if (md == 3)
/*     */       return this.icon[22]; 
/*     */     if (md == 7)
/*     */       return this.icon[10]; 
/*     */     if (md == 8)
/*     */       return this.icon[12]; 
/*     */     if (md == 10 || md == 9 || md == 11)
/*     */       return this.icon[16]; 
/*     */     if (md == 12)
/*     */       return this.icon[17]; 
/*     */     if (md == 13)
/*     */       return this.icon[18]; 
/*     */     if (md == 14 || md == 2)
/*     */       return this.icon[0]; 
/*     */     return (md == 0 || md == 1 || md == 5 || md == 6) ? this.icon[0] : this.icon[7];
/*     */   }
/*     */   
/*  62 */   public BlockMetalDevice() { super(Material.iron);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     this.icon = new IIcon[23];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     this.delay = 0;
/*     */     setHardness(3.0F);
/*     */     setResistance(17.0F);
/*     */     setStepSound(Block.soundTypeMetal);
/*     */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */     setCreativeTab(Thaumcraft.tabTC); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity) {
/* 208 */     if (!world.isRemote)
/* 209 */     { int metadata = world.getBlockMetadata(i, j, k);
/*     */       
/* 211 */       if (metadata == 0)
/* 212 */       { TileCrucible tile = (TileCrucible)world.getTileEntity(i, j, k);
/* 213 */         if (tile != null && entity instanceof EntityItem && !(entity instanceof thaumcraft.common.entities.EntitySpecialItem) && tile.heat > 150 && tile.tank.getFluidAmount() > 0)
/*     */         
/*     */         { 
/* 216 */           tile.attemptSmelt((EntityItem)entity); }
/*     */         else
/* 218 */         { this.delay++;
/* 219 */           if (this.delay < 10)
/* 220 */             return;  this.delay = 0;
/* 221 */           if (entity instanceof EntityLivingBase && tile != null && tile.heat > 150 && tile.tank.getFluidAmount() > 0)
/*     */           
/*     */           { 
/* 224 */             entity.attackEntityFrom(DamageSource.inFire, 1.0F);
/* 225 */             world.playSoundEffect(i, j, k, "random.fizz", 0.4F, 2.0F + world.rand.nextFloat() * 0.4F); }  }  }  }  }
/*     */   public IIcon getIcon(IBlockAccess iblockaccess, int i, int j, int k, int side) { int metadata = iblockaccess.getBlockMetadata(i, j, k); if (metadata == 5 || metadata == 6) return this.icon[8];  if (metadata == 7) { if (side <= 1) return this.icon[11];  return this.icon[10]; }  if (metadata == 8) { TileEntity te = iblockaccess.getTileEntity(i, j, k); if (te != null && te instanceof TileArcaneLampGrowth) { if (((TileArcaneLampGrowth)te).charges > 0) { if (side <= 1) return this.icon[13];  return this.icon[12]; }  if (side <= 1) return this.icon[15];  return this.icon[14]; }  } else if (metadata == 13) { TileEntity te = iblockaccess.getTileEntity(i, j, k); if (te != null && te instanceof TileArcaneLampFertility) { if (((TileArcaneLampFertility)te).charges > 0) { if (side <= 1) return this.icon[19];  return this.icon[18]; }  if (side <= 1)
/*     */           return this.icon[21];  return this.icon[20]; }  } else { if (metadata == 10 || metadata == 9 || metadata == 11)
/*     */         return this.icon[16];  if (metadata == 12)
/*     */         return this.icon[17];  if (metadata == 3)
/*     */         return this.icon[22];  }  if (side == 1)
/*     */       return this.icon[1];  if (side == 0)
/*     */       return this.icon[2];  return this.icon[3]; }
/*     */   @SideOnly(Side.CLIENT) public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) { par3List.add(new ItemStack(par1, 1, 0)); par3List.add(new ItemStack(par1, 1, 1)); par3List.add(new ItemStack(par1, 1, 5)); par3List.add(new ItemStack(par1, 1, 7)); par3List.add(new ItemStack(par1, 1, 8)); par3List.add(new ItemStack(par1, 1, 13)); par3List.add(new ItemStack(par1, 1, 9)); par3List.add(new ItemStack(par1, 1, 3)); par3List.add(new ItemStack(par1, 1, 12)); par3List.add(new ItemStack(par1, 1, 14)); par3List.add(new ItemStack(par1, 1, 2)); }
/*     */   public int getRenderType() { return ConfigBlocks.blockMetalDeviceRI; }
/*     */   public boolean isOpaqueCube() { return false; }
/* 236 */   public boolean renderAsNormalBlock() { return false; } public void setBlockBoundsBasedOnState(IBlockAccess world, int i, int j, int k) { int metadata = world.getBlockMetadata(i, j, k);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     if (metadata == 5 || metadata == 6) {
/* 242 */       setBlockBounds(0.0F, 0.8125F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */     }
/* 244 */     else if (metadata == 7 || metadata == 8 || metadata == 13) {
/* 245 */       setBlockBounds(BlockRenderer.W4, BlockRenderer.W2, BlockRenderer.W4, BlockRenderer.W12, BlockRenderer.W14, BlockRenderer.W12);
/*     */     }
/* 247 */     else if (metadata == 10) {
/* 248 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F);
/*     */     }
/* 250 */     else if (metadata == 11) {
/* 251 */       setBlockBounds(0.0F, -1.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */     }
/* 253 */     else if (metadata == 12) {
/* 254 */       setBlockBounds(BlockRenderer.W3, BlockRenderer.W3, BlockRenderer.W3, BlockRenderer.W13, BlockRenderer.W13, BlockRenderer.W13);
/*     */     }
/* 256 */     else if (metadata == 2) {
/* 257 */       setBlockBounds(BlockRenderer.W5, 0.5F, BlockRenderer.W5, BlockRenderer.W11, 1.0F, BlockRenderer.W11);
/*     */     }
/* 259 */     else if (metadata == 14) {
/* 260 */       TileEntity te = world.getTileEntity(i, j, k);
/* 261 */       if (te != null && te instanceof TileVisRelay)
/* 262 */         switch (ForgeDirection.getOrientation(((TileVisRelay)te).orientation).getOpposite()) {
/*     */           case UP:
/* 264 */             setBlockBounds(BlockRenderer.W5, 0.5F, BlockRenderer.W5, BlockRenderer.W11, 1.0F, BlockRenderer.W11); break;
/*     */           case DOWN:
/* 266 */             setBlockBounds(BlockRenderer.W5, 0.0F, BlockRenderer.W5, BlockRenderer.W11, 0.5F, BlockRenderer.W11); break;
/*     */           case EAST:
/* 268 */             setBlockBounds(0.5F, BlockRenderer.W5, BlockRenderer.W5, 1.0F, BlockRenderer.W11, BlockRenderer.W11); break;
/*     */           case WEST:
/* 270 */             setBlockBounds(0.0F, BlockRenderer.W5, BlockRenderer.W5, 0.5F, BlockRenderer.W11, BlockRenderer.W11); break;
/*     */           case SOUTH:
/* 272 */             setBlockBounds(BlockRenderer.W5, BlockRenderer.W5, 0.5F, BlockRenderer.W11, BlockRenderer.W11, 1.0F); break;
/*     */           case NORTH:
/* 274 */             setBlockBounds(BlockRenderer.W5, BlockRenderer.W5, 0.0F, BlockRenderer.W11, BlockRenderer.W11, 0.5F);
/*     */             break;
/*     */         }  
/*     */     } else {
/* 278 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 279 */     }  super.setBlockBoundsBasedOnState(world, i, j, k); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCollisionBoxesToList(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, List arraylist, Entity par7Entity) {
/* 285 */     int metadata = world.getBlockMetadata(i, j, k);
/*     */     
/* 287 */     if (metadata == 0) {
/* 288 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.3125F, 1.0F);
/* 289 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/* 290 */       float f = 0.125F;
/* 291 */       setBlockBounds(0.0F, 0.0F, 0.0F, f, 0.85F, 1.0F);
/* 292 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/* 293 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.85F, f);
/* 294 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/* 295 */       setBlockBounds(1.0F - f, 0.0F, 0.0F, 1.0F, 0.85F, 1.0F);
/* 296 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/* 297 */       setBlockBounds(0.0F, 0.0F, 1.0F - f, 1.0F, 0.85F, 1.0F);
/* 298 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 304 */     else if (metadata == 2) {
/*     */       
/* 306 */       setBlockBounds(BlockRenderer.W5, 0.5F, BlockRenderer.W5, BlockRenderer.W11, 1.0F, BlockRenderer.W11);
/* 307 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */     }
/* 309 */     else if (metadata == 5) {
/* 310 */       if (par7Entity != null && !(par7Entity instanceof EntityItem)) {
/* 311 */         setBlockBounds(0.0F, 0.8125F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 312 */         super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */       }
/*     */     
/* 315 */     } else if (metadata == 6) {
/* 316 */       setBlockBounds(0.0F, 0.8125F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 317 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */     }
/* 319 */     else if (metadata == 7 || metadata == 8 || metadata == 13) {
/* 320 */       setBlockBounds(BlockRenderer.W4, BlockRenderer.W2, BlockRenderer.W4, BlockRenderer.W12, BlockRenderer.W14, BlockRenderer.W12);
/* 321 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */     }
/* 323 */     else if (metadata == 12) {
/* 324 */       setBlockBounds(BlockRenderer.W3, BlockRenderer.W3, BlockRenderer.W3, BlockRenderer.W13, BlockRenderer.W13, BlockRenderer.W13);
/* 325 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */     }
/* 327 */     else if (metadata == 14) {
/* 328 */       TileEntity te = world.getTileEntity(i, j, k);
/* 329 */       if (te != null && te instanceof TileVisRelay) {
/* 330 */         switch (ForgeDirection.getOrientation(((TileVisRelay)te).orientation).getOpposite()) {
/*     */           case UP:
/* 332 */             setBlockBounds(BlockRenderer.W5, 0.5F, BlockRenderer.W5, BlockRenderer.W11, 1.0F, BlockRenderer.W11); break;
/*     */           case DOWN:
/* 334 */             setBlockBounds(BlockRenderer.W5, 0.0F, BlockRenderer.W5, BlockRenderer.W11, 0.5F, BlockRenderer.W11); break;
/*     */           case EAST:
/* 336 */             setBlockBounds(0.5F, BlockRenderer.W5, BlockRenderer.W5, 1.0F, BlockRenderer.W11, BlockRenderer.W11); break;
/*     */           case WEST:
/* 338 */             setBlockBounds(0.0F, BlockRenderer.W5, BlockRenderer.W5, 0.5F, BlockRenderer.W11, BlockRenderer.W11); break;
/*     */           case SOUTH:
/* 340 */             setBlockBounds(BlockRenderer.W5, BlockRenderer.W5, 0.5F, BlockRenderer.W11, BlockRenderer.W11, 1.0F); break;
/*     */           case NORTH:
/* 342 */             setBlockBounds(BlockRenderer.W5, BlockRenderer.W5, 0.0F, BlockRenderer.W11, BlockRenderer.W11, 0.5F); break;
/*     */         } 
/* 344 */         super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */       } 
/*     */     } else {
/* 347 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 348 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World w, int i, int j, int k, Random r) {
/* 355 */     if (r.nextInt(10) == 0) {
/* 356 */       TileEntity te = w.getTileEntity(i, j, k);
/* 357 */       if (te != null && te instanceof TileCrucible && 
/* 358 */         ((TileCrucible)te).tank.getFluidAmount() > 0 && ((TileCrucible)te).heat > 150) {
/* 359 */         w.playSound(i, j, k, "liquid.lavapop", 0.1F + r.nextFloat() * 0.1F, 1.2F + r.nextFloat() * 0.2F, false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int damageDropped(int metadata) {
/* 368 */     if (metadata == 6) return 5; 
/* 369 */     if (metadata == 10 || metadata == 11) return 9; 
/* 370 */     return metadata;
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createTileEntity(World world, int metadata) {
/* 375 */     if (metadata == 0) return (TileEntity)new TileCrucible(); 
/* 376 */     if (metadata == 5) return (TileEntity)new TileGrate(); 
/* 377 */     if (metadata == 6) return (TileEntity)new TileGrate(); 
/* 378 */     if (metadata == 1) return (TileEntity)new TileAlembic(); 
/* 379 */     if (metadata == 7) return (TileEntity)new TileArcaneLamp(); 
/* 380 */     if (metadata == 8) return (TileEntity)new TileArcaneLampGrowth();
/*     */     
/* 382 */     if (metadata == 10) return (TileEntity)new TileThaumatorium(); 
/* 383 */     if (metadata == 11) return (TileEntity)new TileThaumatoriumTop(); 
/* 384 */     if (metadata == 12) return (TileEntity)new TileBrainbox();
/*     */     
/* 386 */     if (metadata == 13) return (TileEntity)new TileArcaneLampFertility();
/*     */     
/* 388 */     if (metadata == 14) return (TileEntity)new TileVisRelay(); 
/* 389 */     if (metadata == 2) return (TileEntity)new TileMagicWorkbenchCharger(); 
/* 390 */     return super.createTileEntity(world, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasComparatorInputOverride() {
/* 395 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getComparatorInputOverride(World world, int x, int y, int z, int rs) {
/* 401 */     TileEntity te = world.getTileEntity(x, y, z);
/* 402 */     if (te != null && te instanceof TileThaumatorium) {
/* 403 */       return Container.calcRedstoneFromInventory((IInventory)te);
/*     */     }
/* 405 */     if (te != null && te instanceof TileAlembic) {
/* 406 */       float r = ((TileAlembic)te).amount / ((TileAlembic)te).maxAmount;
/* 407 */       return MathHelper.floor_float(r * 14.0F) + ((((TileAlembic)te).amount > 0) ? 1 : 0);
/*     */     } 
/* 409 */     if (te != null && te instanceof TileCrucible) {
/* 410 */       ((TileCrucible)te).getClass(); float r = ((TileCrucible)te).aspects.visSize() / 100.0F;
/* 411 */       return MathHelper.floor_float(r * 14.0F) + ((((TileCrucible)te).aspects.visSize() > 0) ? 1 : 0);
/*     */     } 
/* 413 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World var1, int md) {
/* 418 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNeighborBlockChange(World world, int x, int y, int z, Block nbid) {
/* 423 */     TileEntity te = world.getTileEntity(x, y, z);
/* 424 */     int md = world.getBlockMetadata(x, y, z);
/*     */     
/* 426 */     if (te != null && te instanceof TileCrucible) {
/* 427 */       ((TileCrucible)te).getBellows();
/*     */     }
/*     */     
/* 430 */     if (!world.isRemote) {
/*     */       
/* 432 */       if (te != null && te instanceof TileAlembic) {
/* 433 */         world.markBlockForUpdate(x, y, z);
/*     */       }
/* 435 */       else if (te != null && te instanceof TileArcaneLamp) {
/* 436 */         TileArcaneLamp telb = (TileArcaneLamp)te;
/* 437 */         if (world.isAirBlock(x + telb.facing.offsetX, y + telb.facing.offsetY, z + telb.facing.offsetZ))
/*     */         {
/*     */ 
/*     */           
/* 441 */           dropBlockAsItem(world, x, y, z, 7, 0);
/* 442 */           world.setBlockToAir(x, y, z);
/*     */         }
/*     */       
/* 445 */       } else if (te != null && te instanceof TileArcaneLampGrowth) {
/* 446 */         TileArcaneLampGrowth telb = (TileArcaneLampGrowth)te;
/* 447 */         if (world.isAirBlock(x + telb.facing.offsetX, y + telb.facing.offsetY, z + telb.facing.offsetZ))
/*     */         {
/*     */ 
/*     */           
/* 451 */           dropBlockAsItem(world, x, y, z, 8, 0);
/* 452 */           world.setBlockToAir(x, y, z);
/*     */         }
/*     */       
/* 455 */       } else if (te != null && te instanceof TileBrainbox) {
/* 456 */         TileBrainbox telb = (TileBrainbox)te;
/* 457 */         if (world.isAirBlock(x + telb.facing.offsetX, y + telb.facing.offsetY, z + telb.facing.offsetZ))
/*     */         {
/*     */ 
/*     */           
/* 461 */           dropBlockAsItem(world, x, y, z, 12, 0);
/* 462 */           world.setBlockToAir(x, y, z);
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 472 */       else if (te != null && te instanceof TileVisRelay && md == 14) {
/* 473 */         TileVisRelay telb = (TileVisRelay)te;
/* 474 */         if (world.isAirBlock(x + (ForgeDirection.getOrientation(telb.orientation).getOpposite()).offsetX, y + (ForgeDirection.getOrientation(telb.orientation).getOpposite()).offsetY, z + (ForgeDirection.getOrientation(telb.orientation).getOpposite()).offsetZ))
/*     */         {
/*     */ 
/*     */           
/* 478 */           dropBlockAsItem(world, x, y, z, 14, 0);
/* 479 */           world.setBlockToAir(x, y, z);
/*     */         }
/*     */       
/* 482 */       } else if (md == 10) {
/* 483 */         if (world.getBlock(x, y + 1, z) != this || world.getBlockMetadata(x, y + 1, z) != 11 || world.getBlock(x, y - 1, z) != this || world.getBlockMetadata(x, y - 1, z) != 0) {
/*     */           
/* 485 */           InventoryUtils.dropItems(world, x, y, z);
/* 486 */           world.setBlockToAir(x, y, z);
/* 487 */           world.setBlock(x, y, z, (Block)this, 9, 3);
/*     */           return;
/*     */         } 
/* 490 */         TileEntity tile = world.getTileEntity(x, y, z);
/* 491 */         if (tile != null && tile instanceof TileThaumatorium) {
/* 492 */           ((TileThaumatorium)tile).getUpgrades();
/*     */         }
/*     */       }
/* 495 */       else if (md == 11) {
/* 496 */         if (world.getBlock(x, y - 1, z) != this || world.getBlockMetadata(x, y - 1, z) != 10) {
/* 497 */           world.setBlockToAir(x, y, z);
/* 498 */           world.setBlock(x, y, z, (Block)this, 9, 3);
/*     */           return;
/*     */         } 
/* 501 */         TileEntity tile = world.getTileEntity(x, y - 1, z);
/* 502 */         if (tile != null && tile instanceof TileThaumatorium) {
/* 503 */           ((TileThaumatorium)tile).getUpgrades();
/*     */         }
/*     */       } 
/*     */       
/* 507 */       boolean flag = world.isBlockIndirectlyGettingPowered(x, y, z);
/*     */       
/* 509 */       if (flag || nbid.canProvidePower())
/*     */       {
/* 511 */         onPoweredBlockChange(world, x, y, z, flag);
/*     */       }
/*     */     } 
/*     */     
/* 515 */     super.onNeighborBlockChange(world, x, y, z, nbid);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void breakBlock(World par1World, int par2, int par3, int par4, Block par5, int par6) {
/* 522 */     InventoryUtils.dropItems(par1World, par2, par3, par4);
/*     */     
/* 524 */     TileEntity te = par1World.getTileEntity(par2, par3, par4);
/* 525 */     if (te != null && te instanceof TileCrucible) {
/* 526 */       ((TileCrucible)te).spillRemnants();
/*     */     }
/* 528 */     else if (te != null && te instanceof TileAlembic && ((TileAlembic)te).aspectFilter != null) {
/* 529 */       par1World.spawnEntityInWorld((Entity)new EntityItem(par1World, (par2 + 0.5F), (par3 + 0.5F), (par4 + 0.5F), new ItemStack(ConfigItems.itemResource, 1, 13)));
/*     */ 
/*     */     
/*     */     }
/* 533 */     else if (te != null && te instanceof TileArcaneLamp) {
/* 534 */       ((TileArcaneLamp)te).removeLights();
/*     */     } 
/*     */     
/* 537 */     super.breakBlock(par1World, par2, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float par7, float par8, float par9) {
/* 558 */     int metadata = world.getBlockMetadata(x, y, z);
/*     */     
/* 560 */     if (metadata == 0 && !world.isRemote) {
/* 561 */       FluidStack fs = FluidContainerRegistry.getFluidForFilledItem(player.inventory.getCurrentItem());
/* 562 */       if (fs != null && fs.isFluidEqual(new FluidStack(FluidRegistry.WATER, 1000))) {
/* 563 */         int volume = fs.amount;
/* 564 */         TileEntity te = world.getTileEntity(x, y, z);
/* 565 */         if (te != null && te instanceof TileCrucible) {
/* 566 */           TileCrucible tile = (TileCrucible)te;
/* 567 */           if (tile.tank.getFluidAmount() < tile.tank.getCapacity()) {
/* 568 */             tile.fill(ForgeDirection.UNKNOWN, FluidContainerRegistry.getFluidForFilledItem(player.inventory.getCurrentItem()), true);
/* 569 */             ItemStack emptyContainer = null;
/* 570 */             FluidContainerRegistry.FluidContainerData[] fcs = FluidContainerRegistry.getRegisteredFluidContainerData();
/* 571 */             for (FluidContainerRegistry.FluidContainerData fcd : fcs) {
/* 572 */               if (fcd.filledContainer.isItemEqual(player.inventory.getCurrentItem())) {
/* 573 */                 emptyContainer = fcd.emptyContainer.copy();
/*     */               }
/*     */             } 
/*     */             
/* 577 */             player.inventory.decrStackSize(player.inventory.currentItem, 1);
/* 578 */             if (emptyContainer != null && 
/* 579 */               !player.inventory.addItemStackToInventory(emptyContainer)) {
/* 580 */               player.dropPlayerItemWithRandomChoice(emptyContainer, false);
/*     */             }
/*     */             
/* 583 */             player.inventoryContainer.detectAndSendChanges();
/* 584 */             te.markDirty();
/* 585 */             world.markBlockForUpdate(x, y, z);
/* 586 */             world.playSoundEffect(x + 0.5D, y + 0.5D, z + 0.5D, "game.neutral.swim", 0.33F, 1.0F + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.3F);
/*     */           } else {
/* 588 */             return true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 594 */     if (metadata == 1 && !world.isRemote && !player.isSneaking() && player.getHeldItem() == null) {
/* 595 */       TileEntity te = world.getTileEntity(x, y, z);
/* 596 */       if (te != null && te instanceof TileAlembic) {
/* 597 */         TileAlembic tile = (TileAlembic)te;
/* 598 */         String msg = "";
/* 599 */         if (tile.aspect == null || tile.amount == 0) {
/* 600 */           msg = StatCollector.translateToLocal("tile.alembic.msg.1");
/* 601 */         } else if (tile.amount < tile.maxAmount * 0.4D) {
/* 602 */           msg = StatCollector.translateToLocal("tile.alembic.msg.2");
/* 603 */         } else if (tile.amount < tile.maxAmount * 0.8D) {
/* 604 */           msg = StatCollector.translateToLocal("tile.alembic.msg.3");
/* 605 */         } else if (tile.amount < tile.maxAmount) {
/* 606 */           msg = StatCollector.translateToLocal("tile.alembic.msg.4");
/* 607 */         } else if (tile.amount == tile.maxAmount) {
/* 608 */           msg = StatCollector.translateToLocal("tile.alembic.msg.5");
/*     */         } 
/*     */         
/* 611 */         player.addChatMessage((IChatComponent)new ChatComponentTranslation("§3" + msg, new Object[0]));
/* 612 */         world.playSoundEffect(x, y, z, "thaumcraft:alembicknock", 0.2F, 1.0F);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 618 */     if (metadata == 1) {
/* 619 */       TileEntity te = world.getTileEntity(x, y, z);
/* 620 */       if (te != null && te instanceof TileAlembic) {
/* 621 */         if (player.isSneaking() && ((TileAlembic)te).aspectFilter != null) {
/* 622 */           ((TileAlembic)te).aspectFilter = null;
/* 623 */           world.markBlockForUpdate(x, y, z);
/* 624 */           te.markDirty();
/* 625 */           if (world.isRemote) {
/* 626 */             world.playSound((x + 0.5F), (y + 0.5F), (z + 0.5F), "thaumcraft:page", 1.0F, 1.1F, false);
/*     */           } else {
/* 628 */             ForgeDirection fd = ForgeDirection.getOrientation(side);
/* 629 */             world.spawnEntityInWorld((Entity)new EntityItem(world, (x + 0.5F + fd.offsetX / 3.0F), (y + 0.5F), (z + 0.5F + fd.offsetZ / 3.0F), new ItemStack(ConfigItems.itemResource, 1, 13)));
/*     */           } 
/*     */           
/* 632 */           return true;
/*     */         } 
/*     */         
/* 635 */         if (player.isSneaking() && player.getHeldItem() == null) {
/* 636 */           ((TileAlembic)te).amount = 0;
/* 637 */           ((TileAlembic)te).aspect = null;
/* 638 */           if (world.isRemote) {
/* 639 */             world.playSound((x + 0.5F), (y + 0.5F), (z + 0.5F), "thaumcraft:alembicknock", 0.2F, 1.0F, false);
/* 640 */             world.playSound((x + 0.5F), (y + 0.5F), (z + 0.5F), "game.neutral.swim", 0.5F, 1.0F + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.3F, false);
/*     */           } 
/*     */         } else {
/*     */           
/* 644 */           if (player.getHeldItem() != null && ((TileAlembic)te).aspectFilter == null && player.getHeldItem().getItem() == ConfigItems.itemResource && player.getHeldItem().getItemDamage() == 13) {
/*     */ 
/*     */ 
/*     */             
/* 648 */             if (((TileAlembic)te).amount == 0 && ((IEssentiaContainerItem)player.getHeldItem().getItem()).getAspects(player.getHeldItem()) == null) {
/* 649 */               return true;
/*     */             }
/*     */             
/* 652 */             if (((TileAlembic)te).amount == 0 && ((IEssentiaContainerItem)player.getHeldItem().getItem()).getAspects(player.getHeldItem()) != null) {
/* 653 */               ((TileAlembic)te).aspect = ((IEssentiaContainerItem)player.getHeldItem().getItem()).getAspects(player.getHeldItem()).getAspects()[0];
/*     */             }
/*     */             
/* 656 */             (player.getHeldItem()).stackSize--;
/* 657 */             ((TileAlembic)te).aspectFilter = ((TileAlembic)te).aspect;
/* 658 */             world.markBlockForUpdate(x, y, z);
/* 659 */             te.markDirty();
/* 660 */             if (world.isRemote) {
/* 661 */               world.playSound((x + 0.5F), (y + 0.5F), (z + 0.5F), "thaumcraft:page", 1.0F, 0.9F, false);
/*     */             }
/* 663 */             return true;
/*     */           } 
/*     */           
/* 666 */           if (player.getHeldItem() != null && ((TileAlembic)te).amount > 0 && (player.getHeldItem().getItem() == ConfigItems.itemJarFilled || player.getHeldItem().isItemEqual(new ItemStack(ConfigBlocks.blockJar, 1, 0)) || player.getHeldItem().isItemEqual(new ItemStack(ConfigBlocks.blockJar, 1, 3)))) {
/*     */ 
/*     */ 
/*     */             
/* 670 */             boolean doit = false;
/* 671 */             ItemStack drop = null;
/* 672 */             if (player.getHeldItem().isItemEqual(new ItemStack(ConfigBlocks.blockJar, 1, 0)) || player.getHeldItem().isItemEqual(new ItemStack(ConfigBlocks.blockJar, 1, 3))) {
/*     */               
/* 674 */               drop = new ItemStack(ConfigItems.itemJarFilled, 1, player.getHeldItem().getItemDamage());
/* 675 */               doit = true;
/* 676 */               ((ItemJarFilled)drop.getItem()).setAspects(drop, (new AspectList()).add(((TileAlembic)te).aspect, ((TileAlembic)te).amount));
/* 677 */               ((TileAlembic)te).amount = 0;
/* 678 */               ((TileAlembic)te).aspect = null;
/* 679 */               (player.getHeldItem()).stackSize--;
/* 680 */               if (!player.inventory.addItemStackToInventory(drop) && 
/* 681 */                 !world.isRemote) world.spawnEntityInWorld((Entity)new EntityItem(world, player.posX, player.posY, player.posZ, drop));
/*     */             
/*     */             } else {
/* 684 */               drop = player.getHeldItem();
/* 685 */               if ((((ItemJarFilled)drop.getItem()).getAspects(drop) == null || ((ItemJarFilled)drop.getItem()).getAspects(drop).visSize() == 0 || ((ItemJarFilled)drop.getItem()).getAspects(drop).getAmount(((TileAlembic)te).aspect) > 0) && (((ItemJarFilled)drop.getItem()).getFilter(drop) == null || ((ItemJarFilled)drop.getItem()).getFilter(drop) == ((TileAlembic)te).aspect)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 691 */                 int amount = Math.min((((ItemJarFilled)drop.getItem()).getAspects(drop) == null) ? 64 : (64 - ((ItemJarFilled)drop.getItem()).getAspects(drop).visSize()), ((TileAlembic)te).amount);
/*     */ 
/*     */ 
/*     */                 
/* 695 */                 if (drop.getItemDamage() == 3) amount = ((TileAlembic)te).amount; 
/* 696 */                 if (amount > 0) {
/* 697 */                   ((TileAlembic)te).amount -= amount;
/* 698 */                   AspectList as = ((ItemJarFilled)drop.getItem()).getAspects(drop);
/* 699 */                   if (as == null) as = new AspectList(); 
/* 700 */                   as.add(((TileAlembic)te).aspect, amount);
/* 701 */                   if (as.getAmount(((TileAlembic)te).aspect) > 64) {
/* 702 */                     int q = as.getAmount(((TileAlembic)te).aspect) - 64;
/* 703 */                     as.reduce(((TileAlembic)te).aspect, q);
/*     */                   } 
/* 705 */                   ((ItemJarFilled)drop.getItem()).setAspects(drop, as);
/* 706 */                   if (((TileAlembic)te).amount <= 0) {
/* 707 */                     ((TileAlembic)te).aspect = null;
/*     */                   }
/* 709 */                   doit = true;
/* 710 */                   player.setCurrentItemOrArmor(0, drop);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */             
/* 715 */             if (doit) {
/* 716 */               te.markDirty();
/* 717 */               world.markBlockForUpdate(x, y, z);
/* 718 */               if (world.isRemote) {
/* 719 */                 world.playSound((x + 0.5F), (y + 0.5F), (z + 0.5F), "game.neutral.swim", 0.5F, 1.0F + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.3F, false);
/*     */               }
/*     */             } 
/* 722 */             return true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 727 */     if (metadata == 5) {
/* 728 */       world.setBlockMetadataWithNotify(x, y, z, 6, 2);
/* 729 */       world.playAuxSFXAtEntity(player, 1003, x, y, z, 0);
/* 730 */       return true;
/*     */     } 
/* 732 */     if (metadata == 6) {
/* 733 */       world.setBlockMetadataWithNotify(x, y, z, 5, 2);
/* 734 */       world.playAuxSFXAtEntity(player, 1003, x, y, z, 0);
/* 735 */       return true;
/*     */     } 
/*     */     
/* 738 */     if (world.isRemote) return true;
/*     */     
/* 740 */     if (metadata == 10) {
/* 741 */       TileEntity te = world.getTileEntity(x, y, z);
/* 742 */       if (te instanceof TileThaumatorium && !player.isSneaking()) {
/* 743 */         player.openGui(Thaumcraft.instance, 3, world, x, y, z);
/* 744 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 748 */     if (metadata == 11) {
/* 749 */       TileEntity te = world.getTileEntity(x, y - 1, z);
/* 750 */       if (te instanceof TileThaumatorium && !player.isSneaking()) {
/* 751 */         player.openGui(Thaumcraft.instance, 3, world, x, y - 1, z);
/* 752 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 756 */     if ((metadata == 14 || metadata == 2) && !world.isRemote && !player.isSneaking() && player.getHeldItem() != null && player.getHeldItem().getItem() instanceof thaumcraft.common.items.ItemShard) {
/*     */       
/* 758 */       TileEntity te = world.getTileEntity(x, y, z);
/* 759 */       if (te != null && te instanceof TileVisRelay) {
/* 760 */         TileVisRelay tile = (TileVisRelay)te;
/* 761 */         byte c = (byte)player.getHeldItem().getItemDamage();
/* 762 */         if (c == tile.color || c == 6) {
/* 763 */           tile.color = -1;
/*     */         } else {
/* 765 */           tile.color = c;
/*     */         } 
/* 767 */         tile.removeThisNode();
/* 768 */         tile.nodeRefresh = true;
/* 769 */         tile.markDirty();
/* 770 */         world.markBlockForUpdate(x, y, z);
/* 771 */         world.playSoundEffect(x, y, z, "thaumcraft:crystal", 0.2F, 1.0F);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 776 */     return super.onBlockActivated(world, x, y, z, player, side, par7, par8, par9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onPoweredBlockChange(World par1World, int par2, int par3, int par4, boolean flag) {
/* 783 */     int l = par1World.getBlockMetadata(par2, par3, par4);
/*     */     
/* 785 */     if (l == 5 && flag) {
/*     */       
/* 787 */       par1World.setBlockMetadataWithNotify(par2, par3, par4, 6, 2);
/* 788 */       par1World.playAuxSFXAtEntity((EntityPlayer)null, 1003, par2, par3, par4, 0);
/*     */     }
/* 790 */     else if (l == 6 && !flag) {
/*     */       
/* 792 */       par1World.setBlockMetadataWithNotify(par2, par3, par4, 5, 2);
/* 793 */       par1World.playAuxSFXAtEntity((EntityPlayer)null, 1003, par2, par3, par4, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockPlacedBy(World world, int par2, int par3, int par4, EntityLivingBase ent, ItemStack stack) {
/* 800 */     int l = MathHelper.floor_double((ent.rotationYaw * 4.0F / 360.0F) + 0.5D) & 0x3;
/* 801 */     if (stack.getItemDamage() == 1) {
/* 802 */       TileEntity tile = world.getTileEntity(par2, par3, par4);
/* 803 */       if (tile instanceof TileAlembic) {
/* 804 */         if (l == 0)
/*     */         {
/* 806 */           ((TileAlembic)tile).facing = 2;
/*     */         }
/*     */         
/* 809 */         if (l == 1)
/*     */         {
/* 811 */           ((TileAlembic)tile).facing = 5;
/*     */         }
/*     */         
/* 814 */         if (l == 2)
/*     */         {
/* 816 */           ((TileAlembic)tile).facing = 3;
/*     */         }
/*     */         
/* 819 */         if (l == 3)
/*     */         {
/* 821 */           ((TileAlembic)tile).facing = 4;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLightValue(IBlockAccess world, int x, int y, int z) {
/* 829 */     int md = world.getBlockMetadata(x, y, z);
/* 830 */     if (md == 3) return 11; 
/* 831 */     if (md == 7) return 15; 
/* 832 */     if (md == 8) {
/* 833 */       TileEntity te = world.getTileEntity(x, y, z);
/* 834 */       if (te != null && te instanceof TileArcaneLampGrowth) {
/* 835 */         if (((TileArcaneLampGrowth)te).charges > 0) {
/* 836 */           return 15;
/*     */         }
/* 838 */         return 8;
/*     */       }
/*     */     
/*     */     }
/* 842 */     else if (md == 13) {
/* 843 */       TileEntity te = world.getTileEntity(x, y, z);
/* 844 */       if (te != null && te instanceof TileArcaneLampFertility) {
/* 845 */         if (((TileArcaneLampFertility)te).charges > 0) {
/* 846 */           return 15;
/*     */         }
/* 848 */         return 8;
/*     */       }
/*     */     
/*     */     }
/* 852 */     else if (md == 14) {
/* 853 */       TileEntity te = world.getTileEntity(x, y, z);
/* 854 */       if (te != null && te instanceof TileVisRelay) {
/* 855 */         if (VisNetHandler.isNodeValid(((TileVisRelay)te).getParent())) {
/* 856 */           return 10;
/*     */         }
/* 858 */         return 2;
/*     */       } 
/*     */     } 
/*     */     
/* 862 */     return super.getLightValue(world, x, y, z);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockMetalDevice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */