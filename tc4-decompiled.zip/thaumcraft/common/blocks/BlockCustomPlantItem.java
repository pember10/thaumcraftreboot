/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.EnumPlantType;
/*     */ import net.minecraftforge.common.IPlantable;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockCustomPlantItem
/*     */   extends ItemBlock
/*     */ {
/*     */   public IIcon[] icon;
/*     */   
/*     */   public BlockCustomPlantItem(Block par1) {
/*  26 */     super(par1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  31 */     this.icon = new IIcon[6];
/*     */     setMaxDamage(0);
/*     */     setHasSubtypes(true); } @SideOnly(Side.CLIENT)
/*     */   public void registerIcons(IIconRegister ir) {
/*  35 */     this.icon[0] = ir.registerIcon("thaumcraft:greatwoodsapling");
/*  36 */     this.icon[1] = ir.registerIcon("thaumcraft:silverwoodsapling");
/*  37 */     this.icon[2] = ir.registerIcon("thaumcraft:shimmerleaf");
/*  38 */     this.icon[3] = ir.registerIcon("thaumcraft:cinderpearl");
/*  39 */     this.icon[4] = ir.registerIcon("thaumcraft:purifier_seed");
/*  40 */     this.icon[5] = ir.registerIcon("thaumcraft:manashroom");
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIconFromDamage(int meta) {
/*  46 */     return this.icon[meta];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMetadata(int par1) {
/*  53 */     return par1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/*  59 */     return getUnlocalizedName() + "." + par1ItemStack.getItemDamage();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float p_77648_8_, float p_77648_9_, float p_77648_10_) {
/*  65 */     if (side != 1)
/*     */     {
/*  67 */       return false;
/*     */     }
/*  69 */     if (player.canPlayerEdit(x, y, z, side, stack) && player.canPlayerEdit(x, y + 1, z, side, stack)) {
/*     */ 
/*     */       
/*  72 */       if (world.getBlock(x, y, z).canSustainPlant((IBlockAccess)world, x, y, z, ForgeDirection.UP, new CustomPlantTypes(stack.getItemDamage())) && world.isAirBlock(x, y + 1, z)) {
/*     */         
/*  74 */         world.setBlock(x, y + 1, z, ConfigBlocks.blockCustomPlant, stack.getItemDamage(), 3);
/*  75 */         world.playSoundEffect((x + 0.5F), (y + 1.5F), (z + 0.5F), ConfigBlocks.blockCustomPlant.stepSound.getStepResourcePath(), (ConfigBlocks.blockCustomPlant.stepSound.getVolume() + 1.0F) / 2.0F, ConfigBlocks.blockCustomPlant.stepSound.getPitch() * 0.8F);
/*  76 */         stack.stackSize--;
/*  77 */         return true;
/*     */       } 
/*     */ 
/*     */       
/*  81 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  86 */     return false;
/*     */   }
/*     */   
/*     */   private class CustomPlantTypes
/*     */     implements IPlantable
/*     */   {
/*  92 */     int md = 0;
/*     */     
/*     */     public CustomPlantTypes(int md) {
/*  95 */       this.md = md;
/*     */     }
/*     */ 
/*     */     
/*     */     public EnumPlantType getPlantType(IBlockAccess world, int x, int y, int z) {
/* 100 */       if (this.md == 3) return EnumPlantType.Desert; 
/* 101 */       if (this.md == 4 || this.md == 5) return EnumPlantType.Cave; 
/* 102 */       return EnumPlantType.Plains;
/*     */     }
/*     */ 
/*     */     
/*     */     public Block getPlant(IBlockAccess world, int x, int y, int z) {
/* 107 */       return ConfigBlocks.blockCustomPlant;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getPlantMetadata(IBlockAccess world, int x, int y, int z) {
/* 112 */       return this.md;
/*     */     }
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockCustomPlantItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */