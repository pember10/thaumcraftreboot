/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.BlockPistonBase;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.lib.utils.InventoryUtils;
/*     */ import thaumcraft.common.tiles.TileChestHungry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockChestHungry
/*     */   extends BlockContainer
/*     */ {
/*  37 */   private Random random = new Random();
/*     */   public IIcon icon;
/*     */   
/*     */   public BlockChestHungry() {
/*  41 */     super(Material.wood);
/*  42 */     setHardness(2.5F);
/*  43 */     setStepSound(soundTypeWood);
/*  44 */     setCreativeTab(Thaumcraft.tabTC);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*  51 */     this.icon = ir.registerIcon("thaumcraft:woodplain");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int meta) {
/*  56 */     return this.icon;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/*  62 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/*  74 */     return ConfigBlocks.blockChestHungryRI;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasComparatorInputOverride() {
/*  79 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getComparatorInputOverride(World world, int x, int y, int z, int rs) {
/*  85 */     TileEntity te = world.getTileEntity(x, y, z);
/*  86 */     if (te != null && te instanceof IInventory)
/*  87 */       return Container.calcRedstoneFromInventory((IInventory)te); 
/*  88 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockPlacedBy(World par1World, int par2, int par3, int par4, EntityLivingBase par5EntityLiving, ItemStack is) {
/*  94 */     int var6 = par1World.getBlockMetadata(par2, par3, par4) & 0x3;
/*  95 */     int var7 = BlockPistonBase.determineOrientation(par1World, par2, par3, par4, par5EntityLiving);
/*     */     
/*  97 */     par1World.setBlock(par2, par3, par4, (Block)this, var7, 3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void breakBlock(World par1World, int par2, int par3, int par4, Block par5, int par6) {
/* 103 */     TileChestHungry var7 = (TileChestHungry)par1World.getTileEntity(par2, par3, par4);
/*     */     
/* 105 */     if (var7 != null)
/*     */     {
/* 107 */       for (int var8 = 0; var8 < var7.getSizeInventory(); var8++) {
/*     */         
/* 109 */         ItemStack var9 = var7.getStackInSlot(var8);
/*     */         
/* 111 */         if (var9 != null) {
/*     */           
/* 113 */           float var10 = this.random.nextFloat() * 0.8F + 0.1F;
/* 114 */           float var11 = this.random.nextFloat() * 0.8F + 0.1F;
/*     */ 
/*     */           
/* 117 */           for (float var12 = this.random.nextFloat() * 0.8F + 0.1F; var9.stackSize > 0; par1World.spawnEntityInWorld((Entity)var14)) {
/*     */             
/* 119 */             int var13 = this.random.nextInt(21) + 10;
/*     */             
/* 121 */             if (var13 > var9.stackSize)
/*     */             {
/* 123 */               var13 = var9.stackSize;
/*     */             }
/*     */             
/* 126 */             var9.stackSize -= var13;
/* 127 */             EntityItem var14 = new EntityItem(par1World, (par2 + var10), (par3 + var11), (par4 + var12), new ItemStack(var9.getItem(), var13, var9.getItemDamage()));
/* 128 */             float var15 = 0.05F;
/* 129 */             var14.motionX = ((float)this.random.nextGaussian() * var15);
/* 130 */             var14.motionY = ((float)this.random.nextGaussian() * var15 + 0.2F);
/* 131 */             var14.motionZ = ((float)this.random.nextGaussian() * var15);
/*     */             
/* 133 */             if (var9.hasTagCompound())
/*     */             {
/* 135 */               var14.getEntityItem().setTagCompound((NBTTagCompound)var9.getTagCompound().copy());
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 142 */     super.breakBlock(par1World, par2, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
/* 148 */     float var5 = 0.0625F;
/* 149 */     return AxisAlignedBB.getBoundingBox((par2 + var5), par3, (par4 + var5), ((par2 + 1) - var5), ((par3 + 1) - var5), ((par4 + 1) - var5));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess par1IBlockAccess, int par2, int par3, int par4) {
/* 155 */     setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
/* 160 */     Object var10 = world.getTileEntity(x, y, z);
/* 161 */     if (var10 == null) {
/*     */       return;
/*     */     }
/*     */     
/* 165 */     if (world.isRemote) {
/*     */       return;
/*     */     }
/*     */     
/* 169 */     if (entity instanceof EntityItem && !entity.isDead) {
/* 170 */       ItemStack leftovers = InventoryUtils.placeItemStackIntoInventory(((EntityItem)entity).getEntityItem(), (IInventory)var10, 1, true);
/* 171 */       if (leftovers == null || leftovers.stackSize != (((EntityItem)entity).getEntityItem()).stackSize) {
/* 172 */         world.playSoundAtEntity(entity, "random.eat", 0.25F, (world.rand.nextFloat() - world.rand.nextFloat()) * 0.2F + 1.0F);
/* 173 */         world.addBlockEvent(x, y, z, ConfigBlocks.blockChestHungry, 2, 2);
/*     */       } 
/*     */       
/* 176 */       if (leftovers != null) {
/* 177 */         ((EntityItem)entity).setEntityItemStack(leftovers);
/*     */       } else {
/* 179 */         entity.setDead();
/*     */       } 
/* 181 */       ((TileChestHungry)var10).markDirty();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBlockActivated(World par1World, int par2, int par3, int par4, EntityPlayer par5EntityPlayer, int par6, float par7, float par8, float par9) {
/* 188 */     Object var10 = par1World.getTileEntity(par2, par3, par4);
/* 189 */     if (var10 == null)
/*     */     {
/* 191 */       return true;
/*     */     }
/*     */     
/* 194 */     if (par1World.isRemote)
/*     */     {
/* 196 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 200 */     par5EntityPlayer.displayGUIChest((IInventory)var10);
/* 201 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World par1World, int m) {
/* 208 */     return (TileEntity)new TileChestHungry();
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockChestHungry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */