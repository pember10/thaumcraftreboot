/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileLifter;
/*     */ 
/*     */ public class BlockLifter
/*     */   extends BlockContainer
/*     */ {
/*  22 */   private Random random = new Random();
/*     */   public IIcon iconTop;
/*     */   
/*     */   public BlockLifter() {
/*  26 */     super(Material.wood);
/*  27 */     setHardness(2.5F);
/*  28 */     setResistance(15.0F);
/*  29 */     setStepSound(soundTypeWood);
/*  30 */     setCreativeTab(Thaumcraft.tabTC);
/*     */   }
/*     */ 
/*     */   
/*     */   public IIcon iconBottom;
/*     */   public IIcon iconSide;
/*     */   public IIcon iconGlow;
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*  40 */     this.iconTop = ir.registerIcon("thaumcraft:liftertop");
/*  41 */     this.iconBottom = ir.registerIcon("thaumcraft:arcaneearbottom");
/*  42 */     this.iconSide = ir.registerIcon("thaumcraft:lifterside");
/*  43 */     this.iconGlow = ir.registerIcon("thaumcraft:animatedglow");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IIcon getIcon(int par1, int par2) {
/*  49 */     if (par1 == 0) return this.iconBottom; 
/*  50 */     if (par1 == 1) return this.iconTop; 
/*  51 */     return this.iconSide;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/*  57 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/*  62 */     return ConfigBlocks.blockLifterRI;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World w, int i, int j, int k, Random r) {
/*  68 */     TileEntity te = w.getTileEntity(i, j, k);
/*  69 */     if (te != null && te instanceof TileLifter && !((TileLifter)te).gettingPower() && 
/*  70 */       ((TileLifter)te).rangeAbove > 0) {
/*  71 */       Thaumcraft.proxy.sparkle(i + 0.2F + r.nextFloat() * 0.6F, (j + 1), k + 0.2F + r.nextFloat() * 0.6F, 1.0F, 3, -0.3F);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSideSolid(IBlockAccess world, int x, int y, int z, ForgeDirection side) {
/*  78 */     return (side != ForgeDirection.UP && side != ForgeDirection.DOWN);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canConnectRedstone(IBlockAccess world, int x, int y, int z, int side) {
/*  83 */     return (side > 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockAdded(World world, int x, int y, int z) {
/*  90 */     updateLifterStack(world, x, y, z);
/*  91 */     super.onBlockAdded(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block par5, int par6) {
/*  98 */     updateLifterStack(world, x, y, z);
/*  99 */     super.breakBlock(world, x, y, z, par5, par6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNeighborBlockChange(World world, int x, int y, int z, Block par5) {
/* 107 */     TileEntity te = world.getTileEntity(x, y, z);
/* 108 */     if (te != null && te instanceof TileLifter && ((TileLifter)te).gettingPower() != ((TileLifter)te).lastPowerState) {
/* 109 */       updateLifterStack(world, x, y, z);
/*     */     }
/*     */     
/* 112 */     super.onNeighborBlockChange(world, x, y, z, par5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateLifterStack(World worldObj, int xCoord, int yCoord, int zCoord) {
/* 118 */     int count = 1;
/* 119 */     while (worldObj.getBlock(xCoord, yCoord - count, zCoord) == this) {
/* 120 */       TileEntity te = worldObj.getTileEntity(xCoord, yCoord - count, zCoord);
/* 121 */       if (te != null && te instanceof TileLifter) ((TileLifter)te).requiresUpdate = true; 
/* 122 */       count++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World var1, int md) {
/* 130 */     return (TileEntity)new TileLifter();
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockLifter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */