/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.particle.EffectRenderer;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.EnumCreatureType;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.Explosion;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.IPlantable;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileWarded;
/*     */ 
/*     */ public class BlockWarded extends BlockContainer {
/*     */   public IIcon icon;
/*     */   public IIcon iconRune;
/*     */   int sc;
/*     */   
/*  38 */   public BlockWarded() { super(Material.rock);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     this.sc = 0; setStepSound(soundTypeStone); disableStats(); setResistance(999.0F); setBlockUnbreakable(); }
/*     */   @SideOnly(Side.CLIENT) public void registerBlockIcons(IIconRegister ir) { this.icon = ir.registerIcon("thaumcraft:blank"); this.iconRune = ir.registerIcon("thaumcraft:runeborder"); }
/*     */   public IIcon getIcon(int i, int m) { return this.icon; }
/*  90 */   public boolean isOpaqueCube() { return false; } public Block getBlock(World world, int x, int y, int z) { if (this.sc > 5) {
/*  91 */       this.sc = 0;
/*  92 */       return Blocks.stone;
/*     */     } 
/*  94 */     this.sc++;
/*  95 */     TileEntity tile = world.getTileEntity(x, y, z);
/*  96 */     if (tile != null && tile instanceof TileWarded) {
/*  97 */       this.sc = 0;
/*  98 */       return ((TileWarded)tile).block;
/*     */     } 
/* 100 */     return Blocks.stone; }
/*     */   public boolean renderAsNormalBlock() { return false; }
/*     */   public boolean addHitEffects(World worldObj, MovingObjectPosition target, EffectRenderer effectRenderer) { float f = (float)target.hitVec.xCoord - target.blockX; float f1 = (float)target.hitVec.yCoord - target.blockY; float f2 = (float)target.hitVec.zCoord - target.blockZ; Thaumcraft.proxy.blockWard(worldObj, target.blockX, target.blockY, target.blockZ, ForgeDirection.getOrientation(target.sideHit), f, f1, f2);
/*     */     return true; }
/* 104 */   public int getRenderType() { return ConfigBlocks.blockWardedRI; } public Block getBlock(IBlockAccess world, int x, int y, int z) { if (this.sc > 5) {
/* 105 */       this.sc = 0;
/* 106 */       return Blocks.stone;
/*     */     } 
/* 108 */     this.sc++;
/* 109 */     TileEntity tile = world.getTileEntity(x, y, z);
/* 110 */     if (tile != null && tile instanceof TileWarded) {
/* 111 */       this.sc = 0;
/* 112 */       return ((TileWarded)tile).block;
/*     */     } 
/* 114 */     return Blocks.stone; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Item getItemDropped(int par1, Random par2Random, int par3) {
/* 120 */     return Item.getItemById(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int damageDropped(int par1) {
/* 125 */     return par1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMobilityFlag() {
/* 132 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World var1, int md) {
/* 137 */     return (TileEntity)new TileWarded();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canBeReplacedByLeaves(IBlockAccess world, int x, int y, int z) {
/* 142 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEntityDestroy(IBlockAccess world, int x, int y, int z, Entity entity) {
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreatureSpawn(EnumCreatureType type, IBlockAccess world, int x, int y, int z) {
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(IBlockAccess ba, int x, int y, int z, int par5) {
/* 159 */     return getBlock(ba, x, y, z).getIcon(ba, x, y, z, par5);
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int colorMultiplier(IBlockAccess ba, int x, int y, int z) {
/* 165 */     return getBlock(ba, x, y, z).colorMultiplier(ba, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDamageValue(World world, int x, int y, int z) {
/* 170 */     return getBlock(world, x, y, z).getDamageValue(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMixedBrightnessForBlock(IBlockAccess ba, int x, int y, int z) {
/* 176 */     return getBlock(ba, x, y, z).getMixedBrightnessForBlock(ba, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldSideBeRendered(IBlockAccess ba, int x, int y, int z, int par5) {
/* 181 */     return getBlock(ba, x, y, z).shouldSideBeRendered(ba, x, y, z, par5);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBlockSolid(IBlockAccess ba, int x, int y, int z, int par5) {
/* 186 */     return getBlock(ba, x, y, z).isBlockSolid(ba, x, y, z, par5);
/*     */   }
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getSelectedBoundingBoxFromPool(World ba, int x, int y, int z) {
/* 191 */     return getBlock(ba, x, y, z).getSelectedBoundingBoxFromPool(ba, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getCollisionBoundingBoxFromPool(World ba, int x, int y, int z) {
/* 196 */     return getBlock(ba, x, y, z).getCollisionBoundingBoxFromPool(ba, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public void randomDisplayTick(World ba, int x, int y, int z, Random par5Random) {
/* 201 */     getBlock(ba, x, y, z).randomDisplayTick(ba, x, y, z, par5Random);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canPlaceBlockOnSide(World ba, int x, int y, int z, int par5) {
/* 206 */     return getBlock(ba, x, y, z).canPlaceBlockOnSide(ba, x, y, z, par5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEntityWalking(World ba, int x, int y, int z, Entity par5Entity) {
/* 212 */     getBlock(ba, x, y, z).onEntityWalking(ba, x, y, z, par5Entity);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onBlockClicked(World ba, int x, int y, int z, EntityPlayer par5EntityPlayer) {
/* 217 */     getBlock(ba, x, y, z).onBlockClicked(ba, x, y, z, par5EntityPlayer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void velocityToAddToEntity(World ba, int x, int y, int z, Entity par5Entity, Vec3 par6Vec3) {
/* 222 */     getBlock(ba, x, y, z).velocityToAddToEntity(ba, x, y, z, par5Entity, par6Vec3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess ba, int x, int y, int z) {
/* 227 */     getBlock(ba, x, y, z).setBlockBoundsBasedOnState(ba, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCollisionBoxesToList(World ba, int x, int y, int z, AxisAlignedBB aabb, List list, Entity entity) {
/* 232 */     getBlock(ba, x, y, z).addCollisionBoxesToList(ba, x, y, z, aabb, list, entity);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEntityCollidedWithBlock(World ba, int x, int y, int z, Entity par5Entity) {
/* 237 */     getBlock(ba, x, y, z).onEntityCollidedWithBlock(ba, x, y, z, par5Entity);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onFallenUpon(World ba, int x, int y, int z, Entity par5Entity, float par6) {
/* 242 */     getBlock(ba, x, y, z).onFallenUpon(ba, x, y, z, par5Entity, par6);
/*     */   }
/*     */ 
/*     */   
/*     */   public Item getItem(World ba, int x, int y, int z) {
/* 247 */     return getBlock(ba, x, y, z).getItem(ba, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightValue(IBlockAccess world, int x, int y, int z) {
/* 253 */     TileEntity tile = world.getTileEntity(x, y, z);
/* 254 */     if (tile != null && tile instanceof TileWarded) {
/* 255 */       return ((TileWarded)tile).light;
/*     */     }
/* 257 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLadder(IBlockAccess world, int x, int y, int z, EntityLivingBase entity) {
/* 264 */     return getBlock(world, x, y, z).isLadder(world, x, y, z, entity);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNormalCube(IBlockAccess world, int x, int y, int z) {
/* 269 */     return getBlock(world, x, y, z).isNormalCube(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSideSolid(IBlockAccess world, int x, int y, int z, ForgeDirection side) {
/* 274 */     return getBlock(world, x, y, z).isSideSolid(world, x, y, z, side);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canSustainLeaves(IBlockAccess world, int x, int y, int z) {
/* 279 */     return getBlock(world, x, y, z).canSustainLeaves(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canPlaceTorchOnTop(World world, int x, int y, int z) {
/* 284 */     return getBlock(world, x, y, z).canPlaceTorchOnTop(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack getPickBlock(MovingObjectPosition target, World world, int x, int y, int z) {
/* 289 */     return getBlock(world, x, y, z).getPickBlock(target, world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFoliage(IBlockAccess world, int x, int y, int z) {
/* 294 */     return getBlock(world, x, y, z).isFoliage(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canSustainPlant(IBlockAccess world, int x, int y, int z, ForgeDirection direction, IPlantable plant) {
/* 299 */     return getBlock(world, x, y, z).canSustainPlant(world, x, y, z, direction, plant);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFertile(World world, int x, int y, int z) {
/* 304 */     return getBlock(world, x, y, z).isFertile(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLightOpacity(IBlockAccess world, int x, int y, int z) {
/* 309 */     return getBlock(world, x, y, z).getLightOpacity(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBeaconBase(IBlockAccess world, int x, int y, int z, int beaconX, int beaconY, int beaconZ) {
/* 314 */     return getBlock(world, x, y, z).isBeaconBase(world, x, y, z, beaconX, beaconY, beaconZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getEnchantPowerBonus(World world, int x, int y, int z) {
/* 319 */     return getBlock(world, x, y, z).getEnchantPowerBonus(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canHarvestBlock(EntityPlayer player, int meta) {
/* 335 */     return true;
/*     */   }
/*     */   
/*     */   public void onBlockExploded(World world, int x, int y, int z, Explosion explosion) {}
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockWarded.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */