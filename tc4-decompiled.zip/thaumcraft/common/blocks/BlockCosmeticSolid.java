/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.particle.EffectRenderer;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.EnumCreatureType;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.nodes.INode;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.config.ConfigItems;
/*     */ import thaumcraft.common.items.ItemWispEssence;
/*     */ import thaumcraft.common.tiles.TileNode;
/*     */ import thaumcraft.common.tiles.TileWardingStone;
/*     */ 
/*     */ public class BlockCosmeticSolid
/*     */   extends Block {
/*     */   public IIcon[] icon;
/*     */   
/*     */   public BlockCosmeticSolid() {
/*  41 */     super(Material.rock);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     this.icon = new IIcon[27]; setResistance(10.0F);
/*     */     setHardness(2.0F);
/*     */     setStepSound(soundTypeStone);
/*     */     setCreativeTab(Thaumcraft.tabTC);
/*  53 */     setTickRandomly(true); } @SideOnly(Side.CLIENT) public void registerBlockIcons(IIconRegister ir) { this.icon[0] = ir.registerIcon("thaumcraft:obsidiantile");
/*  54 */     this.icon[1] = ir.registerIcon("thaumcraft:obsidiantotembase");
/*  55 */     this.icon[2] = ir.registerIcon("thaumcraft:obsidiantotem1");
/*  56 */     this.icon[3] = ir.registerIcon("thaumcraft:obsidiantotem2");
/*  57 */     this.icon[4] = ir.registerIcon("thaumcraft:obsidiantotem3");
/*  58 */     this.icon[5] = ir.registerIcon("thaumcraft:obsidiantotem4");
/*  59 */     this.icon[6] = ir.registerIcon("thaumcraft:obsidiantotembaseshaded");
/*  60 */     this.icon[7] = ir.registerIcon("thaumcraft:paving_stone_travel");
/*  61 */     this.icon[8] = ir.registerIcon("thaumcraft:paving_stone_warding");
/*  62 */     this.icon[9] = ir.registerIcon("thaumcraft:thaumiumblock");
/*  63 */     this.icon[10] = ir.registerIcon("thaumcraft:tallowblock");
/*  64 */     this.icon[11] = ir.registerIcon("thaumcraft:tallowblock_top");
/*  65 */     this.icon[12] = ir.registerIcon("thaumcraft:pedestal_top");
/*  66 */     this.icon[13] = ir.registerIcon("thaumcraft:arcane_stone");
/*  67 */     this.icon[14] = ir.registerIcon("thaumcraft:golem_stone_top");
/*  68 */     this.icon[15] = ir.registerIcon("thaumcraft:golem_stone_side");
/*  69 */     this.icon[16] = ir.registerIcon("thaumcraft:golem_stone_top_active");
/*  70 */     this.icon[17] = ir.registerIcon("thaumcraft:es_1");
/*  71 */     this.icon[18] = ir.registerIcon("thaumcraft:es_2");
/*  72 */     this.icon[19] = ir.registerIcon("thaumcraft:es_3");
/*  73 */     this.icon[20] = ir.registerIcon("thaumcraft:es_4");
/*  74 */     this.icon[21] = ir.registerIcon("thaumcraft:er_1");
/*  75 */     this.icon[22] = ir.registerIcon("thaumcraft:er_2");
/*  76 */     this.icon[23] = ir.registerIcon("thaumcraft:er_3");
/*  77 */     this.icon[24] = ir.registerIcon("thaumcraft:er_4");
/*  78 */     this.icon[25] = ir.registerIcon("thaumcraft:crust");
/*  79 */     this.icon[26] = ir.registerIcon("thaumcraft:es_p"); }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int par1, int par2) {
/*  85 */     if (par2 <= 1 || par2 == 8) return this.icon[0]; 
/*  86 */     if (par2 == 2) {
/*  87 */       return this.icon[7];
/*     */     }
/*  89 */     if (par2 == 3) {
/*  90 */       return this.icon[8];
/*     */     }
/*  92 */     if (par2 == 4) {
/*  93 */       return this.icon[9];
/*     */     }
/*  95 */     if (par2 == 5) {
/*  96 */       return (par1 > 1) ? this.icon[10] : this.icon[11];
/*     */     }
/*  98 */     if (par2 == 6) {
/*  99 */       return this.icon[12];
/*     */     }
/* 101 */     if (par2 == 7) {
/* 102 */       return this.icon[13];
/*     */     }
/* 104 */     if (par2 == 9 || par2 == 10) {
/* 105 */       return (par1 == 0) ? this.icon[13] : ((par1 == 1) ? ((par2 == 9) ? this.icon[14] : this.icon[16]) : this.icon[15]);
/*     */     }
/* 107 */     if (par2 == 11 || par2 == 13) {
/* 108 */       return this.icon[17];
/*     */     }
/* 110 */     if (par2 == 12) {
/* 111 */       return this.icon[21];
/*     */     }
/* 113 */     if (par2 == 14) {
/* 114 */       return this.icon[25];
/*     */     }
/* 116 */     if (par2 == 15) {
/* 117 */       return (par1 <= 1) ? this.icon[17] : this.icon[26];
/*     */     }
/* 119 */     return super.getIcon(par1, par2);
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(IBlockAccess ba, int x, int y, int z, int side) {
/* 125 */     int md = ba.getBlockMetadata(x, y, z);
/* 126 */     if ((md == 0 || md == 8) && side > 1 && side < 100) {
/* 127 */       if (ba.getBlock(x, y + 1, z) == this && (ba.getBlockMetadata(x, y + 1, z) == 0 || ba.getBlockMetadata(x, y + 1, z) == 8)) return this.icon[6]; 
/* 128 */       if (ba.getBlock(x, y - 1, z) != this || (ba.getBlockMetadata(x, y - 1, z) != 0 && ba.getBlockMetadata(x, y - 1, z) != 8)) return this.icon[1]; 
/* 129 */       return this.icon[2 + Math.abs((side + x % 4 + z % 4 + y % 4) % 4)];
/*     */     } 
/* 131 */     if (md == 11 || md == 13 || side >= 100) {
/* 132 */       String l = x + "" + y + "" + z;
/* 133 */       Random r1 = new Random((Math.abs(l.hashCode() * 100) + 1));
/* 134 */       int i = r1.nextInt(12345 + side) % 4;
/* 135 */       return this.icon[17 + i];
/* 136 */     }  if (md == 12) {
/* 137 */       switch (side) { case 0: case 1:
/* 138 */           return this.icon[21 + Math.abs(x % 2) + Math.abs(z % 2) * 2];
/* 139 */         case 2: case 3: return this.icon[21 + Math.abs(x % 2) + Math.abs(y % 2) * 2];
/* 140 */         case 4: case 5: return this.icon[21 + Math.abs(z % 2) + Math.abs(y % 2) * 2]; }
/*     */     
/*     */     }
/* 143 */     return super.getIcon(ba, x, y, z, side);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess world, int i, int j, int k) {
/* 148 */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlockBoundsForItemRender() {
/* 153 */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreatureSpawn(EnumCreatureType type, IBlockAccess world, int x, int y, int z) {
/* 159 */     int md = world.getBlockMetadata(x, y, z);
/* 160 */     return (md == 2 || md == 3 || md == 13) ? false : super.canCreatureSpawn(type, world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/* 169 */     par3List.add(new ItemStack(par1, 1, 0));
/* 170 */     par3List.add(new ItemStack(par1, 1, 1));
/* 171 */     par3List.add(new ItemStack(par1, 1, 2));
/* 172 */     par3List.add(new ItemStack(par1, 1, 3));
/* 173 */     par3List.add(new ItemStack(par1, 1, 4));
/* 174 */     par3List.add(new ItemStack(par1, 1, 5));
/* 175 */     par3List.add(new ItemStack(par1, 1, 6));
/* 176 */     par3List.add(new ItemStack(par1, 1, 7));
/* 177 */     par3List.add(new ItemStack(par1, 1, 8));
/* 178 */     par3List.add(new ItemStack(par1, 1, 9));
/* 179 */     par3List.add(new ItemStack(par1, 1, 11));
/* 180 */     par3List.add(new ItemStack(par1, 1, 12));
/* 181 */     par3List.add(new ItemStack(par1, 1, 14));
/* 182 */     par3List.add(new ItemStack(par1, 1, 15));
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBlockHardness(World world, int x, int y, int z) {
/* 187 */     if (world.getBlock(x, y, z) != this) return 4.0F; 
/* 188 */     int md = world.getBlockMetadata(x, y, z);
/* 189 */     if (md <= 1 || md == 8) return 30.0F; 
/* 190 */     if (md == 4 || md == 6 || md == 7) return 4.0F; 
/* 191 */     return super.getBlockHardness(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLightValue(IBlockAccess world, int x, int y, int z) {
/* 196 */     if (world.getBlock(x, y, z) != this) return 0; 
/* 197 */     int md = world.getBlockMetadata(x, y, z);
/* 198 */     if (md == 2) return 9; 
/* 199 */     if (md == 14) return 4; 
/* 200 */     return super.getLightValue(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getExplosionResistance(Entity par1Entity, World world, int x, int y, int z, double explosionX, double explosionY, double explosionZ) {
/* 207 */     if (world.getBlock(x, y, z) != this) return 20.0F; 
/* 208 */     int md = world.getBlockMetadata(x, y, z);
/* 209 */     if (md <= 1 || md == 8) return 999.0F; 
/* 210 */     if (md == 4 || md == 6 || md == 7) return 20.0F; 
/* 211 */     return super.getExplosionResistance(par1Entity, world, x, y, z, explosionX, explosionY, explosionZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int quantityDropped(Random par1Random) {
/* 218 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int damageDropped(int par1) {
/* 223 */     return (par1 == 8) ? 1 : ((par1 == 10) ? 9 : par1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEntityWalking(World world, int x, int y, int z, Entity e) {
/* 228 */     if (world.getBlock(x, y, z) != this)
/* 229 */       return;  int md = world.getBlockMetadata(x, y, z);
/* 230 */     if (md == 2 && e instanceof EntityLivingBase) {
/* 231 */       if (world.isRemote) {
/* 232 */         Thaumcraft.proxy.blockSparkle(world, x, y, z, 32768, 5);
/*     */       }
/* 234 */       ((EntityLivingBase)e).addPotionEffect(new PotionEffect(Potion.moveSpeed.id, 40, 1));
/* 235 */       ((EntityLivingBase)e).addPotionEffect(new PotionEffect(Potion.jump.id, 40, 0));
/*     */     } 
/* 237 */     super.onEntityWalking(world, x, y, z, e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTileEntity(int metadata) {
/* 243 */     if (metadata == 3) return true; 
/* 244 */     if (metadata == 8) return true; 
/* 245 */     return super.hasTileEntity(metadata);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity createTileEntity(World world, int metadata) {
/* 251 */     if (metadata == 3) return (TileEntity)new TileWardingStone(); 
/* 252 */     if (metadata == 8) return (TileEntity)new TileNode(); 
/* 253 */     return super.createTileEntity(world, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addDestroyEffects(World world, int x, int y, int z, int meta, EffectRenderer effectRenderer) {
/* 258 */     if (meta == 8) {
/* 259 */       Thaumcraft.proxy.burst(world, x + 0.5D, y + 0.5D, z + 0.5D, 1.0F);
/* 260 */       world.playSound(x + 0.5D, y + 0.5D, z + 0.5D, "thaumcraft:craftfail", 1.0F, 1.0F, false);
/*     */     } 
/* 262 */     return super.addDestroyEffects(world, x, y, z, meta, effectRenderer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockHarvested(World par1World, int par2, int par3, int par4, int par5, EntityPlayer par6EntityPlayer) {
/* 268 */     if (par1World.getBlock(par2, par3, par4) != this)
/* 269 */       return;  if (par5 == 8 && !par1World.isRemote) {
/*     */       
/* 271 */       TileEntity te = par1World.getTileEntity(par2, par3, par4);
/* 272 */       if (te != null && te instanceof INode && ((INode)te).getAspects().size() > 0)
/* 273 */         for (Aspect aspect : ((INode)te).getAspects().getAspects()) {
/* 274 */           for (int a = 0; a <= ((INode)te).getAspects().getAmount(aspect) / 10; a++) {
/* 275 */             if (((INode)te).getAspects().getAmount(aspect) >= 5) {
/* 276 */               ItemStack ess = new ItemStack(ConfigItems.itemWispEssence);
/* 277 */               AspectList al = new AspectList();
/* 278 */               ((ItemWispEssence)ess.getItem()).setAspects(ess, (new AspectList()).add(aspect, 2));
/*     */               
/* 280 */               dropBlockAsItem(par1World, par2, par3, par4, ess);
/*     */             } 
/*     */           } 
/*     */         }  
/*     */     } 
/* 285 */     super.onBlockHarvested(par1World, par2, par3, par4, par5, par6EntityPlayer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void randomDisplayTick(World world, int x, int y, int z, Random random) {
/* 290 */     if (world.getBlock(x, y, z) != this)
/* 291 */       return;  int md = world.getBlockMetadata(x, y, z);
/* 292 */     if (md == 3) {
/* 293 */       if (world.isBlockIndirectlyGettingPowered(x, y, z)) {
/* 294 */         for (int a = 0; a < Thaumcraft.proxy.particleCount(2); a++) {
/* 295 */           Thaumcraft.proxy.blockRunes(world, x, (y + 0.7F), z, 0.2F + world.rand.nextFloat() * 0.4F, world.rand.nextFloat() * 0.3F, 0.8F + world.rand.nextFloat() * 0.2F, 20, -0.02F);
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 302 */       else if ((world.getBlock(x, y + 1, z) != ConfigBlocks.blockAiry && world.getBlock(x, y + 1, z).getBlocksMovement((IBlockAccess)world, x, y + 1, z)) || (world.getBlock(x, y + 2, z) != ConfigBlocks.blockAiry && world.getBlock(x, y + 1, z).getBlocksMovement((IBlockAccess)world, x, y + 1, z))) {
/*     */ 
/*     */ 
/*     */         
/* 306 */         for (int a = 0; a < Thaumcraft.proxy.particleCount(3); a++) {
/* 307 */           Thaumcraft.proxy.blockRunes(world, x, (y + 0.7F), z, 0.9F + world.rand.nextFloat() * 0.1F, world.rand.nextFloat() * 0.3F, world.rand.nextFloat() * 0.3F, 24, -0.02F);
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 315 */         List list = world.getEntitiesWithinAABBExcludingEntity((Entity)null, AxisAlignedBB.getBoundingBox(x, y, z, (x + 1), (y + 1), (z + 1)).expand(1.0D, 1.0D, 1.0D));
/*     */ 
/*     */         
/* 318 */         if (!list.isEmpty()) {
/*     */           
/* 320 */           Iterator<Entity> iterator = list.iterator();
/*     */           
/* 322 */           while (iterator.hasNext()) {
/*     */             
/* 324 */             Entity entity = iterator.next();
/*     */             
/* 326 */             if (entity instanceof EntityLivingBase && !(entity instanceof EntityPlayer)) {
/*     */               
/* 328 */               Thaumcraft.proxy.blockRunes(world, x, (y + 0.6F + world.rand.nextFloat() * Math.max(0.8F, entity.getEyeHeight())), z, 0.6F + world.rand.nextFloat() * 0.4F, 0.0F, 0.3F + world.rand.nextFloat() * 0.7F, 20, 0.0F);
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBeaconBase(IBlockAccess worldObj, int x, int y, int z, int beaconX, int beaconY, int beaconZ) {
/* 343 */     if (worldObj.getBlock(x, y, z) != this) return false; 
/* 344 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNeighborBlockChange(World world, int x, int y, int z, Block block) {
/* 349 */     if (world.getBlock(x, y, z) == this) {
/* 350 */       int md = world.getBlockMetadata(x, y, z);
/* 351 */       if (md == 9 && world.isBlockIndirectlyGettingPowered(x, y, z)) {
/* 352 */         world.setBlockMetadataWithNotify(x, y, z, 10, 3);
/*     */       }
/* 354 */       else if (md == 10 && !world.isBlockIndirectlyGettingPowered(x, y, z)) {
/* 355 */         world.setBlockMetadataWithNotify(x, y, z, 9, 3);
/*     */       } 
/*     */     } 
/* 358 */     super.onNeighborBlockChange(world, x, y, z, block);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockCosmeticSolid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */