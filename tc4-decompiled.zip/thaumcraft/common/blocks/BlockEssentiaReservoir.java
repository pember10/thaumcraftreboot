/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileEssentiaReservoir;
/*     */ 
/*     */ public class BlockEssentiaReservoir
/*     */   extends BlockContainer {
/*     */   public IIcon icon;
/*     */   
/*     */   public BlockEssentiaReservoir() {
/*  23 */     super(Material.iron);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  31 */     this.icon = null; setHardness(2.0F);
/*     */     setResistance(17.0F);
/*     */     setStepSound(Block.soundTypeMetal);
/*     */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  35 */     setCreativeTab(Thaumcraft.tabTC); } @SideOnly(Side.CLIENT) public void registerBlockIcons(IIconRegister ir) { this.icon = ir.registerIcon("thaumcraft:essentiareservoir"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIcon getIcon(int i, int md) {
/*  41 */     return this.icon;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIcon getIcon(IBlockAccess iblockaccess, int i, int j, int k, int side) {
/*  46 */     return this.icon;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/*  52 */     return ConfigBlocks.blockEssentiaReservoirRI;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/*  57 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/*  63 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderBlockPass() {
/*  68 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int damageDropped(int metadata) {
/*  73 */     return metadata;
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createTileEntity(World world, int metadata) {
/*  78 */     if (metadata == 0) return (TileEntity)new TileEssentiaReservoir(); 
/*  79 */     return super.createTileEntity(world, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World var1, int md) {
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasComparatorInputOverride() {
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getComparatorInputOverride(World world, int x, int y, int z, int rs) {
/*  95 */     TileEntity te = world.getTileEntity(x, y, z);
/*  96 */     if (te != null && te instanceof TileEssentiaReservoir) {
/*  97 */       float r = ((TileEssentiaReservoir)te).essentia.visSize() / ((TileEssentiaReservoir)te).maxAmount;
/*  98 */       return MathHelper.floor_float(r * 14.0F) + ((((TileEssentiaReservoir)te).essentia.visSize() > 0) ? 1 : 0);
/*     */     } 
/* 100 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block par5, int par6) {
/* 106 */     TileEntity te = world.getTileEntity(x, y, z);
/* 107 */     if (te != null && te instanceof TileEssentiaReservoir) {
/* 108 */       int sz = ((TileEssentiaReservoir)te).essentia.visSize() / 16;
/* 109 */       int q = 0;
/* 110 */       if (sz > 0) {
/* 111 */         world.createExplosion(null, x + 0.5D, y + 0.5D, z + 0.5D, 1.0F, false);
/* 112 */         for (int a = 0; a < 50; a++) {
/* 113 */           int xx = x + world.rand.nextInt(5) - world.rand.nextInt(5);
/* 114 */           int yy = y + world.rand.nextInt(5) - world.rand.nextInt(5);
/* 115 */           int zz = z + world.rand.nextInt(5) - world.rand.nextInt(5);
/* 116 */           if (world.isAirBlock(xx, yy, zz)) {
/* 117 */             if (yy < y) {
/* 118 */               world.setBlock(xx, yy, zz, ConfigBlocks.blockFluxGoo, 8, 3);
/*     */             } else {
/* 120 */               world.setBlock(xx, yy, zz, ConfigBlocks.blockFluxGas, 8, 3);
/*     */             } 
/* 122 */             if (q++ >= sz)
/*     */               break; 
/*     */           } 
/*     */         } 
/*     */       } 
/* 127 */     }  super.breakBlock(world, x, y, z, par5, par6);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockEssentiaReservoir.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */