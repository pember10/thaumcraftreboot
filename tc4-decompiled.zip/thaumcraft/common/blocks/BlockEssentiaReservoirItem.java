/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.util.ForgeDirection;
/*    */ import thaumcraft.common.tiles.TileEssentiaReservoir;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockEssentiaReservoirItem
/*    */   extends ItemBlock
/*    */ {
/*    */   public BlockEssentiaReservoirItem(Block par1) {
/* 17 */     super(par1);
/* 18 */     setMaxDamage(0);
/* 19 */     setHasSubtypes(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int par1) {
/* 25 */     return par1;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/* 30 */     boolean placed = super.placeBlockAt(stack, player, world, x, y, z, side, hitX, hitY, hitZ, metadata);
/*    */     
/* 32 */     if (placed) {
/*    */       try {
/* 34 */         TileEssentiaReservoir ts = (TileEssentiaReservoir)world.getTileEntity(x, y, z);
/* 35 */         ts.facing = ForgeDirection.getOrientation(side).getOpposite();
/* 36 */         ts.markDirty();
/* 37 */         world.markBlockForUpdate(x, y, z);
/* 38 */       } catch (Exception e) {}
/*    */     }
/*    */     
/* 41 */     return placed;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockEssentiaReservoirItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */