/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.Explosion;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.api.aspects.IEssentiaContainerItem;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.lib.utils.InventoryUtils;
/*     */ import thaumcraft.common.tiles.TileArcaneBore;
/*     */ import thaumcraft.common.tiles.TileArcaneBoreBase;
/*     */ import thaumcraft.common.tiles.TileArcanePressurePlate;
/*     */ import thaumcraft.common.tiles.TileBanner;
/*     */ import thaumcraft.common.tiles.TileBellows;
/*     */ import thaumcraft.common.tiles.TileOwned;
/*     */ import thaumcraft.common.tiles.TileSensor;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockWoodenDevice
/*     */   extends BlockContainer
/*     */ {
/*  47 */   private Random random = new Random();
/*     */   public IIcon iconDefault; public IIcon iconSilverwood; public IIcon iconGreatwood; public IIcon[] iconAPPlate; public IIcon[] iconAEar; public int renderState; @SideOnly(Side.CLIENT) public void registerBlockIcons(IIconRegister ir) { this.iconDefault = ir.registerIcon("thaumcraft:woodplain"); this.iconSilverwood = ir.registerIcon("thaumcraft:planks_silverwood"); this.iconGreatwood = ir.registerIcon("thaumcraft:planks_greatwood"); this.iconAPPlate[0] = ir.registerIcon("thaumcraft:applate1"); this.iconAPPlate[1] = ir.registerIcon("thaumcraft:applate2"); this.iconAPPlate[2] = ir.registerIcon("thaumcraft:applate3"); this.iconAEar[0] = ir.registerIcon("thaumcraft:arcaneearsideon"); this.iconAEar[1] = ir.registerIcon("thaumcraft:arcaneearsideoff"); this.iconAEar[2] = ir.registerIcon("thaumcraft:arcaneearbottom"); this.iconAEar[3] = ir.registerIcon("thaumcraft:arcaneeartopon");
/*     */     this.iconAEar[4] = ir.registerIcon("thaumcraft:arcaneeartopoff");
/*     */     this.iconAEar[5] = ir.registerIcon("thaumcraft:arcaneearbellside");
/*  51 */     this.iconAEar[6] = ir.registerIcon("thaumcraft:arcaneearbelltop"); } public BlockWoodenDevice() { super(Material.wood);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     this.iconAPPlate = new IIcon[3];
/*  63 */     this.iconAEar = new IIcon[7];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     this.renderState = 0; setHardness(2.5F);
/*     */     setResistance(10.0F);
/*     */     setStepSound(soundTypeWood);
/*     */     setTickRandomly(true);
/* 113 */     setCreativeTab(Thaumcraft.tabTC); } public IIcon getIcon(int par1, int par2) { if (par2 == 0) {
/* 114 */       return this.iconDefault;
/*     */     }
/* 116 */     if (par2 == 6) {
/* 117 */       return this.iconGreatwood;
/*     */     }
/* 119 */     if (par2 == 7) {
/* 120 */       return this.iconSilverwood;
/*     */     }
/* 122 */     if (par2 == 2 || par2 == 3) {
/* 123 */       return this.iconAPPlate[0];
/*     */     }
/*     */ 
/*     */     
/* 127 */     if (this.renderState == 0) {
/* 128 */       switch (par1) { case 0:
/* 129 */           return this.iconAEar[2];
/* 130 */         case 1: return this.iconAEar[4]; }
/*     */ 
/*     */     
/* 133 */     } else if (this.renderState == 1) {
/* 134 */       switch (par1) { case 0:
/* 135 */           return this.iconAEar[2];
/* 136 */         case 1: return this.iconAEar[3]; }
/*     */     
/*     */     } else {
/* 139 */       return (par1 <= 1) ? this.iconAEar[6] : this.iconAEar[5];
/*     */     } 
/*     */     
/* 142 */     return this.iconAEar[0]; } public int tickRate() { return 20; }
/*     */   @SideOnly(Side.CLIENT) public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) { par3List.add(new ItemStack(par1, 1, 0)); par3List.add(new ItemStack(par1, 1, 1)); par3List.add(new ItemStack(par1, 1, 2)); par3List.add(new ItemStack(par1, 1, 4)); par3List.add(new ItemStack(par1, 1, 5)); par3List.add(new ItemStack(par1, 1, 6)); par3List.add(new ItemStack(par1, 1, 7)); par3List.add(new ItemStack(par1, 1, 8)); for (int a = 0; a < 16; a++) {
/*     */       ItemStack banner = new ItemStack(par1, 1, 8); banner.setTagCompound(new NBTTagCompound());
/*     */       banner.stackTagCompound.setByte("color", (byte)a);
/*     */       par3List.add(banner);
/*     */     }  }
/* 148 */   public IIcon getIcon(IBlockAccess world, int x, int y, int z, int side) { int meta = world.getBlockMetadata(x, y, z);
/* 149 */     if (meta == 2 || meta == 3) {
/* 150 */       TileEntity tile = world.getTileEntity(x, y, z);
/* 151 */       if (tile != null && tile instanceof TileArcanePressurePlate) {
/* 152 */         return this.iconAPPlate[((TileArcanePressurePlate)tile).setting];
/*     */       }
/*     */     } 
/* 155 */     return super.getIcon(world, x, y, z, side); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int damageDropped(int par1) {
/* 161 */     return (par1 == 3) ? 2 : par1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Item getItemDropped(int par1, Random par2Random, int par3) {
/* 166 */     if (Config.wardedStone && (par1 == 2 || par1 == 3)) return Item.getItemById(0); 
/* 167 */     if (par1 == 8) return Item.getItemById(0); 
/* 168 */     return super.getItemDropped(par1, par2Random, par3);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBlockHardness(World world, int x, int y, int z) {
/* 173 */     if (world.getBlock(x, y, z) != this) return super.getBlockHardness(world, x, y, z); 
/* 174 */     int md = world.getBlockMetadata(x, y, z);
/* 175 */     if (md == 2 || md == 3) return Config.wardedStone ? -1.0F : 2.0F;
/*     */     
/* 177 */     return super.getBlockHardness(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getExplosionResistance(Entity par1Entity, World world, int x, int y, int z, double explosionX, double explosionY, double explosionZ) {
/* 184 */     if (world.getBlock(x, y, z) != this) return super.getExplosionResistance(par1Entity, world, x, y, z, explosionX, explosionY, explosionZ);
/*     */     
/* 186 */     int md = world.getBlockMetadata(x, y, z);
/* 187 */     if (md == 2 || md == 3) return 999.0F; 
/* 188 */     return super.getExplosionResistance(par1Entity, world, x, y, z, explosionX, explosionY, explosionZ);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockExploded(World world, int x, int y, int z, Explosion explosion) {
/* 194 */     if (world.getBlock(x, y, z) == this) {
/* 195 */       int md = world.getBlockMetadata(x, y, z);
/* 196 */       if (md != 2 && md != 3) super.onBlockExploded(world, x, y, z, explosion); 
/*     */     } else {
/* 198 */       super.onBlockExploded(world, x, y, z, explosion);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/* 205 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/* 211 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/* 216 */     return ConfigBlocks.blockWoodenDeviceRI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getSelectedBoundingBoxFromPool(World p_149633_1_, int p_149633_2_, int p_149633_3_, int p_149633_4_) {
/* 224 */     if (p_149633_1_.getBlock(p_149633_2_, p_149633_3_, p_149633_4_) != this) {
/* 225 */       return AxisAlignedBB.getBoundingBox(p_149633_2_, p_149633_3_, p_149633_4_, p_149633_2_ + 1.0D, p_149633_3_ + 1.0D, p_149633_4_ + 1.0D);
/*     */     }
/* 227 */     return super.getSelectedBoundingBoxFromPool(p_149633_1_, p_149633_2_, p_149633_3_, p_149633_4_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess par1iBlockAccess, int par2, int par3, int par4) {
/* 234 */     if (par1iBlockAccess.getBlock(par2, par3, par4) != this) {
/* 235 */       super.setBlockBoundsBasedOnState(par1iBlockAccess, par2, par3, par4);
/*     */       return;
/*     */     } 
/* 238 */     int meta = par1iBlockAccess.getBlockMetadata(par2, par3, par4);
/* 239 */     if (meta == 0) {
/* 240 */       setBlockBounds(0.1F, 0.0F, 0.1F, 0.9F, 1.0F, 0.9F);
/*     */     
/*     */     }
/* 243 */     else if (meta == 2) {
/* 244 */       float var6 = 0.0625F;
/* 245 */       setBlockBounds(var6, 0.0F, var6, 1.0F - var6, 0.0625F, 1.0F - var6);
/*     */     
/*     */     }
/* 248 */     else if (meta == 3) {
/* 249 */       float var6 = 0.0625F;
/* 250 */       setBlockBounds(var6, 0.0F, var6, 1.0F - var6, 0.03125F, 1.0F - var6);
/*     */     
/*     */     }
/* 253 */     else if (meta == 5) {
/* 254 */       ForgeDirection dir = ForgeDirection.UNKNOWN;
/* 255 */       TileEntity tile = par1iBlockAccess.getTileEntity(par2, par3, par4);
/* 256 */       if (tile != null && tile instanceof TileArcaneBore) {
/* 257 */         dir = ((TileArcaneBore)tile).orientation;
/*     */       }
/* 259 */       setBlockBounds((0 + ((dir.offsetX < 0) ? -1 : 0)), (0 + ((dir.offsetY < 0) ? -1 : 0)), (0 + ((dir.offsetZ < 0) ? -1 : 0)), (1 + ((dir.offsetX > 0) ? 1 : 0)), (1 + ((dir.offsetY > 0) ? 1 : 0)), (1 + ((dir.offsetZ > 0) ? 1 : 0)));
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 264 */     else if (meta == 8) {
/* 265 */       TileEntity tile = par1iBlockAccess.getTileEntity(par2, par3, par4);
/* 266 */       if (tile != null && tile instanceof TileBanner) {
/* 267 */         if (((TileBanner)tile).getWall()) {
/* 268 */           switch (((TileBanner)tile).getFacing()) { case 0:
/* 269 */               setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 0.25F); break;
/* 270 */             case 8: setBlockBounds(0.0F, 0.0F, 0.75F, 1.0F, 2.0F, 1.0F); break;
/* 271 */             case 12: setBlockBounds(0.0F, 0.0F, 0.0F, 0.25F, 2.0F, 1.0F); break;
/* 272 */             case 4: setBlockBounds(0.75F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F); break; }
/*     */         
/*     */         } else {
/* 275 */           setBlockBounds(0.33F, 0.0F, 0.33F, 0.66F, 2.0F, 0.66F);
/*     */         } 
/*     */       } else {
/* 278 */         setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 283 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/* 285 */     super.setBlockBoundsBasedOnState(par1iBlockAccess, par2, par3, par4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCollisionBoxesToList(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, List arraylist, Entity par7Entity) {
/* 293 */     if (world.getBlock(i, j, k) != this) {
/* 294 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */       return;
/*     */     } 
/* 297 */     int meta = world.getBlockMetadata(i, j, k);
/* 298 */     if (meta == 0) {
/* 299 */       setBlockBounds(0.1F, 0.0F, 0.1F, 0.9F, 1.0F, 0.9F);
/*     */     
/*     */     }
/* 302 */     else if (meta == 2 || meta == 3 || meta == 8) {
/* 303 */       setBlockBounds(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
/*     */     
/*     */     }
/* 306 */     else if (meta == 5) {
/* 307 */       ForgeDirection dir = ForgeDirection.UNKNOWN;
/* 308 */       TileEntity tile = world.getTileEntity(i, j, k);
/* 309 */       if (tile != null && tile instanceof TileArcaneBore) {
/* 310 */         dir = ((TileArcaneBore)tile).orientation;
/*     */       }
/* 312 */       setBlockBounds((0 + ((dir.offsetX < 0) ? -1 : 0)), (0 + ((dir.offsetY < 0) ? -1 : 0)), (0 + ((dir.offsetZ < 0) ? -1 : 0)), (1 + ((dir.offsetX > 0) ? 1 : 0)), (1 + ((dir.offsetY > 0) ? 1 : 0)), (1 + ((dir.offsetZ > 0) ? 1 : 0)));
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 318 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/* 320 */     super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNeighborBlockChange(World world, int x, int y, int z, Block par5) {
/* 326 */     int meta = world.getBlockMetadata(x, y, z);
/* 327 */     if (meta == 1) {
/* 328 */       TileEntity tile = world.getTileEntity(x, y, z);
/* 329 */       if (tile != null && tile instanceof TileSensor) {
/* 330 */         ((TileSensor)tile).updateTone();
/*     */       
/*     */       }
/*     */     }
/* 334 */     else if (meta == 5) {
/* 335 */       TileArcaneBore tile = (TileArcaneBore)world.getTileEntity(x, y, z);
/* 336 */       if (tile != null && tile instanceof TileArcaneBore) {
/* 337 */         ForgeDirection d = tile.baseOrientation.getOpposite();
/* 338 */         Block block = world.getBlock(x + d.offsetX, y + d.offsetY, z + d.offsetZ);
/* 339 */         if (block != ConfigBlocks.blockWoodenDevice || !block.isSideSolid((IBlockAccess)world, x + d.offsetX, y + d.offsetY, z + d.offsetZ, tile.baseOrientation)) {
/* 340 */           InventoryUtils.dropItems(world, x, y, z);
/* 341 */           dropBlockAsItem(world, x, y, z, 5, 0);
/* 342 */           world.setBlockToAir(x, y, z);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 347 */     super.onNeighborBlockChange(world, x, y, z, par5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSideSolid(IBlockAccess world, int x, int y, int z, ForgeDirection side) {
/* 355 */     int meta = world.getBlockMetadata(x, y, z);
/* 356 */     if (meta == 4 || meta == 6 || meta == 7) return true; 
/* 357 */     return super.isSideSolid(world, x, y, z, side);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBlockActivated(World w, int x, int y, int z, EntityPlayer p, int par6, float par7, float par8, float par9) {
/* 363 */     if (w.getBlock(x, y, z) != this) return false; 
/* 364 */     int meta = w.getBlockMetadata(x, y, z);
/* 365 */     if (meta == 4 || meta == 6 || meta == 7) return false;
/*     */     
/* 367 */     if (w.isRemote) return true;
/*     */     
/* 369 */     if (meta == 5 && (p.inventory.getCurrentItem() == null || p.inventory.getCurrentItem() == null || !(p.inventory.getCurrentItem().getItem() instanceof thaumcraft.common.items.wands.ItemWandCasting))) {
/* 370 */       p.openGui(Thaumcraft.instance, 15, w, x, y, z);
/* 371 */       return true;
/*     */     } 
/*     */     
/* 374 */     if (meta == 1) {
/* 375 */       TileSensor var6 = (TileSensor)w.getTileEntity(x, y, z);
/*     */       
/* 377 */       if (var6 != null)
/*     */       {
/* 379 */         var6.changePitch();
/* 380 */         var6.triggerNote(w, x, y, z, true);
/*     */       }
/*     */     
/* 383 */     } else if (meta == 2 || meta == 3) {
/* 384 */       TileArcanePressurePlate var6 = (TileArcanePressurePlate)w.getTileEntity(x, y, z);
/*     */       
/* 386 */       if (var6 != null && (var6.owner.equals(p.getCommandSenderName()) || var6.accessList.contains("1" + p.getCommandSenderName())))
/*     */       {
/* 388 */         var6.setting = (byte)(var6.setting + 1);
/* 389 */         if (var6.setting > 2) var6.setting = 0; 
/* 390 */         switch (var6.setting) { case 0:
/* 391 */             p.addChatMessage((IChatComponent)new ChatComponentTranslation("It will now trigger on everything.", new Object[0])); break;
/* 392 */           case 1: p.addChatMessage((IChatComponent)new ChatComponentTranslation("It will now trigger on everything except you.", new Object[0])); break;
/* 393 */           case 2: p.addChatMessage((IChatComponent)new ChatComponentTranslation("It will now trigger on just you.", new Object[0])); break; }
/*     */         
/* 395 */         w.playSoundEffect(x + 0.5D, y + 0.1D, z + 0.5D, "random.click", 0.1F, 0.9F);
/* 396 */         w.markBlockForUpdate(x, y, z);
/* 397 */         var6.markDirty();
/*     */       }
/*     */     
/* 400 */     } else if (meta == 8 && (p.isSneaking() || (p.inventory.getCurrentItem() != null && p.inventory.getCurrentItem().getItem() instanceof thaumcraft.common.items.ItemEssence))) {
/*     */ 
/*     */       
/* 403 */       TileBanner te = (TileBanner)w.getTileEntity(x, y, z);
/* 404 */       if (te != null)
/*     */       {
/* 406 */         if (te.getColor() >= 0) {
/* 407 */           if (p.isSneaking()) {
/* 408 */             te.setAspect(null);
/*     */           }
/* 410 */           else if (((IEssentiaContainerItem)p.getHeldItem().getItem()).getAspects(p.getHeldItem()) != null) {
/* 411 */             te.setAspect(((IEssentiaContainerItem)p.getHeldItem().getItem()).getAspects(p.getHeldItem()).getAspects()[0]);
/* 412 */             (p.getHeldItem()).stackSize--;
/*     */           } 
/*     */           
/* 415 */           w.markBlockForUpdate(x, y, z);
/* 416 */           te.markDirty();
/* 417 */           w.playSoundEffect(x, y, z, "step.cloth", 1.0F, 1.0F);
/*     */         } 
/*     */       }
/*     */     } 
/* 421 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockHarvested(World par1World, int par2, int par3, int par4, int par5, EntityPlayer par6EntityPlayer) {
/* 427 */     int md = par1World.getBlockMetadata(par2, par3, par4);
/* 428 */     if (md == 8) dropBlockAsItem(par1World, par2, par3, par4, par5, 0); 
/* 429 */     super.onBlockHarvested(par1World, par2, par3, par4, par5, par6EntityPlayer);
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<ItemStack> getDrops(World world, int x, int y, int z, int metadata, int fortune) {
/* 434 */     int md = world.getBlockMetadata(x, y, z);
/* 435 */     if (md == 8) {
/* 436 */       ArrayList<ItemStack> drops = new ArrayList<ItemStack>();
/* 437 */       TileEntity te = world.getTileEntity(x, y, z);
/* 438 */       if (te != null && te instanceof TileBanner) {
/* 439 */         ItemStack drop = new ItemStack((Block)this, 1, 8);
/* 440 */         if (((TileBanner)te).getColor() >= 0 || ((TileBanner)te).getAspect() != null) {
/* 441 */           drop.setTagCompound(new NBTTagCompound());
/* 442 */           if (((TileBanner)te).getAspect() != null) {
/* 443 */             drop.stackTagCompound.setString("aspect", ((TileBanner)te).getAspect().getTag());
/*     */           }
/* 445 */           drop.stackTagCompound.setByte("color", ((TileBanner)te).getColor());
/*     */         } 
/* 447 */         drops.add(drop);
/*     */       } 
/* 449 */       return drops;
/*     */     } 
/* 451 */     return super.getDrops(world, x, y, z, metadata, fortune);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockPlacedBy(World w, int x, int y, int z, EntityLivingBase p, ItemStack s) {
/* 457 */     TileEntity tile = w.getTileEntity(x, y, z);
/* 458 */     if (tile != null && tile instanceof TileOwned && p instanceof EntityPlayer) {
/* 459 */       ((TileOwned)tile).owner = ((EntityPlayer)p).getCommandSenderName();
/* 460 */       tile.markDirty();
/*     */     } 
/*     */     
/* 463 */     super.onBlockPlacedBy(w, x, y, z, p, s);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockAdded(World world, int x, int y, int z) {
/* 469 */     super.onBlockAdded(world, x, y, z);
/* 470 */     if (world.getBlock(x, y, z) != this)
/* 471 */       return;  int meta = world.getBlockMetadata(x, y, z);
/* 472 */     if (meta == 1) {
/* 473 */       TileEntity tile = world.getTileEntity(x, y, z);
/* 474 */       if (tile != null && tile instanceof TileSensor) {
/* 475 */         ((TileSensor)tile).updateTone();
/* 476 */         tile.markDirty();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canConnectRedstone(IBlockAccess world, int x, int y, int z, int side) {
/* 486 */     int meta = world.getBlockMetadata(x, y, z);
/* 487 */     if (meta == 0) return false; 
/* 488 */     if (meta == 1 || meta == 2 || meta == 3 || meta == 4 || meta == 5) return true; 
/* 489 */     return super.canConnectRedstone(world, x, y, z, side);
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createTileEntity(World world, int metadata) {
/* 494 */     if (metadata == 0) return (TileEntity)new TileBellows(); 
/* 495 */     if (metadata == 1) return (TileEntity)new TileSensor(); 
/* 496 */     if (metadata == 2) return (TileEntity)new TileArcanePressurePlate(); 
/* 497 */     if (metadata == 3) return (TileEntity)new TileArcanePressurePlate(); 
/* 498 */     if (metadata == 4) return (TileEntity)new TileArcaneBoreBase(); 
/* 499 */     if (metadata == 5) return (TileEntity)new TileArcaneBore(); 
/* 500 */     if (metadata == 8) return (TileEntity)new TileBanner(); 
/* 501 */     return super.createTileEntity(world, metadata);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World var1, int md) {
/* 507 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onBlockEventReceived(World par1World, int par2, int par3, int par4, int par5, int par6) {
/* 512 */     float var7 = (float)Math.pow(2.0D, (par6 - 12) / 12.0D);
/* 513 */     if (par5 <= 4) {
/* 514 */       if (par5 >= 0) {
/* 515 */         String var8 = "harp";
/*     */         
/* 517 */         if (par5 == 1)
/*     */         {
/* 519 */           var8 = "bd";
/*     */         }
/*     */         
/* 522 */         if (par5 == 2)
/*     */         {
/* 524 */           var8 = "snare";
/*     */         }
/*     */         
/* 527 */         if (par5 == 3)
/*     */         {
/* 529 */           var8 = "hat";
/*     */         }
/*     */         
/* 532 */         if (par5 == 4)
/*     */         {
/* 534 */           var8 = "bassattack";
/*     */         }
/*     */         
/* 537 */         par1World.playSoundEffect(par2 + 0.5D, par3 + 0.5D, par4 + 0.5D, "note." + var8, 3.0F, var7);
/*     */       } 
/* 539 */       par1World.spawnParticle("note", par2 + 0.5D, par3 + 1.2D, par4 + 0.5D, par6 / 24.0D, 0.0D, 0.0D);
/* 540 */       return true;
/*     */     } 
/* 542 */     if (par5 == 99) {
/* 543 */       return super.onBlockEventReceived(par1World, par2, par3, par4, par5, par6);
/*     */     }
/* 545 */     return super.onBlockEventReceived(par1World, par2, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random) {
/* 551 */     if (par1World.getBlock(par2, par3, par4) != this)
/* 552 */       return;  if (!par1World.isRemote)
/*     */     {
/* 554 */       if (par1World.getBlockMetadata(par2, par3, par4) == 3)
/*     */       {
/* 556 */         setStateIfMobInteractsWithPlate(par1World, par2, par3, par4);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEntityCollidedWithBlock(World par1World, int par2, int par3, int par4, Entity par5Entity) {
/* 564 */     if (par1World.getBlock(par2, par3, par4) != this)
/*     */       return; 
/* 566 */     if (!par1World.isRemote)
/*     */     {
/* 568 */       if (par1World.getBlockMetadata(par2, par3, par4) == 2)
/*     */       {
/* 570 */         setStateIfMobInteractsWithPlate(par1World, par2, par3, par4);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void setStateIfMobInteractsWithPlate(World world, int x, int y, int z) {
/* 577 */     boolean var5 = (world.getBlockMetadata(x, y, z) == 3);
/* 578 */     boolean var6 = false;
/* 579 */     float var7 = 0.125F;
/* 580 */     List var8 = null;
/* 581 */     String username = "";
/* 582 */     byte setting = 0;
/* 583 */     ArrayList<String> accessList = new ArrayList<String>();
/* 584 */     TileEntity tile = world.getTileEntity(x, y, z);
/* 585 */     if (tile != null && tile instanceof TileArcanePressurePlate) {
/* 586 */       setting = ((TileArcanePressurePlate)tile).setting;
/* 587 */       username = ((TileArcanePressurePlate)tile).owner;
/* 588 */       accessList = ((TileArcanePressurePlate)tile).accessList;
/*     */     } 
/*     */     
/* 591 */     if (setting == 0)
/*     */     {
/* 593 */       var8 = world.getEntitiesWithinAABBExcludingEntity((Entity)null, AxisAlignedBB.getBoundingBox((x + var7), y, (z + var7), ((x + 1) - var7), y + 0.25D, ((z + 1) - var7)));
/*     */     }
/*     */ 
/*     */     
/* 597 */     if (setting == 1)
/*     */     {
/* 599 */       var8 = world.getEntitiesWithinAABB(Entity.class, AxisAlignedBB.getBoundingBox((x + var7), y, (z + var7), ((x + 1) - var7), y + 0.25D, ((z + 1) - var7)));
/*     */     }
/*     */     
/* 602 */     if (setting == 2)
/*     */     {
/* 604 */       var8 = world.getEntitiesWithinAABB(EntityPlayer.class, AxisAlignedBB.getBoundingBox((x + var7), y, (z + var7), ((x + 1) - var7), y + 0.25D, ((z + 1) - var7)));
/*     */     }
/*     */     
/* 607 */     if (!var8.isEmpty()) {
/*     */       
/* 609 */       Iterator<Entity> var9 = var8.iterator();
/*     */       
/* 611 */       while (var9.hasNext()) {
/*     */         
/* 613 */         Entity var10 = var9.next();
/*     */         
/* 615 */         if (!var10.doesEntityNotTriggerPressurePlate()) {
/*     */           
/* 617 */           if (setting == 1 && var10 instanceof EntityPlayer && (((EntityPlayer)var10).getCommandSenderName().equals(username) || accessList.contains("0" + ((EntityPlayer)var10).getCommandSenderName()) || accessList.contains("1" + ((EntityPlayer)var10).getCommandSenderName()))) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 623 */           if (setting == 2 && var10 instanceof EntityPlayer && !((EntityPlayer)var10).getCommandSenderName().equals(username) && !accessList.contains("0" + ((EntityPlayer)var10).getCommandSenderName()) && !accessList.contains("1" + ((EntityPlayer)var10).getCommandSenderName())) {
/*     */             continue;
/*     */           }
/*     */           
/* 627 */           var6 = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 633 */     if (var6 && !var5) {
/*     */       
/* 635 */       world.setBlockMetadataWithNotify(x, y, z, 3, 2);
/* 636 */       world.notifyBlocksOfNeighborChange(x, y, z, (Block)this);
/* 637 */       world.notifyBlocksOfNeighborChange(x, y - 1, z, (Block)this);
/* 638 */       world.markBlockRangeForRenderUpdate(x, y, z, x, y, z);
/* 639 */       world.playSoundEffect(x + 0.5D, y + 0.1D, z + 0.5D, "random.click", 0.2F, 0.6F);
/*     */     } 
/*     */     
/* 642 */     if (!var6 && var5) {
/*     */       
/* 644 */       world.setBlockMetadataWithNotify(x, y, z, 2, 2);
/* 645 */       world.notifyBlocksOfNeighborChange(x, y, z, (Block)this);
/* 646 */       world.notifyBlocksOfNeighborChange(x, y - 1, z, (Block)this);
/* 647 */       world.markBlockRangeForRenderUpdate(x, y, z, x, y, z);
/* 648 */       world.playSoundEffect(x + 0.5D, y + 0.1D, z + 0.5D, "random.click", 0.2F, 0.5F);
/*     */     } 
/*     */     
/* 651 */     if (var6)
/*     */     {
/* 653 */       world.scheduleBlockUpdate(x, y, z, (Block)this, tickRate());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void breakBlock(World par1World, int par2, int par3, int par4, Block par5, int par6) {
/* 661 */     if (par6 == 3) {
/*     */       
/* 663 */       par1World.notifyBlocksOfNeighborChange(par2, par3, par4, (Block)this);
/* 664 */       par1World.notifyBlocksOfNeighborChange(par2, par3 - 1, par4, (Block)this);
/*     */     
/*     */     }
/* 667 */     else if (par6 == 5) {
/* 668 */       InventoryUtils.dropItems(par1World, par2, par3, par4);
/*     */     } 
/*     */     
/* 671 */     super.breakBlock(par1World, par2, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */   
/*     */   public int isProvidingStrongPower(IBlockAccess world, int x, int y, int z, int side) {
/* 676 */     int meta = world.getBlockMetadata(x, y, z);
/* 677 */     if (meta == 1) {
/* 678 */       TileEntity tile = world.getTileEntity(x, y, z);
/* 679 */       if (tile != null && tile instanceof TileSensor)
/* 680 */         return (((TileSensor)tile).redstoneSignal > 0) ? 15 : 0; 
/*     */     } else {
/* 682 */       return (world.getBlockMetadata(x, y, z) == 2) ? 0 : ((side == 1 && world.getBlockMetadata(x, y, z) == 3) ? 15 : 0);
/* 683 */     }  return super.isProvidingStrongPower(world, x, y, z, side);
/*     */   }
/*     */ 
/*     */   
/*     */   public int isProvidingWeakPower(IBlockAccess world, int x, int y, int z, int side) {
/* 688 */     int meta = world.getBlockMetadata(x, y, z);
/* 689 */     if (meta == 1)
/* 690 */     { TileEntity tile = world.getTileEntity(x, y, z);
/* 691 */       if (tile != null && tile instanceof TileSensor) {
/* 692 */         return (((TileSensor)tile).redstoneSignal > 0) ? 15 : 0;
/*     */       } }
/* 694 */     else if (meta == 3) { return 15; }
/* 695 */      return super.isProvidingStrongPower(world, x, y, z, side);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canProvidePower() {
/* 701 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMobilityFlag() {
/* 707 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightOpacity(IBlockAccess world, int x, int y, int z) {
/* 713 */     int meta = world.getBlockMetadata(x, y, z);
/* 714 */     if (meta == 6 || meta == 7) {
/* 715 */       return 255;
/*     */     }
/* 717 */     return super.getLightOpacity(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEntityDestroy(IBlockAccess world, int x, int y, int z, Entity entity) {
/* 722 */     int meta = world.getBlockMetadata(x, y, z);
/* 723 */     if (meta == 2 || meta == 3) {
/* 724 */       return false;
/*     */     }
/* 726 */     return super.canEntityDestroy(world, x, y, z, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFlammability(IBlockAccess world, int x, int y, int z, ForgeDirection face) {
/* 732 */     int meta = world.getBlockMetadata(x, y, z);
/* 733 */     return (meta == 6 || meta == 7) ? 20 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFireSpreadSpeed(IBlockAccess world, int x, int y, int z, ForgeDirection face) {
/* 738 */     int meta = world.getBlockMetadata(x, y, z);
/* 739 */     return (meta == 6 || meta == 7) ? 5 : 0;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockWoodenDevice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */