/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.EnumRarity;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagInt;
/*     */ import net.minecraft.nbt.NBTTagString;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.DimensionManager;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileMirror;
/*     */ import thaumcraft.common.tiles.TileMirrorEssentia;
/*     */ 
/*     */ public class BlockMirrorItem extends ItemBlock {
/*     */   public IIcon[] icon;
/*     */   
/*     */   public BlockMirrorItem(Block par1) {
/*  31 */     super(par1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  36 */     this.icon = new IIcon[5];
/*     */     setMaxDamage(0);
/*     */     setHasSubtypes(true);
/*     */   } @SideOnly(Side.CLIENT)
/*     */   public void registerIcons(IIconRegister par1IconRegister) {
/*  41 */     this.icon[0] = par1IconRegister.registerIcon("thaumcraft:mirrorframe");
/*  42 */     this.icon[1] = par1IconRegister.registerIcon("thaumcraft:mirrorpane");
/*  43 */     this.icon[2] = par1IconRegister.registerIcon("thaumcraft:mirrorpanetrans");
/*  44 */     this.icon[3] = par1IconRegister.registerIcon("thaumcraft:mirrorpaneopen");
/*  45 */     this.icon[4] = par1IconRegister.registerIcon("thaumcraft:mirrorframe2");
/*     */   }
/*     */ 
/*     */   
/*     */   public IIcon getIconFromDamageForRenderPass(int par1, int par2) {
/*  50 */     if (par2 == 0) {
/*  51 */       return this.icon[(par1 <= 1) ? 0 : 4];
/*     */     }
/*  53 */     return this.icon[par2 + par1 % 2 * 2];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getShareTag() {
/*  61 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/*  67 */     int d = (par1ItemStack.getItemDamage() < 6) ? 0 : 6;
/*  68 */     return getUnlocalizedName() + "." + d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onItemUseFirst(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ) {
/*  75 */     if (world.getBlock(x, y, z) == ConfigBlocks.blockMirror) {
/*  76 */       if (world.isRemote) {
/*  77 */         player.swingItem();
/*  78 */         return super.onItemUseFirst(stack, player, world, x, y, z, side, hitX, hitY, hitZ);
/*     */       } 
/*     */       
/*  81 */       if (stack.getItemDamage() <= 5) {
/*  82 */         TileEntity tm = world.getTileEntity(x, y, z);
/*  83 */         if (tm != null && tm instanceof TileMirror && !((TileMirror)tm).isLinkValid()) {
/*  84 */           ItemStack st = stack.copy();
/*  85 */           st.stackSize = 1;
/*  86 */           st.setItemDamage(1);
/*  87 */           st.setTagInfo("linkX", (NBTBase)new NBTTagInt(tm.xCoord));
/*  88 */           st.setTagInfo("linkY", (NBTBase)new NBTTagInt(tm.yCoord));
/*  89 */           st.setTagInfo("linkZ", (NBTBase)new NBTTagInt(tm.zCoord));
/*  90 */           st.setTagInfo("linkDim", (NBTBase)new NBTTagInt(world.provider.dimensionId));
/*  91 */           st.setTagInfo("dimname", (NBTBase)new NBTTagString(DimensionManager.getProvider(world.provider.dimensionId).getDimensionName()));
/*  92 */           world.playSoundEffect(x, y, z, "thaumcraft:jar", 1.0F, 2.0F);
/*  93 */           if (!player.inventory.addItemStackToInventory(st) && 
/*  94 */             !world.isRemote) {
/*  95 */             world.spawnEntityInWorld((Entity)new EntityItem(world, player.posX, player.posY, player.posZ, st));
/*     */           }
/*     */           
/*  98 */           if (!player.capabilities.isCreativeMode) {
/*  99 */             stack.stackSize--;
/*     */           }
/* 101 */           player.inventoryContainer.detectAndSendChanges();
/* 102 */         } else if (tm != null && tm instanceof TileMirror) {
/* 103 */           player.addChatMessage((IChatComponent)new ChatComponentTranslation("§5§oThat mirror is already linked to a valid destination.", new Object[0]));
/*     */         } 
/*     */       } else {
/* 106 */         TileEntity tm = world.getTileEntity(x, y, z);
/* 107 */         if (tm != null && tm instanceof TileMirrorEssentia && !((TileMirrorEssentia)tm).isLinkValid()) {
/* 108 */           ItemStack st = stack.copy();
/* 109 */           st.stackSize = 1;
/* 110 */           st.setItemDamage(7);
/* 111 */           st.setTagInfo("linkX", (NBTBase)new NBTTagInt(tm.xCoord));
/* 112 */           st.setTagInfo("linkY", (NBTBase)new NBTTagInt(tm.yCoord));
/* 113 */           st.setTagInfo("linkZ", (NBTBase)new NBTTagInt(tm.zCoord));
/* 114 */           st.setTagInfo("linkDim", (NBTBase)new NBTTagInt(world.provider.dimensionId));
/* 115 */           st.setTagInfo("dimname", (NBTBase)new NBTTagString(DimensionManager.getProvider(world.provider.dimensionId).getDimensionName()));
/* 116 */           world.playSoundEffect(x, y, z, "thaumcraft:jar", 1.0F, 2.0F);
/* 117 */           if (!player.inventory.addItemStackToInventory(st) && 
/* 118 */             !world.isRemote) {
/* 119 */             world.spawnEntityInWorld((Entity)new EntityItem(world, player.posX, player.posY, player.posZ, st));
/*     */           }
/*     */           
/* 122 */           if (!player.capabilities.isCreativeMode) {
/* 123 */             stack.stackSize--;
/*     */           }
/* 125 */           player.inventoryContainer.detectAndSendChanges();
/* 126 */         } else if (tm != null && tm instanceof TileMirrorEssentia) {
/* 127 */           player.addChatMessage((IChatComponent)new ChatComponentTranslation("§5§oThat mirror is already linked to a valid destination.", new Object[0]));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 132 */     return super.onItemUseFirst(stack, player, world, x, y, z, side, hitX, hitY, hitZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/* 140 */     boolean ret = super.placeBlockAt(stack, player, world, x, y, z, side, hitX, hitY, hitZ, metadata);
/*     */     
/* 142 */     if (ret && !world.isRemote)
/*     */     {
/* 144 */       if (metadata <= 5) {
/* 145 */         TileEntity te = world.getTileEntity(x, y, z);
/* 146 */         if (te != null && te instanceof TileMirror && 
/* 147 */           stack.hasTagCompound()) {
/* 148 */           ((TileMirror)te).linkX = stack.stackTagCompound.getInteger("linkX");
/* 149 */           ((TileMirror)te).linkY = stack.stackTagCompound.getInteger("linkY");
/* 150 */           ((TileMirror)te).linkZ = stack.stackTagCompound.getInteger("linkZ");
/* 151 */           ((TileMirror)te).linkDim = stack.stackTagCompound.getInteger("linkDim");
/* 152 */           ((TileMirror)te).restoreLink();
/*     */         } 
/*     */       } else {
/*     */         
/* 156 */         TileEntity te = world.getTileEntity(x, y, z);
/* 157 */         if (te != null && te instanceof TileMirrorEssentia && 
/* 158 */           stack.hasTagCompound()) {
/* 159 */           ((TileMirrorEssentia)te).linkX = stack.stackTagCompound.getInteger("linkX");
/* 160 */           ((TileMirrorEssentia)te).linkY = stack.stackTagCompound.getInteger("linkY");
/* 161 */           ((TileMirrorEssentia)te).linkZ = stack.stackTagCompound.getInteger("linkZ");
/* 162 */           ((TileMirrorEssentia)te).linkDim = stack.stackTagCompound.getInteger("linkDim");
/* 163 */           ((TileMirrorEssentia)te).restoreLink();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getRenderPasses(int metadata) {
/* 178 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresMultipleRenderPasses() {
/* 185 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumRarity getRarity(ItemStack itemstack) {
/* 191 */     return EnumRarity.uncommon;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMetadata(int par1) {
/* 198 */     return par1;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addInformation(ItemStack item, EntityPlayer par2EntityPlayer, List<String> list, boolean par4) {
/* 204 */     if (item.hasTagCompound()) {
/* 205 */       int lx = item.stackTagCompound.getInteger("linkX");
/* 206 */       int ly = item.stackTagCompound.getInteger("linkY");
/* 207 */       int lz = item.stackTagCompound.getInteger("linkZ");
/* 208 */       int ldim = item.stackTagCompound.getInteger("linkDim");
/* 209 */       String dimname = item.stackTagCompound.getString("dimname");
/* 210 */       list.add("Linked to " + lx + "," + ly + "," + lz + " in " + dimname);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockMirrorItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */