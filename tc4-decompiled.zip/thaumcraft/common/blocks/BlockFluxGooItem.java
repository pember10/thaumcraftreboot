/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ 
/*    */ 
/*    */ public class BlockFluxGooItem
/*    */   extends ItemBlock
/*    */ {
/*    */   public BlockFluxGooItem(Block i) {
/* 11 */     super(i);
/* 12 */     this.maxStackSize = 64;
/* 13 */     setHasSubtypes(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFull3D() {
/* 18 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int i) {
/* 24 */     return 8;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockFluxGooItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */