/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.world.ColorizerGrass;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.entities.EntityFallingTaint;
/*     */ import thaumcraft.common.entities.monster.EntityTaintSporeSwarmer;
/*     */ import thaumcraft.common.lib.CustomSoundType;
/*     */ import thaumcraft.common.lib.utils.Utils;
/*     */ import thaumcraft.common.lib.world.ThaumcraftWorldGenerator;
/*     */ 
/*     */ public class BlockTaint
/*     */   extends Block {
/*     */   private IIcon iconCrust;
/*     */   private IIcon iconSoil;
/*     */   private IIcon iconFlesh;
/*     */   
/*     */   public BlockTaint() {
/*  42 */     super(Config.taintMaterial);
/*  43 */     setHardness(2.0F);
/*  44 */     setResistance(10.0F);
/*  45 */     setStepSound((Block.SoundType)new CustomSoundType("gore", 0.5F, 0.8F));
/*  46 */     setTickRandomly(true);
/*  47 */     setCreativeTab(Thaumcraft.tabTC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/*  54 */     for (int var4 = 0; var4 <= 2; var4++)
/*     */     {
/*  56 */       par3List.add(new ItemStack(par1, 1, var4));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister par1IconRegister) {
/*  68 */     this.iconCrust = par1IconRegister.registerIcon("thaumcraft:taint_crust");
/*  69 */     this.iconSoil = par1IconRegister.registerIcon("thaumcraft:taint_soil");
/*  70 */     this.iconFlesh = par1IconRegister.registerIcon("thaumcraft:fleshblock");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(IBlockAccess ba, int x, int y, int z, int side) {
/*  77 */     int md = ba.getBlockMetadata(x, y, z);
/*  78 */     if (md == 0) {
/*  79 */       return this.iconCrust;
/*     */     }
/*  81 */     if (md == 1) {
/*  82 */       return this.iconSoil;
/*     */     }
/*  84 */     if (md == 2) {
/*  85 */       return this.iconFlesh;
/*     */     }
/*  87 */     return this.iconCrust;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int par1, int md) {
/*  99 */     if (md == 0) {
/* 100 */       return this.iconCrust;
/*     */     }
/* 102 */     if (md == 1) {
/* 103 */       return this.iconSoil;
/*     */     }
/* 105 */     if (md == 2) {
/* 106 */       return this.iconFlesh;
/*     */     }
/* 108 */     return this.iconCrust;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getBlockColor() {
/* 115 */     double d0 = 0.5D;
/* 116 */     double d1 = 1.0D;
/* 117 */     return ColorizerGrass.getGrassColor(d0, d1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getRenderColor(int par1) {
/* 124 */     return (par1 == 1) ? ThaumcraftWorldGenerator.biomeTaint.color : super.getBlockColor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int colorMultiplier(IBlockAccess par1IBlockAccess, int par2, int par3, int par4) {
/* 131 */     int md = par1IBlockAccess.getBlockMetadata(par2, par3, par4);
/* 132 */     if (md != 1) return super.colorMultiplier(par1IBlockAccess, par2, par3, par4);
/*     */     
/* 134 */     int l = 0;
/* 135 */     int i1 = 0;
/* 136 */     int j1 = 0;
/*     */     
/* 138 */     for (int k1 = -1; k1 <= 1; k1++) {
/*     */       
/* 140 */       for (int l1 = -1; l1 <= 1; l1++) {
/*     */         
/* 142 */         int i2 = par1IBlockAccess.getBiomeGenForCoords(par2 + l1, par4 + k1).getBiomeGrassColor(par2, par3, par4);
/* 143 */         l += (i2 & 0xFF0000) >> 16;
/* 144 */         i1 += (i2 & 0xFF00) >> 8;
/* 145 */         j1 += i2 & 0xFF;
/*     */       } 
/*     */     } 
/*     */     
/* 149 */     return (l / 9 & 0xFF) << 16 | (i1 / 9 & 0xFF) << 8 | j1 / 9 & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTick(World world, int x, int y, int z, Random random) {
/* 158 */     if (!world.isRemote) {
/*     */       
/* 160 */       int md = world.getBlockMetadata(x, y, z);
/* 161 */       if (md == 2)
/*     */         return; 
/* 163 */       BlockTaintFibres.taintBiomeSpread(world, x, y, z, random, this);
/*     */       
/* 165 */       if (md == 0) {
/* 166 */         if (tryToFall(world, x, y, z, x, y, z)) {
/*     */           return;
/*     */         }
/* 169 */         if (world.isAirBlock(x, y + 1, z)) {
/* 170 */           boolean doIt = true;
/* 171 */           ForgeDirection dir = ForgeDirection.getOrientation(2 + random.nextInt(4));
/* 172 */           for (int a = 0; a < 4; a++) {
/* 173 */             if (!world.isAirBlock(x + dir.offsetX, y - a, z + dir.offsetZ)) {
/* 174 */               doIt = false;
/*     */               break;
/*     */             } 
/* 177 */             if (world.getBlock(x, y - a, z) != this) {
/* 178 */               doIt = false;
/*     */               break;
/*     */             } 
/*     */           } 
/* 182 */           if (doIt && 
/* 183 */             tryToFall(world, x, y, z, x + dir.offsetX, y, z + dir.offsetZ)) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 190 */       int xx = x + random.nextInt(3) - 1;
/* 191 */       int yy = y + random.nextInt(5) - 3;
/* 192 */       int zz = z + random.nextInt(3) - 1;
/*     */       
/* 194 */       if ((world.getBiomeGenForCoords(xx, zz)).biomeID == Config.biomeTaintID) {
/* 195 */         Block bi = world.getBlock(xx, yy, zz);
/*     */ 
/*     */         
/* 198 */         if (BlockTaintFibres.spreadFibres(world, xx, yy, zz));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 204 */         if (md == 0) {
/* 205 */           if (Config.spawnTaintSpore && world.isAirBlock(x, y + 1, z) && random.nextInt(200) == 0) {
/*     */ 
/*     */             
/* 208 */             List<Entity> targets = world.getEntitiesWithinAABB(EntityTaintSporeSwarmer.class, AxisAlignedBB.getBoundingBox(x, y, z, (x + 1), (y + 1), (z + 1)).expand(16.0D, 16.0D, 16.0D));
/*     */             
/* 210 */             if (targets.size() <= 0) {
/* 211 */               world.setBlockToAir(x, y, z);
/* 212 */               EntityTaintSporeSwarmer spore = new EntityTaintSporeSwarmer(world);
/* 213 */               spore.setLocationAndAngles((x + 0.5F), y, (z + 0.5F), 0.0F, 0.0F);
/* 214 */               world.spawnEntityInWorld((Entity)spore);
/* 215 */               world.playSoundAtEntity((Entity)spore, "thaumcraft:roots", 0.1F, 0.9F + world.rand.nextFloat() * 0.2F);
/*     */             } 
/*     */           } else {
/*     */             
/* 219 */             boolean doIt = (world.getBlock(x, y + 1, z) == this);
/* 220 */             if (doIt) {
/* 221 */               for (int a = 2; a < 6; a++) {
/* 222 */                 ForgeDirection dir = ForgeDirection.getOrientation(a);
/* 223 */                 if (world.getBlock(x + dir.offsetX, y + dir.offsetY, z + dir.offsetZ) != this) {
/* 224 */                   doIt = false;
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/* 229 */             if (doIt) {
/* 230 */               world.setBlock(x, y, z, ConfigBlocks.blockFluxGoo, ((BlockFluxGoo)ConfigBlocks.blockFluxGoo).getQuanta(), 3);
/*     */             }
/*     */           }
/*     */         
/*     */         }
/*     */       }
/* 236 */       else if (md == 0 && random.nextInt(20) == 0) {
/* 237 */         world.setBlock(x, y, z, ConfigBlocks.blockFluxGoo, ((BlockFluxGoo)ConfigBlocks.blockFluxGoo).getQuanta(), 3);
/*     */       
/*     */       }
/* 240 */       else if (md == 1 && random.nextInt(10) == 0) {
/* 241 */         world.setBlock(x, y, z, Blocks.dirt, 0, 3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Item getItemDropped(int md, Random rand, int fortune) {
/* 254 */     return (md == 1) ? Blocks.dirt.getItemDropped(0, rand, fortune) : ((md == 2) ? Items.rotten_flesh : Item.getItemById(0));
/*     */   }
/*     */ 
/*     */   
/*     */   public int damageDropped(int par1) {
/* 259 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getPickBlock(MovingObjectPosition target, World world, int x, int y, int z) {
/* 267 */     return new ItemStack(this, 1, world.getBlockMetadata(x, y, z));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canSilkHarvest(World world, EntityPlayer player, int x, int y, int z, int metadata) {
/* 273 */     if (metadata == 2) return true; 
/* 274 */     return super.canSilkHarvest(world, player, x, y, z, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public int quantityDropped(int meta, int fortune, Random random) {
/* 279 */     if (meta == 2) return 9;
/*     */     
/* 281 */     return super.quantityDropped(meta, fortune, random);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getBlockHardness(World world, int x, int y, int z) {
/* 287 */     int md = world.getBlockMetadata(x, y, z);
/* 288 */     if (md == 0) return 1.75F; 
/* 289 */     if (md == 1) return 1.5F; 
/* 290 */     if (md == 2) return 0.2F; 
/* 291 */     return super.getBlockHardness(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canFallBelow(World par0World, int par1, int par2, int par3) {
/* 297 */     Block l = par0World.getBlock(par1, par2, par3);
/* 298 */     int md = par0World.getBlockMetadata(par1, par2, par3);
/* 299 */     for (int xx = -1; xx <= 1; ) { for (int zz = -1; zz <= 1; ) { for (int yy = -1; yy <= 1; yy++) {
/* 300 */           if (Utils.isWoodLog((IBlockAccess)par0World, par1 + xx, par2 + yy, par3 + zz))
/* 301 */             return false; 
/*     */         }  zz++; }
/*     */        xx++; }
/* 304 */      if (l.isAir((IBlockAccess)par0World, par1, par2, par3))
/*     */     {
/* 306 */       return true;
/*     */     }
/* 308 */     if (l == ConfigBlocks.blockFluxGoo && md >= 4)
/*     */     {
/* 310 */       return false;
/*     */     }
/* 312 */     if (l == Blocks.fire || l == ConfigBlocks.blockTaintFibres)
/*     */     {
/* 314 */       return true;
/*     */     }
/* 316 */     if (l.isReplaceable((IBlockAccess)par0World, par1, par2, par3))
/*     */     {
/* 318 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 322 */     return (l.getMaterial() == Material.water) ? true : ((l.getMaterial() == Material.lava));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean tryToFall(World par1World, int x, int y, int z, int x2, int y2, int z2) {
/* 328 */     int md = par1World.getBlockMetadata(x, y, z);
/* 329 */     if (canFallBelow(par1World, x2, y2 - 1, z2) && y2 >= 0) {
/*     */       
/* 331 */       byte b0 = 32;
/*     */       
/* 333 */       if (par1World.checkChunksExist(x2 - b0, y2 - b0, z2 - b0, x2 + b0, y2 + b0, z2 + b0)) {
/*     */         
/* 335 */         if (!par1World.isRemote)
/*     */         {
/* 337 */           EntityFallingTaint entityfalling = new EntityFallingTaint(par1World, (x2 + 0.5F), (y2 + 0.5F), (z2 + 0.5F), this, md, x, y, z);
/*     */           
/* 339 */           onStartFalling(entityfalling);
/* 340 */           par1World.spawnEntityInWorld((Entity)entityfalling);
/* 341 */           return true;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 346 */         par1World.setBlockToAir(x, y, z);
/*     */         
/* 348 */         while (canFallBelow(par1World, x2, y2 - 1, z2) && y2 > 0)
/*     */         {
/* 350 */           y2--;
/*     */         }
/*     */         
/* 353 */         if (y2 > 0)
/*     */         {
/* 355 */           par1World.setBlock(x, y, z, this, md, 3);
/*     */         }
/*     */       } 
/*     */     } 
/* 359 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEntityWalking(World world, int i, int j, int k, Entity entity) {
/* 366 */     int md = world.getBlockMetadata(i, j, k);
/* 367 */     if (md == 2)
/* 368 */       return;  if (!world.isRemote && entity instanceof EntityLivingBase && !((EntityLivingBase)entity).isEntityUndead())
/*     */     {
/* 370 */       if (entity instanceof EntityPlayer && world.rand.nextInt(100) == 0) {
/* 371 */         ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(Config.potionTaintPoisonID, 80, 0, false));
/*     */       }
/* 373 */       else if (!(entity instanceof EntityPlayer) && world.rand.nextInt(20) == 0) {
/* 374 */         ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(Config.potionTaintPoisonID, 160, 0, false));
/*     */       } 
/*     */     }
/* 377 */     super.onEntityWalking(world, i, j, k, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onStartFalling(EntityFallingTaint entityfalling) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onFinishFalling(World par1World, int par2, int par3, int par4, int par5) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World world, int i, int j, int k, Random random) {
/* 396 */     int md = world.getBlockMetadata(i, j, k);
/* 397 */     if (md == 0 && world.isAirBlock(i, j - 1, k) && random.nextInt(10) == 0) {
/* 398 */       Thaumcraft.proxy.dropletFX(world, i + 0.1F + world.rand.nextFloat() * 0.8F, j, k + 0.1F + world.rand.nextFloat() * 0.8F, 0.3F, 0.1F, 0.8F);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBlockEventReceived(World world, int x, int y, int z, int id, int cd) {
/* 407 */     if (id == 1) {
/*     */       
/* 409 */       if (world.isRemote) {
/* 410 */         world.playSound(x, y, z, "thaumcraft:roots", 0.1F, 0.9F + world.rand.nextFloat() * 0.2F, false);
/*     */       }
/* 412 */       return true;
/*     */     } 
/*     */     
/* 415 */     return super.onBlockEventReceived(world, x, y, z, id, cd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSideSolid(IBlockAccess world, int x, int y, int z, ForgeDirection side) {
/* 454 */     return true;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockTaint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */