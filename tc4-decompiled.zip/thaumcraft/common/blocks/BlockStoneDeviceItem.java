/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.util.ForgeDirection;
/*    */ import thaumcraft.common.tiles.TileFluxScrubber;
/*    */ 
/*    */ public class BlockStoneDeviceItem
/*    */   extends ItemBlock
/*    */ {
/*    */   public BlockStoneDeviceItem(Block par1) {
/* 15 */     super(par1);
/* 16 */     setMaxDamage(0);
/* 17 */     setHasSubtypes(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int par1) {
/* 24 */     return par1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/* 30 */     return getUnlocalizedName() + "." + par1ItemStack.getItemDamage();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/* 39 */     boolean ret = super.placeBlockAt(stack, player, world, x, y, z, side, hitX, hitY, hitZ, metadata);
/* 40 */     if (metadata == 14) {
/* 41 */       TileFluxScrubber tile = (TileFluxScrubber)world.getTileEntity(x, y, z);
/* 42 */       if (tile != null && tile instanceof TileFluxScrubber) {
/* 43 */         tile.facing = ForgeDirection.getOrientation(side).getOpposite();
/* 44 */         tile.markDirty();
/* 45 */         world.markBlockForUpdate(x, y, x);
/*    */       } 
/*    */     } 
/* 48 */     return ret;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockStoneDeviceItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */