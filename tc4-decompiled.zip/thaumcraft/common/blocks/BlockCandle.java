/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.api.crafting.IInfusionStabiliser;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.lib.utils.Utils;
/*     */ 
/*     */ public class BlockCandle extends Block implements IInfusionStabiliser {
/*     */   public IIcon icon;
/*     */   public IIcon iconStub;
/*     */   
/*     */   public BlockCandle() {
/*  28 */     super(Material.circuits);
/*  29 */     setHardness(0.1F);
/*  30 */     this; setStepSound(soundTypeCloth);
/*  31 */     setCreativeTab(Thaumcraft.tabTC);
/*  32 */     setLightLevel(0.95F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/*  39 */     for (int var4 = 0; var4 < 16; var4++)
/*     */     {
/*  41 */       par3List.add(new ItemStack(par1, 1, var4));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*  50 */     this.icon = ir.registerIcon("thaumcraft:candle");
/*  51 */     this.iconStub = ir.registerIcon("thaumcraft:candlestub");
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int meta) {
/*  57 */     return this.icon;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderColor(int par1) {
/*  62 */     return Utils.colors[par1];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canPlaceBlockAt(World par1World, int par2, int par3, int par4) {
/*  68 */     return World.doesBlockHaveSolidTopSurface((IBlockAccess)par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNeighborBlockChange(World par1World, int par2, int par3, int par4, Block par5) {
/*  75 */     int var6 = par1World.getBlockMetadata(par2, par3, par4);
/*  76 */     boolean var7 = canPlaceBlockAt(par1World, par2, par3 - 1, par4);
/*     */     
/*  78 */     if (!var7) {
/*     */       
/*  80 */       dropBlockAsItem(par1World, par2, par3, par4, var6, 0);
/*  81 */       par1World.setBlockToAir(par2, par3, par4);
/*     */     } 
/*     */     
/*  84 */     super.onNeighborBlockChange(par1World, par2, par3, par4, par5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canPlaceBlockOnSide(World par1World, int par2, int par3, int par4, int par5) {
/*  90 */     return canPlaceBlockAt(par1World, par2, par3 - 1, par4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int colorMultiplier(IBlockAccess par1iBlockAccess, int par2, int par3, int par4) {
/*  96 */     int md = par1iBlockAccess.getBlockMetadata(par2, par3, par4);
/*  97 */     return Utils.colors[md];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int damageDropped(int par1) {
/* 103 */     return par1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess par1iBlockAccess, int par2, int par3, int par4) {
/* 109 */     setBlockBounds(0.375F, 0.0F, 0.375F, 0.625F, 0.5F, 0.625F);
/* 110 */     super.setBlockBoundsBasedOnState(par1iBlockAccess, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSideSolid(IBlockAccess world, int x, int y, int z, ForgeDirection side) {
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/* 126 */     return ConfigBlocks.blockCandleRI;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/* 132 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void randomDisplayTick(World par1World, int par2, int par3, int par4, Random par5Random) {
/* 144 */     double var7 = (par2 + 0.5F);
/* 145 */     double var9 = (par3 + 0.7F);
/* 146 */     double var11 = (par4 + 0.5F);
/*     */     
/* 148 */     par1World.spawnParticle("smoke", var7, var9, var11, 0.0D, 0.0D, 0.0D);
/* 149 */     par1World.spawnParticle("flame", var7, var9, var11, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canStabaliseInfusion(World world, int x, int y, int z) {
/* 155 */     return true;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockCandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */