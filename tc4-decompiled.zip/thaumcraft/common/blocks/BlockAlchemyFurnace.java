/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.client.fx.ParticleEngine;
/*     */ import thaumcraft.client.fx.particles.FXSlimyBubble;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileAlchemyFurnaceAdvanced;
/*     */ import thaumcraft.common.tiles.TileAlchemyFurnaceAdvancedNozzle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockAlchemyFurnace
/*     */   extends BlockContainer
/*     */ {
/*     */   public IIcon icon;
/*     */   
/*     */   public BlockAlchemyFurnace() {
/*  60 */     super(Material.iron);
/*  61 */     setHardness(3.0F);
/*  62 */     setResistance(17.0F);
/*  63 */     setStepSound(Block.soundTypeMetal);
/*  64 */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*  71 */     this.icon = ir.registerIcon("thaumcraft:metalbase");
/*     */   }
/*     */ 
/*     */   
/*     */   public IIcon getIcon(int i, int md) {
/*  76 */     return this.icon;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/*  83 */     par3List.add(new ItemStack(par1, 1, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/*  88 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/*  99 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess world, int i, int j, int k) {
/* 104 */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getSelectedBoundingBoxFromPool(World w, int i, int j, int k) {
/* 109 */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 110 */     return super.getSelectedBoundingBoxFromPool(w, i, j, k);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCollisionBoxesToList(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, List arraylist, Entity entity) {
/* 116 */     int md = world.getBlockMetadata(i, j, k);
/* 117 */     if (md == 0 && !(entity instanceof net.minecraft.entity.EntityLivingBase)) {
/* 118 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.7F, 1.0F);
/* 119 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, entity);
/*     */     } else {
/* 121 */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 122 */       super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, entity);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightValue(IBlockAccess world, int x, int y, int z) {
/* 130 */     int metadata = world.getBlockMetadata(x, y, z);
/* 131 */     if (metadata == 0) {
/* 132 */       TileAlchemyFurnaceAdvanced tile = (TileAlchemyFurnaceAdvanced)world.getTileEntity(x, y, z);
/* 133 */       if (tile != null && tile.heat > 100) {
/* 134 */         return (int)(tile.heat / tile.maxPower * 12.0F);
/*     */       }
/*     */     } 
/* 137 */     return super.getLightValue(world, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity) {
/* 142 */     if (!world.isRemote) {
/* 143 */       int metadata = world.getBlockMetadata(i, j, k);
/* 144 */       if (metadata == 0) {
/* 145 */         TileAlchemyFurnaceAdvanced tile = (TileAlchemyFurnaceAdvanced)world.getTileEntity(i, j, k);
/* 146 */         if (tile != null && entity instanceof EntityItem && tile.process(((EntityItem)entity).getEntityItem())) {
/* 147 */           ItemStack s = ((EntityItem)entity).getEntityItem();
/* 148 */           s.stackSize--;
/* 149 */           world.playSoundAtEntity(entity, "thaumcraft:bubble", 0.2F, 1.0F + world.rand.nextFloat() * 0.4F);
/* 150 */           if (s.stackSize <= 0) {
/* 151 */             entity.setDead();
/*     */           } else {
/* 153 */             ((EntityItem)entity).setEntityItemStack(s);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Item getItemDropped(int md, Random par2Random, int par3) {
/* 162 */     return (md == 0) ? Item.getItemFromBlock(ConfigBlocks.blockStoneDevice) : ((md == 1 || md == 2 || md == 3 || md == 4) ? Item.getItemFromBlock(ConfigBlocks.blockMetalDevice) : Item.getItemById(0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int damageDropped(int metadata) {
/* 168 */     if (metadata == 1 || metadata == 4) return 3; 
/* 169 */     if (metadata == 3) return 9; 
/* 170 */     if (metadata == 2) return 1; 
/* 171 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createTileEntity(World world, int metadata) {
/* 176 */     if (metadata == 0) return (TileEntity)new TileAlchemyFurnaceAdvanced(); 
/* 177 */     if (metadata == 1) return (TileEntity)new TileAlchemyFurnaceAdvancedNozzle(); 
/* 178 */     return super.createTileEntity(world, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasComparatorInputOverride() {
/* 183 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getComparatorInputOverride(World world, int x, int y, int z, int rs) {
/* 189 */     TileEntity te = world.getTileEntity(x, y, z);
/* 190 */     if (te != null && te instanceof TileAlchemyFurnaceAdvancedNozzle) {
/* 191 */       if (((TileAlchemyFurnaceAdvancedNozzle)te).furnace != null) {
/* 192 */         float r = ((TileAlchemyFurnaceAdvancedNozzle)te).furnace.vis / ((TileAlchemyFurnaceAdvancedNozzle)te).furnace.maxVis;
/*     */         
/* 194 */         return (MathHelper.floor_float(r * 14.0F) + ((TileAlchemyFurnaceAdvancedNozzle)te).furnace.vis > 0) ? 1 : 0;
/*     */       } 
/* 196 */       return 0;
/*     */     } 
/* 198 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World var1, int md) {
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block bl, int md) {
/* 210 */     if (!world.isRemote) {
/* 211 */       if (md != 0)
/*     */       
/* 213 */       { for (int a = -1; a <= 1; a++) {
/* 214 */           for (int b = -1; b <= 1; b++) {
/* 215 */             for (int c = -1; c <= 1; c++) {
/* 216 */               if (world.getBlock(x + a, y + b, z + c) == this && world.getBlockMetadata(x + a, y + b, z + c) == 0) {
/* 217 */                 TileAlchemyFurnaceAdvanced tile = (TileAlchemyFurnaceAdvanced)world.getTileEntity(x + a, y + b, z + c);
/* 218 */                 if (tile != null) {
/* 219 */                   tile.destroy = true; // Byte code: goto -> 276
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }  }
/* 225 */       else { for (int a = -1; a <= 1; a++) {
/* 226 */           for (int b = 0; b <= 1; b++) {
/* 227 */             for (int c = -1; c <= 1; c++) {
/* 228 */               if ((a != 0 || b != 0 || c != 0) && world.getBlock(x + a, y + b, z + c) == this) {
/* 229 */                 int m = world.getBlockMetadata(x + a, y + b, z + c);
/* 230 */                 world.setBlock(x + a, y + b, z + c, Block.getBlockFromItem(getItemDropped(m, world.rand, 0)), damageDropped(m), 3);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }  }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World world, int x, int y, int z, Random rand) {
/* 242 */     int meta = world.getBlockMetadata(x, y, z);
/* 243 */     if (meta == 0) {
/* 244 */       TileAlchemyFurnaceAdvanced tile = (TileAlchemyFurnaceAdvanced)world.getTileEntity(x, y, z);
/* 245 */       if (tile != null && tile.vis > 0) {
/* 246 */         FXSlimyBubble ef = new FXSlimyBubble(world, (x + rand.nextFloat()), (y + 1), (z + rand.nextFloat()), 0.06F + rand.nextFloat() * 0.06F);
/*     */         
/* 248 */         ef.setAlphaF(0.8F);
/* 249 */         ef.setRBGColorF(0.6F - rand.nextFloat() * 0.2F, 0.0F, 0.6F + rand.nextFloat() * 0.2F);
/* 250 */         ParticleEngine.instance.addEffect(world, (EntityFX)ef);
/*     */         
/* 252 */         if (rand.nextInt(50) == 0) {
/* 253 */           double var21 = (x + rand.nextFloat());
/* 254 */           double var22 = y + this.maxY;
/* 255 */           double var23 = (z + rand.nextFloat());
/* 256 */           world.playSound(var21, var22, var23, "liquid.lavapop", 0.1F + rand.nextFloat() * 0.1F, 0.9F + rand.nextFloat() * 0.15F, false);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 261 */         int q = rand.nextInt(2);
/* 262 */         int w = rand.nextInt(2);
/*     */         
/* 264 */         FXSlimyBubble ef2 = new FXSlimyBubble(world, x - 0.6D + rand.nextFloat() * 0.2D + (q * 2), (y + 2), z - 0.6D + rand.nextFloat() * 0.2D + (w * 2), 0.06F + rand.nextFloat() * 0.06F);
/*     */         
/* 266 */         ef2.setAlphaF(0.8F);
/* 267 */         ef2.setRBGColorF(0.6F - rand.nextFloat() * 0.2F, 0.0F, 0.6F + rand.nextFloat() * 0.2F);
/* 268 */         ParticleEngine.instance.addEffect(world, (EntityFX)ef2);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 273 */     super.randomDisplayTick(world, x, y, z, rand);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockAlchemyFurnace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */