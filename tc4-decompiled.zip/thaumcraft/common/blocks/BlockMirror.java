/*     */ package thaumcraft.common.blocks;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagInt;
/*     */ import net.minecraft.nbt.NBTTagString;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.DimensionManager;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.tiles.TileMirror;
/*     */ import thaumcraft.common.tiles.TileMirrorEssentia;
/*     */ 
/*     */ public class BlockMirror extends BlockContainer {
/*     */   public IIcon icon;
/*     */   public IIcon iconEss;
/*     */   
/*     */   public BlockMirror() {
/*  35 */     super(Material.glass);
/*  36 */     setHardness(1.0F);
/*  37 */     setResistance(10.0F);
/*  38 */     setStepSound(new CustomStepSound("jar", 0.5F, 2.0F));
/*  39 */     setCreativeTab(Thaumcraft.tabTC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*  47 */     this.icon = ir.registerIcon("thaumcraft:mirrorframe");
/*  48 */     this.iconEss = ir.registerIcon("thaumcraft:mirrorframe2");
/*     */   }
/*     */ 
/*     */   
/*     */   public IIcon getIcon(int i, int m) {
/*  53 */     return (m < 6) ? this.icon : this.iconEss;
/*     */   }
/*     */ 
/*     */   
/*     */   public int damageDropped(int par1) {
/*  58 */     return par1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/*  65 */     par3List.add(new ItemStack(par1, 1, 0));
/*  66 */     par3List.add(new ItemStack(par1, 1, 6));
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createTileEntity(World world, int metadata) {
/*  71 */     if (metadata <= 5) new TileMirror(); 
/*  72 */     if (metadata > 5 && metadata <= 11) return (TileEntity)new TileMirrorEssentia(); 
/*  73 */     return super.createTileEntity(world, metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World var1, int md) {
/*  78 */     return (TileEntity)new TileMirror();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/*  84 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/*  89 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBlockHarvested(World par1World, int par2, int par3, int par4, int par5, EntityPlayer par6EntityPlayer) {
/* 102 */     dropBlockAsItem(par1World, par2, par3, par4, par5, 0);
/* 103 */     super.onBlockHarvested(par1World, par2, par3, par4, par5, par6EntityPlayer);
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<ItemStack> getDrops(World world, int x, int y, int z, int metadata, int fortune) {
/* 108 */     ArrayList<ItemStack> drops = new ArrayList<ItemStack>();
/* 109 */     int md = world.getBlockMetadata(x, y, z);
/* 110 */     if (md < 6) {
/* 111 */       TileMirror tileMirror = (TileMirror)world.getTileEntity(x, y, z);
/* 112 */       ItemStack itemStack = new ItemStack((Block)this, 1, 0);
/* 113 */       if (tileMirror != null && tileMirror instanceof TileMirror) {
/* 114 */         if (tileMirror.linked) {
/* 115 */           itemStack.setTagInfo("linkX", (NBTBase)new NBTTagInt(tileMirror.linkX));
/* 116 */           itemStack.setTagInfo("linkY", (NBTBase)new NBTTagInt(tileMirror.linkY));
/* 117 */           itemStack.setTagInfo("linkZ", (NBTBase)new NBTTagInt(tileMirror.linkZ));
/* 118 */           itemStack.setTagInfo("linkDim", (NBTBase)new NBTTagInt(tileMirror.linkDim));
/* 119 */           itemStack.setTagInfo("dimname", (NBTBase)new NBTTagString(DimensionManager.getProvider(world.provider.dimensionId).getDimensionName()));
/* 120 */           itemStack.setItemDamage(1);
/* 121 */           tileMirror.invalidateLink();
/*     */         } 
/* 123 */         drops.add(itemStack);
/*     */       } 
/* 125 */       return drops;
/*     */     } 
/* 127 */     TileMirrorEssentia tm = (TileMirrorEssentia)world.getTileEntity(x, y, z);
/* 128 */     ItemStack drop = new ItemStack((Block)this, 1, 6);
/* 129 */     if (tm != null && tm instanceof TileMirrorEssentia) {
/* 130 */       if (tm.linked) {
/* 131 */         drop.setTagInfo("linkX", (NBTBase)new NBTTagInt(tm.linkX));
/* 132 */         drop.setTagInfo("linkY", (NBTBase)new NBTTagInt(tm.linkY));
/* 133 */         drop.setTagInfo("linkZ", (NBTBase)new NBTTagInt(tm.linkZ));
/* 134 */         drop.setTagInfo("linkDim", (NBTBase)new NBTTagInt(tm.linkDim));
/* 135 */         drop.setTagInfo("dimname", (NBTBase)new NBTTagString(DimensionManager.getProvider(world.provider.dimensionId).getDimensionName()));
/* 136 */         drop.setItemDamage(7);
/* 137 */         tm.invalidateLink();
/*     */       } 
/* 139 */       drops.add(drop);
/*     */     } 
/* 141 */     return drops;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
/* 148 */     int md = world.getBlockMetadata(x, y, z);
/* 149 */     if (md < 6 && !world.isRemote && entity instanceof EntityItem && !entity.isDead && ((EntityItem)entity).timeUntilPortal == 0) {
/*     */       
/* 151 */       TileMirror taf = (TileMirror)world.getTileEntity(x, y, z);
/* 152 */       if (taf != null) {
/* 153 */         taf.transport((EntityItem)entity);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int onBlockPlaced(World par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8, int par9) {
/* 161 */     if (par9 > 6) { par9 = 6; }
/*     */     
/* 163 */     else if (par9 > 0 && par9 < 6) { par9 = 0; }
/*     */     
/* 165 */     return par9 + par5;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNeighborBlockChange(World world, int i, int j, int k, Block l) {
/* 170 */     if (!world.isRemote) {
/*     */       
/* 172 */       int i1 = world.getBlockMetadata(i, j, k);
/* 173 */       boolean flag = false;
/* 174 */       if (!world.isSideSolid(i - 1, j, k, ForgeDirection.getOrientation(5)) && i1 % 6 == 5) flag = true; 
/* 175 */       if (!world.isSideSolid(i + 1, j, k, ForgeDirection.getOrientation(4)) && i1 % 6 == 4) flag = true; 
/* 176 */       if (!world.isSideSolid(i, j, k - 1, ForgeDirection.getOrientation(3)) && i1 % 6 == 3) flag = true; 
/* 177 */       if (!world.isSideSolid(i, j, k + 1, ForgeDirection.getOrientation(2)) && i1 % 6 == 2) flag = true; 
/* 178 */       if (!world.isSideSolid(i, j - 1, k, ForgeDirection.getOrientation(1)) && i1 % 6 == 1) flag = true; 
/* 179 */       if (!world.isSideSolid(i, j + 1, k, ForgeDirection.getOrientation(0)) && i1 % 6 == 0) flag = true; 
/* 180 */       if (flag) {
/*     */         
/* 182 */         dropBlockAsItem(world, i, j, k, i1, 0);
/* 183 */         world.setBlockToAir(i, j, k);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkIfAttachedToBlock(World world, int i, int j, int k) {
/* 190 */     if (!canPlaceBlockAt(world, i, j, k))
/*     */     {
/* 192 */       return false;
/*     */     }
/*     */     
/* 195 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canPlaceBlockOnSide(World world, int i, int j, int k, int l) {
/* 202 */     if (l == 0 && world.isSideSolid(i, j + 1, k, ForgeDirection.getOrientation(0))) return true; 
/* 203 */     if (l == 1 && world.isSideSolid(i, j - 1, k, ForgeDirection.getOrientation(1))) return true; 
/* 204 */     if (l == 2 && world.isSideSolid(i, j, k + 1, ForgeDirection.getOrientation(2))) return true; 
/* 205 */     if (l == 3 && world.isSideSolid(i, j, k - 1, ForgeDirection.getOrientation(3))) return true; 
/* 206 */     if (l == 4 && world.isSideSolid(i + 1, j, k, ForgeDirection.getOrientation(4))) return true; 
/* 207 */     return (l == 5 && world.isSideSolid(i - 1, j, k, ForgeDirection.getOrientation(5)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canPlaceBlockAt(World world, int i, int j, int k) {
/* 213 */     if (world.isSideSolid(i - 1, j, k, ForgeDirection.getOrientation(5))) return true; 
/* 214 */     if (world.isSideSolid(i + 1, j, k, ForgeDirection.getOrientation(4))) return true; 
/* 215 */     if (world.isSideSolid(i, j, k - 1, ForgeDirection.getOrientation(3))) return true; 
/* 216 */     if (world.isSideSolid(i, j, k + 1, ForgeDirection.getOrientation(2))) return true; 
/* 217 */     if (world.isSideSolid(i, j - 1, k, ForgeDirection.getOrientation(1))) return true; 
/* 218 */     return world.isSideSolid(i, j + 1, k, ForgeDirection.getOrientation(0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBlockActivated(World par1World, int par2, int par3, int par4, EntityPlayer par5EntityPlayer, int par6, float par7, float par8, float par9) {
/* 226 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
/* 233 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getSelectedBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
/* 239 */     setBlockBoundsBasedOnState((IBlockAccess)par1World, par2, par3, par4);
/* 240 */     return super.getSelectedBoundingBoxFromPool(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess par1IBlockAccess, int par2, int par3, int par4) {
/* 246 */     setBlockBoundsForBlockRender(par1IBlockAccess.getBlockMetadata(par2, par3, par4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCollisionBoxesToList(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, List arraylist, Entity par7Entity) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockBoundsForBlockRender(int par1) {
/* 258 */     float w = 0.0625F;
/* 259 */     switch (par1 % 6) { case 0:
/* 260 */         setBlockBounds(0.0F, 1.0F - w, 0.0F, 1.0F, 1.0F, 1.0F); break;
/* 261 */       case 1: setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, w, 1.0F); break;
/* 262 */       case 2: setBlockBounds(0.0F, 0.0F, 1.0F - w, 1.0F, 1.0F, 1.0F); break;
/* 263 */       case 3: setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, w); break;
/* 264 */       case 4: setBlockBounds(1.0F - w, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); break;
/* 265 */       case 5: setBlockBounds(0.0F, 0.0F, 0.0F, w, 1.0F, 1.0F);
/*     */         break; }
/*     */   
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockMirror.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */