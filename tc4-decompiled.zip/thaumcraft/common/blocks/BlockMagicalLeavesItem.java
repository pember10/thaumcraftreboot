/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ public class BlockMagicalLeavesItem
/*    */   extends ItemBlock
/*    */ {
/*    */   public BlockMagicalLeavesItem(Block par1) {
/* 12 */     super(par1);
/* 13 */     setMaxDamage(0);
/* 14 */     setHasSubtypes(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int par1) {
/* 23 */     return par1 | 0x4;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/* 39 */     int var2 = par1ItemStack.getItemDamage();
/*    */     
/* 41 */     return getUnlocalizedName() + "." + BlockMagicalLeaves.leafType[var2 & 0x1];
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockMagicalLeavesItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */