/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.aspects.IEssentiaContainerItem;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileJarFillable;
/*     */ 
/*     */ public class ItemJarFilled
/*     */   extends Item implements IEssentiaContainerItem {
/*     */   public ItemJarFilled() {
/*  30 */     setMaxDamage(0);
/*  31 */     setMaxStackSize(1);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon icon;
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerIcons(IIconRegister ir) {
/*  39 */     this.icon = ir.registerIcon("thaumcraft:blank");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIconFromDamage(int par1) {
/*  44 */     return this.icon;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMetadata(int par1) {
/*  50 */     return par1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer player, List<String> list, boolean par4) {
/*  55 */     AspectList aspects = getAspects(stack);
/*  56 */     if (aspects != null && aspects.size() > 0) {
/*  57 */       for (Aspect tag : aspects.getAspectsSorted()) {
/*  58 */         if (Thaumcraft.proxy.playerKnowledge.hasDiscoveredAspect(player.getCommandSenderName(), tag)) {
/*  59 */           list.add(tag.getName() + " x " + aspects.getAmount(tag));
/*     */         } else {
/*  61 */           list.add(StatCollector.translateToLocal("tc.aspect.unknown"));
/*     */         } 
/*     */       } 
/*     */     }
/*  65 */     if (stack.hasTagCompound() && stack.stackTagCompound.hasKey("AspectFilter")) {
/*  66 */       String tf = stack.stackTagCompound.getString("AspectFilter");
/*  67 */       Aspect tag = Aspect.getAspect(tf);
/*  68 */       if (Thaumcraft.proxy.playerKnowledge.hasDiscoveredAspect(player.getCommandSenderName(), tag)) {
/*  69 */         list.add("§5" + tag.getName());
/*     */       } else {
/*  71 */         list.add("§5" + StatCollector.translateToLocal("tc.aspect.unknown"));
/*     */       } 
/*     */     } 
/*  74 */     super.addInformation(stack, player, list, par4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnlocalizedName(ItemStack stack) {
/*  81 */     if (stack.getItemDamage() == 3) {
/*  82 */       return super.getUnlocalizedName(stack) + ".void";
/*     */     }
/*  84 */     return super.getUnlocalizedName(stack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float par8, float par9, float par10) {
/*  90 */     Block block = world.getBlock(x, y, z);
/*     */     
/*  92 */     if (block == Blocks.snow_layer && (world.getBlockMetadata(x, y, z) & 0x7) < 1) {
/*     */       
/*  94 */       side = 1;
/*     */     }
/*  96 */     else if (block != Blocks.vine && block != Blocks.tallgrass && block != Blocks.deadbush && !block.isReplaceable((IBlockAccess)world, x, y, z)) {
/*     */       
/*  98 */       if (side == 0)
/*     */       {
/* 100 */         y--;
/*     */       }
/*     */       
/* 103 */       if (side == 1)
/*     */       {
/* 105 */         y++;
/*     */       }
/*     */       
/* 108 */       if (side == 2)
/*     */       {
/* 110 */         z--;
/*     */       }
/*     */       
/* 113 */       if (side == 3)
/*     */       {
/* 115 */         z++;
/*     */       }
/*     */       
/* 118 */       if (side == 4)
/*     */       {
/* 120 */         x--;
/*     */       }
/*     */       
/* 123 */       if (side == 5)
/*     */       {
/* 125 */         x++;
/*     */       }
/*     */     } 
/*     */     
/* 129 */     if (stack.stackSize == 0)
/*     */     {
/* 131 */       return false;
/*     */     }
/* 133 */     if (!player.canPlayerEdit(x, y, z, side, stack))
/*     */     {
/* 135 */       return false;
/*     */     }
/* 137 */     if (y == 255 && ConfigBlocks.blockJar.getMaterial().isSolid())
/*     */     {
/* 139 */       return false;
/*     */     }
/* 141 */     if (world.canPlaceEntityOnSide(ConfigBlocks.blockJar, x, y, z, false, side, (Entity)player, stack)) {
/*     */       
/* 143 */       Block var12 = ConfigBlocks.blockJar;
/* 144 */       int var13 = getMetadata(stack.getItemDamage());
/* 145 */       int var14 = ConfigBlocks.blockJar.onBlockPlaced(world, x, y, z, side, par8, par9, par10, var13);
/*     */       
/* 147 */       if (placeBlockAt(stack, player, world, x, y, z, side, par8, par9, par10, var14)) {
/*     */         
/* 149 */         TileEntity te = world.getTileEntity(x, y, z);
/* 150 */         if (te != null && te instanceof TileJarFillable)
/*     */         {
/* 152 */           if (stack.hasTagCompound()) {
/* 153 */             AspectList aspects = getAspects(stack);
/* 154 */             if (aspects != null && aspects.size() == 1) {
/* 155 */               ((TileJarFillable)te).amount = aspects.getAmount(aspects.getAspects()[0]);
/* 156 */               ((TileJarFillable)te).aspect = aspects.getAspects()[0];
/*     */             } 
/* 158 */             String tf = stack.stackTagCompound.getString("AspectFilter");
/* 159 */             if (tf != null) ((TileJarFillable)te).aspectFilter = Aspect.getAspect(tf); 
/*     */           } 
/*     */         }
/* 162 */         world.playSoundEffect((x + 0.5F), (y + 0.5F), (z + 0.5F), var12.stepSound.func_150496_b(), (var12.stepSound.getVolume() + 1.0F) / 2.0F, var12.stepSound.getPitch() * 0.8F);
/* 163 */         stack.stackSize--;
/*     */       } 
/*     */       
/* 166 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 170 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/* 176 */     if (!world.setBlock(x, y, z, ConfigBlocks.blockJar, metadata, 3))
/*     */     {
/* 178 */       return false;
/*     */     }
/*     */     
/* 181 */     if (world.getBlock(x, y, z) == ConfigBlocks.blockJar) {
/*     */       
/* 183 */       ConfigBlocks.blockJar.onBlockPlacedBy(world, x, y, z, (EntityLivingBase)player, stack);
/* 184 */       ConfigBlocks.blockJar.onPostBlockPlaced(world, x, y, z, metadata);
/*     */     } 
/*     */     
/* 187 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AspectList getAspects(ItemStack itemstack) {
/* 193 */     if (itemstack.hasTagCompound()) {
/* 194 */       AspectList aspects = new AspectList();
/* 195 */       aspects.readFromNBT(itemstack.getTagCompound());
/* 196 */       return (aspects.size() > 0) ? aspects : null;
/*     */     } 
/* 198 */     return null;
/*     */   }
/*     */   
/*     */   public Aspect getFilter(ItemStack itemstack) {
/* 202 */     if (itemstack.hasTagCompound()) {
/* 203 */       return Aspect.getAspect(itemstack.stackTagCompound.getString("AspectFilter"));
/*     */     }
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAspects(ItemStack itemstack, AspectList aspects) {
/* 210 */     if (!itemstack.hasTagCompound()) itemstack.setTagCompound(new NBTTagCompound()); 
/* 211 */     aspects.writeToNBT(itemstack.getTagCompound());
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\ItemJarFilled.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */