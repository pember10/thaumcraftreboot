/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class BlockCustomOreItem
/*    */   extends ItemBlock
/*    */ {
/* 10 */   public static final int[] colors = new int[] { 16777215, 16777086, 16727041, 37119, 40960, 15650047, 5592439 };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BlockCustomOreItem(Block par1) {
/* 24 */     super(par1);
/* 25 */     setMaxDamage(0);
/* 26 */     setHasSubtypes(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int par1) {
/* 33 */     return par1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/* 39 */     return getUnlocalizedName() + "." + par1ItemStack.getItemDamage();
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockCustomOreItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */