/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagInt;
/*     */ import net.minecraft.nbt.NBTTagString;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.aspects.IEssentiaContainerItem;
/*     */ import thaumcraft.api.nodes.NodeModifier;
/*     */ import thaumcraft.api.nodes.NodeType;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileJarNode;
/*     */ 
/*     */ public class ItemJarNode extends Item implements IEssentiaContainerItem {
/*     */   public ItemJarNode() {
/*  34 */     setMaxDamage(0);
/*  35 */     setMaxStackSize(1);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon icon;
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerIcons(IIconRegister ir) {
/*  43 */     this.icon = ir.registerIcon("thaumcraft:blank");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIconFromDamage(int par1) {
/*  48 */     return this.icon;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMetadata(int par1) {
/*  54 */     return par1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer player, List<String> list, boolean par4) {
/*  59 */     String desc = "§9" + StatCollector.translateToLocal("nodetype." + getNodeType(stack) + ".name");
/*  60 */     if (getNodeModifier(stack) != null) {
/*  61 */       desc = desc + ", " + StatCollector.translateToLocal("nodemod." + getNodeModifier(stack) + ".name");
/*     */     }
/*  63 */     list.add(desc);
/*  64 */     AspectList aspects = getAspects(stack);
/*  65 */     if (aspects != null && aspects.size() > 0) {
/*  66 */       for (Aspect tag : aspects.getAspectsSorted()) {
/*  67 */         if (Thaumcraft.proxy.playerKnowledge.hasDiscoveredAspect(player.getCommandSenderName(), tag)) {
/*  68 */           list.add(tag.getName() + " x " + aspects.getAmount(tag));
/*     */         } else {
/*  70 */           list.add(StatCollector.translateToLocal("tc.aspect.unknown"));
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*  75 */     super.addInformation(stack, player, list, par4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float par8, float par9, float par10) {
/*  81 */     Block var11 = world.getBlock(x, y, z);
/*     */     
/*  83 */     if (var11 == Blocks.snow_layer) {
/*     */       
/*  85 */       side = 1;
/*     */     }
/*  87 */     else if (var11 != Blocks.vine && var11 != Blocks.tallgrass && var11 != Blocks.deadbush && (var11.isAir((IBlockAccess)world, x, y, z) || !var11.isReplaceable((IBlockAccess)world, x, y, z))) {
/*     */ 
/*     */       
/*  90 */       if (side == 0)
/*     */       {
/*  92 */         y--;
/*     */       }
/*     */       
/*  95 */       if (side == 1)
/*     */       {
/*  97 */         y++;
/*     */       }
/*     */       
/* 100 */       if (side == 2)
/*     */       {
/* 102 */         z--;
/*     */       }
/*     */       
/* 105 */       if (side == 3)
/*     */       {
/* 107 */         z++;
/*     */       }
/*     */       
/* 110 */       if (side == 4)
/*     */       {
/* 112 */         x--;
/*     */       }
/*     */       
/* 115 */       if (side == 5)
/*     */       {
/* 117 */         x++;
/*     */       }
/*     */     } 
/*     */     
/* 121 */     if (stack.stackSize == 0)
/*     */     {
/* 123 */       return false;
/*     */     }
/* 125 */     if (!player.canPlayerEdit(x, y, z, side, stack))
/*     */     {
/* 127 */       return false;
/*     */     }
/* 129 */     if (y == 255 && ConfigBlocks.blockJar.getMaterial().isSolid())
/*     */     {
/* 131 */       return false;
/*     */     }
/* 133 */     if (world.canPlaceEntityOnSide(ConfigBlocks.blockJar, x, y, z, false, side, (Entity)player, stack)) {
/*     */       
/* 135 */       Block var12 = ConfigBlocks.blockJar;
/* 136 */       int var13 = 2;
/* 137 */       int var14 = ConfigBlocks.blockJar.onBlockPlaced(world, x, y, z, side, par8, par9, par10, var13);
/*     */       
/* 139 */       if (placeBlockAt(stack, player, world, x, y, z, side, par8, par9, par10, var14)) {
/*     */         
/* 141 */         TileEntity te = world.getTileEntity(x, y, z);
/* 142 */         if (te != null && te instanceof TileJarNode)
/*     */         {
/* 144 */           if (stack.hasTagCompound()) {
/* 145 */             AspectList aspects = getAspects(stack);
/* 146 */             if (aspects != null) {
/* 147 */               ((TileJarNode)te).setAspects(aspects);
/* 148 */               ((TileJarNode)te).setNodeType(getNodeType(stack));
/* 149 */               ((TileJarNode)te).setNodeModifier(getNodeModifier(stack));
/* 150 */               ((TileJarNode)te).setId(getNodeId(stack));
/*     */             } 
/*     */           } 
/*     */         }
/* 154 */         world.playSoundEffect((x + 0.5F), (y + 0.5F), (z + 0.5F), var12.stepSound.getStepResourcePath(), (var12.stepSound.getVolume() + 1.0F) / 2.0F, var12.stepSound.getPitch() * 0.8F);
/* 155 */         stack.stackSize--;
/*     */       } 
/*     */       
/* 158 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/* 168 */     if (!world.setBlock(x, y, z, ConfigBlocks.blockJar, metadata, 3))
/*     */     {
/* 170 */       return false;
/*     */     }
/*     */     
/* 173 */     if (world.getBlock(x, y, z) == ConfigBlocks.blockJar) {
/*     */       
/* 175 */       ConfigBlocks.blockJar.onBlockPlacedBy(world, x, y, z, (EntityLivingBase)player, stack);
/* 176 */       ConfigBlocks.blockJar.onPostBlockPlaced(world, x, y, z, metadata);
/*     */     } 
/*     */     
/* 179 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AspectList getAspects(ItemStack itemstack) {
/* 185 */     if (itemstack.hasTagCompound()) {
/* 186 */       AspectList aspects = new AspectList();
/* 187 */       aspects.readFromNBT(itemstack.getTagCompound());
/* 188 */       return (aspects.size() > 0) ? aspects : null;
/*     */     } 
/* 190 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAspects(ItemStack itemstack, AspectList aspects) {
/* 195 */     if (!itemstack.hasTagCompound()) itemstack.setTagCompound(new NBTTagCompound()); 
/* 196 */     aspects.writeToNBT(itemstack.getTagCompound());
/*     */   }
/*     */   
/*     */   public void setNodeAttributes(ItemStack itemstack, NodeType type, NodeModifier mod, String id) {
/* 200 */     if (!itemstack.hasTagCompound()) itemstack.setTagCompound(new NBTTagCompound()); 
/* 201 */     itemstack.setTagInfo("nodetype", (NBTBase)new NBTTagInt(type.ordinal()));
/* 202 */     if (mod != null) itemstack.setTagInfo("nodemod", (NBTBase)new NBTTagInt(mod.ordinal())); 
/* 203 */     itemstack.setTagInfo("nodeid", (NBTBase)new NBTTagString(id));
/*     */   }
/*     */   
/*     */   public NodeType getNodeType(ItemStack itemstack) {
/* 207 */     if (!itemstack.hasTagCompound()) return null; 
/* 208 */     return NodeType.values()[itemstack.getTagCompound().getInteger("nodetype")];
/*     */   }
/*     */   
/*     */   public NodeModifier getNodeModifier(ItemStack itemstack) {
/* 212 */     if (!itemstack.hasTagCompound() || !itemstack.getTagCompound().hasKey("nodemod")) return null; 
/* 213 */     return NodeModifier.values()[itemstack.getTagCompound().getInteger("nodemod")];
/*     */   }
/*     */   
/*     */   public String getNodeId(ItemStack itemstack) {
/* 217 */     if (!itemstack.hasTagCompound()) return "0"; 
/* 218 */     return itemstack.getTagCompound().getString("nodeid");
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\ItemJarNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */