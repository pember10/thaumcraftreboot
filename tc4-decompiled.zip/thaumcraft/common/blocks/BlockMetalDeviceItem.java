/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.tiles.TileArcaneLamp;
/*     */ import thaumcraft.common.tiles.TileArcaneLampFertility;
/*     */ import thaumcraft.common.tiles.TileArcaneLampGrowth;
/*     */ import thaumcraft.common.tiles.TileBrainbox;
/*     */ import thaumcraft.common.tiles.TileVisRelay;
/*     */ 
/*     */ public class BlockMetalDeviceItem
/*     */   extends ItemBlock {
/*     */   public BlockMetalDeviceItem(Block par1) {
/*  21 */     super(par1);
/*  22 */     setMaxDamage(0);
/*  23 */     setHasSubtypes(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMetadata(int par1) {
/*  30 */     return par1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/*  36 */     return getUnlocalizedName() + "." + par1ItemStack.getItemDamage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float par8, float par9, float par10) {
/*  43 */     if (stack.getItemDamage() == 0 || stack.getItemDamage() == 1 || stack.getItemDamage() == 2 || stack.getItemDamage() == 3 || stack.getItemDamage() == 5 || stack.getItemDamage() == 6 || stack.getItemDamage() == 7 || stack.getItemDamage() == 8 || stack.getItemDamage() == 9 || stack.getItemDamage() == 13 || stack.getItemDamage() == 14)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  54 */       return super.onItemUse(stack, player, world, x, y, z, side, par8, par9, par10);
/*     */     }
/*  56 */     Block bi = world.getBlock(x, y, z);
/*  57 */     int md = world.getBlockMetadata(x, y, z);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     if (stack.getItemDamage() == 12) {
/*  66 */       if (bi == ConfigBlocks.blockMetalDevice && (md == 10 || md == 11))
/*  67 */         return super.onItemUse(stack, player, world, x, y, z, side, par8, par9, par10); 
/*  68 */       return false;
/*     */     } 
/*     */     
/*  71 */     if (bi == ConfigBlocks.blockMetalDevice && md == 0) {
/*     */       
/*  73 */       if (side == 0 || side == 1)
/*     */       {
/*     */         
/*  76 */         return false;
/*     */       }
/*     */       
/*  79 */       if (side == 2)
/*     */       {
/*  81 */         z--;
/*     */       }
/*     */       
/*  84 */       if (side == 3)
/*     */       {
/*  86 */         z++;
/*     */       }
/*     */       
/*  89 */       if (side == 4)
/*     */       {
/*  91 */         x--;
/*     */       }
/*     */       
/*  94 */       if (side == 5)
/*     */       {
/*  96 */         x++;
/*     */       }
/*     */     } 
/*     */     
/* 100 */     if (stack.stackSize == 0)
/*     */     {
/* 102 */       return false;
/*     */     }
/* 104 */     if (!player.canPlayerEdit(x, y, z, side, stack))
/*     */     {
/* 106 */       return false;
/*     */     }
/* 108 */     if (y == 255 && this.field_150939_a.getMaterial().isSolid())
/*     */     {
/* 110 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 114 */     Block var11 = world.getBlock(x, y, z);
/* 115 */     if (world.isAirBlock(x, y, z) || var11.isReplaceable((IBlockAccess)world, x, y, z) || var11 == Blocks.vine || var11 == Blocks.tallgrass || var11 == Blocks.deadbush || var11 == Blocks.snow_layer)
/*     */     {
/*     */ 
/*     */       
/* 119 */       for (int a = 2; a < 6; a++) {
/* 120 */         ForgeDirection dir = ForgeDirection.getOrientation(a);
/* 121 */         int xx = x + dir.offsetX;
/* 122 */         int yy = y + dir.offsetY;
/* 123 */         int zz = z + dir.offsetZ;
/* 124 */         Block bid = world.getBlock(xx, yy, zz);
/* 125 */         int meta = world.getBlockMetadata(xx, yy, zz);
/* 126 */         if (bid == ConfigBlocks.blockMetalDevice && meta == 0 && 
/* 127 */           placeBlockAt(stack, player, world, x, y, z, side, par8, par9, par10, stack.getItemDamage())) {
/*     */           
/* 129 */           world.playSoundEffect((x + 0.5F), (y + 0.5F), (z + 0.5F), this.field_150939_a.stepSound.getStepResourcePath(), (this.field_150939_a.stepSound.getVolume() + 1.0F) / 2.0F, this.field_150939_a.stepSound.getPitch() * 0.8F);
/* 130 */           stack.stackSize--;
/* 131 */           world.setBlock(x, y, z, ConfigBlocks.blockMetalDevice, dir.getOpposite().ordinal() - 1, 3);
/* 132 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata) {
/* 147 */     boolean ret = super.placeBlockAt(stack, player, world, x, y, z, side, hitX, hitY, hitZ, metadata);
/* 148 */     if (metadata == 7) {
/* 149 */       TileArcaneLamp tile = (TileArcaneLamp)world.getTileEntity(x, y, z);
/* 150 */       if (tile != null && tile instanceof TileArcaneLamp) {
/* 151 */         tile.facing = ForgeDirection.getOrientation(side).getOpposite();
/* 152 */         world.markBlockForUpdate(x, y, x);
/*     */       }
/*     */     
/* 155 */     } else if (metadata == 8) {
/* 156 */       TileArcaneLampGrowth tile = (TileArcaneLampGrowth)world.getTileEntity(x, y, z);
/* 157 */       if (tile != null && tile instanceof TileArcaneLampGrowth) {
/* 158 */         tile.facing = ForgeDirection.getOrientation(side).getOpposite();
/* 159 */         world.markBlockForUpdate(x, y, x);
/*     */       }
/*     */     
/* 162 */     } else if (metadata == 12) {
/* 163 */       TileBrainbox tile = (TileBrainbox)world.getTileEntity(x, y, z);
/* 164 */       if (tile != null && tile instanceof TileBrainbox) {
/* 165 */         tile.facing = ForgeDirection.getOrientation(side).getOpposite();
/* 166 */         world.markBlockForUpdate(x, y, x);
/*     */       }
/*     */     
/* 169 */     } else if (metadata == 13) {
/* 170 */       TileArcaneLampFertility tile = (TileArcaneLampFertility)world.getTileEntity(x, y, z);
/* 171 */       if (tile != null && tile instanceof TileArcaneLampFertility) {
/* 172 */         tile.facing = ForgeDirection.getOrientation(side).getOpposite();
/* 173 */         world.markBlockForUpdate(x, y, x);
/*     */       }
/*     */     
/* 176 */     } else if (metadata == 14) {
/* 177 */       TileVisRelay tile = (TileVisRelay)world.getTileEntity(x, y, z);
/* 178 */       if (tile != null && tile instanceof TileVisRelay) {
/* 179 */         tile.orientation = (short)side;
/* 180 */         world.markBlockForUpdate(x, y, x);
/*     */       } 
/*     */     } 
/* 183 */     return ret;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockMetalDeviceItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */