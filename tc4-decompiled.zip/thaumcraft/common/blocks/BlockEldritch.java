/*     */ package thaumcraft.common.blocks;
/*     */ public class BlockEldritch extends BlockContainer { public IIcon icon; public IIcon[] insIcon; private Random rand;
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*     */     this.icon = ir.registerIcon("thaumcraft:obsidiantile");
/*     */     this.insIcon[0] = ir.registerIcon("thaumcraft:es_i_1");
/*     */     this.insIcon[1] = ir.registerIcon("thaumcraft:es_i_2");
/*     */     this.insIcon[2] = ir.registerIcon("thaumcraft:deco_1");
/*     */     this.insIcon[3] = ir.registerIcon("thaumcraft:deco_2");
/*     */     this.insIcon[4] = ir.registerIcon("thaumcraft:deco_3");
/*     */     this.insIcon[5] = ir.registerIcon("thaumcraft:es_5");
/*     */     this.insIcon[6] = ir.registerIcon("thaumcraft:es_6");
/*     */     this.insIcon[7] = ir.registerIcon("thaumcraft:es_7");
/*     */     this.insIcon[8] = ir.registerIcon("thaumcraft:es_8");
/*     */   }
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int meta) {
/*     */     return (meta == 4) ? this.insIcon[0] : ((meta == 5) ? this.insIcon[1] : ((meta == 6) ? this.insIcon[2] : ((meta == 7) ? this.insIcon[4] : ((meta == 8) ? this.insIcon[3] : ((meta == 9) ? ConfigBlocks.blockCosmeticSolid.getIcon(side, 14) : ((meta == 10) ? this.insIcon[5] : this.icon))))));
/*     */   }
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(IBlockAccess ba, int x, int y, int z, int side) {
/*     */     int md = ba.getBlockMetadata(x, y, z);
/*     */     if (md == 8) {
/*     */       TileEntity te = ba.getTileEntity(x, y, z);
/*     */       if (te instanceof TileEldritchLock && ((TileEldritchLock)te).getFacing() == side)
/*     */         return this.insIcon[3]; 
/*     */       return this.insIcon[4];
/*     */     } 
/*     */     if (md == 10) {
/*     */       String l = x + "" + y + "" + z;
/*     */       Random r1 = new Random((Math.abs(l.hashCode() * 100) + 1));
/*     */       int i = r1.nextInt(12345 + side) % 4;
/*     */       return this.insIcon[5 + i];
/*     */     } 
/*     */     return super.getIcon(ba, x, y, z, side);
/*     */   }
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/*     */     par3List.add(new ItemStack(par1, 1, 4));
/*     */   }
/*     */   
/*  42 */   public BlockEldritch() { super(Material.rock);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  52 */     this.icon = null;
/*  53 */     this.insIcon = new IIcon[9];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     this.rand = new Random(); setResistance(20000.0F); setHardness(50.0F); setStepSound(soundTypeStone); setTickRandomly(true); setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); setLightOpacity(0); setCreativeTab(Thaumcraft.tabTC); }
/*     */   public int getLightValue(IBlockAccess world, int x, int y, int z) { int meta = world.getBlockMetadata(x, y, z); if (meta == 4 || meta == 5 || meta == 7) return 12;  if (meta == 6 || meta == 8) return 5;  if (meta == 9) return 4;  if (meta == 10) return 0;  return 8; }
/*     */   public boolean canCreatureSpawn(EnumCreatureType type, IBlockAccess world, int x, int y, int z) { return false; }
/* 184 */   public void setBlockBoundsBasedOnState(IBlockAccess world, int i, int j, int k) { setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); super.setBlockBoundsBasedOnState(world, i, j, k); } public int getExpDrop(IBlockAccess world, int metadata, int fortune) { if (metadata == 5 || metadata == 10) return MathHelper.getRandomIntegerInRange(this.rand, 1, 4); 
/* 185 */     if (metadata == 9) return MathHelper.getRandomIntegerInRange(this.rand, 6, 10); 
/* 186 */     return super.getExpDrop(world, metadata, fortune); } public void addCollisionBoxesToList(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, List arraylist, Entity par7Entity) { setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity); } public boolean hasTileEntity(int metadata) { return (metadata == 0 || metadata == 1 || metadata == 3 || metadata == 8 || metadata == 9 || metadata == 10); } public TileEntity createTileEntity(World world, int metadata) { if (metadata == 0) return (TileEntity)new TileEldritchAltar();  if (metadata == 1) return (TileEntity)new TileEldritchObelisk();  if (metadata == 3) return (TileEntity)new TileEldritchCap();  if (metadata == 8) return (TileEntity)new TileEldritchLock();  if (metadata == 9) return (TileEntity)new TileEldritchCrabSpawner();  if (metadata == 10) return (TileEntity)new TileEldritchTrap();  return null; } public int getRenderType() { return ConfigBlocks.blockEldritchRI; }
/*     */   public boolean renderAsNormalBlock() { return false; }
/*     */   public boolean isOpaqueCube() { return false; }
/*     */   public Item getItemDropped(int md, Random rand, int fortune) { return (md == 4) ? Item.getItemFromBlock((Block)this) : ((md == 5) ? ConfigItems.itemResource : Item.getItemById(0)); }
/*     */   public int damageDropped(int metadata) { return (metadata == 2) ? 1 : metadata; }
/* 191 */   public ArrayList<ItemStack> getDrops(World world, int x, int y, int z, int md, int fortune) { ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
/* 192 */     if (md == 5) {
/* 193 */       ret.add(new ItemStack(ConfigItems.itemResource, 1, 9));
/* 194 */       return ret;
/*     */     } 
/*     */     
/* 197 */     return super.getDrops(world, x, y, z, md, fortune); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block block, int meta) {
/* 203 */     if (!world.isRemote && meta < 4) {
/* 204 */       for (int xx = x - 3; xx <= x + 3; xx++) {
/* 205 */         for (int yy = y - 2; yy <= y + 2; yy++) {
/* 206 */           for (int zz = z - 3; zz <= z + 3; zz++) {
/* 207 */             if (world.getBlock(xx, yy, zz) == this && world.getBlockMetadata(xx, yy, zz) < 4)
/* 208 */               world.setBlockToAir(xx, yy, zz); 
/*     */           } 
/*     */         } 
/* 211 */       }  world.createExplosion(null, x + 0.5D, y + 0.5D, z + 0.5D, 1.0F, false);
/*     */     } 
/*     */     
/* 214 */     super.breakBlock(world, x, y, z, block, meta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getBlockHardness(World world, int x, int y, int z) {
/* 221 */     int meta = world.getBlockMetadata(x, y, z);
/* 222 */     if (meta == 4 || meta == 5) return 2.0F; 
/* 223 */     if (meta == 6) return 4.0F; 
/* 224 */     if (meta == 7 || meta == 8) return -1.0F; 
/* 225 */     if (meta == 9 || meta == 10) return 15.0F;
/*     */     
/* 227 */     return super.getBlockHardness(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getExplosionResistance(Entity par1Entity, World world, int x, int y, int z, double explosionX, double explosionY, double explosionZ) {
/* 234 */     int meta = world.getBlockMetadata(x, y, z);
/* 235 */     if (meta == 4 || meta == 5 || meta == 9 || meta == 10) return 30.0F; 
/* 236 */     if (meta == 6) return 100.0F; 
/* 237 */     if (meta == 7 || meta == 8) return Float.MAX_VALUE; 
/* 238 */     return super.getExplosionResistance(par1Entity, world, x, y, z, explosionX, explosionY, explosionZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float par7, float par8, float par9) {
/* 247 */     int metadata = world.getBlockMetadata(x, y, z);
/*     */     
/* 249 */     if (metadata == 0 && !world.isRemote && !player.isSneaking() && player.getHeldItem() != null && player.getHeldItem().getItem() instanceof thaumcraft.common.items.ItemEldritchObject && player.getHeldItem().getItemDamage() == 0) {
/*     */ 
/*     */ 
/*     */       
/* 253 */       TileEntity te = world.getTileEntity(x, y, z);
/* 254 */       if (te != null && te instanceof TileEldritchAltar) {
/* 255 */         TileEldritchAltar tile = (TileEldritchAltar)te;
/* 256 */         if (tile.getEyes() < 4) {
/* 257 */           if (tile.getEyes() >= 2) {
/* 258 */             tile.setSpawner(true);
/* 259 */             tile.setSpawnType((byte)1);
/*     */           } 
/* 261 */           tile.setEyes((byte)(tile.getEyes() + 1));
/* 262 */           tile.checkForMaze();
/* 263 */           (player.getHeldItem()).stackSize--;
/* 264 */           tile.markDirty();
/* 265 */           world.markBlockForUpdate(x, y, z);
/* 266 */           world.playSoundEffect(x, y, z, "thaumcraft:crystal", 0.2F, 1.0F);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 271 */     if (metadata == 8 && player.inventory.getCurrentItem() != null && player.inventory.getCurrentItem().getItem() instanceof thaumcraft.common.items.ItemEldritchObject && player.inventory.getCurrentItem().getItemDamage() == 2) {
/*     */ 
/*     */       
/* 274 */       TileEntity te = world.getTileEntity(x, y, z);
/* 275 */       if (te != null && te instanceof TileEldritchLock && ((TileEldritchLock)te).count < 0) {
/* 276 */         ((TileEldritchLock)te).count = 0;
/* 277 */         world.markBlockForUpdate(x, y, z);
/* 278 */         te.markDirty();
/* 279 */         (player.getHeldItem()).stackSize--;
/* 280 */         world.playSoundEffect(x, y, z, "thaumcraft:runicShieldCharge", 1.0F, 1.0F);
/*     */       } 
/*     */     } 
/*     */     
/* 284 */     return super.onBlockActivated(world, x, y, z, player, side, par7, par8, par9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World w, int i, int j, int k, Random r) {
/* 292 */     int md = w.getBlockMetadata(i, j, k);
/* 293 */     if (md == 8) {
/* 294 */       TileEntity te = w.getTileEntity(i, j, k);
/* 295 */       if (te == null || !(te instanceof TileEldritchLock) || ((TileEldritchLock)te).count < 0)
/* 296 */         return;  FXSpark ef = new FXSpark(w, (i + w.rand.nextFloat()), (j + w.rand.nextFloat()), (k + w.rand.nextFloat()), 0.5F);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 301 */       ef.setRBGColorF(0.65F + w.rand.nextFloat() * 0.1F, 1.0F, 1.0F);
/* 302 */       ef.setAlphaF(0.8F);
/* 303 */       ParticleEngine.instance.addEffect(w, (EntityFX)ef);
/*     */     }
/* 305 */     else if (md == 10) {
/* 306 */       int x = i + r.nextInt(2) - r.nextInt(2);
/* 307 */       int y = j + r.nextInt(2) - r.nextInt(2);
/* 308 */       int z = k + r.nextInt(2) - r.nextInt(2);
/* 309 */       if (w.isAirBlock(x, y, z)) {
/* 310 */         Thaumcraft.proxy.blockRunes(w, (x + r.nextFloat()), (y + r.nextFloat()), (z + r.nextFloat()), 0.5F + r.nextFloat() * 0.5F, r.nextFloat() * 0.3F, 0.9F + r.nextFloat() * 0.1F, 16 + r.nextInt(4), 0.0F);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity createNewTileEntity(World p_149915_1_, int p_149915_2_) {
/* 319 */     return null;
/*     */   } }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockEldritch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */