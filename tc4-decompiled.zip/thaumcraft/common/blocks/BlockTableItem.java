/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class BlockTableItem
/*    */   extends ItemBlock
/*    */ {
/*    */   public BlockTableItem(Block par1) {
/* 11 */     super(par1);
/* 12 */     setMaxDamage(0);
/* 13 */     setHasSubtypes(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int par1) {
/* 20 */     return par1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/* 26 */     if (par1ItemStack.getItemDamage() >= 2 && par1ItemStack.getItemDamage() <= 9)
/* 27 */       return getUnlocalizedName() + ".research"; 
/* 28 */     return getUnlocalizedName() + "." + par1ItemStack.getItemDamage();
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockTableItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */