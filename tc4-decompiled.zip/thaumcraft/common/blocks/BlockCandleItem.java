/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import thaumcraft.common.Thaumcraft;
/*    */ 
/*    */ 
/*    */ public class BlockCandleItem
/*    */   extends ItemBlock
/*    */ {
/*    */   public BlockCandleItem(Block par1) {
/* 13 */     super(par1);
/* 14 */     setMaxDamage(0);
/* 15 */     setHasSubtypes(true);
/* 16 */     setCreativeTab(Thaumcraft.tabTC);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMetadata(int par1) {
/* 22 */     return par1;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getUnlocalizedName(ItemStack par1ItemStack) {
/* 27 */     return getUnlocalizedName() + "." + par1ItemStack.getItemDamage();
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockCandleItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */