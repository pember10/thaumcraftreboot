/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.particle.EntityFX;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fluids.BlockFluidFinite;
/*     */ import thaumcraft.client.fx.ParticleEngine;
/*     */ import thaumcraft.client.fx.particles.FXBubble;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ import thaumcraft.common.entities.monster.EntityThaumicSlime;
/*     */ import thaumcraft.common.lib.CustomSoundType;
/*     */ import thaumcraft.common.lib.utils.Utils;
/*     */ import thaumcraft.common.lib.world.ThaumcraftWorldGenerator;
/*     */ 
/*     */ public class BlockFluxGoo extends BlockFluidFinite {
/*     */   public IIcon iconStill;
/*     */   
/*     */   public BlockFluxGoo() {
/*  31 */     super(ConfigBlocks.FLUXGOO, Config.fluxGoomaterial);
/*  32 */     setStepSound((Block.SoundType)new CustomSoundType("gore", 1.0F, 1.0F));
/*  33 */     setCreativeTab(Thaumcraft.tabTC);
/*     */   }
/*     */   public IIcon iconFlow;
/*     */   static {
/*  37 */     defaultDisplacements.put(ConfigBlocks.blockTaintFibres, Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*  46 */     this.iconStill = ir.registerIcon("thaumcraft:fluxgoo");
/*  47 */     this.iconFlow = ir.registerIcon("thaumcraft:fluxgoo");
/*  48 */     ConfigBlocks.FLUXGOO.setIcons(this.iconStill, this.iconFlow);
/*     */   }
/*     */ 
/*     */   
/*     */   public IIcon getIcon(int par1, int par2) {
/*  53 */     return this.iconStill;
/*     */   }
/*     */   
/*     */   public int getQuanta() {
/*  57 */     return this.quantaPerBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
/*  63 */     int md = world.getBlockMetadata(x, y, z);
/*  64 */     if (entity instanceof EntityThaumicSlime) {
/*  65 */       EntityThaumicSlime slime = (EntityThaumicSlime)entity;
/*  66 */       if (slime.getSlimeSize() < md && world.rand.nextBoolean()) {
/*  67 */         slime.setSlimeSize(slime.getSlimeSize() + 1);
/*  68 */         if (md > 1) {
/*  69 */           world.setBlockMetadataWithNotify(x, y, z, md - 1, 3);
/*     */         } else {
/*  71 */           world.setBlockToAir(x, y, z);
/*     */         } 
/*     */       } 
/*     */     } else {
/*  75 */       entity.motionX *= (1.0F - getQuantaPercentage((IBlockAccess)world, x, y, z));
/*  76 */       entity.motionZ *= (1.0F - getQuantaPercentage((IBlockAccess)world, x, y, z));
/*     */       
/*  78 */       if (entity instanceof EntityLivingBase) {
/*  79 */         PotionEffect pe = new PotionEffect(Config.potionVisExhaustID, 600, md / 3, true);
/*  80 */         pe.getCurativeItems().clear();
/*  81 */         ((EntityLivingBase)entity).addPotionEffect(pe);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World world, int x, int y, int z, Random rand) {
/*  90 */     int meta = world.getBlockMetadata(x, y, z);
/*  91 */     if (rand.nextInt(50 - Thaumcraft.proxy.particleCount(10)) <= meta) {
/*     */       
/*  93 */       FXBubble fb = new FXBubble(world, (x + rand.nextFloat()), (y + 0.125F * meta), (z + rand.nextFloat()), 0.0D, 0.0D, 0.0D, 0);
/*     */       
/*  95 */       fb.setAlphaF(0.25F);
/*  96 */       ParticleEngine.instance.addEffect(world, (EntityFX)fb);
/*     */     } 
/*     */     
/*  99 */     super.randomDisplayTick(world, x, y, z, rand);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateTick(World world, int x, int y, int z, Random rand) {
/* 104 */     super.updateTick(world, x, y, z, rand);
/*     */     
/* 106 */     int meta = world.getBlockMetadata(x, y, z);
/* 107 */     if (meta >= 2 && meta < 6 && world.isAirBlock(x, y + 1, z) && rand.nextInt(25) == 0) {
/*     */       
/* 109 */       world.setBlockToAir(x, y, z);
/* 110 */       EntityThaumicSlime slime = new EntityThaumicSlime(world);
/* 111 */       slime.setLocationAndAngles((x + 0.5F), y, (z + 0.5F), 0.0F, 0.0F);
/* 112 */       slime.setSlimeSize(1);
/* 113 */       world.spawnEntityInWorld((Entity)slime);
/* 114 */       world.playSoundAtEntity((Entity)slime, "thaumcraft:gore", 1.0F, 1.0F);
/* 115 */     } else if (meta >= 6 && world.isAirBlock(x, y + 1, z)) {
/* 116 */       if (rand.nextInt(25) == 0) {
/* 117 */         world.setBlockToAir(x, y, z);
/* 118 */         EntityThaumicSlime slime = new EntityThaumicSlime(world);
/* 119 */         slime.setLocationAndAngles((x + 0.5F), y, (z + 0.5F), 0.0F, 0.0F);
/* 120 */         slime.setSlimeSize(2);
/* 121 */         world.spawnEntityInWorld((Entity)slime);
/* 122 */         world.playSoundAtEntity((Entity)slime, "thaumcraft:gore", 1.0F, 1.0F);
/* 123 */       } else if (Config.taintFromFlux && rand.nextInt(50) == 0) {
/* 124 */         Utils.setBiomeAt(world, x, z, ThaumcraftWorldGenerator.biomeTaint);
/*     */         
/* 126 */         world.setBlock(x, y, z, ConfigBlocks.blockTaintFibres, 0, 3);
/* 127 */         world.addBlockEvent(x, y, z, ConfigBlocks.blockTaintFibres, 1, 0);
/*     */       }
/*     */     
/* 130 */     } else if (rand.nextInt(30) == 0) {
/* 131 */       if (meta == 0) {
/* 132 */         world.setBlockToAir(x, y, z);
/*     */       } else {
/* 134 */         world.setBlockMetadataWithNotify(x, y, z, meta - 1, 3);
/* 135 */         if (rand.nextBoolean() && world.isAirBlock(x, y + 1, z)) {
/* 136 */           world.setBlock(x, y + 1, z, ConfigBlocks.blockFluxGas, 0, 3);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isReplaceable(IBlockAccess world, int x, int y, int z) {
/* 143 */     int meta = world.getBlockMetadata(x, y, z);
/* 144 */     return (meta < 2);
/*     */   }
/*     */   
/*     */   public boolean isInsideOfMaterial(World worldObj, Entity entity) {
/* 148 */     double d0 = entity.posY + entity.getEyeHeight();
/* 149 */     int i = MathHelper.floor_double(entity.posX);
/* 150 */     int j = MathHelper.floor_float(MathHelper.floor_double(d0));
/* 151 */     int k = MathHelper.floor_double(entity.posZ);
/* 152 */     Block l = worldObj.getBlock(i, j, k);
/*     */     
/* 154 */     if (l.getMaterial() == this.blockMaterial) {
/* 155 */       float f = getQuantaPercentage((IBlockAccess)worldObj, i, j, k) - 0.11111111F;
/* 156 */       float f1 = (j + 1) - f;
/* 157 */       return (d0 < f1);
/*     */     } 
/* 159 */     return false;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockFluxGoo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */