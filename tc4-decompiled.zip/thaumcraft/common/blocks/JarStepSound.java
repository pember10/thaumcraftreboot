/*    */ package thaumcraft.common.blocks;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ 
/*    */ public class JarStepSound
/*    */   extends Block.SoundType
/*    */ {
/*    */   public JarStepSound(String par1Str, float par2, float par3) {
/*  9 */     super(par1Str, par2, par3);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getBreakSound() {
/* 18 */     return "thaumcraft:" + this.soundName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getStepResourcePath() {
/* 28 */     return "thaumcraft:" + this.soundName;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\JarStepSound.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */