/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fluids.BlockFluidFinite;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.Config;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ 
/*     */ public class BlockFluxGas extends BlockFluidFinite {
/*     */   public IIcon iconStill;
/*     */   public IIcon iconFlow;
/*     */   
/*     */   public BlockFluxGas() {
/*  26 */     super(ConfigBlocks.FLUXGAS, Config.fluxGoomaterial);
/*  27 */     setCreativeTab(Thaumcraft.tabTC);
/*  28 */     this.densityDir = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*  37 */     this.iconStill = ir.registerIcon("thaumcraft:fluxgas");
/*  38 */     this.iconFlow = ir.registerIcon("thaumcraft:fluxgas");
/*  39 */     ConfigBlocks.FLUXGAS.setIcons(this.iconStill, this.iconFlow);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDensityDir() {
/*  44 */     return this.densityDir;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRenderType() {
/*  49 */     return ConfigBlocks.blockFluxGasRI;
/*     */   }
/*     */   
/*     */   public void setDensityDir(int densityDir) {
/*  53 */     this.densityDir = densityDir;
/*     */   }
/*     */ 
/*     */   
/*     */   public IIcon getIcon(int par1, int par2) {
/*  58 */     return this.iconStill;
/*     */   }
/*     */   
/*     */   public int getQuanta() {
/*  62 */     return this.quantaPerBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
/*  68 */     int md = world.getBlockMetadata(x, y, z);
/*  69 */     if (world.rand.nextInt(10) == 0 && entity instanceof EntityLivingBase && !(entity instanceof thaumcraft.api.entities.ITaintedMob) && !((EntityLivingBase)entity).isEntityUndead() && !((EntityLivingBase)entity).isPotionActive(Config.potionVisExhaustID) && !((EntityLivingBase)entity).isPotionActive(Potion.confusion.id)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  74 */       if (world.rand.nextBoolean()) {
/*  75 */         PotionEffect pe = new PotionEffect(Config.potionVisExhaustID, 1200, md / 3, true);
/*  76 */         pe.getCurativeItems().clear();
/*  77 */         ((EntityLivingBase)entity).addPotionEffect(pe);
/*     */       } else {
/*  79 */         ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(Potion.confusion.id, 80 + md * 20, 0, false));
/*     */       } 
/*     */       
/*  82 */       if (md > 0) {
/*  83 */         world.setBlockMetadataWithNotify(x, y, z, md - 1, 3);
/*     */       } else {
/*  85 */         world.setBlockToAir(x, y, z);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTick(World world, int x, int y, int z, Random rand) {
/*  93 */     super.updateTick(world, x, y, z, rand);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReplaceable(IBlockAccess world, int x, int y, int z) {
/* 112 */     int meta = world.getBlockMetadata(x, y, z);
/* 113 */     return (meta < 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInsideOfMaterial(World worldObj, Entity entity) {
/* 119 */     double d0 = entity.posY + entity.getEyeHeight();
/* 120 */     int i = MathHelper.floor_double(entity.posX);
/* 121 */     int j = MathHelper.floor_float(MathHelper.floor_double(d0));
/* 122 */     int k = MathHelper.floor_double(entity.posZ);
/* 123 */     Block l = worldObj.getBlock(i, j, k);
/*     */     
/* 125 */     if (l.getMaterial() == this.blockMaterial) {
/*     */       
/* 127 */       float f = getQuantaPercentage((IBlockAccess)worldObj, i, j, k) - 0.11111111F;
/* 128 */       float f1 = (j + 1) - f;
/* 129 */       return (d0 < f1);
/*     */     } 
/*     */ 
/*     */     
/* 133 */     return false;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockFluxGas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */