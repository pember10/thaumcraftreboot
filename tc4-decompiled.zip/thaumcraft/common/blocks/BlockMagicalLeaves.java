/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.world.ColorizerFoliage;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.config.ConfigBlocks;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockMagicalLeaves
/*     */   extends Block
/*     */   implements IShearable
/*     */ {
/*  34 */   public static final String[] leafType = new String[] { "greatwood", "silverwood" };
/*     */   int[] adjacentTreeBlocks;
/*     */   public IIcon[] icon;
/*     */   
/*     */   public BlockMagicalLeaves() {
/*  39 */     super(Material.leaves);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     this.icon = new IIcon[4]; setTickRandomly(true);
/*     */     setCreativeTab(Thaumcraft.tabTC);
/*     */     setHardness(0.2F);
/*     */     setLightOpacity(1);
/*  52 */     setStepSound(soundTypeGrass); } @SideOnly(Side.CLIENT) public void registerBlockIcons(IIconRegister ir) { this.icon[0] = ir.registerIcon("thaumcraft:greatwoodleaves");
/*  53 */     this.icon[1] = ir.registerIcon("thaumcraft:greatwoodleaveslow");
/*  54 */     this.icon[2] = ir.registerIcon("thaumcraft:silverwoodleaves");
/*  55 */     this.icon[3] = ir.registerIcon("thaumcraft:silverwoodleaveslow"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IIcon getIcon(int par1, int par2) {
/*  64 */     int idx = !Blocks.leaves.isOpaqueCube() ? 0 : 1;
/*  65 */     return ((par2 & 0x1) == 1) ? this.icon[idx + 2] : this.icon[idx];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/*  76 */     par3List.add(new ItemStack(par1, 1, 0));
/*  77 */     par3List.add(new ItemStack(par1, 1, 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean shouldSideBeRendered(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5) {
/*  91 */     Block var6 = par1IBlockAccess.getBlock(par2, par3, par4);
/*  92 */     return (Blocks.leaves.isOpaqueCube() && var6 == this) ? false : super.shouldSideBeRendered(par1IBlockAccess, par2, par3, par4, par5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getBlockColor() {
/* 100 */     double var1 = 0.5D;
/* 101 */     double var3 = 1.0D;
/* 102 */     return ColorizerFoliage.getFoliageColor(var1, var3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getRenderColor(int par1) {
/* 112 */     return ((par1 & 0x1) == 0) ? ColorizerFoliage.getFoliageColorBasic() : 8952234;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int colorMultiplier(IBlockAccess par1IBlockAccess, int par2, int par3, int par4) {
/* 124 */     int var5 = par1IBlockAccess.getBlockMetadata(par2, par3, par4);
/*     */     
/* 126 */     if ((var5 & 0x1) == 1)
/*     */     {
/* 128 */       return 8952234;
/*     */     }
/*     */ 
/*     */     
/* 132 */     int var6 = 0;
/* 133 */     int var7 = 0;
/* 134 */     int var8 = 0;
/*     */     
/* 136 */     for (int var9 = -1; var9 <= 1; var9++) {
/*     */       
/* 138 */       for (int var10 = -1; var10 <= 1; var10++) {
/*     */         
/* 140 */         int var11 = par1IBlockAccess.getBiomeGenForCoords(par2 + var10, par4 + var9).getBiomeFoliageColor(par2, par3, par4);
/* 141 */         var6 += (var11 & 0xFF0000) >> 16;
/* 142 */         var7 += (var11 & 0xFF00) >> 8;
/* 143 */         var8 += var11 & 0xFF;
/*     */       } 
/*     */     } 
/*     */     
/* 147 */     return (var6 / 9 & 0xFF) << 16 | (var7 / 9 & 0xFF) << 8 | var8 / 9 & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightValue(IBlockAccess world, int x, int y, int z) {
/* 153 */     if ((world.getBlockMetadata(x, y, z) & 0x1) == 1) return 7;
/*     */     
/* 155 */     return super.getLightValue(world, x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void breakBlock(World par1World, int par2, int par3, int par4, Block par5, int par6) {
/* 164 */     byte var7 = 1;
/* 165 */     int var8 = var7 + 1;
/*     */     
/* 167 */     if (par1World.checkChunksExist(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */     {
/* 169 */       for (int var9 = -var7; var9 <= var7; var9++) {
/*     */         
/* 171 */         for (int var10 = -var7; var10 <= var7; var10++) {
/*     */           
/* 173 */           for (int var11 = -var7; var11 <= var7; var11++) {
/*     */             
/* 175 */             Block var12 = par1World.getBlock(par2 + var9, par3 + var10, par4 + var11);
/*     */             
/* 177 */             if (var12 != Blocks.air)
/*     */             {
/* 179 */               var12.beginLeavesDecay(par1World, par2 + var9, par3 + var10, par4 + var11);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random) {
/* 193 */     if (!par1World.isRemote) {
/*     */       
/* 195 */       int var6 = par1World.getBlockMetadata(par2, par3, par4);
/*     */       
/* 197 */       if ((var6 & 0x8) != 0 && (var6 & 0x4) == 0) {
/*     */         
/* 199 */         byte var7 = 4;
/* 200 */         int var8 = var7 + 1;
/* 201 */         byte var9 = 32;
/* 202 */         int var10 = var9 * var9;
/* 203 */         int var11 = var9 / 2;
/*     */         
/* 205 */         if (this.adjacentTreeBlocks == null)
/*     */         {
/* 207 */           this.adjacentTreeBlocks = new int[var9 * var9 * var9];
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 212 */         if (par1World.checkChunksExist(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8)) {
/*     */           int i;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 218 */           for (i = -var7; i <= var7; i++) {
/*     */             
/* 220 */             for (int var13 = -var7; var13 <= var7; var13++) {
/*     */               
/* 222 */               for (int var14 = -var7; var14 <= var7; var14++) {
/*     */                 
/* 224 */                 Block block = par1World.getBlock(par2 + i, par3 + var13, par4 + var14);
/*     */                 
/* 226 */                 if (block != null && block.canSustainLeaves((IBlockAccess)par1World, par2 + i, par3 + var13, par4 + var14)) {
/*     */                   
/* 228 */                   this.adjacentTreeBlocks[(i + var11) * var10 + (var13 + var11) * var9 + var14 + var11] = 0;
/*     */                 }
/* 230 */                 else if (block != null && block.isLeaves((IBlockAccess)par1World, par2 + i, par3 + var13, par4 + var14)) {
/*     */                   
/* 232 */                   this.adjacentTreeBlocks[(i + var11) * var10 + (var13 + var11) * var9 + var14 + var11] = -2;
/*     */                 }
/*     */                 else {
/*     */                   
/* 236 */                   this.adjacentTreeBlocks[(i + var11) * var10 + (var13 + var11) * var9 + var14 + var11] = -1;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/* 241 */           int var15 = 0;
/* 242 */           for (i = 1; i <= 4; i++) {
/*     */             
/* 244 */             for (int var13 = -var7; var13 <= var7; var13++) {
/*     */               
/* 246 */               for (int var14 = -var7; var14 <= var7; var14++) {
/*     */                 
/* 248 */                 for (var15 = -var7; var15 <= var7; var15++) {
/*     */                   
/* 250 */                   if (this.adjacentTreeBlocks[(var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11] == i - 1) {
/*     */                     
/* 252 */                     if (this.adjacentTreeBlocks[(var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11] == -2)
/*     */                     {
/* 254 */                       this.adjacentTreeBlocks[(var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11] = i;
/*     */                     }
/*     */                     
/* 257 */                     if (this.adjacentTreeBlocks[(var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11] == -2)
/*     */                     {
/* 259 */                       this.adjacentTreeBlocks[(var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11] = i;
/*     */                     }
/*     */                     
/* 262 */                     if (this.adjacentTreeBlocks[(var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11] == -2)
/*     */                     {
/* 264 */                       this.adjacentTreeBlocks[(var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11] = i;
/*     */                     }
/*     */                     
/* 267 */                     if (this.adjacentTreeBlocks[(var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11] == -2)
/*     */                     {
/* 269 */                       this.adjacentTreeBlocks[(var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11] = i;
/*     */                     }
/*     */                     
/* 272 */                     if (this.adjacentTreeBlocks[(var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 - 1] == -2)
/*     */                     {
/* 274 */                       this.adjacentTreeBlocks[(var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 - 1] = i;
/*     */                     }
/*     */                     
/* 277 */                     if (this.adjacentTreeBlocks[(var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1] == -2)
/*     */                     {
/* 279 */                       this.adjacentTreeBlocks[(var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1] = i;
/*     */                     }
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 288 */         int var12 = this.adjacentTreeBlocks[var11 * var10 + var11 * var9 + var11];
/*     */         
/* 290 */         if (var12 >= 0) {
/*     */           
/* 292 */           par1World.setBlock(par2, par3, par4, this, var6 & 0xFFFFFFF7, 3);
/*     */         }
/*     */         else {
/*     */           
/* 296 */           removeLeaves(par1World, par2, par3, par4);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World par1World, int par2, int par3, int par4, Random par5Random) {
/* 309 */     if (par1World.canLightningStrikeAt(par2, par3 + 1, par4)) if (!World.doesBlockHaveSolidTopSurface((IBlockAccess)par1World, par2, par3 - 1, par4) && par5Random.nextInt(15) == 1) {
/*     */         
/* 311 */         double var6 = (par2 + par5Random.nextFloat());
/* 312 */         double var8 = par3 - 0.05D;
/* 313 */         double var10 = (par4 + par5Random.nextFloat());
/* 314 */         par1World.spawnParticle("dripWater", var6, var8, var10, 0.0D, 0.0D, 0.0D);
/*     */       } 
/*     */     
/* 317 */     int md = par1World.getBlockMetadata(par2, par3, par4);
/* 318 */     if ((md & 0x1) == 1 && par5Random.nextInt(500) == 0) {
/* 319 */       Thaumcraft.proxy.sparkle(par2 + 0.5F + par1World.rand.nextFloat() - par1World.rand.nextFloat(), par3 + 0.5F + par1World.rand.nextFloat() - par1World.rand.nextFloat(), par4 + 0.5F + par1World.rand.nextFloat() - par1World.rand.nextFloat(), 2.0F, 7, 0.0F);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeLeaves(World par1World, int par2, int par3, int par4) {
/* 330 */     dropBlockAsItem(par1World, par2, par3, par4, par1World.getBlockMetadata(par2, par3, par4), 0);
/* 331 */     par1World.setBlockToAir(par2, par3, par4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dropBlockAsItemWithChance(World par1World, int par2, int par3, int par4, int meta, float par6, int par7) {
/* 340 */     if (!par1World.isRemote && (meta & 0x8) != 0 && (meta & 0x4) == 0)
/*     */     {
/* 342 */       if ((meta & 0x1) == 0 && par1World.rand.nextInt(200) == 0) {
/*     */         
/* 344 */         dropBlockAsItem(par1World, par2, par3, par4, new ItemStack(ConfigBlocks.blockCustomPlant, 1, 0));
/*     */       
/*     */       }
/* 347 */       else if ((meta & 0x1) == 1 && par1World.rand.nextInt(250) == 0) {
/*     */         
/* 349 */         dropBlockAsItem(par1World, par2, par3, par4, new ItemStack(ConfigBlocks.blockCustomPlant, 1, 1));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void harvestBlock(World par1World, EntityPlayer par2EntityPlayer, int par3, int par4, int par5, int par6) {
/* 363 */     super.harvestBlock(par1World, par2EntityPlayer, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int damageDropped(int par1) {
/* 372 */     return par1 & 0x1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int quantityDropped(Random par1Random) {
/* 378 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Item getItemDropped(int par1, Random par2Random, int par3) {
/* 384 */     return Item.getItemById(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpaqueCube() {
/* 394 */     return Blocks.leaves.isOpaqueCube();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isShearable(ItemStack item, IBlockAccess world, int x, int y, int z) {
/* 401 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<ItemStack> onSheared(ItemStack item, IBlockAccess world, int x, int y, int z, int fortune) {
/* 407 */     ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
/* 408 */     ret.add(new ItemStack(this, 1, world.getBlockMetadata(x, y, z) & 0x3));
/*     */     
/* 410 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginLeavesDecay(World world, int x, int y, int z) {
/* 416 */     world.setBlockMetadataWithNotify(x, y, z, world.getBlockMetadata(x, y, z) | 0x8, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLeaves(IBlockAccess world, int x, int y, int z) {
/* 422 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getPickBlock(MovingObjectPosition target, World world, int x, int y, int z) {
/* 428 */     int md = world.getBlockMetadata(x, y, z);
/* 429 */     return new ItemStack(this, 1, md & 0x1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFlammability(IBlockAccess world, int x, int y, int z, ForgeDirection face) {
/* 434 */     return 60;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFireSpreadSpeed(IBlockAccess world, int x, int y, int z, ForgeDirection face) {
/* 439 */     return 30;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockMagicalLeaves.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */