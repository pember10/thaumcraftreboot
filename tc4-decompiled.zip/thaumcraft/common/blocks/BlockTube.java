/*     */ package thaumcraft.common.blocks;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.DrawBlockHighlightEvent;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ import thaumcraft.client.renderers.block.BlockRenderer;
/*     */ 
/*     */ public class BlockTube extends BlockContainer {
/*     */   public IIcon[] icon;
/*     */   public IIcon iconValve;
/*     */   private RayTracer rayTracer;
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister ir) {
/*     */     this.icon[0] = ir.registerIcon("thaumcraft:pipe_1");
/*     */     this.icon[1] = ir.registerIcon("thaumcraft:pipe_2");
/*     */     this.icon[2] = ir.registerIcon("thaumcraft:pipe_3");
/*     */     this.icon[3] = ir.registerIcon("thaumcraft:pipe_filter");
/*     */     this.icon[4] = ir.registerIcon("thaumcraft:pipe_filter_core");
/*     */     this.icon[5] = ir.registerIcon("thaumcraft:pipe_buffer");
/*     */     this.icon[6] = ir.registerIcon("thaumcraft:pipe_restrict");
/*     */     this.icon[7] = ir.registerIcon("thaumcraft:pipe_oneway");
/*     */     this.iconValve = ir.registerIcon("thaumcraft:pipe_valve");
/*     */   }
/*     */   
/*     */   public IIcon getIcon(int i, int md) {
/*     */     return (md == 4) ? this.icon[5] : ((md == 5) ? this.icon[6] : this.icon[0]);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
/*     */     par3List.add(new ItemStack(par1, 1, 0));
/*     */     par3List.add(new ItemStack(par1, 1, 1));
/*     */     par3List.add(new ItemStack(par1, 1, 2));
/*     */     par3List.add(new ItemStack(par1, 1, 3));
/*     */     par3List.add(new ItemStack(par1, 1, 4));
/*     */     par3List.add(new ItemStack(par1, 1, 5));
/*     */     par3List.add(new ItemStack(par1, 1, 6));
/*     */     par3List.add(new ItemStack(par1, 1, 7));
/*     */   }
/*     */   
/*     */   public int getRenderType() {
/*     */     return ConfigBlocks.blockTubeRI;
/*     */   }
/*     */   
/*     */   public boolean isOpaqueCube() {
/*     */     return false;
/*     */   }
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/*     */     return false;
/*     */   }
/*     */   
/*  61 */   public BlockTube() { super(Material.iron);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     this.icon = new IIcon[8];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     this.rayTracer = new RayTracer(); setHardness(0.5F); setResistance(5.0F); setStepSound(Block.soundTypeMetal); setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); setCreativeTab(Thaumcraft.tabTC); }
/*     */   @SideOnly(Side.CLIENT) public AxisAlignedBB getSelectedBoundingBoxFromPool(World world, int x, int y, int z) { int metadata = world.getBlockMetadata(x, y, z); boolean noDoodads = ((Minecraft.getMinecraft()).thePlayer == null || (Minecraft.getMinecraft()).thePlayer.getCurrentEquippedItem() == null || (!((Minecraft.getMinecraft()).thePlayer.getCurrentEquippedItem().getItem() instanceof thaumcraft.common.items.wands.ItemWandCasting) && !((Minecraft.getMinecraft()).thePlayer.getCurrentEquippedItem().getItem() instanceof thaumcraft.common.items.relics.ItemResonator))); if ((metadata == 0 || metadata == 1 || metadata == 3 || metadata == 5 || metadata == 6) && noDoodads) { float minx = BlockRenderer.W6, maxx = BlockRenderer.W10; float miny = BlockRenderer.W5, maxy = BlockRenderer.W11; float minz = BlockRenderer.W5, maxz = BlockRenderer.W11; ForgeDirection fd = null; for (int side = 0; side < 6; side++) { fd = ForgeDirection.getOrientation(side); TileEntity te = ThaumcraftApiHelper.getConnectableTile(world, x, y, z, fd); if (te != null)
/*     */           switch (side) { case 0: miny = 0.0F; break;case 1: maxy = 1.0F; break;case 2: minz = 0.0F; break;case 3: maxz = 1.0F; break;case 4: minx = 0.0F; break;
/*     */             case 5: maxx = 1.0F; break; }   }  setBlockBounds(minx, miny, minz, maxx, maxy, maxz); }  if (metadata == 4 && noDoodads)
/*     */       setBlockBounds(0.25F, 0.25F, 0.25F, 0.75F, 0.75F, 0.75F);  if (metadata == 7)
/*     */       setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);  return super.getSelectedBoundingBoxFromPool(world, x, y, z); }
/* 330 */   public void setBlockBoundsBasedOnState(IBlockAccess world, int i, int j, int k) { int metadata = world.getBlockMetadata(i, j, k); if (metadata == 2) { setBlockBounds(0.25F, 0.0F, 0.25F, 0.75F, 1.0F, 0.75F); } else if (metadata == 7) { setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); }  } @SideOnly(Side.CLIENT) @SubscribeEvent public void onBlockHighlight(DrawBlockHighlightEvent event) { if (event.target.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK && event.player.worldObj.getBlock(event.target.blockX, event.target.blockY, event.target.blockZ) == this && event.player.worldObj.getBlockMetadata(event.target.blockX, event.target.blockY, event.target.blockZ) != 7 && event.player.getCurrentEquippedItem() != null && (event.player.getCurrentEquippedItem().getItem() instanceof thaumcraft.common.items.wands.ItemWandCasting || event.player.getCurrentEquippedItem().getItem() instanceof thaumcraft.common.items.relics.ItemResonator))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 336 */       RayTracer.retraceBlock(event.player.worldObj, event.player, event.target.blockX, event.target.blockY, event.target.blockZ); }  } public void addCollisionBoxesToList(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, List arraylist, Entity par7Entity) { int metadata = world.getBlockMetadata(i, j, k); if (metadata == 0 || metadata == 1 || metadata == 3 || metadata == 4 || metadata == 5 || metadata == 6) { float minx = BlockRenderer.W6, maxx = BlockRenderer.W10; float miny = BlockRenderer.W6, maxy = BlockRenderer.W10; float minz = BlockRenderer.W6, maxz = BlockRenderer.W10; ForgeDirection fd = null; for (int side = 0; side < 6; side++) { fd = ForgeDirection.getOrientation(side); TileEntity te = ThaumcraftApiHelper.getConnectableTile(world, i, j, k, fd); if (te != null) switch (side) { case 0: miny = 0.0F; break;case 1: maxy = 1.0F; break;case 2: minz = 0.0F; break;case 3: maxz = 1.0F; break;case 4: minx = 0.0F; break;case 5: maxx = 1.0F; break; }   }  setBlockBounds(minx, miny, minz, maxx, maxy, maxz); super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity); } else { setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, arraylist, par7Entity); }  }
/*     */   public int damageDropped(int metadata) { return metadata; }
/*     */   public TileEntity createTileEntity(World world, int metadata) { if (metadata == 0) return (TileEntity)new TileTube();  if (metadata == 1) return (TileEntity)new TileTubeValve();  if (metadata == 2) return (TileEntity)new TileCentrifuge();  if (metadata == 3) return (TileEntity)new TileTubeFilter();  if (metadata == 4)
/*     */       return (TileEntity)new TileTubeBuffer();  if (metadata == 5)
/*     */       return (TileEntity)new TileTubeRestrict();  if (metadata == 6)
/*     */       return (TileEntity)new TileTubeOneway();  if (metadata == 7)
/*     */       return (TileEntity)new TileEssentiaCrystalizer();  return super.createTileEntity(world, metadata); }
/*     */   public TileEntity createNewTileEntity(World var1, int md) { return null; }
/* 344 */   public MovingObjectPosition collisionRayTrace(World world, int x, int y, int z, Vec3 start, Vec3 end) { TileEntity tile = world.getTileEntity(x, y, z);
/* 345 */     if (tile == null || (!(tile instanceof TileTube) && !(tile instanceof TileTubeBuffer))) {
/* 346 */       return super.collisionRayTrace(world, x, y, z, start, end);
/*     */     }
/* 348 */     List<IndexedCuboid6> cuboids = new LinkedList<IndexedCuboid6>();
/* 349 */     if (tile instanceof TileTube) {
/* 350 */       ((TileTube)tile).addTraceableCuboids(cuboids);
/* 351 */     } else if (tile instanceof TileTubeBuffer) {
/* 352 */       ((TileTubeBuffer)tile).addTraceableCuboids(cuboids);
/*     */     } 
/*     */     
/* 355 */     return this.rayTracer.rayTraceCuboids(new Vector3(start), new Vector3(end), cuboids, new BlockCoord(x, y, z), (Block)this); }
/*     */ 
/*     */   
/*     */   public boolean hasComparatorInputOverride() {
/*     */     return true;
/*     */   }
/*     */   
/*     */   public int getComparatorInputOverride(World world, int x, int y, int z, int rs) {
/*     */     TileEntity te = world.getTileEntity(x, y, z);
/*     */     if (te != null && te instanceof TileTubeBuffer) {
/*     */       ((TileTubeBuffer)te).getClass();
/*     */       float r = ((TileTubeBuffer)te).aspects.visSize() / 8.0F;
/*     */       return MathHelper.floor_float(r * 14.0F) + ((((TileTubeBuffer)te).aspects.visSize() > 0) ? 1 : 0);
/*     */     } 
/*     */     return 0;
/*     */   }
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block par5, int par6) {
/*     */     TileEntity te = world.getTileEntity(x, y, z);
/*     */     if (te != null && te instanceof TileTubeFilter && ((TileTubeFilter)te).aspectFilter != null && !world.isRemote)
/*     */       world.spawnEntityInWorld((Entity)new EntityItem(world, (x + 0.5F), (y + 0.5F), (z + 0.5F), new ItemStack(ConfigItems.itemResource, 1, 13))); 
/*     */     super.breakBlock(world, x, y, z, par5, par6);
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float par7, float par8, float par9) {
/*     */     int metadata = world.getBlockMetadata(x, y, z);
/*     */     if (metadata == 1) {
/*     */       if (player.getHeldItem() != null && (player.getHeldItem().getItem() instanceof thaumcraft.common.items.wands.ItemWandCasting || player.getHeldItem().getItem() instanceof thaumcraft.common.items.relics.ItemResonator || player.getHeldItem().getItem() == Item.getItemFromBlock((Block)this)))
/*     */         return false; 
/*     */       TileEntity te = world.getTileEntity(x, y, z);
/*     */       if (te instanceof TileTubeValve) {
/*     */         ((TileTubeValve)te).allowFlow = !((TileTubeValve)te).allowFlow;
/*     */         world.markBlockForUpdate(x, y, z);
/*     */         if (!world.isRemote)
/*     */           world.playSoundEffect(x + 0.5D, y + 0.5D, z + 0.5D, "thaumcraft:squeek", 0.7F, 0.9F + world.rand.nextFloat() * 0.2F); 
/*     */         return true;
/*     */       } 
/*     */     } 
/*     */     if (metadata == 3) {
/*     */       TileEntity te = world.getTileEntity(x, y, z);
/*     */       if (te != null && te instanceof TileTubeFilter && player.isSneaking() && ((TileTubeFilter)te).aspectFilter != null) {
/*     */         ((TileTubeFilter)te).aspectFilter = null;
/*     */         world.markBlockForUpdate(x, y, z);
/*     */         if (world.isRemote) {
/*     */           world.playSound((x + 0.5F), (y + 0.5F), (z + 0.5F), "thaumcraft:page", 1.0F, 1.0F, false);
/*     */         } else {
/*     */           ForgeDirection fd = ForgeDirection.getOrientation(side);
/*     */           world.spawnEntityInWorld((Entity)new EntityItem(world, (x + 0.5F + fd.offsetX / 3.0F), (y + 0.5F), (z + 0.5F + fd.offsetZ / 3.0F), new ItemStack(ConfigItems.itemResource, 1, 13)));
/*     */         } 
/*     */         return true;
/*     */       } 
/*     */       if (te != null && te instanceof TileTubeFilter && player.getHeldItem() != null && ((TileTubeFilter)te).aspectFilter == null && player.getHeldItem().getItem() == ConfigItems.itemResource && player.getHeldItem().getItemDamage() == 13) {
/*     */         if (((IEssentiaContainerItem)player.getHeldItem().getItem()).getAspects(player.getHeldItem()) != null) {
/*     */           ((TileTubeFilter)te).aspectFilter = ((IEssentiaContainerItem)player.getHeldItem().getItem()).getAspects(player.getHeldItem()).getAspects()[0];
/*     */           (player.getHeldItem()).stackSize--;
/*     */           world.markBlockForUpdate(x, y, z);
/*     */           if (world.isRemote)
/*     */             world.playSound((x + 0.5F), (y + 0.5F), (z + 0.5F), "thaumcraft:page", 1.0F, 1.0F, false); 
/*     */         } 
/*     */         return true;
/*     */       } 
/*     */     } 
/*     */     return super.onBlockActivated(world, x, y, z, player, side, par7, par8, par9);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\blocks\BlockTube.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */