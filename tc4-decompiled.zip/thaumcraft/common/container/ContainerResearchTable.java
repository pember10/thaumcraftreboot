/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import thaumcraft.api.IScribeTools;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.common.items.ItemResearchNotes;
/*     */ import thaumcraft.common.tiles.TileResearchTable;
/*     */ 
/*     */ public class ContainerResearchTable extends Container {
/*     */   public TileResearchTable tileEntity;
/*     */   String[] aspects;
/*     */   EntityPlayer player;
/*     */   
/*     */   public ContainerResearchTable(InventoryPlayer iinventory, TileResearchTable iinventory1) {
/*  20 */     this.player = iinventory.player;
/*  21 */     this.tileEntity = iinventory1;
/*  22 */     this.aspects = (String[])Aspect.aspects.keySet().toArray((Object[])new String[0]);
/*     */ 
/*     */     
/*  25 */     addSlotToContainer(new SlotLimitedByClass(IScribeTools.class, (IInventory)iinventory1, 0, 14, 10));
/*  26 */     addSlotToContainer(new SlotLimitedByClass(ItemResearchNotes.class, (IInventory)iinventory1, 1, 70, 10));
/*     */ 
/*     */     
/*  29 */     bindPlayerInventory(iinventory);
/*     */   }
/*     */   protected void bindPlayerInventory(InventoryPlayer inventoryPlayer) {
/*     */     int i;
/*  33 */     for (i = 0; i < 3; i++) {
/*  34 */       for (int j = 0; j < 9; j++) {
/*  35 */         addSlotToContainer(new Slot((IInventory)inventoryPlayer, j + i * 9 + 9, 48 + j * 18, 175 + i * 18));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  40 */     for (i = 0; i < 9; i++) {
/*  41 */       addSlotToContainer(new Slot((IInventory)inventoryPlayer, i, 48 + i * 18, 233));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean enchantItem(EntityPlayer par1EntityPlayer, int button) {
/*  48 */     if (button == 1) {
/*  49 */       return true;
/*     */     }
/*  51 */     if (button == 5) {
/*  52 */       this.tileEntity.duplicate(par1EntityPlayer);
/*  53 */       return true;
/*     */     } 
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int slot) {
/*  60 */     ItemStack stack = null;
/*  61 */     Slot slotObject = this.inventorySlots.get(slot);
/*     */ 
/*     */     
/*  64 */     if (slotObject != null && slotObject.getHasStack()) {
/*  65 */       ItemStack stackInSlot = slotObject.getStack();
/*  66 */       stack = stackInSlot.copy();
/*     */ 
/*     */       
/*  69 */       if (slot < 2) {
/*  70 */         if (!mergeItemStack(stackInSlot, 2, this.inventorySlots.size(), true))
/*     */         {
/*  72 */           return null;
/*     */         }
/*     */       }
/*  75 */       else if (!mergeItemStack(stackInSlot, 0, 2, false)) {
/*  76 */         return null;
/*     */       } 
/*     */       
/*  79 */       if (stackInSlot.stackSize == 0) {
/*  80 */         slotObject.putStack(null);
/*     */       } else {
/*  82 */         slotObject.onSlotChanged();
/*     */       } 
/*     */     } 
/*     */     
/*  86 */     return stack;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean mergeItemStack(ItemStack par1ItemStack, int par2, int par3, boolean par4) {
/*  92 */     boolean var5 = false;
/*  93 */     int var6 = par2;
/*     */     
/*  95 */     if (par4)
/*     */     {
/*  97 */       var6 = par3 - 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     if (par1ItemStack.isStackable())
/*     */     {
/* 105 */       while (par1ItemStack.stackSize > 0 && ((!par4 && var6 < par3) || (par4 && var6 >= par2))) {
/*     */         
/* 107 */         Slot var7 = this.inventorySlots.get(var6);
/* 108 */         ItemStack var8 = var7.getStack();
/*     */         
/* 110 */         if (var8 != null && var7.isItemValid(par1ItemStack) && var8.getItem() == par1ItemStack.getItem() && (!par1ItemStack.getHasSubtypes() || par1ItemStack.getItemDamage() == var8.getItemDamage()) && ItemStack.areItemStackTagsEqual(par1ItemStack, var8)) {
/*     */ 
/*     */ 
/*     */           
/* 114 */           int var9 = var8.stackSize + par1ItemStack.stackSize;
/*     */           
/* 116 */           if (var9 <= par1ItemStack.getMaxStackSize()) {
/*     */             
/* 118 */             par1ItemStack.stackSize = 0;
/* 119 */             var8.stackSize = var9;
/* 120 */             var7.onSlotChanged();
/* 121 */             var5 = true;
/*     */           }
/* 123 */           else if (var8.stackSize < par1ItemStack.getMaxStackSize()) {
/*     */             
/* 125 */             par1ItemStack.stackSize -= par1ItemStack.getMaxStackSize() - var8.stackSize;
/* 126 */             var8.stackSize = par1ItemStack.getMaxStackSize();
/* 127 */             var7.onSlotChanged();
/* 128 */             var5 = true;
/*     */           } 
/*     */         } 
/*     */         
/* 132 */         if (par4) {
/*     */           
/* 134 */           var6--;
/*     */           
/*     */           continue;
/*     */         } 
/* 138 */         var6++;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 143 */     if (par1ItemStack.stackSize > 0) {
/*     */       
/* 145 */       if (par4) {
/*     */         
/* 147 */         var6 = par3 - 1;
/*     */       }
/*     */       else {
/*     */         
/* 151 */         var6 = par2;
/*     */       } 
/*     */       
/* 154 */       while ((!par4 && var6 < par3) || (par4 && var6 >= par2)) {
/*     */         
/* 156 */         Slot var7 = this.inventorySlots.get(var6);
/* 157 */         ItemStack var8 = var7.getStack();
/*     */         
/* 159 */         if (var8 == null && var7.isItemValid(par1ItemStack)) {
/*     */           
/* 161 */           var7.putStack(par1ItemStack.copy());
/* 162 */           var7.onSlotChanged();
/* 163 */           par1ItemStack.stackSize = 0;
/* 164 */           var5 = true;
/*     */           
/*     */           break;
/*     */         } 
/* 168 */         if (par4) {
/*     */           
/* 170 */           var6--;
/*     */           
/*     */           continue;
/*     */         } 
/* 174 */         var6++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 179 */     return var5;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer player) {
/* 184 */     return this.tileEntity.isUseableByPlayer(player);
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerResearchTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */