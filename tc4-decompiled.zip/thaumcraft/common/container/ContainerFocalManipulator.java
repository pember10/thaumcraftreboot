/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import thaumcraft.api.wands.ItemFocusBasic;
/*     */ import thaumcraft.common.tiles.TileFocalManipulator;
/*     */ 
/*     */ 
/*     */ public class ContainerFocalManipulator
/*     */   extends Container
/*     */ {
/*     */   private TileFocalManipulator table;
/*     */   private int lastBreakTime;
/*     */   
/*     */   public ContainerFocalManipulator(InventoryPlayer par1InventoryPlayer, TileFocalManipulator tileEntity) {
/*  20 */     this.table = tileEntity;
/*  21 */     addSlotToContainer(new SlotLimitedByClass(ItemFocusBasic.class, (IInventory)tileEntity, 0, 88, 60));
/*     */     
/*     */     int i;
/*  24 */     for (i = 0; i < 3; i++) {
/*     */       
/*  26 */       for (int j = 0; j < 9; j++)
/*     */       {
/*  28 */         addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, j + i * 9 + 9, 16 + j * 18, 151 + i * 18));
/*     */       }
/*     */     } 
/*     */     
/*  32 */     for (i = 0; i < 9; i++)
/*     */     {
/*  34 */       addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, i, 16 + i * 18, 209));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean enchantItem(EntityPlayer p, int button) {
/*  42 */     if (button >= 0 && 
/*  43 */       !this.table.startCraft(button, p)) {
/*  44 */       this.table.getWorldObj().playSoundEffect(this.table.xCoord, this.table.yCoord, this.table.zCoord, "thaumcraft:craftfail", 0.33F, 1.0F);
/*     */     }
/*     */ 
/*     */     
/*  48 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer par1EntityPlayer) {
/*  55 */     return this.table.isUseableByPlayer(par1EntityPlayer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int par2) {
/*  64 */     ItemStack itemstack = null;
/*  65 */     Slot slot = this.inventorySlots.get(par2);
/*     */     
/*  67 */     if (slot != null && slot.getHasStack()) {
/*     */       
/*  69 */       ItemStack itemstack1 = slot.getStack();
/*  70 */       itemstack = itemstack1.copy();
/*     */       
/*  72 */       if (par2 != 0) {
/*     */         
/*  74 */         if (itemstack1.getItem() instanceof ItemFocusBasic)
/*     */         {
/*  76 */           if (!mergeItemStack(itemstack1, 0, 1, false))
/*     */           {
/*  78 */             return null;
/*     */           }
/*     */         }
/*  81 */         else if (par2 >= 1 && par2 < 28)
/*     */         {
/*  83 */           if (!mergeItemStack(itemstack1, 28, 37, false))
/*     */           {
/*  85 */             return null;
/*     */           }
/*     */         }
/*  88 */         else if (par2 >= 28 && par2 < 37 && !mergeItemStack(itemstack1, 1, 28, false))
/*     */         {
/*  90 */           return null;
/*     */         }
/*     */       
/*  93 */       } else if (!mergeItemStack(itemstack1, 1, 37, false)) {
/*     */         
/*  95 */         return null;
/*     */       } 
/*     */       
/*  98 */       if (itemstack1.stackSize == 0) {
/*     */         
/* 100 */         slot.putStack((ItemStack)null);
/*     */       }
/*     */       else {
/*     */         
/* 104 */         slot.onSlotChanged();
/*     */       } 
/*     */       
/* 107 */       if (itemstack1.stackSize == itemstack.stackSize)
/*     */       {
/* 109 */         return null;
/*     */       }
/*     */       
/* 112 */       slot.onPickupFromSlot(par1EntityPlayer, itemstack1);
/*     */     } 
/*     */     
/* 115 */     return itemstack;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerFocalManipulator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */