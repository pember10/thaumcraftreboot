/*    */ package thaumcraft.common.container;
/*    */ 
/*    */ import cpw.mods.fml.common.FMLCommonHandler;
/*    */ import cpw.mods.fml.common.eventhandler.Event;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.SlotCrafting;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.event.entity.player.PlayerDestroyItemEvent;
/*    */ import thaumcraft.api.aspects.AspectList;
/*    */ import thaumcraft.common.items.wands.ItemWandCasting;
/*    */ import thaumcraft.common.lib.crafting.ThaumcraftCraftingManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SlotCraftingArcaneWorkbench
/*    */   extends SlotCrafting
/*    */ {
/*    */   private final IInventory craftMatrix;
/*    */   private EntityPlayer thePlayer;
/*    */   private int amountCrafted;
/*    */   
/*    */   public SlotCraftingArcaneWorkbench(EntityPlayer par1EntityPlayer, IInventory par2IInventory, IInventory par3IInventory, int par4, int par5, int par6) {
/* 29 */     super(par1EntityPlayer, par2IInventory, par3IInventory, par4, par5, par6);
/* 30 */     this.thePlayer = par1EntityPlayer;
/* 31 */     this.craftMatrix = par2IInventory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onPickupFromSlot(EntityPlayer par1EntityPlayer, ItemStack par1ItemStack) {
/* 41 */     FMLCommonHandler.instance().firePlayerCraftingEvent(this.thePlayer, par1ItemStack, this.craftMatrix);
/* 42 */     onCrafting(par1ItemStack);
/*    */     
/* 44 */     AspectList aspects = ThaumcraftCraftingManager.findMatchingArcaneRecipeAspects(this.craftMatrix, this.thePlayer);
/* 45 */     if (aspects.size() > 0 && this.craftMatrix.getStackInSlot(10) != null) {
/* 46 */       ItemWandCasting wand = (ItemWandCasting)this.craftMatrix.getStackInSlot(10).getItem();
/* 47 */       wand.consumeAllVisCrafting(this.craftMatrix.getStackInSlot(10), par1EntityPlayer, aspects, true);
/*    */     } 
/*    */     
/* 50 */     for (int var2 = 0; var2 < 9; var2++) {
/*    */       
/* 52 */       ItemStack var3 = this.craftMatrix.getStackInSlot(var2);
/*    */       
/* 54 */       if (var3 != null) {
/*    */         
/* 56 */         this.craftMatrix.decrStackSize(var2, 1);
/*    */         
/* 58 */         if (var3.getItem().hasContainerItem(var3)) {
/*    */           
/* 60 */           ItemStack var4 = var3.getItem().getContainerItem(var3);
/*    */           
/* 62 */           if (var4 != null && var4.isItemStackDamageable() && var4.getItemDamage() > var4.getMaxDamage()) {
/*    */             
/* 64 */             MinecraftForge.EVENT_BUS.post((Event)new PlayerDestroyItemEvent(this.thePlayer, var4));
/*    */ 
/*    */ 
/*    */           
/*    */           }
/* 69 */           else if (!var3.getItem().doesContainerItemLeaveCraftingGrid(var3) || !this.thePlayer.inventory.addItemStackToInventory(var4)) {
/*    */             
/* 71 */             if (this.craftMatrix.getStackInSlot(var2) == null) {
/*    */               
/* 73 */               this.craftMatrix.setInventorySlotContents(var2, var4);
/*    */             }
/*    */             else {
/*    */               
/* 77 */               this.thePlayer.dropPlayerItemWithRandomChoice(var4, false);
/*    */             } 
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\SlotCraftingArcaneWorkbench.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */