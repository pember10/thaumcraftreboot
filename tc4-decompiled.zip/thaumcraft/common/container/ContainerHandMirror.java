/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.ICrafting;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.common.items.relics.ItemHandMirror;
/*     */ 
/*     */ public class ContainerHandMirror
/*     */   extends Container {
/*     */   private World worldObj;
/*     */   private int posX;
/*     */   private int posY;
/*     */   private int posZ;
/*  19 */   public IInventory input = new InventoryHandMirror(this);
/*  20 */   ItemStack mirror = null;
/*  21 */   EntityPlayer player = null;
/*     */ 
/*     */   
/*     */   public ContainerHandMirror(InventoryPlayer iinventory, World par2World, int par3, int par4, int par5) {
/*  25 */     this.worldObj = par2World;
/*  26 */     this.posX = par3;
/*  27 */     this.posY = par4;
/*  28 */     this.posZ = par5;
/*  29 */     this.player = iinventory.player;
/*  30 */     this.mirror = iinventory.getCurrentItem();
/*     */     
/*  32 */     addSlotToContainer(new Slot(this.input, 0, 80, 24));
/*  33 */     bindPlayerInventory(iinventory);
/*  34 */     onCraftMatrixChanged(this.input);
/*     */   }
/*     */   protected void bindPlayerInventory(InventoryPlayer inventoryPlayer) {
/*     */     int i;
/*  38 */     for (i = 0; i < 3; i++) {
/*  39 */       for (int j = 0; j < 9; j++) {
/*  40 */         addSlotToContainer(new Slot((IInventory)inventoryPlayer, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  45 */     for (i = 0; i < 9; i++) {
/*  46 */       addSlotToContainer(new Slot((IInventory)inventoryPlayer, i, 8 + i * 18, 142));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCraftMatrixChanged(IInventory par1IInventory) {
/*  53 */     if (this.input.getStackInSlot(0) != null && ItemStack.areItemStacksEqual(this.input.getStackInSlot(0), this.mirror)) {
/*     */       
/*  55 */       this.player.openContainer = this.player.inventoryContainer;
/*     */     }
/*  57 */     else if (!this.worldObj.isRemote && this.input.getStackInSlot(0) != null && this.player != null && 
/*  58 */       ItemHandMirror.transport(this.mirror, this.input.getStackInSlot(0), this.player, this.worldObj)) {
/*  59 */       this.input.setInventorySlotContents(0, null);
/*  60 */       for (int var4 = 0; var4 < this.crafters.size(); var4++)
/*     */       {
/*  62 */         ((ICrafting)this.crafters.get(var4)).sendSlotContents(this, 0, null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int slot) {
/*  73 */     ItemStack stack = null;
/*  74 */     Slot slotObject = this.inventorySlots.get(slot);
/*     */ 
/*     */     
/*  77 */     if (slotObject != null && slotObject.getHasStack() && !(slotObject.getStack().getItem() instanceof ItemHandMirror)) {
/*  78 */       ItemStack stackInSlot = slotObject.getStack();
/*  79 */       stack = stackInSlot.copy();
/*     */       
/*  81 */       if (slot == 0) {
/*  82 */         if (!mergeItemStack(stackInSlot, 1, this.inventorySlots.size(), true, 64))
/*     */         {
/*  84 */           return null;
/*     */         }
/*     */       }
/*  87 */       else if (!mergeItemStack(stackInSlot, 0, 1, false, 64)) {
/*  88 */         return null;
/*     */       } 
/*     */       
/*  91 */       if (stackInSlot.stackSize == 0) {
/*  92 */         slotObject.putStack(null);
/*     */       } else {
/*  94 */         slotObject.onSlotChanged();
/*     */       } 
/*     */     } 
/*     */     
/*  98 */     return stack;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer var1) {
/* 103 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onContainerClosed(EntityPlayer par1EntityPlayer) {
/* 109 */     super.onContainerClosed(par1EntityPlayer);
/*     */     
/* 111 */     if (!this.worldObj.isRemote)
/*     */     {
/* 113 */       for (int var2 = 0; var2 < 1; var2++) {
/*     */         
/* 115 */         ItemStack var3 = this.input.getStackInSlotOnClosing(var2);
/*     */         
/* 117 */         if (var3 != null)
/*     */         {
/* 119 */           par1EntityPlayer.dropPlayerItemWithRandomChoice(var3, false);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean mergeItemStack(ItemStack par1ItemStack, int par2, int par3, boolean par4, int limit) {
/* 127 */     boolean var5 = false;
/* 128 */     int var6 = par2;
/*     */     
/* 130 */     if (par4)
/*     */     {
/* 132 */       var6 = par3 - 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     if (par1ItemStack.isStackable())
/*     */     {
/* 140 */       while (par1ItemStack.stackSize > 0 && ((!par4 && var6 < par3) || (par4 && var6 >= par2))) {
/*     */         
/* 142 */         Slot var7 = this.inventorySlots.get(var6);
/* 143 */         ItemStack var8 = var7.getStack();
/*     */         
/* 145 */         if (var8 != null && var8.getItem() == par1ItemStack.getItem() && (!par1ItemStack.getHasSubtypes() || par1ItemStack.getItemDamage() == var8.getItemDamage()) && ItemStack.areItemStackTagsEqual(par1ItemStack, var8)) {
/*     */ 
/*     */ 
/*     */           
/* 149 */           int var9 = var8.stackSize + par1ItemStack.stackSize;
/*     */           
/* 151 */           if (var9 <= Math.min(par1ItemStack.getMaxStackSize(), limit)) {
/*     */             
/* 153 */             par1ItemStack.stackSize = 0;
/* 154 */             var8.stackSize = var9;
/* 155 */             var7.onSlotChanged();
/* 156 */             var5 = true;
/*     */           }
/* 158 */           else if (var8.stackSize < Math.min(par1ItemStack.getMaxStackSize(), limit)) {
/*     */             
/* 160 */             par1ItemStack.stackSize -= Math.min(par1ItemStack.getMaxStackSize(), limit) - var8.stackSize;
/* 161 */             var8.stackSize = Math.min(par1ItemStack.getMaxStackSize(), limit);
/* 162 */             var7.onSlotChanged();
/* 163 */             var5 = true;
/*     */           } 
/*     */         } 
/*     */         
/* 167 */         if (par4) {
/*     */           
/* 169 */           var6--;
/*     */           
/*     */           continue;
/*     */         } 
/* 173 */         var6++;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 178 */     if (par1ItemStack.stackSize > 0) {
/*     */       
/* 180 */       if (par4) {
/*     */         
/* 182 */         var6 = par3 - 1;
/*     */       }
/*     */       else {
/*     */         
/* 186 */         var6 = par2;
/*     */       } 
/*     */       
/* 189 */       while ((!par4 && var6 < par3) || (par4 && var6 >= par2)) {
/*     */         
/* 191 */         Slot var7 = this.inventorySlots.get(var6);
/* 192 */         ItemStack var8 = var7.getStack();
/*     */         
/* 194 */         if (var8 == null) {
/*     */           
/* 196 */           ItemStack res = par1ItemStack.copy();
/* 197 */           res.stackSize = Math.min(res.stackSize, limit);
/* 198 */           var7.putStack(res);
/* 199 */           var7.onSlotChanged();
/* 200 */           par1ItemStack.stackSize -= res.stackSize;
/* 201 */           var5 = true;
/*     */           
/*     */           break;
/*     */         } 
/* 205 */         if (par4) {
/*     */           
/* 207 */           var6--;
/*     */           
/*     */           continue;
/*     */         } 
/* 211 */         var6++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 216 */     return var5;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerHandMirror.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */