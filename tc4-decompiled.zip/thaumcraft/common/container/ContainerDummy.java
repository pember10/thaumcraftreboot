/*    */ package thaumcraft.common.container;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ 
/*    */ public class ContainerDummy
/*    */   extends Container
/*    */ {
/*    */   public boolean canInteractWith(EntityPlayer var1) {
/* 10 */     return false;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerDummy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */