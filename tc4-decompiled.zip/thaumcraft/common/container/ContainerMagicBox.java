/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import thaumcraft.common.tiles.TileMagicBox;
/*     */ 
/*     */ public class ContainerMagicBox
/*     */   extends Container {
/*     */   private TileMagicBox box;
/*     */   public IInventory playerInv;
/*     */   private int numRows;
/*     */   
/*     */   public ContainerMagicBox(IInventory par1IInventory, TileMagicBox par2IInventory) {
/*  17 */     this.box = par2IInventory;
/*  18 */     this.numRows = par2IInventory.getSizeInventory() / 9;
/*  19 */     this.playerInv = par1IInventory;
/*  20 */     par2IInventory.openInventory();
/*     */     
/*  22 */     bindBoxInventory(0);
/*  23 */     bindPlayerInventory();
/*     */     
/*  25 */     if (this.box.getWorldObj() != null && (this.box.getWorldObj()).isRemote) {
/*  26 */       TileMagicBox.tc = this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void bindBoxInventory(int row) {
/*  34 */     for (int j = 0; j < 3; j++) {
/*     */       
/*  36 */       for (int k = 0; k < 9; k++)
/*     */       {
/*  38 */         addSlotToContainer(new Slot((IInventory)this.box, k + (j + row) * 9, 8 + k * 18, 18 + j * 18));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void bindPlayerInventory() {
/*     */     int j;
/*  46 */     for (j = 0; j < 3; j++) {
/*     */       
/*  48 */       for (int k = 0; k < 9; k++)
/*     */       {
/*  50 */         addSlotToContainer(new Slot(this.playerInv, k + j * 9 + 9, 8 + k * 18, 103 + j * 18));
/*     */       }
/*     */     } 
/*     */     
/*  54 */     for (j = 0; j < 9; j++)
/*     */     {
/*  56 */       addSlotToContainer(new Slot(this.playerInv, j, 8 + j * 18, 161));
/*     */     }
/*     */   }
/*     */   
/*     */   public void refreshInventory() {
/*  61 */     this.inventoryItemStacks.clear();
/*  62 */     this.inventorySlots.clear();
/*  63 */     bindBoxInventory(0);
/*  64 */     bindPlayerInventory();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer par1EntityPlayer) {
/*  70 */     return this.box.isUseableByPlayer(par1EntityPlayer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int par2) {
/*  79 */     ItemStack itemstack = null;
/*  80 */     Slot slot = this.inventorySlots.get(par2);
/*     */     
/*  82 */     if (slot != null && slot.getHasStack()) {
/*     */       
/*  84 */       ItemStack itemstack1 = slot.getStack();
/*  85 */       itemstack = itemstack1.copy();
/*     */       
/*  87 */       if (par2 < this.numRows * 9) {
/*     */         
/*  89 */         if (!mergeItemStack(itemstack1, this.numRows * 9, this.inventorySlots.size(), true))
/*     */         {
/*  91 */           return null;
/*     */         }
/*     */       }
/*  94 */       else if (!mergeItemStack(itemstack1, 0, this.numRows * 9, false)) {
/*     */         
/*  96 */         return null;
/*     */       } 
/*     */       
/*  99 */       if (itemstack1.stackSize == 0) {
/*     */         
/* 101 */         slot.putStack((ItemStack)null);
/*     */       }
/*     */       else {
/*     */         
/* 105 */         slot.onSlotChanged();
/*     */       } 
/*     */     } 
/*     */     
/* 109 */     return itemstack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onContainerClosed(EntityPlayer par1EntityPlayer) {
/* 118 */     super.onContainerClosed(par1EntityPlayer);
/* 119 */     this.box.closeInventory();
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerMagicBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */