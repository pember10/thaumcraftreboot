/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.InventoryCrafting;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.CraftingManager;
/*     */ import thaumcraft.common.items.wands.ItemWandCasting;
/*     */ import thaumcraft.common.lib.crafting.ThaumcraftCraftingManager;
/*     */ import thaumcraft.common.tiles.TileArcaneWorkbench;
/*     */ 
/*     */ 
/*     */ public class ContainerArcaneWorkbench
/*     */   extends Container
/*     */ {
/*     */   private TileArcaneWorkbench tileEntity;
/*     */   private InventoryPlayer ip;
/*     */   
/*     */   public ContainerArcaneWorkbench(InventoryPlayer par1InventoryPlayer, TileArcaneWorkbench e) {
/*  23 */     this.tileEntity = e;
/*  24 */     this.tileEntity.eventHandler = this;
/*  25 */     this.ip = par1InventoryPlayer;
/*  26 */     addSlotToContainer((Slot)new SlotCraftingArcaneWorkbench(par1InventoryPlayer.player, (IInventory)this.tileEntity, (IInventory)this.tileEntity, 9, 160, 64));
/*  27 */     addSlotToContainer(new SlotLimitedByWand((IInventory)this.tileEntity, 10, 160, 24));
/*     */     
/*     */     int var6;
/*     */     
/*  31 */     for (var6 = 0; var6 < 3; var6++) {
/*     */       
/*  33 */       for (int var7 = 0; var7 < 3; var7++)
/*     */       {
/*  35 */         addSlotToContainer(new Slot((IInventory)this.tileEntity, var7 + var6 * 3, 40 + var7 * 24, 40 + var6 * 24));
/*     */       }
/*     */     } 
/*     */     
/*  39 */     for (var6 = 0; var6 < 3; var6++) {
/*     */       
/*  41 */       for (int var7 = 0; var7 < 9; var7++)
/*     */       {
/*  43 */         addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, var7 + var6 * 9 + 9, 16 + var7 * 18, 151 + var6 * 18));
/*     */       }
/*     */     } 
/*     */     
/*  47 */     for (var6 = 0; var6 < 9; var6++)
/*     */     {
/*  49 */       addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, var6, 16 + var6 * 18, 209));
/*     */     }
/*     */     
/*  52 */     onCraftMatrixChanged((IInventory)this.tileEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCraftMatrixChanged(IInventory par1IInventory) {
/*  61 */     InventoryCrafting ic = new InventoryCrafting(new ContainerDummy(), 3, 3);
/*  62 */     for (int a = 0; a < 9; a++) {
/*  63 */       ic.setInventorySlotContents(a, this.tileEntity.getStackInSlot(a));
/*     */     }
/*  65 */     this.tileEntity.setInventorySlotContentsSoftly(9, CraftingManager.getInstance().findMatchingRecipe(ic, this.tileEntity.getWorldObj()));
/*     */ 
/*     */     
/*  68 */     if (this.tileEntity.getStackInSlot(9) == null && this.tileEntity.getStackInSlot(10) != null && this.tileEntity.getStackInSlot(10).getItem() instanceof ItemWandCasting) {
/*     */ 
/*     */       
/*  71 */       ItemWandCasting wand = (ItemWandCasting)this.tileEntity.getStackInSlot(10).getItem();
/*     */       
/*  73 */       if (wand.consumeAllVisCrafting(this.tileEntity.getStackInSlot(10), this.ip.player, ThaumcraftCraftingManager.findMatchingArcaneRecipeAspects((IInventory)this.tileEntity, this.ip.player), false))
/*     */       {
/*     */ 
/*     */         
/*  77 */         this.tileEntity.setInventorySlotContentsSoftly(9, ThaumcraftCraftingManager.findMatchingArcaneRecipe((IInventory)this.tileEntity, this.ip.player));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onContainerClosed(EntityPlayer par1EntityPlayer) {
/*  88 */     super.onContainerClosed(par1EntityPlayer);
/*     */     
/*  90 */     if (!(this.tileEntity.getWorldObj()).isRemote)
/*     */     {
/*  92 */       this.tileEntity.eventHandler = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer par1EntityPlayer) {
/*  99 */     return (this.tileEntity.getWorldObj().getTileEntity(this.tileEntity.xCoord, this.tileEntity.yCoord, this.tileEntity.zCoord) != this.tileEntity) ? false : ((par1EntityPlayer.getDistanceSq(this.tileEntity.xCoord + 0.5D, this.tileEntity.yCoord + 0.5D, this.tileEntity.zCoord + 0.5D) <= 64.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int par1) {
/* 108 */     ItemStack var2 = null;
/* 109 */     Slot var3 = this.inventorySlots.get(par1);
/*     */     
/* 111 */     if (var3 != null && var3.getHasStack()) {
/*     */       
/* 113 */       ItemStack var4 = var3.getStack();
/* 114 */       var2 = var4.copy();
/*     */       
/* 116 */       if (par1 == 0) {
/*     */         
/* 118 */         if (!mergeItemStack(var4, 11, 47, true))
/*     */         {
/* 120 */           return null;
/*     */         }
/*     */         
/* 123 */         var3.onSlotChange(var4, var2);
/*     */       }
/* 125 */       else if (par1 >= 11 && par1 < 38) {
/*     */         
/* 127 */         if (var4.getItem() instanceof ItemWandCasting && !((ItemWandCasting)var4.getItem()).isStaff(var4))
/*     */         {
/* 129 */           if (!mergeItemStack(var4, 1, 2, false)) {
/* 130 */             return null;
/*     */           }
/* 132 */           var3.onSlotChange(var4, var2);
/*     */         }
/* 134 */         else if (!mergeItemStack(var4, 38, 47, false))
/*     */         {
/* 136 */           return null;
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 141 */       else if (par1 >= 38 && par1 < 47) {
/*     */         
/* 143 */         if (var4.getItem() instanceof ItemWandCasting && !((ItemWandCasting)var4.getItem()).isStaff(var4))
/*     */         {
/* 145 */           if (!mergeItemStack(var4, 1, 2, false)) {
/* 146 */             return null;
/*     */           }
/* 148 */           var3.onSlotChange(var4, var2);
/*     */         }
/* 150 */         else if (!mergeItemStack(var4, 11, 38, false))
/*     */         {
/* 152 */           return null;
/*     */         }
/*     */       
/*     */       }
/* 156 */       else if (!mergeItemStack(var4, 11, 47, false)) {
/*     */         
/* 158 */         return null;
/*     */       } 
/*     */       
/* 161 */       if (var4.stackSize == 0) {
/*     */         
/* 163 */         var3.putStack((ItemStack)null);
/*     */       }
/*     */       else {
/*     */         
/* 167 */         var3.onSlotChanged();
/*     */       } 
/*     */       
/* 170 */       if (var4.stackSize == var2.stackSize)
/*     */       {
/* 172 */         return null;
/*     */       }
/*     */       
/* 175 */       var3.onPickupFromSlot(this.ip.player, var4);
/*     */     } 
/*     */     
/* 178 */     return var2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack slotClick(int par1, int par2, int par3, EntityPlayer par4EntityPlayer) {
/* 184 */     if (par3 == 4) {
/* 185 */       par2 = 1;
/* 186 */       return super.slotClick(par1, par2, par3, par4EntityPlayer);
/*     */     } 
/* 188 */     if ((par1 == 0 || par1 == 1) && par2 > 0) par2 = 0; 
/* 189 */     return super.slotClick(par1, par2, par3, par4EntityPlayer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_94530_a(ItemStack par1ItemStack, Slot par2Slot) {
/* 195 */     return (par2Slot.inventory != this.tileEntity && super.func_94530_a(par1ItemStack, par2Slot));
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerArcaneWorkbench.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */