/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ public class InventoryFake
/*     */   implements IInventory
/*     */ {
/*     */   private ItemStack[] stackList;
/*     */   
/*     */   public InventoryFake(ItemStack[] stackList) {
/*  14 */     this.stackList = stackList;
/*     */   }
/*     */   
/*     */   public InventoryFake(ArrayList<ItemStack> stackList) {
/*  18 */     this.stackList = stackList.<ItemStack>toArray(new ItemStack[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSizeInventory() {
/*  26 */     return this.stackList.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getStackInSlot(int par1) {
/*  34 */     return (par1 >= getSizeInventory()) ? null : this.stackList[par1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getStackInSlotOnClosing(int par1) {
/*  44 */     if (this.stackList[par1] != null) {
/*  45 */       ItemStack var2 = this.stackList[par1];
/*  46 */       this.stackList[par1] = null;
/*  47 */       return var2;
/*     */     } 
/*  49 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack decrStackSize(int par1, int par2) {
/*  59 */     if (this.stackList[par1] != null) {
/*     */ 
/*     */       
/*  62 */       if ((this.stackList[par1]).stackSize <= par2) {
/*  63 */         ItemStack itemStack = this.stackList[par1];
/*  64 */         this.stackList[par1] = null;
/*  65 */         return itemStack;
/*     */       } 
/*  67 */       ItemStack var3 = this.stackList[par1].splitStack(par2);
/*     */       
/*  69 */       if ((this.stackList[par1]).stackSize == 0) {
/*  70 */         this.stackList[par1] = null;
/*     */       }
/*     */       
/*  73 */       return var3;
/*     */     } 
/*     */     
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInventorySlotContents(int par1, ItemStack par2ItemStack) {
/*  86 */     this.stackList[par1] = par2ItemStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInventoryStackLimit() {
/*  95 */     return 64;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUseableByPlayer(EntityPlayer par1EntityPlayer) {
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isItemValidForSlot(int i, ItemStack itemstack) {
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInventoryName() {
/* 114 */     return "container.fake";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasCustomInventoryName() {
/* 119 */     return false;
/*     */   }
/*     */   
/*     */   public void markDirty() {}
/*     */   
/*     */   public void openInventory() {}
/*     */   
/*     */   public void closeInventory() {}
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\InventoryFake.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */