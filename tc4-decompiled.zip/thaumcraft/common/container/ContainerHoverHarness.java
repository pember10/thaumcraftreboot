/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class ContainerHoverHarness extends Container {
/*     */   private World worldObj;
/*     */   private int posX;
/*     */   private int posY;
/*     */   private int posZ;
/*  18 */   public IInventory input = new InventoryHoverHarness(this);
/*  19 */   ItemStack armor = null;
/*  20 */   EntityPlayer player = null;
/*     */   
/*     */   private int blockSlot;
/*     */   
/*     */   public ContainerHoverHarness(InventoryPlayer iinventory, World par2World, int par3, int par4, int par5) {
/*  25 */     this.worldObj = par2World;
/*  26 */     this.posX = par3;
/*  27 */     this.posY = par4;
/*  28 */     this.posZ = par5;
/*  29 */     this.player = iinventory.player;
/*  30 */     this.armor = iinventory.getCurrentItem();
/*  31 */     this.blockSlot = iinventory.currentItem + 28;
/*     */     
/*  33 */     addSlotToContainer(new Slot(this.input, 0, 80, 32));
/*  34 */     bindPlayerInventory(iinventory);
/*  35 */     if (!par2World.isRemote) {
/*     */       try {
/*  37 */         ItemStack jar = ItemStack.loadItemStackFromNBT(this.armor.stackTagCompound.getCompoundTag("jar"));
/*  38 */         this.input.setInventorySlotContents(0, jar);
/*  39 */       } catch (Exception e) {}
/*     */     }
/*  41 */     onCraftMatrixChanged(this.input);
/*     */   }
/*     */   protected void bindPlayerInventory(InventoryPlayer inventoryPlayer) {
/*     */     int i;
/*  45 */     for (i = 0; i < 3; i++) {
/*  46 */       for (int j = 0; j < 9; j++) {
/*  47 */         addSlotToContainer(new Slot((IInventory)inventoryPlayer, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  52 */     for (i = 0; i < 9; i++) {
/*  53 */       addSlotToContainer(new Slot((IInventory)inventoryPlayer, i, 8 + i * 18, 142));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int slot) {
/*  64 */     if (slot == this.blockSlot) return null; 
/*  65 */     ItemStack stack = null;
/*  66 */     Slot slotObject = this.inventorySlots.get(slot);
/*     */ 
/*     */     
/*  69 */     if (slotObject != null && slotObject.getHasStack()) {
/*  70 */       ItemStack stackInSlot = slotObject.getStack();
/*  71 */       stack = stackInSlot.copy();
/*     */       
/*  73 */       if (slot == 0) {
/*  74 */         if (!this.input.isItemValidForSlot(slot, stackInSlot) || !mergeItemStack(stackInSlot, 1, this.inventorySlots.size(), true, 64))
/*     */         {
/*     */           
/*  77 */           return null;
/*     */         
/*     */         }
/*     */       }
/*  81 */       else if (!this.input.isItemValidForSlot(slot, stackInSlot) || !mergeItemStack(stackInSlot, 0, 1, false, 1)) {
/*     */         
/*  83 */         return null;
/*     */       } 
/*     */       
/*  86 */       if (stackInSlot.stackSize == 0) {
/*  87 */         slotObject.putStack(null);
/*     */       } else {
/*  89 */         slotObject.onSlotChanged();
/*     */       } 
/*     */     } 
/*     */     
/*  93 */     return stack;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack slotClick(int par1, int par2, int par3, EntityPlayer par4EntityPlayer) {
/*  99 */     if (par1 == this.blockSlot) return null; 
/* 100 */     InventoryPlayer inventoryplayer = par4EntityPlayer.inventory;
/* 101 */     if (par1 != 0 || this.input.isItemValidForSlot(par1, inventoryplayer.getItemStack()) || (par1 == 0 && inventoryplayer.getItemStack() == null))
/*     */     {
/* 103 */       return super.slotClick(par1, par2, par3, par4EntityPlayer);
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer var1) {
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putStackInSlot(int par1, ItemStack par2ItemStack) {
/* 119 */     if (this.input.isItemValidForSlot(par1, par2ItemStack)) super.putStackInSlot(par1, par2ItemStack);
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void onContainerClosed(EntityPlayer par1EntityPlayer) {
/* 125 */     if (!this.worldObj.isRemote) {
/*     */       
/* 127 */       ItemStack var3 = this.input.getStackInSlotOnClosing(0);
/* 128 */       if (var3 != null) {
/* 129 */         NBTTagCompound var4 = new NBTTagCompound();
/* 130 */         var3.writeToNBT(var4);
/* 131 */         this.armor.setTagInfo("jar", (NBTBase)var4);
/*     */       } else {
/* 133 */         this.armor.setTagInfo("jar", (NBTBase)new NBTTagCompound());
/*     */       } 
/* 135 */       if (this.player == null)
/* 136 */         return;  if (this.player.getHeldItem() != null && this.player.getHeldItem().isItemEqual(this.armor))
/* 137 */         this.player.setCurrentItemOrArmor(0, this.armor); 
/* 138 */       this.player.inventory.markDirty();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean mergeItemStack(ItemStack par1ItemStack, int par2, int par3, boolean par4, int limit) {
/* 144 */     boolean var5 = false;
/* 145 */     int var6 = par2;
/*     */     
/* 147 */     if (par4)
/*     */     {
/* 149 */       var6 = par3 - 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     if (par1ItemStack.isStackable())
/*     */     {
/* 157 */       while (par1ItemStack.stackSize > 0 && ((!par4 && var6 < par3) || (par4 && var6 >= par2))) {
/*     */         
/* 159 */         Slot var7 = this.inventorySlots.get(var6);
/* 160 */         ItemStack var8 = var7.getStack();
/*     */         
/* 162 */         if (var8 != null && var8.getItem() == par1ItemStack.getItem() && (!par1ItemStack.getHasSubtypes() || par1ItemStack.getItemDamage() == var8.getItemDamage()) && ItemStack.areItemStackTagsEqual(par1ItemStack, var8)) {
/*     */ 
/*     */ 
/*     */           
/* 166 */           int var9 = var8.stackSize + par1ItemStack.stackSize;
/*     */           
/* 168 */           if (var9 <= Math.min(par1ItemStack.getMaxStackSize(), limit)) {
/*     */             
/* 170 */             par1ItemStack.stackSize = 0;
/* 171 */             var8.stackSize = var9;
/* 172 */             var7.onSlotChanged();
/* 173 */             var5 = true;
/*     */           }
/* 175 */           else if (var8.stackSize < Math.min(par1ItemStack.getMaxStackSize(), limit)) {
/*     */             
/* 177 */             par1ItemStack.stackSize -= Math.min(par1ItemStack.getMaxStackSize(), limit) - var8.stackSize;
/* 178 */             var8.stackSize = Math.min(par1ItemStack.getMaxStackSize(), limit);
/* 179 */             var7.onSlotChanged();
/* 180 */             var5 = true;
/*     */           } 
/*     */         } 
/*     */         
/* 184 */         if (par4) {
/*     */           
/* 186 */           var6--;
/*     */           
/*     */           continue;
/*     */         } 
/* 190 */         var6++;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 195 */     if (par1ItemStack.stackSize > 0) {
/*     */       
/* 197 */       if (par4) {
/*     */         
/* 199 */         var6 = par3 - 1;
/*     */       }
/*     */       else {
/*     */         
/* 203 */         var6 = par2;
/*     */       } 
/*     */       
/* 206 */       while ((!par4 && var6 < par3) || (par4 && var6 >= par2)) {
/*     */         
/* 208 */         Slot var7 = this.inventorySlots.get(var6);
/* 209 */         ItemStack var8 = var7.getStack();
/*     */         
/* 211 */         if (var8 == null) {
/*     */           
/* 213 */           ItemStack res = par1ItemStack.copy();
/* 214 */           res.stackSize = Math.min(res.stackSize, limit);
/* 215 */           var7.putStack(res);
/* 216 */           var7.onSlotChanged();
/* 217 */           par1ItemStack.stackSize -= res.stackSize;
/* 218 */           var5 = true;
/*     */           
/*     */           break;
/*     */         } 
/* 222 */         if (par4) {
/*     */           
/* 224 */           var6--;
/*     */           
/*     */           continue;
/*     */         } 
/* 228 */         var6++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 233 */     return var5;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerHoverHarness.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */