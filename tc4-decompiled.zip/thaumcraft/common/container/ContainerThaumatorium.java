/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import thaumcraft.api.ThaumcraftApi;
/*     */ import thaumcraft.api.crafting.CrucibleRecipe;
/*     */ import thaumcraft.common.lib.research.ResearchManager;
/*     */ import thaumcraft.common.tiles.TileThaumatorium;
/*     */ 
/*     */ public class ContainerThaumatorium
/*     */   extends Container
/*     */ {
/*     */   private TileThaumatorium thaumatorium;
/*  19 */   private EntityPlayer player = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<CrucibleRecipe> recipes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerThaumatorium(InventoryPlayer par1InventoryPlayer, TileThaumatorium tileEntity) {
/*  45 */     this.recipes = new ArrayList<CrucibleRecipe>(); this.player = par1InventoryPlayer.player; this.thaumatorium = tileEntity; this.thaumatorium.eventHandler = this; addSlotToContainer(new Slot((IInventory)tileEntity, 0, 48, 16)); int i; for (i = 0; i < 3; i++) {
/*     */       for (int j = 0; j < 9; j++)
/*     */         addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, j + i * 9 + 9, 8 + j * 18, 84 + i * 18)); 
/*     */     }  for (i = 0; i < 9; i++)
/*     */       addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, i, 8 + i * 18, 142)); 
/*  50 */     onCraftMatrixChanged((IInventory)this.thaumatorium); } public void onCraftMatrixChanged(IInventory par1iInventory) { super.onCraftMatrixChanged(par1iInventory);
/*  51 */     updateRecipes(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onContainerClosed(EntityPlayer par1EntityPlayer) {
/*  58 */     super.onContainerClosed(par1EntityPlayer);
/*     */     
/*  60 */     if (!(this.thaumatorium.getWorldObj()).isRemote)
/*     */     {
/*  62 */       this.thaumatorium.eventHandler = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateRecipes() {
/*  68 */     this.recipes.clear();
/*  69 */     if (this.thaumatorium.inputStack != null || this.thaumatorium.recipeHash != null) {
/*  70 */       for (Object r : ThaumcraftApi.getCraftingRecipes()) {
/*  71 */         if (r instanceof CrucibleRecipe) {
/*  72 */           if (ResearchManager.isResearchComplete(this.player.getCommandSenderName(), ((CrucibleRecipe)r).key) && ((CrucibleRecipe)r).catalystMatches(this.thaumatorium.inputStack)) {
/*     */             
/*  74 */             this.recipes.add((CrucibleRecipe)r);
/*     */             continue;
/*     */           } 
/*  77 */           if (this.thaumatorium.recipeHash != null && this.thaumatorium.recipeHash.size() > 0) {
/*  78 */             for (Integer hash : this.thaumatorium.recipeHash) {
/*  79 */               if (((CrucibleRecipe)r).hash == hash.intValue()) {
/*  80 */                 this.recipes.add((CrucibleRecipe)r);
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean enchantItem(EntityPlayer par1EntityPlayer, int button) {
/*  94 */     if (this.recipes.size() > 0 && 
/*  95 */       button >= 0 && button < this.recipes.size()) {
/*  96 */       boolean found = false;
/*  97 */       for (int a = 0; a < this.thaumatorium.recipeHash.size(); a++) {
/*  98 */         if (((CrucibleRecipe)this.recipes.get(button)).hash == ((Integer)this.thaumatorium.recipeHash.get(a)).intValue()) {
/*  99 */           found = true;
/* 100 */           this.thaumatorium.recipeEssentia.remove(a);
/* 101 */           this.thaumatorium.recipePlayer.remove(a);
/* 102 */           this.thaumatorium.recipeHash.remove(a);
/* 103 */           this.thaumatorium.currentCraft = -1;
/*     */           break;
/*     */         } 
/*     */       } 
/* 107 */       if (!found) {
/* 108 */         this.thaumatorium.recipeEssentia.add(((CrucibleRecipe)this.recipes.get(button)).aspects.copy());
/* 109 */         this.thaumatorium.recipePlayer.add(par1EntityPlayer.getCommandSenderName());
/* 110 */         this.thaumatorium.recipeHash.add(Integer.valueOf(((CrucibleRecipe)this.recipes.get(button)).hash));
/*     */       } 
/* 112 */       this.thaumatorium.markDirty();
/* 113 */       this.thaumatorium.getWorldObj().markBlockForUpdate(this.thaumatorium.xCoord, this.thaumatorium.yCoord, this.thaumatorium.zCoord);
/* 114 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer par1EntityPlayer) {
/* 124 */     return this.thaumatorium.isUseableByPlayer(par1EntityPlayer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int par2) {
/* 133 */     ItemStack itemstack = null;
/* 134 */     Slot slot = this.inventorySlots.get(par2);
/*     */     
/* 136 */     if (slot != null && slot.getHasStack()) {
/*     */       
/* 138 */       ItemStack itemstack1 = slot.getStack();
/* 139 */       itemstack = itemstack1.copy();
/*     */       
/* 141 */       if (par2 != 0) {
/*     */         
/* 143 */         if (!mergeItemStack(itemstack1, 0, 1, false))
/*     */         {
/* 145 */           return null;
/*     */         }
/*     */       }
/* 148 */       else if (par2 >= 1 && par2 < 28) {
/*     */         
/* 150 */         if (!mergeItemStack(itemstack1, 28, 37, false))
/*     */         {
/* 152 */           return null;
/*     */         }
/*     */       } else {
/* 155 */         if (par2 >= 28 && par2 < 37 && !mergeItemStack(itemstack1, 1, 28, false))
/*     */         {
/* 157 */           return null;
/*     */         }
/* 159 */         if (!mergeItemStack(itemstack1, 1, 37, false))
/*     */         {
/* 161 */           return null;
/*     */         }
/*     */       } 
/* 164 */       if (itemstack1.stackSize == 0) {
/*     */         
/* 166 */         slot.putStack((ItemStack)null);
/*     */       }
/*     */       else {
/*     */         
/* 170 */         slot.onSlotChanged();
/*     */       } 
/*     */       
/* 173 */       if (itemstack1.stackSize == itemstack.stackSize)
/*     */       {
/* 175 */         return null;
/*     */       }
/*     */       
/* 178 */       slot.onPickupFromSlot(par1EntityPlayer, itemstack1);
/*     */     } 
/*     */     
/* 181 */     return itemstack;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerThaumatorium.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */