/*    */ package thaumcraft.common.container;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import thaumcraft.common.items.ItemBathSalts;
/*    */ import thaumcraft.common.tiles.TileSpa;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContainerSpa
/*    */   extends Container
/*    */ {
/*    */   private TileSpa spa;
/*    */   private int lastBreakTime;
/*    */   
/*    */   public ContainerSpa(InventoryPlayer par1InventoryPlayer, TileSpa tileEntity) {
/* 29 */     this.spa = tileEntity;
/* 30 */     addSlotToContainer(new SlotLimitedByClass(ItemBathSalts.class, (IInventory)tileEntity, 0, 65, 31));
/*    */     
/*    */     int i;
/* 33 */     for (i = 0; i < 3; i++) {
/*    */       
/* 35 */       for (int j = 0; j < 9; j++)
/*    */       {
/* 37 */         addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*    */       }
/*    */     } 
/*    */     
/* 41 */     for (i = 0; i < 9; i++)
/*    */     {
/* 43 */       addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, i, 8 + i * 18, 142));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean enchantItem(EntityPlayer p, int button) {
/* 52 */     if (button == 1) {
/* 53 */       this.spa.toggleMix();
/*    */     }
/* 55 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer par1EntityPlayer) {
/* 62 */     return this.spa.isUseableByPlayer(par1EntityPlayer);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int slot) {
/* 70 */     ItemStack stack = null;
/* 71 */     Slot slotObject = this.inventorySlots.get(slot);
/*    */ 
/*    */     
/* 74 */     if (slotObject != null && slotObject.getHasStack()) {
/* 75 */       ItemStack stackInSlot = slotObject.getStack();
/* 76 */       stack = stackInSlot.copy();
/*    */       
/* 78 */       if (slot == 0) {
/* 79 */         if (!this.spa.isItemValidForSlot(slot, stackInSlot) || !mergeItemStack(stackInSlot, 1, this.inventorySlots.size(), true))
/*    */         {
/*    */           
/* 82 */           return null;
/*    */         
/*    */         }
/*    */       }
/* 86 */       else if (!this.spa.isItemValidForSlot(slot, stackInSlot) || !mergeItemStack(stackInSlot, 0, 1, false)) {
/*    */         
/* 88 */         return null;
/*    */       } 
/*    */       
/* 91 */       if (stackInSlot.stackSize == 0) {
/* 92 */         slotObject.putStack(null);
/*    */       } else {
/* 94 */         slotObject.onSlotChanged();
/*    */       } 
/*    */     } 
/*    */     
/* 98 */     return stack;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerSpa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */