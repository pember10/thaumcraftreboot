/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.common.blocks.ItemJarFilled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InventoryHoverHarness
/*     */   implements IInventory
/*     */ {
/*     */   private ItemStack[] stackList;
/*     */   private Container eventHandler;
/*     */   
/*     */   public InventoryHoverHarness(Container par1Container) {
/*  23 */     this.stackList = new ItemStack[1];
/*  24 */     this.eventHandler = par1Container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSizeInventory() {
/*  33 */     return this.stackList.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getStackInSlot(int par1) {
/*  42 */     return (par1 >= getSizeInventory()) ? null : this.stackList[par1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getStackInSlotOnClosing(int par1) {
/*  52 */     if (this.stackList[par1] != null) {
/*     */       
/*  54 */       ItemStack var2 = this.stackList[par1];
/*  55 */       this.stackList[par1] = null;
/*  56 */       return var2;
/*     */     } 
/*     */ 
/*     */     
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack decrStackSize(int par1, int par2) {
/*  71 */     if (this.stackList[par1] != null) {
/*     */ 
/*     */ 
/*     */       
/*  75 */       if ((this.stackList[par1]).stackSize <= par2) {
/*     */         
/*  77 */         ItemStack itemStack = this.stackList[par1];
/*  78 */         this.stackList[par1] = null;
/*  79 */         this.eventHandler.onCraftMatrixChanged(this);
/*  80 */         return itemStack;
/*     */       } 
/*     */ 
/*     */       
/*  84 */       ItemStack var3 = this.stackList[par1].splitStack(par2);
/*     */       
/*  86 */       if ((this.stackList[par1]).stackSize == 0)
/*     */       {
/*  88 */         this.stackList[par1] = null;
/*     */       }
/*     */       
/*  91 */       this.eventHandler.onCraftMatrixChanged(this);
/*  92 */       return var3;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInventorySlotContents(int par1, ItemStack par2ItemStack) {
/* 107 */     this.stackList[par1] = par2ItemStack;
/* 108 */     this.eventHandler.onCraftMatrixChanged(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInventoryStackLimit() {
/* 118 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUseableByPlayer(EntityPlayer par1EntityPlayer) {
/* 127 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isItemValidForSlot(int i, ItemStack jar) {
/* 134 */     if (jar != null && jar.getItem() instanceof ItemJarFilled && jar.hasTagCompound()) {
/* 135 */       AspectList aspects = ((ItemJarFilled)jar.getItem()).getAspects(jar);
/* 136 */       if (aspects != null && aspects.size() > 0 && aspects.getAmount(Aspect.ENERGY) > 0) {
/* 137 */         return true;
/*     */       }
/*     */     } 
/* 140 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInventoryName() {
/* 145 */     return "container.hoverharness";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasCustomInventoryName() {
/* 150 */     return false;
/*     */   }
/*     */   
/*     */   public void markDirty() {}
/*     */   
/*     */   public void openInventory() {}
/*     */   
/*     */   public void closeInventory() {}
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\InventoryHoverHarness.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */