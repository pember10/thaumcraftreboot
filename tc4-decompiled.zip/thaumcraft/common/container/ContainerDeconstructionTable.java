/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import cpw.mods.fml.common.network.simpleimpl.IMessage;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.ICrafting;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.common.Thaumcraft;
/*     */ import thaumcraft.common.lib.crafting.ThaumcraftCraftingManager;
/*     */ import thaumcraft.common.lib.network.PacketHandler;
/*     */ import thaumcraft.common.lib.network.playerdata.PacketAspectPool;
/*     */ import thaumcraft.common.lib.research.ResearchManager;
/*     */ import thaumcraft.common.tiles.TileDeconstructionTable;
/*     */ 
/*     */ public class ContainerDeconstructionTable
/*     */   extends Container {
/*     */   private TileDeconstructionTable table;
/*     */   private int lastBreakTime;
/*     */   
/*     */   public ContainerDeconstructionTable(InventoryPlayer par1InventoryPlayer, TileDeconstructionTable tileEntity) {
/*  28 */     this.table = tileEntity;
/*  29 */     addSlotToContainer(new SlotLimitedHasAspects((IInventory)tileEntity, 0, 64, 16));
/*     */     
/*     */     int i;
/*  32 */     for (i = 0; i < 3; i++) {
/*     */       
/*  34 */       for (int j = 0; j < 9; j++)
/*     */       {
/*  36 */         addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*     */       }
/*     */     } 
/*     */     
/*  40 */     for (i = 0; i < 9; i++)
/*     */     {
/*  42 */       addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, i, 8 + i * 18, 142));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCraftingToCrafters(ICrafting par1ICrafting) {
/*  49 */     super.addCraftingToCrafters(par1ICrafting);
/*  50 */     par1ICrafting.sendProgressBarUpdate(this, 0, this.table.breaktime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean enchantItem(EntityPlayer p, int button) {
/*  57 */     if (button == 1 && 
/*  58 */       this.table.aspect != null) {
/*  59 */       Thaumcraft.proxy.playerKnowledge.addAspectPool(p.getCommandSenderName(), this.table.aspect, (short)1);
/*  60 */       ResearchManager.scheduleSave(p);
/*  61 */       PacketHandler.INSTANCE.sendTo((IMessage)new PacketAspectPool(this.table.aspect.getTag(), Short.valueOf((short)1), Short.valueOf(Thaumcraft.proxy.playerKnowledge.getAspectPoolFor(p.getCommandSenderName(), this.table.aspect))), (EntityPlayerMP)p);
/*     */ 
/*     */ 
/*     */       
/*  65 */       this.table.aspect = null;
/*  66 */       this.table.getWorldObj().markBlockForUpdate(this.table.xCoord, this.table.yCoord, this.table.zCoord);
/*     */     } 
/*     */     
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void detectAndSendChanges() {
/*  78 */     super.detectAndSendChanges();
/*     */     
/*  80 */     for (int i = 0; i < this.crafters.size(); i++) {
/*     */       
/*  82 */       ICrafting icrafting = this.crafters.get(i);
/*     */       
/*  84 */       if (this.lastBreakTime != this.table.breaktime)
/*     */       {
/*  86 */         icrafting.sendProgressBarUpdate(this, 0, this.table.breaktime);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  91 */     this.lastBreakTime = this.table.breaktime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void updateProgressBar(int par1, int par2) {
/*  98 */     if (par1 == 0)
/*     */     {
/* 100 */       this.table.breaktime = par2;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer par1EntityPlayer) {
/* 109 */     return this.table.isUseableByPlayer(par1EntityPlayer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int par2) {
/* 118 */     ItemStack itemstack = null;
/* 119 */     Slot slot = this.inventorySlots.get(par2);
/*     */     
/* 121 */     if (slot != null && slot.getHasStack()) {
/*     */       
/* 123 */       ItemStack itemstack1 = slot.getStack();
/* 124 */       itemstack = itemstack1.copy();
/*     */       
/* 126 */       if (par2 != 0) {
/*     */         
/* 128 */         AspectList al = ThaumcraftCraftingManager.getObjectTags(itemstack1);
/* 129 */         al = ThaumcraftCraftingManager.getBonusTags(itemstack1, al);
/*     */         
/* 131 */         if (al != null && al.size() > 0)
/*     */         {
/* 133 */           if (!mergeItemStack(itemstack1, 0, 1, false))
/*     */           {
/* 135 */             return null;
/*     */           }
/*     */         }
/* 138 */         else if (par2 >= 1 && par2 < 28)
/*     */         {
/* 140 */           if (!mergeItemStack(itemstack1, 28, 37, false))
/*     */           {
/* 142 */             return null;
/*     */           }
/*     */         }
/* 145 */         else if (par2 >= 28 && par2 < 37 && !mergeItemStack(itemstack1, 1, 28, false))
/*     */         {
/* 147 */           return null;
/*     */         }
/*     */       
/* 150 */       } else if (!mergeItemStack(itemstack1, 1, 37, false)) {
/*     */         
/* 152 */         return null;
/*     */       } 
/*     */       
/* 155 */       if (itemstack1.stackSize == 0) {
/*     */         
/* 157 */         slot.putStack((ItemStack)null);
/*     */       }
/*     */       else {
/*     */         
/* 161 */         slot.onSlotChanged();
/*     */       } 
/*     */       
/* 164 */       if (itemstack1.stackSize == itemstack.stackSize)
/*     */       {
/* 166 */         return null;
/*     */       }
/*     */       
/* 169 */       slot.onPickupFromSlot(par1EntityPlayer, itemstack1);
/*     */     } 
/*     */     
/* 172 */     return itemstack;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerDeconstructionTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */