/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InventoryHandMirror
/*     */   implements IInventory
/*     */ {
/*     */   private ItemStack[] stackList;
/*     */   private Container eventHandler;
/*     */   
/*     */   public InventoryHandMirror(Container par1Container) {
/*  20 */     this.stackList = new ItemStack[1];
/*  21 */     this.eventHandler = par1Container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSizeInventory() {
/*  30 */     return this.stackList.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getStackInSlot(int par1) {
/*  39 */     return (par1 >= getSizeInventory()) ? null : this.stackList[par1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getStackInSlotOnClosing(int par1) {
/*  50 */     if (this.stackList[par1] != null) {
/*     */       
/*  52 */       ItemStack var2 = this.stackList[par1];
/*  53 */       this.stackList[par1] = null;
/*  54 */       return var2;
/*     */     } 
/*     */ 
/*     */     
/*  58 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack decrStackSize(int par1, int par2) {
/*  69 */     if (this.stackList[par1] != null) {
/*     */ 
/*     */ 
/*     */       
/*  73 */       if ((this.stackList[par1]).stackSize <= par2) {
/*     */         
/*  75 */         ItemStack itemStack = this.stackList[par1];
/*  76 */         this.stackList[par1] = null;
/*  77 */         this.eventHandler.onCraftMatrixChanged(this);
/*  78 */         return itemStack;
/*     */       } 
/*     */ 
/*     */       
/*  82 */       ItemStack var3 = this.stackList[par1].splitStack(par2);
/*     */       
/*  84 */       if ((this.stackList[par1]).stackSize == 0)
/*     */       {
/*  86 */         this.stackList[par1] = null;
/*     */       }
/*     */       
/*  89 */       this.eventHandler.onCraftMatrixChanged(this);
/*  90 */       return var3;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInventorySlotContents(int par1, ItemStack par2ItemStack) {
/* 105 */     this.stackList[par1] = par2ItemStack;
/* 106 */     this.eventHandler.onCraftMatrixChanged(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInventoryStackLimit() {
/* 116 */     return 64;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUseableByPlayer(EntityPlayer par1EntityPlayer) {
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isItemValidForSlot(int i, ItemStack itemstack) {
/* 130 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInventoryName() {
/* 135 */     return "container.handmirror";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasCustomInventoryName() {
/* 140 */     return false;
/*     */   }
/*     */   
/*     */   public void markDirty() {}
/*     */   
/*     */   public void openInventory() {}
/*     */   
/*     */   public void closeInventory() {}
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\InventoryHandMirror.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */