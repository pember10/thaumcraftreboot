/*     */ package thaumcraft.common.container;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.ICrafting;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.common.lib.crafting.ThaumcraftCraftingManager;
/*     */ import thaumcraft.common.tiles.TileAlchemyFurnace;
/*     */ 
/*     */ public class ContainerAlchemyFurnace
/*     */   extends Container
/*     */ {
/*     */   private TileAlchemyFurnace furnace;
/*     */   private int lastCookTime;
/*     */   private int lastBurnTime;
/*     */   private int lastItemBurnTime;
/*     */   private int lastVis;
/*     */   private int lastSmelt;
/*     */   
/*     */   public ContainerAlchemyFurnace(InventoryPlayer par1InventoryPlayer, TileAlchemyFurnace tileEntity) {
/*  27 */     this.furnace = tileEntity;
/*  28 */     addSlotToContainer(new SlotLimitedHasAspects((IInventory)tileEntity, 0, 80, 8));
/*  29 */     addSlotToContainer(new Slot((IInventory)tileEntity, 1, 80, 48));
/*     */     
/*     */     int i;
/*  32 */     for (i = 0; i < 3; i++) {
/*     */       
/*  34 */       for (int j = 0; j < 9; j++)
/*     */       {
/*  36 */         addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*     */       }
/*     */     } 
/*     */     
/*  40 */     for (i = 0; i < 9; i++)
/*     */     {
/*  42 */       addSlotToContainer(new Slot((IInventory)par1InventoryPlayer, i, 8 + i * 18, 142));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCraftingToCrafters(ICrafting par1ICrafting) {
/*  48 */     super.addCraftingToCrafters(par1ICrafting);
/*  49 */     par1ICrafting.sendProgressBarUpdate(this, 0, this.furnace.furnaceCookTime);
/*  50 */     par1ICrafting.sendProgressBarUpdate(this, 1, this.furnace.furnaceBurnTime);
/*  51 */     par1ICrafting.sendProgressBarUpdate(this, 2, this.furnace.currentItemBurnTime);
/*  52 */     par1ICrafting.sendProgressBarUpdate(this, 3, this.furnace.vis);
/*  53 */     par1ICrafting.sendProgressBarUpdate(this, 4, this.furnace.smeltTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void detectAndSendChanges() {
/*  61 */     super.detectAndSendChanges();
/*     */     
/*  63 */     for (int i = 0; i < this.crafters.size(); i++) {
/*     */       
/*  65 */       ICrafting icrafting = this.crafters.get(i);
/*     */       
/*  67 */       if (this.lastCookTime != this.furnace.furnaceCookTime)
/*     */       {
/*  69 */         icrafting.sendProgressBarUpdate(this, 0, this.furnace.furnaceCookTime);
/*     */       }
/*     */       
/*  72 */       if (this.lastBurnTime != this.furnace.furnaceBurnTime)
/*     */       {
/*  74 */         icrafting.sendProgressBarUpdate(this, 1, this.furnace.furnaceBurnTime);
/*     */       }
/*     */       
/*  77 */       if (this.lastItemBurnTime != this.furnace.currentItemBurnTime)
/*     */       {
/*  79 */         icrafting.sendProgressBarUpdate(this, 2, this.furnace.currentItemBurnTime);
/*     */       }
/*     */       
/*  82 */       if (this.lastVis != this.furnace.vis)
/*     */       {
/*  84 */         icrafting.sendProgressBarUpdate(this, 3, this.furnace.vis);
/*     */       }
/*     */       
/*  87 */       if (this.lastSmelt != this.furnace.smeltTime)
/*     */       {
/*  89 */         icrafting.sendProgressBarUpdate(this, 4, this.furnace.smeltTime);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  94 */     this.lastCookTime = this.furnace.furnaceCookTime;
/*  95 */     this.lastBurnTime = this.furnace.furnaceBurnTime;
/*  96 */     this.lastItemBurnTime = this.furnace.currentItemBurnTime;
/*  97 */     this.lastVis = this.furnace.vis;
/*  98 */     this.lastSmelt = this.furnace.smeltTime;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void updateProgressBar(int par1, int par2) {
/* 104 */     if (par1 == 0)
/*     */     {
/* 106 */       this.furnace.furnaceCookTime = par2;
/*     */     }
/*     */     
/* 109 */     if (par1 == 1)
/*     */     {
/* 111 */       this.furnace.furnaceBurnTime = par2;
/*     */     }
/*     */     
/* 114 */     if (par1 == 2)
/*     */     {
/* 116 */       this.furnace.currentItemBurnTime = par2;
/*     */     }
/*     */     
/* 119 */     if (par1 == 3)
/*     */     {
/* 121 */       this.furnace.vis = par2;
/*     */     }
/*     */     
/* 124 */     if (par1 == 4)
/*     */     {
/* 126 */       this.furnace.smeltTime = par2;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer par1EntityPlayer) {
/* 132 */     return this.furnace.isUseableByPlayer(par1EntityPlayer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int par2) {
/* 140 */     ItemStack itemstack = null;
/* 141 */     Slot slot = this.inventorySlots.get(par2);
/*     */     
/* 143 */     if (slot != null && slot.getHasStack()) {
/*     */       
/* 145 */       ItemStack itemstack1 = slot.getStack();
/* 146 */       itemstack = itemstack1.copy();
/*     */       
/* 148 */       if (par2 != 1 && par2 != 0) {
/*     */         
/* 150 */         AspectList al = ThaumcraftCraftingManager.getObjectTags(itemstack1);
/* 151 */         al = ThaumcraftCraftingManager.getBonusTags(itemstack1, al);
/*     */         
/* 153 */         if (TileAlchemyFurnace.isItemFuel(itemstack1))
/*     */         {
/* 155 */           if (!mergeItemStack(itemstack1, 1, 2, false))
/*     */           {
/*     */             
/* 158 */             if (!mergeItemStack(itemstack1, 0, 1, false))
/*     */             {
/* 160 */               return null;
/*     */             }
/*     */           }
/*     */         }
/* 164 */         else if (al != null && al.size() > 0)
/*     */         {
/* 166 */           if (!mergeItemStack(itemstack1, 0, 1, false))
/*     */           {
/* 168 */             return null;
/*     */           }
/*     */         }
/* 171 */         else if (par2 >= 2 && par2 < 29)
/*     */         {
/* 173 */           if (!mergeItemStack(itemstack1, 29, 38, false))
/*     */           {
/* 175 */             return null;
/*     */           }
/*     */         }
/* 178 */         else if (par2 >= 29 && par2 < 38 && !mergeItemStack(itemstack1, 2, 29, false))
/*     */         {
/* 180 */           return null;
/*     */         }
/*     */       
/* 183 */       } else if (!mergeItemStack(itemstack1, 2, 38, false)) {
/*     */         
/* 185 */         return null;
/*     */       } 
/*     */       
/* 188 */       if (itemstack1.stackSize == 0) {
/*     */         
/* 190 */         slot.putStack((ItemStack)null);
/*     */       }
/*     */       else {
/*     */         
/* 194 */         slot.onSlotChanged();
/*     */       } 
/*     */       
/* 197 */       if (itemstack1.stackSize == itemstack.stackSize)
/*     */       {
/* 199 */         return null;
/*     */       }
/*     */       
/* 202 */       slot.onPickupFromSlot(par1EntityPlayer, itemstack1);
/*     */     } 
/*     */     
/* 205 */     return itemstack;
/*     */   }
/*     */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerAlchemyFurnace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */