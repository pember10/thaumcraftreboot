/*    */ package thaumcraft.common.container;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemPickaxe;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import thaumcraft.common.items.wands.foci.ItemFocusExcavation;
/*    */ import thaumcraft.common.tiles.TileArcaneBore;
/*    */ 
/*    */ public class ContainerArcaneBore
/*    */   extends Container
/*    */ {
/*    */   private TileArcaneBore tileEntity;
/*    */   
/*    */   public ContainerArcaneBore(InventoryPlayer iinventory, TileArcaneBore e) {
/* 19 */     this.tileEntity = e;
/* 20 */     addSlotToContainer(new SlotLimitedByClass(ItemFocusExcavation.class, (IInventory)e, 0, 26, 18));
/* 21 */     addSlotToContainer(new SlotLimitedByClass(ItemPickaxe.class, (IInventory)e, 1, 74, 18));
/* 22 */     bindPlayerInventory(iinventory);
/*    */   }
/*    */   protected void bindPlayerInventory(InventoryPlayer inventoryPlayer) {
/*    */     int i;
/* 26 */     for (i = 0; i < 3; i++) {
/* 27 */       for (int j = 0; j < 9; j++) {
/* 28 */         addSlotToContainer(new Slot((IInventory)inventoryPlayer, j + i * 9 + 9, 8 + j * 18, 59 + i * 18));
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 33 */     for (i = 0; i < 9; i++) {
/* 34 */       addSlotToContainer(new Slot((IInventory)inventoryPlayer, i, 8 + i * 18, 117));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer par1EntityPlayer) {
/* 41 */     return (this.tileEntity.getWorldObj().getTileEntity(this.tileEntity.xCoord, this.tileEntity.yCoord, this.tileEntity.zCoord) != this.tileEntity) ? false : ((par1EntityPlayer.getDistanceSq(this.tileEntity.xCoord + 0.5D, this.tileEntity.yCoord + 0.5D, this.tileEntity.zCoord + 0.5D) <= 64.0D));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int slot) {
/* 49 */     ItemStack stack = null;
/* 50 */     Slot slotObject = this.inventorySlots.get(slot);
/*    */ 
/*    */     
/* 53 */     if (slotObject != null && slotObject.getHasStack()) {
/* 54 */       ItemStack stackInSlot = slotObject.getStack();
/* 55 */       stack = stackInSlot.copy();
/*    */ 
/*    */       
/* 58 */       if (slot <= 1) {
/* 59 */         if (!mergeItemStack(stackInSlot, 2, this.inventorySlots.size(), true)) {
/* 60 */           return null;
/*    */         }
/*    */       }
/* 63 */       else if (slot > 1) {
/* 64 */         if (stackInSlot.getItem() instanceof ItemFocusExcavation) {
/* 65 */           if (!mergeItemStack(stackInSlot, 0, 1, false)) {
/* 66 */             return null;
/*    */           
/*    */           }
/*    */         }
/* 70 */         else if (stackInSlot.getItem() instanceof ItemPickaxe && 
/* 71 */           !mergeItemStack(stackInSlot, 1, 2, false)) {
/* 72 */           return null;
/*    */ 
/*    */ 
/*    */         
/*    */         }
/*    */ 
/*    */ 
/*    */       
/*    */       }
/* 81 */       else if (!mergeItemStack(stackInSlot, 2, 38, false)) {
/*    */         
/* 83 */         return null;
/*    */       } 
/*    */       
/* 86 */       if (stackInSlot.stackSize == 0) {
/* 87 */         slotObject.putStack(null);
/*    */       } else {
/* 89 */         slotObject.onSlotChanged();
/*    */       } 
/*    */       
/* 92 */       if (stackInSlot.stackSize == stack.stackSize)
/*    */       {
/* 94 */         return null;
/*    */       }
/*    */     } 
/*    */     
/* 98 */     return stack;
/*    */   }
/*    */ }


/* Location:              X:\Git\Minecraft\Thaumcraft4\Thaumcraft-deobf-1.7.10-4.2.3.5_TEST.jar!\thaumcraft\common\container\ContainerArcaneBore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */